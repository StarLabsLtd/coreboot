/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link/build/first-entry-link-matrix/selected/native/dxe-policy-native_policy.o: \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/native_policy.c \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/authvar_native_x86.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/authvar_transport.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/payload_mm_authvar_service.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/coreboot_tables.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/uefi.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/boot_private_buffer.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/dma_handoff.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/image_policy_snapshot.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/guid/cbmem_table_hob.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/guid/memory_allocation_hob.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/pi/hob.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/pi/boot_mode.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot_checksum.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot_hobs.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/native_policy.h \
 /home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/direct_image_table.h
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/authvar_native_x86.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/authvar_transport.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/payload_mm_authvar_service.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/coreboot_tables.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/uefi.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/boot_private_buffer.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/dma_handoff.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/image_policy_snapshot.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/guid/cbmem_table_hob.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/guid/memory_allocation_hob.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/pi/hob.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/pi/boot_mode.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot_checksum.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot_hobs.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/../../boot/coreboot.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//src/modules/dxe_core/native_policy.h:
/home/sean/Documents/.cdk2-worktrees/native-first-entry-selected-link//include/cdk2/direct_image_table.h:
