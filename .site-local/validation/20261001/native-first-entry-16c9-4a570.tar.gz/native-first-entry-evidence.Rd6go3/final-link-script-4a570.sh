#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

# This is a link/configuration gate, not first-entry origin or activation proof.
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$root/tests/scratch_make_environment.sh"
cdk2_clear_scratch_make_environment
unset CDK2_BUILD_DIR CDK2_CONFIG_LOCK_FD COREBOOT_CONFIG COREBOOT_OUTPUT_DIR
unset COREBOOT_CDK2_PROFILE
source_config=$(realpath "${1:?actual coreboot source configuration required}")
output=$(realpath -m "${2:?isolated output directory required}")
bearssl=$(realpath "${3:?pinned BearSSL source directory required}")
test -f "$source_config"
test -f "$bearssl/inc/bearssl.h"
grep -qx 'CONFIG_PAYLOAD_MM_AUTHVAR_SERVICE_ROUTE_ATTESTED=y' "$source_config"
mkdir -p "$output"
sed '/^CONFIG_CDK2_NATIVE_FIRST_ENTRY_POLICY_COPY=y$/d' \
	"$root/tests/native_first_entry_policy.config" > "$output/default.config"
sed 's/^CONFIG_PAYLOAD_MM_AUTHVAR_SERVICE_ROUTE_ATTESTED=y$/# CONFIG_PAYLOAD_MM_AUTHVAR_SERVICE_ROUTE_ATTESTED is not set/' \
	"$source_config" > "$output/route-off.config"

run_make()
{
	MAKEFLAGS= MFLAGS= MAKEOVERRIDES= ${MAKE:-make} --no-print-directory \
		-f "$root/Makefile" CDK2_BUILD_DIR="$build" \
		CDK2_DEFCONFIG="$profile" COREBOOT_CONFIG="$configuration" \
		CDK2_BEARSSL_DIR="$bearssl" "$@"
}

for selection in selected default; do
	build="$output/$selection"
	configuration="$source_config"
	profile="$root/tests/native_first_entry_policy.config"
	if test "$selection" = default; then
		profile="$output/default.config"
	fi
	run_make defconfig > "$output/$selection-config.log" 2>&1
	run_make config >> "$output/$selection-config.log" 2>&1
	run_make -j2 CDK2_CONFIG_READY=1 "$build/native/DxeCore.efi" \
		"$build/native/cdk2-coreboot-stage.elf" \
		> "$output/$selection-link.log" 2>&1
	test -s "$build/native/DxeCore.efi"
	test -s "$build/native/cdk2-coreboot-stage.elf"
	if test "$selection" = selected; then
		grep -qx 'CONFIG_CDK2_NATIVE_FIRST_ENTRY_POLICY_COPY=y' "$build/.config"
		for symbol in copy close; do
			test "$(grep -c "[[:space:]]cdk2_dxe_native_policy_$symbol$" \
				"$build/native/DxeCore.map")" = 1
		done
		grep -q 'cdk2_coreboot_reserve_boot_private_buffer$' \
			"$build/native/cdk2-coreboot-stage.map"
		object="$build/native/dxe-policy-native_policy.o"
		# Use the exact compiler/Make spelling; CDK2_DIR retains a trailing slash.
		header=$(awk '{ for (i = 1; i <= NF; ++i)
			if ($i ~ /\/native_policy\.h$/) { print $i; exit } }' "${object%.o}.d")
		test -f "$header"
		# The cmp-preserving command stamp intentionally has a FORCE input.
		# Ignore only that already-evaluated stamp for this header graph probe.
		run_make -q -o "$build/native/command-inputs" CDK2_CONFIG_READY=1 "$object"
		set +e
		run_make -q -o "$build/native/command-inputs" CDK2_CONFIG_READY=1 \
			-W "$header" "$object"
		status=$?
		set -e
		test "$status" = 1
	else
		! grep -qx 'CONFIG_CDK2_NATIVE_FIRST_ENTRY_POLICY_COPY=y' "$build/.config"
		! grep -q 'cdk2_dxe_native_policy_' "$build/native/DxeCore.map"
		! test -e "$build/native/dxe-policy-native_policy.o"
	fi
done

# A source-selection parser negative, not an alternative authority configuration.
build="$output/route-off"
profile="$root/tests/native_first_entry_policy.config"
configuration="$output/route-off.config"
run_make defconfig > "$output/route-off-config.log" 2>&1
run_make config >> "$output/route-off-config.log" 2>&1
! grep -qx 'CONFIG_CDK2_NATIVE_FIRST_ENTRY_POLICY_COPY=y' "$build/.config"
sha256sum "$source_config" "$output"/*/.config \
	"$output/selected/native/DxeCore.efi" "$output/default/native/DxeCore.efi" \
	"$output/selected/native/cdk2-coreboot-stage.elf" \
	"$output/default/native/cdk2-coreboot-stage.elf"
printf '%s\n' 'Native first-entry selected/default source links: PASS'
