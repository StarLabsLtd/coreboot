# Experimental native first-entry copy receipts

This is an unactivated WIP, not usable image-verifier or platform-origin proof.
All actual initialized-entry success-copy cases deliberately close/scrub and
return EFI_UNSUPPORTED before configuration tables or driver dispatch. No
SecureBoot mode is locally overridden. Mutation invalidation, native origin,
resumed-CPU protection and usable verifier lifetime remain open.

The twelve source paths in source-16c9.tar are from signed remote WIP
16c9f7d058d0bf171c981bf4dbe29633f6886e34, based on exact GUI parent
d51df85330bdd6e4ebf1b862661ceb9a5b9afcd1. Its original worktree remains unchanged.
Initialized-entry author 11961, Adapter 85775 and root 42465 each exited zero:
six cases at O0/O2 ASan/UBSan plus exact removed-refusal mutation. Actual DXE
initialization, public Load/Start callbacks, owned table/driver observations,
transport, importer and slot owner execute; MODULE/prefix/trigger/MMIO remain
fixture models. The component config header is SHA256
78b97c2da99c1bb7c24d7e55674390110c044d216d07158146cd1df98c012edc;
that component override is not Kconfig-selected platform admission.

Root's initialized-entry and genuine-join receipts use the actual coreboot
held-op9 producer d159942f5e77425c84e81a75988ee3741ea23653 and cached pinned
MbedTLS 0bebf8b8c7f07abe3571ded48a11aa907a1ffb20. These are distinct
from the immutable held-SMM source configuration used by the selected link
gate below. Author/Adapter receipt logs are preserved without inventing a
claim that all readers used the same producer checkout identity.

selected-source-e8ea.tar is signed remote WIP
e8eabff0efa2107ef343d236e27b31ae3773ca67 on
agent/native-first-entry-selected-link-wip, a temporary child of
protected-variable candidate 526b2b3509425b91b35bfda47641aba18d4634a2.
Its mechanisms are source-equivalent to 16c9; two added files exercise real
Kconfig-selected native DxeCore and prefix links. This is not the final linear
parent or a READY publication.

The real imported coreboot source configuration has SHA256
0b5be5aa9b706d8f29e73b3815522022bf3378100d347578ebc5f51497ef8a33.
It is the immutable coreboot 348 held-op9 SMM-only configuration, not a whole
ROM/loaded native payload origin receipt. Both selected and default-OFF native
links passed; default-OFF excludes policy objects, and a source-route OFF
parser negative refuses Kconfig selection. Author matrix 3830 and independent
root matrix 36796 exited zero, with identical selected/default PE and prefix
hashes. Existing selected native-coreboot-stage admission 84299 also exited
zero (real MTRR ownership/coreboot fixture prerequisite). Both source patches
are included, against the exact main and selected parents listed above.
Actual private-header Make readiness uses the exact compiler dependency path
and ignores only the already-evaluated cmp-preserving command-inputs stamp.

The first matrix log failed at the FORCE-stamp probe; subsequent probe logs
failed because a canonicalized header path did not match Make's exact
double-slash dependency spelling. These are retained as failed diagnostic
receipts, not failed compiler links or passing tests. The exact-author log is
the completed matrix. Link maps bind copy/close and transport once within
DxeCore; variable-runtime transport objects reside in a separate PE image.

The later final-link-script-4a570.sh and source-only patch retain Adapter's
bounded robustness correction: scan every dependency field rather than only
the first, keeping the compiler's exact header spelling. Production/source
records and e8 source archive are unchanged. Author cached actual matrix 67706
exited zero after that correction; the independent root matrix above used
the exact e8 script and is not relabeled as a later source execution.

No hardware, whole-ROM, policy-handler registration or selected boot success
is claimed. No generated receipt normalizes artifact identity.
