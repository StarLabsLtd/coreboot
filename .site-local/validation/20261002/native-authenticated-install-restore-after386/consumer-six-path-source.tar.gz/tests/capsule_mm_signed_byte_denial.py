# SPDX-License-Identifier: GPL-2.0-only
"""Bind the native one-byte corruption to a valid envelope and invalid CMS."""

import pathlib
import sys


def main():
    tools, capsule, authenticated, target, public_certificate, version = sys.argv[1:]
    sys.path.insert(0, tools)
    from validate_capsule import ValidationError, parse_capsule_details, verify_signature

    original = pathlib.Path(capsule).read_bytes()
    details = parse_capsule_details(original)
    attempted_version = int(version, 16 if version.startswith("0x") else 10)
    if details["fw_version"] != attempted_version:
        raise ValidationError("native attempted version differs from signed capsule version")
    if details["authenticated"] != pathlib.Path(authenticated).read_bytes():
        raise ValidationError("native authenticated bytes differ from signed capsule")
    if details["image"] != pathlib.Path(target).read_bytes():
        raise ValidationError("native target differs from signed complete image")
    verify_signature(details, public_certificate)

    changed = original[:-1] + bytes([original[-1] ^ 1])
    wrong = parse_capsule_details(changed)
    for key in details:
        if key not in ("authenticated", "payload", "image") and wrong[key] != details[key]:
            raise ValidationError("signed-byte mutation changed capsule framing")
    for key in ("authenticated", "payload", "image"):
        expected = details[key][:-1] + bytes([details[key][-1] ^ 1])
        if wrong[key] != expected:
            raise ValidationError("signed-byte mutation differs from native corruption")
    try:
        verify_signature(wrong, public_certificate)
    except ValidationError as error:
        if str(error) != "capsule PKCS#7 verification failed":
            raise
    else:
        raise ValidationError("corrupted signed ROM byte unexpectedly verifies")
    print("Actual capsule tools: framing unchanged, valid CMS before / invalid CMS after: PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
