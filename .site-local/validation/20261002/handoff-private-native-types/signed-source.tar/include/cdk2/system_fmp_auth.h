/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_AUTH_H
#define CDK2_SYSTEM_FMP_AUTH_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

#define CDK2_FMP_AUTH_MONOTONIC_SIZE 8U
#define CDK2_FMP_AUTH_CERT_HEADER_SIZE 24U

struct cdk2_system_fmp_auth_view {
	uint64_t monotonic_count;
	const uint8_t *payload;
	size_t payload_size;
};

struct cdk2_system_fmp_signed_span {
	const uint8_t *data;
	size_t size;
};

/*
 * Native crypto backends verify one detached PKCS7 signature against one DER
 * trust certificate.  The signed bytes are ordered payload, monotonic count,
 * matching EDK2 26.09 FmpAuthenticationLibPkcs7 exactly.
 */
typedef bool cdk2_system_fmp_pkcs7_verify_fn(void *context,
	const uint8_t *signature, size_t signature_size,
	const uint8_t *certificate, size_t certificate_size,
	const struct cdk2_system_fmp_signed_span signed_data[2]);

EFI_STATUS cdk2_system_fmp_authenticate(const void *image, size_t image_size,
	const void *certificate_xdr, size_t certificate_xdr_size,
	cdk2_system_fmp_pkcs7_verify_fn *verify, void *context,
	struct cdk2_system_fmp_auth_view *view);

#endif
