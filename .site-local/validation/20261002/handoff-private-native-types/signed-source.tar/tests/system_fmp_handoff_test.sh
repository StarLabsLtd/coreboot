#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM

build_and_run() {
	name=$1
	shift
	cc -std=gnu11 -Wall -Wextra -Werror \
		-ffunction-sections -fdata-sections -I"$root/include" \
		-I"$root/src/boot" "$@" \
		"$root/tests/system_fmp_handoff_test.c" \
		"$root/src/modules/system_fmp/handoff.c" \
		-Wl,--gc-sections -o "$temporary/$name"
	"$temporary/$name"
}

build_and_run ordinary
build_and_run optimized -O2
build_and_run sanitized -O1 -g -fsanitize=address,undefined \
	-fno-omit-frame-pointer

printf '%s\n' 'SystemFmp coreboot contract ordinary/O2/ASan+UBSan tests: PASS'
