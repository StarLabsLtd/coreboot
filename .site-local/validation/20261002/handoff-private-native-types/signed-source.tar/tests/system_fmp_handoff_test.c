/* SPDX-License-Identifier: GPL-2.0-only */
#include "../src/boot/coreboot.h"

#include <cdk2/system_fmp_handoff.h>
#include <assert.h>
#include <string.h>

#define IMAGE_SIZE 0x01000000U

static struct lb_efi_fw_info firmware;
static struct {
	struct cb_capsule_handoff header;
	struct cb_capsule_update_region regions[2];
} update;
static EFI_STATUS firmware_status;
static EFI_STATUS update_status;

EFI_STATUS cdk2_coreboot_find_unique_record(
	const struct cdk2_coreboot_handoff *coreboot, UINT32 tag,
	UINT32 minimum_size, const void **record)
{
	(void)coreboot;
	if (record == NULL)
		return EFI_INVALID_PARAMETER;
	if (tag == CB_TAG_FW_INFO) {
		if (EFI_ERROR(firmware_status))
			return firmware_status;
		if (firmware.size < minimum_size)
			return EFI_COMPROMISED_DATA;
		*record = &firmware;
		return EFI_SUCCESS;
	}
	assert(tag == CB_TAG_CAPSULE_HANDOFF);
	if (EFI_ERROR(update_status))
		return update_status;
	if (update.header.size < minimum_size)
		return EFI_COMPROMISED_DATA;
	*record = &update.header;
	return EFI_SUCCESS;
}

static struct cbuint64 packed(UINT64 value)
{
	return (struct cbuint64){ (UINT32)value, (UINT32)(value >> 32) };
}

static void reset_fixture(void)
{
	static const UINT8 image_type[16] = {
		0xe6, 0xd0, 0x5c, 0x97, 0x40, 0xc5, 0x2b, 0x4e,
		0x90, 0x6c, 0x72, 0xc0, 0xd0, 0xd1, 0xe4, 0x0d,
	};
	firmware_status = EFI_SUCCESS;
	update_status = EFI_SUCCESS;
	firmware = (struct lb_efi_fw_info){
		.tag = CB_TAG_FW_INFO,
		.size = sizeof(firmware),
		.version = 10U,
		.lowest_supported_version = 8U,
		.fw_size = IMAGE_SIZE,
	};
	memcpy(firmware.guid, image_type, sizeof(image_type));
	memset(&update, 0, sizeof(update));
	update.header = (struct cb_capsule_handoff){
		.tag = CB_TAG_CAPSULE_HANDOFF,
		.size = sizeof(update.header) + sizeof(update.regions[0]),
		.revision = CB_CAPSULE_HANDOFF_REVISION,
		.header_size = sizeof(update.header),
		.flags = CB_CAPSULE_HANDOFF_REQUIRED_FLAGS,
		.broker_type = CB_CAPSULE_BROKER_COREBOOT_UPDATE,
		.capsule_format = CB_CAPSULE_FORMAT_FMP_V3,
		.authentication_format = CB_CAPSULE_AUTH_EFI_PKCS7,
		.board_binding_format =
			CB_CAPSULE_BOARD_BINDING_CBFS_BUILD_INFO_V1,
		.payload_format = CB_CAPSULE_PAYLOAD_MSS1_V1,
		.broker_capabilities = CB_CAPSULE_BROKER_REQUIRED_CAPABILITIES,
		.version = firmware.version,
		.lowest_supported_version = firmware.lowest_supported_version,
		.capsule_flags = CB_CAPSULE_FLAGS_PERSIST_RESET,
		.block_size = 0x1000U,
		.erase_size = 0x1000U,
		.region_count = 1U,
		.image_size = packed(IMAGE_SIZE),
		.boot_media_size = packed(IMAGE_SIZE),
		.smmstore_offset = packed(0x00f00000U),
		.smmstore_size = packed(0x00010000U),
	};
	memcpy(update.header.image_type_guid, image_type, sizeof(image_type));
	update.regions[0] = (struct cb_capsule_update_region){
		.image_offset = packed(0x00800000U),
		.flash_offset = packed(0x00800000U),
		.size = packed(0x00700000U),
		.flags = CB_CAPSULE_REGION_BIOS,
	};
}

static EFI_STATUS consume(struct cdk2_system_fmp_handoff *handoff)
{
	struct cdk2_coreboot_handoff coreboot = {0};

	memset(handoff, 0xa5, sizeof(*handoff));
	return cdk2_system_fmp_handoff_from_coreboot(&coreboot, handoff);
}

static void success(void)
{
	struct cdk2_system_fmp_handoff handoff;

	reset_fixture();
	assert(consume(&handoff) == EFI_SUCCESS);
	assert(handoff.version == 10U && handoff.lowest_supported_version == 8U);
	assert(handoff.image_size == IMAGE_SIZE &&
		handoff.boot_media_size == IMAGE_SIZE);
	assert(handoff.region_count == 1U &&
		handoff.regions[0].flags == CB_CAPSULE_REGION_BIOS);
	assert(handoff.regions[0].flash_offset == 0x00800000U &&
		handoff.regions[0].size == 0x00700000U);
	assert(memcmp(&handoff.image_type, firmware.guid, 16U) == 0);
}

static void missing_and_identity_rejections(void)
{
	struct cdk2_system_fmp_handoff handoff;

	reset_fixture();
	assert(cdk2_system_fmp_handoff_from_coreboot(NULL, &handoff) ==
		EFI_INVALID_PARAMETER);
	assert(cdk2_system_fmp_handoff_from_coreboot(
		&(struct cdk2_coreboot_handoff){0}, NULL) == EFI_INVALID_PARAMETER);
	firmware_status = EFI_NOT_FOUND;
	assert(consume(&handoff) == EFI_NOT_FOUND && handoff.region_count == 0U);
	reset_fixture();
	firmware_status = EFI_COMPROMISED_DATA;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA &&
		handoff.region_count == 0U);
	reset_fixture();
	update_status = EFI_COMPROMISED_DATA;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA &&
		handoff.region_count == 0U);
	reset_fixture();
	firmware.guid[0] ^= 1U;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.version++;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.lowest_supported_version = update.header.version + 1U;
	firmware.lowest_supported_version = update.header.lowest_supported_version;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.image_size = packed(IMAGE_SIZE - 1U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
}

static void header_rejections(void)
{
	struct cdk2_system_fmp_handoff handoff;

#define REJECT(member, value) do { \
	reset_fixture(); \
	update.header.member = (value); \
	assert(consume(&handoff) == EFI_COMPROMISED_DATA); \
} while (0)
	REJECT(size, sizeof(update.header));
	REJECT(revision, 1U);
	REJECT(header_size, sizeof(update.header) - 4U);
	REJECT(flags, update.header.flags | (1U << 31));
	REJECT(broker_type, 0U);
	REJECT(capsule_format, 2U);
	REJECT(authentication_format, 0U);
	REJECT(board_binding_format, 0U);
	REJECT(payload_format, 2U);
	REJECT(capsule_flags, 0U);
	REJECT(broker_capabilities, CB_CAPSULE_BROKER_APPLY_REGIONS);
	REJECT(reserved16, 1U);
	REJECT(region_count, 0U);
	REJECT(region_count, CDK2_SYSTEM_FMP_MAX_REGIONS + 1U);
	REJECT(block_size, 0U);
	REJECT(erase_size, 0U);
#undef REJECT
	reset_fixture();
	update.header.size += sizeof(update.regions[1]);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.reserved32[1] = 1U;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.reserved32[0] = 1U;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.erase_size = 0x1800U;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
}

static void region_rejections(void)
{
	struct cdk2_system_fmp_handoff handoff;

	reset_fixture();
	update.regions[0].size = packed(0U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].flash_offset = packed(IMAGE_SIZE - 0x1000U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].image_offset = packed(IMAGE_SIZE - 0x1000U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].flash_offset = packed(0x00800001U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].image_offset = packed(0x00800001U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].size = packed(0x006ff001U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].reserved = 1U;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].flags = 1U << 31;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].flags = 0U;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.regions[0].flash_offset = packed(0x00ef0000U);
	update.regions[0].size = packed(0x00020000U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.region_count = 2U;
	update.header.size += sizeof(update.regions[1]);
	update.regions[0].size = packed(0x00100000U);
	update.regions[1] = (struct cb_capsule_update_region){
		.image_offset = packed(0x00880000U),
		.flash_offset = packed(0x00a00000U),
		.size = packed(0x00100000U),
	};
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.region_count = 2U;
	update.header.size += sizeof(update.regions[1]);
	update.regions[0].size = packed(0x00100000U);
	update.regions[1] = (struct cb_capsule_update_region){
		.image_offset = packed(0x00a00000U),
		.flash_offset = packed(0x00880000U),
		.size = packed(0x00100000U),
	};
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.region_count = 2U;
	update.header.size += sizeof(update.regions[1]);
	update.regions[0].size = packed(0x00100000U);
	update.regions[1] = (struct cb_capsule_update_region){
		.image_offset = packed(0x00a00000U),
		.flash_offset = packed(0x00a00000U),
		.size = packed(0x00100000U),
		.flags = CB_CAPSULE_REGION_BIOS,
	};
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.region_count = 2U;
	update.header.size += sizeof(update.regions[1]);
	update.regions[0].size = packed(0x00100000U);
	update.regions[1] = (struct cb_capsule_update_region){
		.image_offset = packed(0x00a00000U),
		.flash_offset = packed(0x00a00000U),
		.size = packed(0x00100000U),
	};
	assert(consume(&handoff) == EFI_SUCCESS);
	assert(handoff.region_count == 2U &&
		handoff.regions[1].flash_offset == 0x00a00000U);
	reset_fixture();
	update.header.region_count = 2U;
	update.header.size += sizeof(update.regions[1]);
	update.regions[1] = update.regions[0];
	update.regions[1].flags = 0U;
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.smmstore_offset = packed(UINT64_MAX - 0x100U);
	update.header.smmstore_size = packed(0x200U);
	update.header.boot_media_size = packed(UINT64_MAX);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.smmstore_size = packed(0U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
	reset_fixture();
	update.header.smmstore_offset = packed(IMAGE_SIZE - 0x1000U);
	update.header.smmstore_size = packed(0x2000U);
	assert(consume(&handoff) == EFI_COMPROMISED_DATA);
}

int main(void)
{
	success();
	missing_and_identity_rejections();
	header_rejections();
	region_rejections();
	return 0;
}
