#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-only
"""HOST parser/observer tests with modeled bytes, not native CBMEM evidence."""

import importlib.util
import copy
import hashlib
import json
import struct
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "qmp_cbmem_console", root / "util/qemu/bin/qmp_cbmem_console.py")
observer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observer)
sys.modules["qmp_cbmem_console"] = observer
contract_spec = importlib.util.spec_from_file_location(
    "setup_acceptance_contract", root / "util/qemu/bin/setup_acceptance_contract.py")
contract = importlib.util.module_from_spec(contract_spec)
contract_spec.loader.exec_module(contract)


def record(tag, body):
    return struct.pack("<II", tag, 8 + len(body)) + body


def table(records):
    body = b"".join(records)
    header = bytearray(struct.pack("<4sIIIII", b"LBIO", 24, 0, len(body),
                                   observer.checksum(body), len(records)))
    struct.pack_into("<I", header, 8, observer.checksum(header))
    return bytes(header) + body


def logo_fixture(bmp_mode):
    """HOST modeled source/retained bytes, not a producer or display proof."""
    config = b"CONFIG_USE_COREBOOT_FOR_BMP_RENDERING=y\n" if bmp_mode else b"# no BMP\n"
    width, height = (234, 234) if bmp_mode else (486, 63)
    x, y = (800 - width) // 2, (600 - height) // 2
    bmp = None
    if bmp_mode:
        row = (width * 3 + 3) & ~3
        bmp = bytearray(54 + row * height)
        bmp[:2] = b"BM"
        struct.pack_into("<I", bmp, 2, len(bmp))
        struct.pack_into("<IIIIHH", bmp, 10, 54, 40, width, height, 1, 24)
        bmp = bytes(bmp)
    manifest = {
        "geometry": {"mode": "coreboot-bmp" if bmp_mode else "cdk2-fallback",
                     "logo": [x, y, width, height], "status": [x, y + height + 8, width, 48]},
        "producer_config_sha256": hashlib.sha256(config).hexdigest(),
        "boot_logo_source_sha256": "a" * 64,
        "logo_bmp_sha256": hashlib.sha256(bmp).hexdigest() if bmp else "",
    }
    framebuffer = record(0x12, struct.pack("<QIII", 0xfd000000, 800, 600, 3200) +
                         bytes((32, 16, 8, 8, 8, 0, 8, 24, 8, 0, 0, 0)))
    records = [(0x12, framebuffer)]
    if bmp:
        splash = record(0x51, struct.pack("<HHQIIIIQI", 2, 3, 0xfd000000,
                        x, y, width, height, 0x304000, len(bmp)))
        allocation = record(0x31, struct.pack("<QII", 0x304000,
                            (len(bmp) + 4095) & ~4095, 0x42534c48))
        memory = record(1, struct.pack("<QQI", 0x300000, 0x100000, 16))
        records += [(0x51, splash), (0x31, allocation), (1, memory)]
    return manifest, config, bmp, records


class LogoGeometryTest(unittest.TestCase):
    def test_both_source_modes(self):
        for bmp_mode, expected in ((False, [157, 339, 486, 48]), (True, [283, 425, 234, 48])):
            manifest, config, bmp, records = logo_fixture(bmp_mode)
            self.assertEqual(contract.reference_status_geometry(manifest, config, bmp, records), expected)
            extent = contract.splash_bmp_extent(records, manifest, 16 * 1024 * 1024)
            self.assertEqual(extent, (0x304000, len(bmp)) if bmp else None)

    def test_geometry_and_source_binding(self):
        manifest, config, bmp, records = logo_fixture(True)
        for field, value in (("mode", "unknown"), ("logo", [283, 183, 235, 234]),
                             ("status", [283, 425, 800, 48]), ("status", [True, 425, 234, 48])):
            changed = copy.deepcopy(manifest)
            changed["geometry"][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                contract.reference_status_geometry(changed, config, bmp, records)
        for field in ("logo_bmp_sha256", "producer_config_sha256", "boot_logo_source_sha256"):
            changed = copy.deepcopy(manifest)
            changed[field] = "wrong"
            with self.subTest(field=field), self.assertRaises(ValueError):
                contract.reference_status_geometry(changed, config, bmp, records)
        for offset in (0, 2, 10, 14, 18, 22, 26, 28, 30):
            changed_bmp = bytearray(bmp)
            changed_bmp[offset] ^= 1
            changed = copy.deepcopy(manifest)
            changed["logo_bmp_sha256"] = hashlib.sha256(changed_bmp).hexdigest()
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                contract.reference_status_geometry(changed, config, bytes(changed_bmp), records)
        fallback, source, _, fallback_records = logo_fixture(False)
        with self.assertRaises(ValueError):
            contract.reference_status_geometry(fallback, source, bmp, fallback_records)
        with self.assertRaises(ValueError):
            contract.splash_bmp_extent(fallback_records + [records[1]], fallback, 16 * 1024 * 1024)

    def test_real_handoff_extent_contract(self):
        manifest, _, _, records = logo_fixture(True)
        for index, offsets in ((0, (16, 20, 28, 37)), (1, (8, 10, 12, 20, 36)),
                               (2, (8, 20)), (3, (24,))):
            for offset in offsets:
                changed = list(records)
                raw = bytearray(changed[index][1])
                raw[offset] ^= 1
                changed[index] = (changed[index][0], bytes(raw))
                with self.subTest(index=index, offset=offset), self.assertRaises(ValueError):
                    contract.splash_bmp_extent(changed, manifest, 16 * 1024 * 1024)
        for index in (0, 1, 2):
            with self.subTest(duplicate=index), self.assertRaises(ValueError):
                contract.splash_bmp_extent(records + [records[index]], manifest, 16 * 1024 * 1024)
        with self.assertRaises(ValueError):
            contract.splash_bmp_extent(records, manifest, 0x304100)
        for index, offset, value in ((2, 16, 1), (3, 8, 0x400000), (3, 16, 1)):
            changed = list(records)
            raw = bytearray(changed[index][1])
            struct.pack_into("<I", raw, offset, value)
            changed[index] = (changed[index][0], bytes(raw))
            with self.subTest(index=index, offset=offset), self.assertRaises(ValueError):
                contract.splash_bmp_extent(changed, manifest, 16 * 1024 * 1024)

    def test_retained_saved_input_binding(self):
        for bmp_mode in (False, True):
            fixture = ConsoleTest()
            fixture.setUp()
            manifest, config, bmp, records = logo_fixture(bmp_mode)
            fixture.memory_record = record(1, struct.pack("<QQI", 0x300000, 0x100000, 16))
            leaf = [fixture.memory_record, fixture.console_record] + \
                [raw for tag, raw in records if tag != 1]
            fixture.install(0x300000, table(leaf))
            if bmp:
                fixture.install(0x304000, bmp)
            with tempfile.TemporaryDirectory(prefix="qmp-logo-host-test.") as directory:
                run = Path(directory)
                reader = observer.ConsoleReader(fixture.qmp, run / "scratch")
                (run / "cbmem-live.log").write_bytes(reader.snapshot())
                (run / "cbmem-console.bin").write_bytes(reader.last_snapshot)
                (run / "cbmem-observer.json").write_text(json.dumps(reader.metadata))
                for index, raw in enumerate(reader.table_snapshots):
                    (run / f"cbmem-table-{index}.bin").write_bytes(raw)
                (run / "coreboot-config.txt").write_bytes(config)
                if bmp:
                    (run / "logo.bmp").write_bytes(bmp)
                    (run / "cbmem-splash-bmp.bin").write_bytes(reader.read(0x304000, len(bmp)))
                self.assertEqual(contract.saved_status_geometry(run, manifest),
                                 manifest["geometry"]["status"])
                if bmp:
                    changed = bytearray(bmp)
                    changed[-1] ^= 1
                    (run / "cbmem-splash-bmp.bin").write_bytes(changed)
                    with self.assertRaises(ValueError):
                        contract.saved_status_geometry(run, manifest)
                    (run / "cbmem-splash-bmp.bin").write_bytes(bmp)
                    (run / "logo.bmp").unlink()
                    (run / "logo.bmp").symlink_to(run / "cbmem-splash-bmp.bin")
                    with self.assertRaises(ValueError):
                        contract.saved_status_geometry(run, manifest)
                (run / "coreboot-config.txt").write_bytes(config + b"# changed\n")
                with self.assertRaises(ValueError):
                    contract.saved_status_geometry(run, manifest)


class ConsoleTest(unittest.TestCase):
    def setUp(self):
        self.memory = bytearray(16 * 1024 * 1024)
        self.console_address = 0x301000
        self.body = b"CDK2 | HOST modeled console\n"
        self.console = struct.pack("<II", 56, len(self.body)) + self.body.ljust(56, b"\0")
        self.console_record = record(0x31, struct.pack(
            "<QII", self.console_address, len(self.console), observer.CONSOLE_ID))
        self.memory_record = record(1, struct.pack("<QQI", 0x300000, 0x10000, 16))
        self.install(0x500, table([record(0x11, struct.pack("<Q", 0x300000))]))
        self.install(0x300000, table([self.memory_record, self.console_record]))
        self.install(self.console_address, self.console)
        self.commands = []

    def install(self, address, data):
        self.memory[address:address + len(data)] = data

    def qmp(self, command):
        self.commands.append(command["execute"])
        if command["execute"] == "query-memory-size-summary":
            return {"return": {"base-memory": len(self.memory), "plugged-memory": 0}}
        self.assertEqual(command["execute"], "pmemsave")
        arguments = command["arguments"]
        address, size = arguments["val"], arguments["size"]
        observer.checked_range(address, size, len(self.memory))
        Path(arguments["filename"]).write_bytes(self.memory[address:address + size])
        return {"return": {}}

    def read(self):
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-host-test.") as scratch:
            reader = observer.ConsoleReader(self.qmp, scratch)
            body = reader.snapshot()
            self.assertEqual(reader.metadata["console_address"], self.console_address)
            self.assertEqual(reader.metadata["cursor"], len(body))
            self.assertEqual(len(reader.metadata["tables"]), 2)
            self.assertTrue(set(self.commands) <= {"query-memory-size-summary", "pmemsave"})
            return body

    def test_actual_wire_checksums(self):
        self.assertEqual(observer.checksum(b""), 0xFFFF)
        self.assertEqual(observer.checksum(b"abc"), 0x9D3B)
        self.assertEqual(self.read(), self.body)

    def test_valid_table_drift_after_acceptance(self):
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-host-test.") as scratch:
            reads = []

            def watched_qmp(command):
                if command["execute"] == "pmemsave":
                    reads.append(command["arguments"]["val"])
                return self.qmp(command)

            reader = observer.ConsoleReader(watched_qmp, scratch)
            self.assertEqual(reader.snapshot(), self.body)
            accepted = copy.deepcopy(reader.metadata)
            snapshots = list(reader.table_snapshots)
            changed_address = self.console_address + 0x1000
            changed_console = record(0x31, struct.pack(
                "<QII", changed_address, len(self.console), observer.CONSOLE_ID))
            self.install(changed_address, self.console)
            changed_leaf = table([self.memory_record, changed_console])
            self.assertEqual(observer.parse_table(changed_leaf)[1][1], changed_console)
            self.install(0x300000, changed_leaf)
            with self.assertRaisesRegex(ValueError, "accepted LBIO table chain changed"):
                reader.snapshot()
            self.assertNotIn(changed_address, reads)
            self.assertEqual(reader.metadata, accepted)
            self.assertEqual(reader.table_snapshots, snapshots)

    def test_table_shape_and_checksums(self):
        valid = table([self.memory_record, self.console_record])
        for offset in (0, 8, 16, 24):
            bad = bytearray(valid)
            bad[offset] ^= 1
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                observer.parse_table(bad)
        with self.assertRaises(ValueError):
            observer.parse_table(valid[:-1])
        for bad in (record(0x31, b""), struct.pack("<II", 0x31, 0)):
            with self.assertRaises(ValueError):
                observer.console_extent(observer.parse_table(table([bad])), len(self.memory))

    def test_console_ownership_and_bounds(self):
        for records in ([self.memory_record],
                        [self.memory_record, self.console_record, self.console_record],
                        [record(1, struct.pack("<QQI", 0x300000, 0x10000, 1)),
                         self.console_record],
                        [self.memory_record, record(0x31, struct.pack(
                            "<QII", len(self.memory) - 4, 64, observer.CONSOLE_ID))],
                        [record(1, struct.pack("<QQI", (1 << 64) - 1, 2, 16)),
                         self.console_record]):
            with self.subTest(records=records), self.assertRaises(ValueError):
                observer.console_extent(observer.parse_table(table(records)), len(self.memory))

    def test_missing_ambiguous_and_cyclic_locators(self):
        self.memory[0x500:0x504] = b"\0" * 4
        with self.assertRaises(observer.TableNotReady):
            self.read()
        locator = table([record(0x11, struct.pack("<Q", 0x300000))])
        self.install(0x500, locator)
        self.install(0xF0000, locator)
        with self.assertRaises(ValueError):
            self.read()
        self.memory[0xF0000:0xF0004] = b"\0" * 4
        self.install(0x300000, table([record(0x11, struct.pack("<Q", 0x500))]))
        with self.assertRaises(ValueError):
            self.read()

    def test_forward_depth_duplicates_and_physical_range(self):
        for records in ([record(0x11, struct.pack("<Q", 0x300000))] * 2,
                        [record(0x11, struct.pack("<Q", len(self.memory)))],
                        [record(0x11, struct.pack("<Q", 0x300001))]):
            self.install(0x500, table(records))
            with self.assertRaises(ValueError):
                self.read()
        addresses = [0x500, 0x300000, 0x302000, 0x303000, 0x304000]
        for current, following in zip(addresses, addresses[1:]):
            self.install(current, table([record(0x11, struct.pack("<Q", following))]))
        with self.assertRaises(ValueError):
            self.read()

    def test_cursor_and_live_overflow(self):
        for size, cursor in ((55, 0), (56, 57), (56, 1 << 30),
                             (56, observer.OVERFLOW | 56)):
            with self.subTest(size=size, cursor=cursor), self.assertRaises(ValueError):
                observer.console_bytes(struct.pack("<II", size, cursor) + self.console[8:])
        ring = struct.pack("<II", 4, observer.OVERFLOW | 2) + b"cdab"
        self.assertEqual(observer.console_bytes(ring), b"abcd")
        self.install(self.console_address, struct.pack("<II", 56, observer.OVERFLOW | 2) +
                     self.console[8:])
        with self.assertRaises(ValueError):
            self.read()

    def test_moving_snapshot_and_qmp_failure(self):
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-host-test.") as scratch:
            reader = observer.ConsoleReader(self.qmp, scratch)
            original = reader.read

            def moving(address, size):
                data = original(address, size)
                if address == self.console_address and size == 8:
                    return struct.pack("<II", 56, len(self.body) + 1)
                return data

            reader.read = moving
            with self.assertRaises(observer.ConsoleSnapshotMotion):
                reader.snapshot()
            self.assertIsNone(reader.metadata)
            reader.qmp = lambda _command: {"error": {"desc": "modeled physical read failure"}}
            with self.assertRaises(ValueError):
                reader.read = original
                reader.read(0, 4096)

    def save_capture(self, directory):
        reader = observer.ConsoleReader(self.qmp, directory / "scratch")
        body = reader.snapshot()
        (directory / "cbmem-observer.json").write_text(json.dumps(reader.metadata))
        (directory / "cbmem-live.log").write_bytes(body)
        (directory / "cbmem-console.bin").write_bytes(reader.last_snapshot)
        for index, data in enumerate(reader.table_snapshots):
            (directory / f"cbmem-table-{index}.bin").write_bytes(data)
        return reader.metadata

    def test_saved_capture_identity_and_hostile_metadata(self):
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-saved-host-test.") as scratch:
            directory = Path(scratch)
            metadata = self.save_capture(directory)
            self.assertEqual(observer.validate_saved_console(directory), self.body)
            changes = (("source", "invented-producer"), ("physical_limit", True),
                       ("physical_limit", 1 << 33), ("tables", []),
                       ("publication_retries", observer.MAX_PUBLICATION_RETRIES + 1),
                       ("publication_retries", True),
                       ("console_address", self.console_address + 4),
                       ("console_bytes", len(self.console) + 1),
                       ("cursor", len(self.body) + 1), ("snapshot_sha256", "0" * 64))
            for key, value in changes:
                bad = dict(metadata, **{key: value})
                (directory / "cbmem-observer.json").write_text(json.dumps(bad))
                with self.subTest(key=key), self.assertRaises(ValueError):
                    observer.validate_saved_console(directory)
            (directory / "cbmem-observer.json").write_text(json.dumps(metadata))
            for name in ("cbmem-table-0.bin", "cbmem-table-1.bin",
                         "cbmem-console.bin", "cbmem-live.log"):
                path = directory / name
                original = path.read_bytes()
                bad = bytearray(original)
                bad[-1] ^= 1
                path.write_bytes(bad)
                with self.subTest(name=name), self.assertRaises(ValueError):
                    observer.validate_saved_console(directory)
                path.write_bytes(original)
            path = directory / "cbmem-console.bin"
            path.rename(directory / "actual-console.bin")
            path.symlink_to("actual-console.bin")
            with self.assertRaises(ValueError):
                observer.validate_saved_console(directory)

    def test_saved_forward_chain_and_locator(self):
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-saved-host-test.") as scratch:
            directory = Path(scratch)
            metadata = self.save_capture(directory)
            for index, address in ((0, 0x2000), (0, 0x501), (1, 0x302000), (1, 0x500)):
                bad = json.loads(json.dumps(metadata))
                bad["tables"][index]["address"] = address
                (directory / "cbmem-observer.json").write_text(json.dumps(bad))
                with self.subTest(index=index, address=address), self.assertRaises(ValueError):
                    observer.validate_saved_console(directory)

    def test_quiet_contract_preserves_debug_and_real_input(self):
        self.assertEqual(contract.expected_actions("hotkey"), contract.EXPECTED_ACTIONS)
        self.assertEqual(contract.expected_actions("boot-to-fw-ui"),
                         contract.BOOT_TO_FW_UI_ACTIONS)
        for mode in ("hotkey", "boot-to-fw-ui"):
            actions = contract.expected_actions(mode, "quiet")
            self.assertTrue(any("wait_cbmem" in action for action in actions))
            self.assertFalse(any(action.get("wait_serial", "").startswith("Setup")
                                 for action in actions))
            self.assertEqual([action for action in actions if "vnc_key" in action],
                             [action for action in contract.expected_actions(mode)
                              if "vnc_key" in action])
            self.assertEqual([action for action in actions if "capture" in action],
                             [action for action in contract.expected_actions(mode)
                              if "capture" in action])
            self.assertEqual(actions[-1], {"wait_serial": "CDK2_RUNTIME_OK"
                             if mode == "hotkey" else "CDK2_LINUX_OK"})
        with self.assertRaises(ValueError):
            contract.expected_actions("hotkey", "fabricated")

    def test_initial_publication_retry_is_bounded_and_not_late(self):
        valid = table([self.memory_record, self.console_record])
        unfinished = bytearray(valid)
        unfinished[16] ^= 1
        self.install(0x300000, unfinished)
        now = [0.0]
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-publication-host-test.") as scratch, \
                patch.object(observer.time, "monotonic", lambda: now[0]):
            reader = observer.ConsoleReader(self.qmp, scratch)
            with self.assertRaises(observer.TableNotReady):
                reader.snapshot()
            reads = len(self.commands)
            now[0] = observer.PUBLICATION_RETRY_INTERVAL / 2
            with self.assertRaises(observer.TableNotReady):
                reader.snapshot()
            self.assertEqual(len(self.commands), reads)
            self.assertEqual(reader.publication_retries, 1)
            now[0] = observer.MAX_PUBLICATION_SECONDS
            with self.assertRaises(ValueError) as failure:
                reader.snapshot()
            self.assertNotIsInstance(failure.exception, observer.TableNotReady)
            self.assertEqual(len(self.commands), reads)
            self.assertIsNone(reader.metadata)
            # A stable malformed table cannot become acceptable after expiry.
            self.install(0x300000, valid)
            with self.assertRaises(ValueError) as failure:
                reader.snapshot()
            self.assertNotIsInstance(failure.exception, observer.TableNotReady)

    def test_spaced_publication_beyond_old_count_then_late_corruption(self):
        valid = table([self.memory_record, self.console_record])
        unfinished = bytearray(valid)
        unfinished[16] ^= 1
        self.install(0x300000, unfinished)
        now = [0.0]
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-publication-host-test.") as scratch, \
                patch.object(observer.time, "monotonic", lambda: now[0]):
            reader = observer.ConsoleReader(self.qmp, scratch)
            for _ in range(40):
                with self.assertRaises(observer.TableNotReady):
                    reader.snapshot()
                now[0] = reader.publication_next_read
            self.assertEqual(reader.publication_retries, 40)
            self.install(0x300000, valid)
            self.assertEqual(reader.snapshot(), self.body)
            self.assertEqual(reader.metadata["publication_retries"], 40)
            for label in ("first", "last"):
                data = (Path(scratch) / f"publication-{label}-table.bin").read_bytes()
                capture = json.loads((Path(scratch) / f"publication-{label}.json").read_text())
                self.assertEqual(data, unfinished)
                self.assertEqual(capture["address"], 0x300000)
                self.assertEqual(capture["bytes"], len(data))
                self.assertEqual(capture["sha256"], observer.hashlib.sha256(data).hexdigest())
                self.assertLess(capture["elapsed_seconds"], observer.MAX_PUBLICATION_SECONDS)
            self.install(0x300000, unfinished)
            with self.assertRaises(ValueError) as failure:
                reader.snapshot()
            self.assertNotIsInstance(failure.exception, observer.TableNotReady)

    def test_initial_publication_attempt_cap(self):
        valid = table([self.memory_record, self.console_record])
        unfinished = bytearray(valid)
        unfinished[16] ^= 1
        self.install(0x300000, unfinished)
        now = [0.0]
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-publication-host-test.") as scratch, \
                patch.object(observer.time, "monotonic", lambda: now[0]):
            reader = observer.ConsoleReader(self.qmp, scratch)
            for index in range(observer.MAX_PUBLICATION_RETRIES):
                with self.assertRaises(observer.TableNotReady):
                    reader.snapshot()
                if index + 1 < observer.MAX_PUBLICATION_RETRIES:
                    now[0] = reader.publication_next_read
            self.assertEqual(reader.publication_retries, observer.MAX_PUBLICATION_RETRIES)
            reads = len(self.commands)
            # Test the independent count guard before the modeled clock expires.
            now[0] += observer.PUBLICATION_RETRY_INTERVAL / 2
            self.assertLess(now[0], observer.MAX_PUBLICATION_SECONDS)
            with self.assertRaises(ValueError) as failure:
                reader.snapshot()
            self.assertNotIsInstance(failure.exception, observer.TableNotReady)
            self.assertEqual(len(self.commands), reads)

    def test_initial_transient_can_publish_but_qmp_error_cannot(self):
        valid = table([self.memory_record, self.console_record])
        unfinished = bytearray(valid)
        unfinished[16] ^= 1
        self.install(0x300000, unfinished)
        now = [0.0]
        with tempfile.TemporaryDirectory(prefix="qmp-cbmem-publication-host-test.") as scratch, \
                patch.object(observer.time, "monotonic", lambda: now[0]):
            reader = observer.ConsoleReader(self.qmp, scratch)
            with self.assertRaises(observer.TableNotReady):
                reader.snapshot()
            self.install(0x300000, valid)
            now[0] = reader.publication_next_read
            self.assertEqual(reader.snapshot(), self.body)
            self.assertEqual(reader.metadata["publication_retries"], 1)
            reader.qmp = lambda _command: {"error": {"desc": "modeled QMP read failure"}}
            with self.assertRaises(ValueError) as failure:
                reader.snapshot()
            self.assertNotIsInstance(failure.exception, observer.TableNotReady)

    def test_initial_qmp_error_is_not_missing_locator_or_publication(self):
        for address in (0x500, 0x300000):
            original = self.qmp

            def failed(command):
                if command["execute"] == "pmemsave" and \
                        command["arguments"]["val"] == address:
                    return {"error": {"desc": "modeled QMP table read failure"}}
                return original(command)

            with tempfile.TemporaryDirectory(prefix="qmp-cbmem-qmp-host-test.") as scratch:
                reader = observer.ConsoleReader(failed, scratch)
                with self.assertRaises(observer.PhysicalReadError):
                    reader.snapshot()
                self.assertEqual(reader.publication_retries, 0)
                self.assertFalse(list(Path(scratch).glob("publication-*")))


if __name__ == "__main__":
    unittest.main()
