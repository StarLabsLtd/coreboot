# SPDX-License-Identifier: GPL-2.0-only
"""HOST modeled runner epochs, not firmware or capsule authentication proof."""

import importlib.util
import json
import os
import struct
import subprocess
import tempfile
import unittest
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("runner", Path(__file__).with_name(
    "system_fmp_core_ram_native_test.py"))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
from qmp_cbmem_console import checksum


def table(version, capsule):
    body = struct.pack("<II16sIII", 0x45, 36,
                       uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le,
                       version, 0x001A0009, 8388608)
    if capsule:
        body += struct.pack("<IIQI", 0x46, 20, 0x200000, 8388608)
    header = bytearray(struct.pack("<4sIIIII", b"LBIO", 24, 0, len(body),
                                  checksum(body), 2 if capsule else 1))
    struct.pack_into("<I", header, 8, checksum(header))
    return bytes(header) + body


class EpochTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directories = []
        self.bodies = {}
        self.normal = (b"CDK2 | CAPSULE_RAM | begin | NOT_STARTED\n"
                       b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n"
                       b"CDK2 | PCI_ROOTS | begin\n")
        for index in range(3):
            directory = Path(self.temporary.name) / str(index)
            directory.mkdir()
            self.directories.append(directory)
            (directory / "cbmem-observer.json").write_text(json.dumps({
                "tables": [{}], "physical_limit": 1024 * 1024 * 1024}))
            (directory / "cbmem-table-0.bin").write_bytes(table(
                0x001A000A if index == 2 else 0x001A0009, index == 1))
            self.bodies[directory] = self.normal if index != 1 else \
                b"CDK2 | CAPSULE_RAM | begin | NOT_STARTED\n"

    def check(self):
        with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get):
            runner.check_boots(self.directories, 8388608)

    def test_three_epochs(self):
        self.check()

    def test_restore_running_differs_from_attempt_history(self):
        for index, directory in enumerate(self.directories):
            (directory / "cbmem-table-0.bin").write_bytes(table(
                0x001A0009 if index == 2 else 0x001A000A, index == 1))
        with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get):
            runner.check_boots(self.directories, 8388608, 0x001A000A, 0x001A0009)
            with self.assertRaisesRegex(ValueError, "identity"):
                runner.check_boots(self.directories, 8388608, 0x001A000A, 0x001A000B)

    def test_unsigned_version_input(self):
        self.assertEqual(runner.version_number("0x001a000b"), 0x001A000B)
        for value in ("-1", "01", "4294967296", "0x100000000", "1;exit"):
            with self.assertRaises(runner.argparse.ArgumentTypeError):
                runner.version_number(value)

    def test_actual_application_state_tuple(self):
        # Actual app helper, not modeled GetVariable/MM or native admission.
        root = Path(__file__).resolve().parents[1]
        source = Path(self.temporary.name) / "state.c"
        source.write_text('''#include <assert.h>
#include "system_fmp_core_ram_stage_app.c"
int main(void)
{
    struct cdk2_fmp_descriptor descriptor = {0};
    uint32_t state[5] = {0};
    descriptor.version = 0x001a0009U;
    descriptor.lowest_supported_version = 0x001a0009U;
    assert(state_matches(&descriptor, state, 0x001a0009U, 0U));
    state[0] = 1U;
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0U));
    state[0] = 0x01010101U;
    state[1] = state[4] = 0x001a000aU;
    state[2] = 0x001a0009U;
    descriptor.version = descriptor.last_attempt_version = 0x001a000aU;
    assert(state_matches(&descriptor, state, 0x001a000aU, 0x001a000aU));
    descriptor.version = 0x001a0009U;
    descriptor.last_attempt_version = state[1] = state[4] = 0x001a000bU;
    assert(state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
    assert(!state_matches(&descriptor, state, 0x001a000bU, 0x001a000bU));
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000aU));
    descriptor.lowest_supported_version++;
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
    descriptor.lowest_supported_version--;
    descriptor.last_attempt_status = 1U;
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
    descriptor.last_attempt_status = 0U;
    for (unsigned int index = 0; index < 5; index++) {
        uint32_t saved = state[index];
        state[index] ^= 1U;
        assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
        state[index] = saved;
    }
    return 0;
}
''')
        for optimization in ("-O0", "-O2"):
            executable = source.with_name("state" + optimization)
            subprocess.run([os.environ.get("HOSTCC", "cc"), "-std=gnu11", "-Wall",
                            "-Wextra", "-Werror", optimization, "-ffunction-sections",
                            "-fdata-sections", "-Wl,--gc-sections", "-I" + str(root / "include"),
                            "-I" + str(root / "tests"), str(source), "-o", str(executable)],
                           check=True)
            subprocess.run([str(executable)], check=True)

    def test_uncaptured_previous_tail(self):
        # Previous capture ended before PCI; warm console retains that missing
        # old tail. It must not be misclassified as warm PCI execution.
        self.bodies[self.directories[0]] = self.normal
        self.bodies[self.directories[1]] = self.normal + \
            b"uncaptured previous boot tail\nCDK2 | CAPSULE_RAM | begin\n"
        self.bodies[self.directories[2]] = self.bodies[self.directories[1]] + self.normal
        self.check()

    def test_normal_completion_required(self):
        self.bodies[self.directories[0]] = self.normal.replace(
            b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n", b"")
        with self.assertRaisesRegex(ValueError, "RAM phase"):
            self.check()

    def test_warm_pci_refused(self):
        self.bodies[self.directories[1]] += b"CDK2 | PCI_ROOTS | begin\n"
        with self.assertRaisesRegex(ValueError, "entered PCI"):
            self.check()

    def test_wrong_installed_version(self):
        (self.directories[2] / "cbmem-table-0.bin").write_bytes(table(0x001A0009, False))
        with self.assertRaisesRegex(ValueError, "identity"):
            self.check()

    def test_missing_warm_handoff(self):
        (self.directories[1] / "cbmem-table-0.bin").write_bytes(table(0x001A0009, False))
        with self.assertRaisesRegex(ValueError, "handoff"):
            self.check()

    def test_exact_prior_chain_only_provisional_after_reset(self):
        previous = self.directories[0]
        old = (previous / "cbmem-table-0.bin").read_bytes()
        reader = SimpleNamespace(metadata={"tables": [{}]}, table_snapshots=[old])
        self.assertTrue(runner.previous_table_during_reset(reader, previous, 1))
        with self.assertRaisesRegex(ValueError, "never published"):
            runner.previous_table_during_reset(reader, previous, 11)
        reader.metadata = {"tables": [{"address": 4096}]}
        self.assertFalse(runner.previous_table_during_reset(reader, previous, 1))

    def test_same_metadata_changed_bytes_not_a_publication_retry(self):
        previous = self.directories[0]
        reader = SimpleNamespace(metadata={"tables": [{}]},
                                 table_snapshots=[b"corrupted accepted old table"])
        with self.assertRaisesRegex(ValueError, "disagrees"):
            runner.previous_table_during_reset(reader, previous, 1)

    def test_accepted_current_table_drift_remains_fatal(self):
        from qmp_cbmem_console_test import ConsoleTest
        # The production ConsoleReader's accepted-chain refusal remains active;
        # the runner's special case never globally catches/retries this error.
        fixture = ConsoleTest()
        fixture.setUp()
        fixture.test_valid_table_drift_after_acceptance()

    def test_qmp_cannot_request_guest_reset(self):
        qmp = runner.Qmp.__new__(runner.Qmp)
        with self.assertRaisesRegex(ValueError, "non-observer"):
            qmp({"execute": "system_reset"})

    def test_actual_elf32_container_vs_elf64_loaded_identity(self):
        payloads = []
        for bits in (32, 64):
            data = bytearray(256)
            data[:7] = b"\x7fELF" + bytes((1 if bits == 32 else 2, 1, 1))
            struct.pack_into("<H", data, 18, 3 if bits == 32 else 62)
            if bits == 32:
                struct.pack_into("<II", data, 24, 0x100000, 64)
                struct.pack_into("<HH", data, 42, 32, 1)
                struct.pack_into("<IIIIIIII", data, 64, 1, 128, 0x100000,
                                 0x100000, 4, 8, 7, 0)
            else:
                struct.pack_into("<QQ", data, 24, 0x100000, 64)
                struct.pack_into("<HH", data, 54, 56, 1)
                struct.pack_into("<IIQQQQQQ", data, 64, 1, 5, 128, 0x100000,
                                 0x100000, 4, 8, 4096)
            data[128:132] = b"real"
            path = Path(self.temporary.name) / f"core{bits}.elf"
            path.write_bytes(data)
            payloads.append(path)
        self.assertEqual(runner.loads(payloads[0]), runner.loads(payloads[1]))
        data[128] ^= 1
        payloads[1].write_bytes(data)
        self.assertNotEqual(runner.loads(payloads[0]), runner.loads(payloads[1]))
        for offset, format_string, value in ((4, "<B", 3), (5, "<B", 2),
                                             (18, "<H", 3), (32, "<Q", 255),
                                             (54, "<H", 32), (56, "<H", 0),
                                             (64, "<I", 0), (72, "<Q", 255),
                                             (104, "<Q", 3)):
            changed = bytearray(data)
            struct.pack_into(format_string, changed, offset, value)
            payloads[1].write_bytes(changed)
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                runner.loads(payloads[1])


if __name__ == "__main__":
    unittest.main()
