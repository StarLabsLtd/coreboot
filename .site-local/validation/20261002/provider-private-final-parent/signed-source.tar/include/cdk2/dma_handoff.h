/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_DMA_HANDOFF_H_
#define CDK2_DMA_HANDOFF_H_

#include <coreboot_tables.h>
#include <uefi.h>

#define DMA_HANDOFF_REVISION 2U
#define DMA_HANDOFF_GRANULE_SHIFT 12U
#define DMA_HANDOFF_MAX_REQUESTERS CB_PRH_PCI_TOPOLOGY_MAX_ENTRIES

#define DMA_HANDOFF_PROTECTION_ACTIVE             (1U << 0)
#define DMA_HANDOFF_DEFAULT_DENY                  (1U << 1)
#define DMA_HANDOFF_COMPLETE_BME_INVENTORY_CLEAR  (1U << 2)
#define DMA_HANDOFF_COREBOOT_OWNS_IOMMU           (1U << 3)
#define DMA_HANDOFF_PRH_REVISION_4                (1U << 4)
#define DMA_HANDOFF_VALID_UNTIL_EBS               (1U << 5)
#define DMA_HANDOFF_REQUIRED_FLAGS \
	(DMA_HANDOFF_PROTECTION_ACTIVE | DMA_HANDOFF_DEFAULT_DENY | \
	 DMA_HANDOFF_COMPLETE_BME_INVENTORY_CLEAR | \
	 DMA_HANDOFF_COREBOOT_OWNS_IOMMU | DMA_HANDOFF_PRH_REVISION_4 | \
	 DMA_HANDOFF_VALID_UNTIL_EBS)

#define DMA_HANDOFF_REQUESTER_EXACT_BDF       (1U << 0)
#define DMA_HANDOFF_REQUESTER_ISOLATED_DOMAIN (1U << 1)
#define DMA_HANDOFF_REQUESTER_BME_CLEAR       (1U << 2)
#define DMA_HANDOFF_REQUESTER_ARENA_ONLY      (1U << 3)
#define DMA_HANDOFF_REQUESTER_FLAGS \
	(DMA_HANDOFF_REQUESTER_EXACT_BDF | \
	 DMA_HANDOFF_REQUESTER_ISOLATED_DOMAIN | \
	 DMA_HANDOFF_REQUESTER_BME_CLEAR | DMA_HANDOFF_REQUESTER_ARENA_ONLY)

#define DMA_HANDOFF_ARENA_READ      (1U << 0)
#define DMA_HANDOFF_ARENA_WRITE     (1U << 1)
#define DMA_HANDOFF_ARENA_PREMAPPED (1U << 2)
#define DMA_HANDOFF_ARENA_IMMUTABLE (1U << 3)
#define DMA_HANDOFF_ARENA_COHERENT  (1U << 4)
#define DMA_HANDOFF_ARENA_FLAGS \
	(DMA_HANDOFF_ARENA_READ | DMA_HANDOFF_ARENA_WRITE | \
	 DMA_HANDOFF_ARENA_PREMAPPED | DMA_HANDOFF_ARENA_IMMUTABLE | \
	 DMA_HANDOFF_ARENA_COHERENT)

#define CDK2_DMA_HANDOFF_HOB_GUID \
	{ 0x77af3f2b, 0x65bb, 0x4e28, \
	  { 0x91, 0xe1, 0x49, 0xca, 0x7a, 0x98, 0xb2, 0x70 } }
#define CDK2_DMA_HANDOFF_HOB_REVISION 2U

struct dma_handoff_header {
	UINT32 revision;
	UINT32 size;
	UINT16 header_size;
	UINT16 requester_size;
	UINT16 flags;
	UINT16 granule_shift;
	UINT32 requester_count;
	UINT32 crc32;
	UINT64 generation;
	UINT32 reserved[2];
} __packed;

struct dma_handoff_requester {
	UINT16 segment;
	UINT16 bdf;
	UINT16 protection_domain;
	UINT16 flags;
	UINT64 arena_cpu_base;
	UINT64 arena_device_base;
	UINT32 arena_pages;
	UINT32 arena_flags;
} __packed;

struct cdk2_dma_handoff_state {
	BOOLEAN valid;
	UINT64 generation;
	UINT32 requester_count;
	struct dma_handoff_requester requesters[DMA_HANDOFF_MAX_REQUESTERS];
};

struct cdk2_dma_handoff_hob {
	UINT16 revision;
	UINT16 length;
	UINT32 requester_count;
	UINT64 generation;
	struct dma_handoff_requester requesters[];
} __packed;

_Static_assert(sizeof(struct dma_handoff_header) == 40,
	"unexpected DMA handoff header size");
_Static_assert(sizeof(struct dma_handoff_requester) == 32,
	"unexpected DMA requester size");
_Static_assert(sizeof(struct cdk2_dma_handoff_hob) == 16,
	"unexpected DMA handoff HOB header size");

struct cdk2_coreboot_handoff;

EFI_STATUS cdk2_dma_handoff_find_blob(
	const struct cdk2_coreboot_handoff *coreboot, UINT32 minimum_size,
	EFI_PHYSICAL_ADDRESS *base, UINT32 *size);
EFI_STATUS cdk2_dma_handoff_consume(
	const struct cdk2_coreboot_handoff *coreboot,
	EFI_PHYSICAL_ADDRESS cbmem_base, UINT32 cbmem_size,
	struct cdk2_dma_handoff_state *state);
EFI_STATUS cdk2_dma_handoff_import(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_dma_handoff_state *state);

#endif
