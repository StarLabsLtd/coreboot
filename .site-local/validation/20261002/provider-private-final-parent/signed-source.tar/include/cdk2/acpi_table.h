/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_ACPI_TABLE_H_
#define CDK2_ACPI_TABLE_H_

#include <uefi.h>

#define CDK2_ACPI_HEADER_SIZE 36U
#define CDK2_ACPI_RSDP_SIZE 36U
#define CDK2_ACPI_MAX_TABLE_SIZE SIZE_1MB

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
#include <cdk2/diagnostic.h>
void cdk2_acpi_diagnostic(const char *message);
void cdk2_acpi_diagnostic_value(const char *label, UINT64 value);
void cdk2_acpi_diagnostic_bytes(const char *label, const void *bytes,
	UINTN count);
#define CDK2_ACPI_DIAG(message) cdk2_acpi_diagnostic(message)
#define CDK2_ACPI_DIAG_VALUE(label, value) \
	cdk2_acpi_diagnostic_value((label), (value))
#define CDK2_ACPI_DIAG_BYTES(label, bytes, count) \
	cdk2_acpi_diagnostic_bytes((label), (bytes), (count))
#else
#define CDK2_ACPI_DIAG(message) do { } while (0)
#define CDK2_ACPI_DIAG_VALUE(label, value) do { } while (0)
#define CDK2_ACPI_DIAG_BYTES(label, bytes, count) do { } while (0)
#endif

typedef EFI_STATUS cdk2_acpi_allocate_fn(void *context, UINTN size,
					 UINTN alignment, void **buffer);
typedef void cdk2_acpi_free_fn(void *context, void *buffer);

struct cdk2_acpi_allocator {
	void *context;
	cdk2_acpi_allocate_fn *allocate;
	cdk2_acpi_free_fn *free;
};

struct cdk2_acpi_record {
	void *table;
	UINT32 length;
	UINTN key;
	BOOLEAN owned;
};

struct cdk2_acpi_tables {
	struct cdk2_acpi_allocator allocator;
	struct cdk2_acpi_record *records;
	UINTN capacity;
	UINTN count;
	UINTN next_key;
	UINTN replacement_index;
	BOOLEAN replacement_pending;
	UINT8 *rsdp;
	UINT32 rsdp_length;
	UINT8 *rsdp10;
	UINT8 *rsdt;
	UINT8 *xsdt;
};

EFI_STATUS
cdk2_acpi_tables_initialize(struct cdk2_acpi_tables *tables,
			    const struct cdk2_acpi_allocator *allocator,
			    struct cdk2_acpi_record *records, UINTN capacity,
			    const void *source_rsdp);
void cdk2_acpi_tables_destroy(struct cdk2_acpi_tables *tables);
EFI_STATUS cdk2_acpi_install(struct cdk2_acpi_tables *tables, const void *table,
			     UINTN table_size, UINTN *key);
EFI_STATUS cdk2_acpi_uninstall(struct cdk2_acpi_tables *tables, UINTN key);
const void *cdk2_acpi_rsdp(const struct cdk2_acpi_tables *tables);
UINT8 cdk2_acpi_checksum(const void *buffer, UINTN size);

#endif
