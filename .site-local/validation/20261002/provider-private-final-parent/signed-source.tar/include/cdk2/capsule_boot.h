/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_CAPSULE_BOOT_H_
#define CDK2_CAPSULE_BOOT_H_

#include <uefi.h>
#include <cdk2/capsule_delivery_policy.h>

#define CDK2_CAPSULE_WARN_RESET_REQUIRED ((EFI_STATUS)6U)
_Static_assert(CDK2_CAPSULE_WARN_RESET_REQUIRED == 6U,
	"capsule reset warning ABI changed");

struct cdk2_capsule_boot_protocol;
typedef EFI_STATUS CDK2_MS_ABI cdk2_capsule_process_scatter_fn(
	struct cdk2_capsule_boot_protocol *, UINT64 scatter_gather);
typedef EFI_STATUS CDK2_MS_ABI cdk2_capsule_boot_process_fn(
	struct cdk2_capsule_boot_protocol *, const void *capsule, UINTN size);
struct cdk2_capsule_boot_protocol {
	cdk2_capsule_process_scatter_fn *process_scatter;
	cdk2_capsule_boot_process_fn *validate_capsule;
	cdk2_capsule_boot_process_fn *process_capsule;
	BOOLEAN reset_required;
	struct cdk2_capsule_delivery_policy delivery_policy;
};

#endif
