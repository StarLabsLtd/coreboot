/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_HANDOFF_H
#define CDK2_SYSTEM_FMP_HANDOFF_H

#include <coreboot_tables.h>

#define CDK2_SYSTEM_FMP_MAX_REGIONS 16U

struct cdk2_coreboot_handoff;

struct cdk2_system_fmp_region {
	UINT64 image_offset;
	UINT64 flash_offset;
	UINT64 size;
	UINT32 flags;
};

struct cdk2_system_fmp_handoff {
	EFI_GUID image_type;
	UINT32 version;
	UINT32 lowest_supported_version;
	UINT32 capsule_flags;
	UINT32 block_size;
	UINT32 erase_size;
	UINT32 region_count;
	UINT64 image_size;
	UINT64 boot_media_size;
	UINT64 smmstore_offset;
	UINT64 smmstore_size;
	struct cdk2_system_fmp_region regions[CDK2_SYSTEM_FMP_MAX_REGIONS];
};

EFI_STATUS cdk2_system_fmp_handoff_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_handoff *handoff);

#endif
