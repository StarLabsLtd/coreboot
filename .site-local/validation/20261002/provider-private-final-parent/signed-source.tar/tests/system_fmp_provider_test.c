/* SPDX-License-Identifier: GPL-2.0-only */
#include <assert.h>
#include <stdint.h>
#include <string.h>

#include <cdk2/system_fmp_provider.h>

static EFI_STATUS close_status;
static UINTN executions;
static UINTN progress_calls;
static UINTN progress_executions[2];
static struct cdk2_system_fmp_provider *callback_provider;
static const UINT8 *callback_image;

static EFI_STATUS CDK2_MS_ABI hostile_progress(UINTN completion)
{
	UINT32 updatable = 0xdeadbeefU;
	CHAR16 *abort_reason = (void *)1;
	UINTN slot;

	assert(completion == 0U || completion == 100U);
	slot = completion == 0U ? 0U : 1U;
	progress_calls++;
	progress_executions[slot] = executions;
	assert(callback_provider->protocol.check_image(
		&callback_provider->protocol, CDK2_SYSTEM_FMP_IMAGE_INDEX,
		callback_image, 4U, &updatable) == EFI_ACCESS_DENIED);
	assert(updatable == 0xdeadbeefU);
	assert(callback_provider->protocol.set_image(
		&callback_provider->protocol, CDK2_SYSTEM_FMP_IMAGE_INDEX,
		callback_image, 4U, NULL, NULL, &abort_reason) == EFI_ACCESS_DENIED);
	assert(abort_reason == (void *)1);
	assert(cdk2_system_fmp_provider_close(callback_provider) ==
		EFI_ACCESS_DENIED);
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI failing_progress(UINTN completion)
{
	assert(completion == 0U);
	return EFI_DEVICE_ERROR;
}

EFI_STATUS cdk2_system_fmp_session_initialize(
	struct cdk2_system_fmp_session *session,
	const struct cdk2_system_fmp_session_config *config)
{
	(void)config;
	memset(session, 0, sizeof(*session));
	session->initialized = true;
	session->ready = true;
	session->info.image_type.data1 = 0x11223344U;
	session->info.current_version = 7U;
	session->info.lowest_supported_version = 4U;
	session->info.image_size = 4096U;
	session->info.hardware_instance = 9U;
	session->info.state_flags =
		CDK2_SYSTEM_FMP_INFO_STATE_LAST_ATTEMPT_STATUS_VALID |
		CDK2_SYSTEM_FMP_INFO_STATE_LAST_ATTEMPT_VERSION_VALID;
	session->info.last_attempt_version = 6U;
	session->info.last_attempt_status = 1U;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_session_execute(
	struct cdk2_system_fmp_session *session,
	const struct cdk2_system_fmp_session_request *request,
	struct cdk2_system_fmp_session_result *result)
{
	uintptr_t image = (uintptr_t)request->authenticated_image;
	uintptr_t start = (uintptr_t)session;

	if (image >= start && image < start + sizeof(*session))
		return EFI_INVALID_PARAMETER;
	if (*(const UINT8 *)request->authenticated_image == 0xffU)
		return EFI_INVALID_PARAMETER;
	executions++;
	result->image_updatable = CDK2_FMP_IMAGE_UPDATABLE_VALID;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_session_close(
	struct cdk2_system_fmp_session *session)
{
	if (EFI_ERROR(close_status))
		return close_status;
	memset(session, 0, sizeof(*session));
	return EFI_SUCCESS;
}

int main(void)
{
	struct cdk2_system_fmp_session_config config = {0};
	struct cdk2_system_fmp_provider provider = {0};
	struct cdk2_system_fmp_provider other = {0};
	struct cdk2_fmp_protocol wrong = {0};
	struct cdk2_fmp_descriptor descriptor;
	cdk2_fmp_check_image_fn *check;
	cdk2_fmp_set_image_fn *set;
	cdk2_fmp_get_image_fn *get;
	cdk2_fmp_get_package_info_fn *get_package;
	cdk2_fmp_set_package_info_fn *set_package;
	CHAR16 *abort_reason = (void *)1;
	CHAR16 *package_name = (void *)1;
	UINT8 descriptor_count;
	UINT32 descriptor_version;
	UINT32 package_version;
	UINT32 updatable;
	UINTN descriptor_size;
	UINTN size;
	UINT8 image[4] = {0};

	assert(cdk2_system_fmp_provider_initialize(NULL, &config) ==
		EFI_INVALID_PARAMETER);
	assert(cdk2_system_fmp_provider_initialize(
		(struct cdk2_system_fmp_provider *)MAX_UINTN, &config) ==
		EFI_INVALID_PARAMETER);
	assert(cdk2_system_fmp_provider_initialize(&provider,
		(const struct cdk2_system_fmp_session_config *)MAX_UINTN) ==
		EFI_INVALID_PARAMETER);
	assert(cdk2_system_fmp_provider_initialize(&provider, &config) ==
		EFI_SUCCESS);
	assert(cdk2_system_fmp_provider_initialize(&other, &config) ==
		EFI_ALREADY_STARTED);
	size = 0U;
	assert(provider.protocol.get_image_info(&provider.protocol, &size, NULL,
		&descriptor_version, &descriptor_count, &descriptor_size,
		&package_version, &package_name) == EFI_BUFFER_TOO_SMALL);
	assert(size == sizeof(descriptor));
	assert(provider.protocol.get_image_info(&wrong, &size, &descriptor,
		&descriptor_version, &descriptor_count, &descriptor_size,
		&package_version, &package_name) == EFI_INVALID_PARAMETER);
	assert(provider.protocol.get_image_info(&provider.protocol,
		(UINTN *)&provider.session.info.image_size, NULL,
		&descriptor_version, &descriptor_count, &descriptor_size,
		&package_version, &package_name) == EFI_INVALID_PARAMETER);
	size = sizeof(descriptor);
	assert(provider.protocol.get_image_info(&provider.protocol, &size,
		(struct cdk2_fmp_descriptor *)&provider.session,
		&descriptor_version, &descriptor_count, &descriptor_size,
		&package_version, &package_name) == EFI_INVALID_PARAMETER);
	assert(provider.protocol.get_image_info(&provider.protocol, &size,
		&descriptor, &descriptor_version, &descriptor_count,
		&descriptor_size, &descriptor_version, &package_name) ==
		EFI_INVALID_PARAMETER);
	size = sizeof(descriptor);
	assert(provider.protocol.get_image_info(&provider.protocol, &size,
		&descriptor, &descriptor_version, &descriptor_count,
		&descriptor_size, &package_version, &package_name) == EFI_SUCCESS);
	assert(descriptor.image_index == CDK2_SYSTEM_FMP_IMAGE_INDEX &&
		descriptor.version == 7U && descriptor.lowest_supported_version == 4U &&
		descriptor.hardware_instance == 9U && descriptor.size == 4096U &&
		descriptor.last_attempt_version == 6U &&
		descriptor.last_attempt_status == 1U);
	get = provider.protocol.get_image;
	set = provider.protocol.set_image;
	check = provider.protocol.check_image;
	get_package = provider.protocol.get_package_info;
	set_package = provider.protocol.set_package_info;
	assert(get_package(&wrong, NULL, NULL, NULL, NULL, NULL) ==
		EFI_INVALID_PARAMETER);
	assert(get_package(&provider.protocol, NULL, NULL, NULL, NULL, NULL) ==
		EFI_UNSUPPORTED);
	assert(set_package(&wrong, NULL, 0U, NULL, 0U, NULL) ==
		EFI_INVALID_PARAMETER);
	assert(set_package(&provider.protocol, NULL, 0U, NULL, 0U, NULL) ==
		EFI_UNSUPPORTED);
	size = sizeof(image);
	assert(get(&wrong, 1U, image, &size) == EFI_INVALID_PARAMETER);
	assert(get(&provider.protocol, 1U, image,
		(UINTN *)MAX_UINTN) == EFI_INVALID_PARAMETER);
	assert(get(&provider.protocol, 1U, image, &size) == EFI_UNSUPPORTED);
	updatable = 0xdeadbeefU;
	assert(check(&wrong, 1U, image, sizeof(image), &updatable) ==
		EFI_INVALID_PARAMETER);
	updatable = 0xdeadbeefU;
	assert(check(&provider.protocol, 1U, &provider.session,
		sizeof(provider.session), &updatable) == EFI_INVALID_PARAMETER);
	assert(updatable == 0xdeadbeefU && executions == 0U);
	assert(check(&provider.protocol, 1U, (const void *)MAX_UINTN, 2U,
		&updatable) == EFI_INVALID_PARAMETER);
	assert(updatable == 0xdeadbeefU && executions == 0U);
	assert(check(&provider.protocol, 1U, image, sizeof(image),
		(UINT32 *)&provider.session.info.current_version) ==
		EFI_INVALID_PARAMETER);
	assert(check(&provider.protocol, 1U, image, sizeof(image),
		(UINT32 *)image) == EFI_INVALID_PARAMETER);
	image[0] = 0xffU;
	updatable = 0xdeadbeefU;
	assert(check(&provider.protocol, 1U, image, sizeof(image), &updatable) ==
		EFI_INVALID_PARAMETER);
	assert(updatable == CDK2_FMP_IMAGE_UPDATABLE_INVALID && executions == 0U);
	image[0] = 0U;
	updatable = 0U;
	assert(check(&provider.protocol, 1U, image, sizeof(image), &updatable) ==
		EFI_SUCCESS);
	assert(updatable == CDK2_FMP_IMAGE_UPDATABLE_VALID && executions == 1U);
	assert(set(&provider.protocol, 1U, image, sizeof(image), NULL, NULL,
		&abort_reason) == EFI_SUCCESS);
	assert(abort_reason == NULL && executions == 2U);
	callback_provider = &provider;
	callback_image = image;
	abort_reason = (void *)1;
	assert(set(&provider.protocol, 1U, image, sizeof(image), NULL,
		hostile_progress, &abort_reason) == EFI_SUCCESS);
	assert(abort_reason == NULL && progress_calls == 2U && executions == 3U);
	assert(progress_executions[0] == 2U && progress_executions[1] == 3U);
	abort_reason = (void *)1;
	assert(set(&provider.protocol, 1U, image, sizeof(image), NULL,
		failing_progress, &abort_reason) == EFI_DEVICE_ERROR);
	assert(abort_reason == NULL && executions == 3U);
	updatable = 0U;
	assert(check(&provider.protocol, 1U, image, sizeof(image), &updatable) ==
		EFI_SUCCESS);
	assert(updatable == CDK2_FMP_IMAGE_UPDATABLE_VALID && executions == 4U);
	assert(set(&provider.protocol, 1U, image, sizeof(image), NULL, NULL,
		(CHAR16 **)&provider.session.info.current_version) ==
		EFI_INVALID_PARAMETER);
	assert(set(&provider.protocol, 1U, image, sizeof(image), NULL, NULL,
		(CHAR16 **)image) == EFI_INVALID_PARAMETER);
	assert(set(&provider.protocol, 1U, image, sizeof(image), NULL, NULL,
		(CHAR16 **)MAX_UINTN) == EFI_INVALID_PARAMETER);
	assert(set(&provider.protocol, 1U, image, sizeof(image), NULL,
		(cdk2_fmp_progress_fn *)(UINTN)&provider.session, NULL) ==
		EFI_INVALID_PARAMETER);
	close_status = EFI_DEVICE_ERROR;
	assert(cdk2_system_fmp_provider_close(&provider) == EFI_DEVICE_ERROR);
	assert(cdk2_system_fmp_provider_initialize(&other, &config) ==
		EFI_ALREADY_STARTED);
	close_status = EFI_SUCCESS;
	assert(cdk2_system_fmp_provider_close(&provider) == EFI_SUCCESS);
	assert(cdk2_system_fmp_provider_close(&provider) == EFI_NOT_STARTED);
	assert(cdk2_system_fmp_provider_initialize(&other, &config) == EFI_SUCCESS);
	assert(cdk2_system_fmp_provider_close(&other) == EFI_SUCCESS);
	return 0;
}
