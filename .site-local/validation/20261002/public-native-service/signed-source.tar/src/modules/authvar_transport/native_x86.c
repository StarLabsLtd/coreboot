/* SPDX-License-Identifier: GPL-2.0-only */

#include <cdk2/authvar_native_x86.h>
#include <stdint.h>

#if !defined(__x86_64__)
#error "The native authenticated-variable trigger requires x86-64 save-state registers"
#endif

EFI_STATUS cdk2_authvar_native_x86_trigger(void *context, UINT16 port, UINT8 value)
{
	const uint64_t command = value;
	const uint64_t address = port;
	const uint64_t legacy_frame_address = 0;

	(void)context;
	__asm__ volatile("outb %%al, %%dx"
		: : "a" (command), "d" (address), "c" (legacy_frame_address) : "memory");
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_authvar_native_x86_cache(void *context, void *base, UINTN size)
{
	uintptr_t address, last;

	(void)context;
	if (base == NULL || !size || size - 1 > UINTPTR_MAX - (uintptr_t)base)
		return EFI_INVALID_PARAMETER;
	address = (uintptr_t)base & ~(uintptr_t)63;
	last = ((uintptr_t)base + size - 1) & ~(uintptr_t)63;
	for (;;) {
		__asm__ volatile("clflush (%0)" : : "r" ((void *)address) : "memory");
		if (address == last)
			break;
		address += 64;
	}
	__asm__ volatile("mfence" : : : "memory");
	return EFI_SUCCESS;
}

void cdk2_authvar_native_x86_barrier(void *context)
{
	(void)context;
	__asm__ volatile("mfence" : : : "memory");
}
