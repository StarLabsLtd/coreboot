/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#include <cdk2/dxe_core.h>
#include <cdk2/pe_image_view.h>
#include <cdk2/authvar_presence_lifecycle.h>
#include <cdk2/config.h>
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
#include <cdk2/authvar_presence_lifecycle_close_composition.h>
#endif
#include <cdk2/cpu_arch.h>
#include <cdk2/local_apic_timer.h>
#include <cdk2/fat_binding.h>
#include <cdk2/metronome.h>
#include <cdk2/pci_io_abi.h>
#include <cdk2/pci_dma_control.h>
#include <cdk2/runtime_arch.h>
#include <cdk2/security_router.h>
#include <cdk2/watchdog.h>
#include <cdk2/xhci_control.h>
#include <industry_standard/pe_image.h>

#include <stdarg.h>
#include <string.h>
#include "diagnostic.h"
#include "private_image.h"
#if CONFIG_CDK2_LINEAR_BOOT
#include "private_control.h"
#endif

static struct cdk2_dxe_core *active_core;
#ifdef CDK2_HOST_TEST
static UINTN runtime_image_register_test_calls;
#endif
static const EFI_GUID timer_arch_guid = { 0x26baccb3, 0x6f42, 0x11d4,
	{ 0xbc, 0xe7, 0x00, 0x80, 0xc7, 0x3c, 0x88, 0x81 } };
#if CONFIG_CDK2_LINEAR_BOOT
static const EFI_GUID xhci_control_guid = CDK2_XHCI_CONTROL_GUID;
#if CONFIG_PAYLOAD_DMA_HANDOFF
static const EFI_GUID pci_dma_control_guid = CDK2_PCI_DMA_CONTROL_GUID;
#endif
#endif

static void CDK2_MS_ABI event_timer_tick(UINT64 period)
{
	if (active_core != NULL)
		cdk2_dxe_event_advance(&active_core->events, period);
}
static EFI_STATUS CDK2_MS_ABI service_stall(UINTN microseconds);
static EFI_STATUS CDK2_MS_ABI service_locate_protocol(const EFI_GUID *, void *,
	void **);

#ifdef CDK2_DEBUG
#define IMAGE_NOT_FOUND_TRACE_LIMIT 64U
#define CONNECT_TRACE_LIMIT 256U
static UINTN image_service_trace_depth;
static UINTN image_service_trace_count;
static UINTN connect_trace_count;

static void trace_image_not_found(UINT32 service, const EFI_GUID *guid,
	void *handle)
{
	if (image_service_trace_depth == 0U || image_service_trace_count >=
	    IMAGE_NOT_FOUND_TRACE_LIMIT)
		return;
	image_service_trace_count++;
	cdk2_diag_emit(CDK2_DIAG_ERROR, CDK2_DIAG_DXE_MAIN, service,
		EFI_NOT_FOUND);
	cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "not-found handle", (UINTN)handle);
	if (guid != NULL)
		cdk2_diag_bytes(CDK2_DIAG_DXE_MAIN, "not-found protocol GUID",
			guid, sizeof(*guid));
}
#else
#define trace_image_not_found(service, guid, handle) do { } while (0)
#endif
static EFI_STATUS CDK2_MS_ABI service_create_event_ex(UINT32, UINTN,
	cdk2_dxe_notify_fn *, const void *, const EFI_GUID *, void **);
static const EFI_GUID runtime_arch_guid;
static void *connect_stack[16];
static void *connect_driver_stack[16];
static UINTN connect_depth;
static void *disconnect_stack[16];
static UINTN disconnect_depth;
static struct {
	void *controller;
	void *driver;
	void *image;
	BOOLEAN started;
} connected_pairs[4096];
static UINTN connected_pair_count;
static struct cdk2_cpu_arch *tpl_cpu;
static BOOLEAN high_tpl_interrupts_enabled;
static const EFI_GUID loaded_image_guid = { 0x5b1b31a1, 0x9562, 0x11d2,
	{ 0x8e, 0x3f, 0, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID loaded_image_device_path_guid = { 0xbc62157e, 0x3e33,
	0x4fec, { 0x99, 0x20, 0x2d, 0x3b, 0x36, 0xd7, 0x50, 0xdf } };
static const EFI_GUID simple_fs_guid = { 0x964e5b22, 0x6459, 0x11d2,
	{ 0x8e, 0x39, 0, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID file_info_guid = { 0x09576e92, 0x6d3f, 0x11d2,
	{ 0x8e, 0x39, 0, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID device_path_guid = { 0x09576e91, 0x6d3f, 0x11d2,
	{ 0x8e, 0x39, 0, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
#ifdef CDK2_DEBUG
static void trace_path(const CHAR8 *label, const void *path, UINTN span)
{
	UINTN bytes;

	if (path == NULL || span < 4U || EFI_ERROR(cdk2_dxe_device_path_size(path,
	    span > 4096U ? 4096U : span,
	    &bytes)))
		return;
	cdk2_diag_value(CDK2_DIAG_DXE_MAIN, label, bytes);
	cdk2_diag_bytes(CDK2_DIAG_DXE_MAIN, "path head", path,
		bytes > 256U ? 128U : bytes);
	if (bytes > 256U)
		cdk2_diag_bytes(CDK2_DIAG_DXE_MAIN, "path tail",
			(const UINT8 *)path + bytes - 128U, 128U);
}

static void trace_handle_path(const CHAR8 *label, void *handle)
{
	void *path = NULL;
	UINTN span = 0U;

	if (!EFI_ERROR(cdk2_dxe_handle_span(&active_core->database, handle,
	    &device_path_guid, &path, &span)))
		trace_path(label, path, span);
}
static const EFI_GUID pci_io_guid = { 0x4cf5b200, 0x68b8, 0x4ca5,
	{ 0x9e, 0xec, 0xb2, 0x3e, 0x3f, 0x50, 0x02, 0x9a } };
#endif
#if !CONFIG_CDK2_STRICT_DIRECT_RUNTIME
static const EFI_GUID fv2_guid = { 0x220e73b6, 0x6bdb, 0x4413,
	{ 0x84, 0x05, 0xb9, 0x74, 0xb1, 0x08, 0x61, 0x9a } };
#endif
static const EFI_GUID watchdog_guid = { 0x665e3ff5, 0x46cc, 0x11d4,
	{ 0x9a, 0x38, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
static const EFI_GUID exit_boot_services_guid = { 0x27abf055, 0xb1b8, 0x4c26,
	{ 0x80, 0x48, 0x74, 0x8f, 0x37, 0xba, 0xa2, 0xdf } };
static const EFI_GUID exit_boot_services_failed_guid = { 0x5aea42b5, 0x31e1,
	0x4515, { 0xbc, 0x31, 0xb8, 0xd5, 0x25, 0x75, 0x65, 0xa6 } };
static const EFI_GUID before_exit_boot_services_guid = { 0x8be0e274, 0x3970,
	0x4b44, { 0x80, 0xc5, 0x1a, 0xb9, 0x50, 0x2f, 0x3b, 0xfc } };
static const EFI_GUID cpu_arch_guid = { 0x26baccb1, 0x6f42, 0x11d4,
	{ 0xbc, 0xe7, 0x00, 0x80, 0xc7, 0x3c, 0x88, 0x81 } };
static const EFI_GUID runtime_arch_guid = { 0xb7dfb4e1, 0x052f, 0x449f,
	{ 0x87, 0xbe, 0x98, 0x18, 0xfc, 0x91, 0xb7, 0x33 } };
static const EFI_GUID metronome_guid = { 0x26baccb2, 0x6f42, 0x11d4,
	{ 0xbc, 0xe7, 0x00, 0x80, 0xc7, 0x3c, 0x88, 0x81 } };
static const EFI_GUID security2_guid = { 0x94ab2f58, 0x1438, 0x4ef1,
	{ 0x91, 0x52, 0x18, 0x94, 0x1a, 0x3a, 0x0e, 0x68 } };
static const EFI_GUID virtual_address_change_guid = { 0x13fa7698, 0xc831,
	0x49c7, { 0x87, 0xea, 0x8f, 0x43, 0xfc, 0xc2, 0x51, 0x96 } };

extern EFI_STATUS cdk2_native_load_pe32_plus(const void *image,
					     unsigned long long image_size, unsigned long long destination,
	unsigned long long destination_size, unsigned long long *loaded_base,
	unsigned long long *loaded_size, unsigned long long *entry_point);

struct open_information {
	void *agent;
	void *controller;
	UINT32 attributes;
	UINT32 count;
};

typedef EFI_STATUS CDK2_MS_ABI file_authentication_fn(const void *,
	const void *, void *, UINTN, BOOLEAN);
struct security2_protocol {
	file_authentication_fn *file_authentication;
};

struct runtime_event_entry {
	struct cdk2_runtime_list_entry link;
	UINT32 type;
	UINTN notify_tpl;
	cdk2_runtime_notify_fn *notify;
	void *context;
	void *event;
};

struct runtime_image_entry {
	struct cdk2_runtime_list_entry link;
	void *image_base;
	UINT64 image_size;
	void *relocation_data;
	void *handle;
};

typedef char runtime_event_link_offset[
	(offsetof(struct runtime_event_entry, link) == 0U) ? 1 : -1];
typedef char runtime_image_link_offset[
	(offsetof(struct runtime_image_entry, link) == 0U) ? 1 : -1];

static void runtime_list_insert(struct cdk2_runtime_list_entry *head,
	struct cdk2_runtime_list_entry *entry)
{
	entry->forward = head;
	entry->back = head->back;
	head->back->forward = entry;
	head->back = entry;
}

static void runtime_list_remove(struct cdk2_runtime_list_entry *entry)
{
	entry->back->forward = entry->forward;
	entry->forward->back = entry->back;
	entry->forward = entry->back = entry;
}

static BOOLEAN image_range_valid(UINTN offset, UINTN size, UINTN limit)
{
	return offset <= limit && size <= limit - offset;
}

static EFI_STATUS snapshot_runtime_relocations(struct cdk2_dxe_core *core,
	struct cdk2_dxe_image *image, void **snapshot)
{
	const EFI_IMAGE_DOS_HEADER *dos = image->base;
	const EFI_IMAGE_NT_HEADERS64 *header;
	EFI_IMAGE_DATA_DIRECTORY directory;
	const EFI_IMAGE_BASE_RELOCATION *block;
	UINT8 *output;
	UINTN count = 0, end, index, offset, pe_offset = 0, size;
	EFI_STATUS status;

	if (image->size >= sizeof(*dos) && dos->e_magic == EFI_IMAGE_DOS_SIGNATURE)
		pe_offset = dos->e_lfanew;
	if (!image_range_valid(pe_offset, sizeof(*header), image->size))
		return EFI_COMPROMISED_DATA;
	header = (const void *)((const UINT8 *)image->base + pe_offset);
	if (header->signature != EFI_IMAGE_NT_SIGNATURE ||
	    header->optional_header.magic != EFI_IMAGE_NT_OPTIONAL_HDR64_MAGIC ||
	    header->optional_header.number_of_rva_and_sizes <=
	    EFI_IMAGE_DIRECTORY_ENTRY_BASERELOC)
		return EFI_UNSUPPORTED;
	directory = header->optional_header.data_directory[
		EFI_IMAGE_DIRECTORY_ENTRY_BASERELOC];
	if (directory.size == 0U || !image_range_valid(directory.virtual_address,
	    directory.size, image->size))
		return EFI_UNSUPPORTED;
	offset = directory.virtual_address;
	end = offset + directory.size;
	while (offset < end) {
		const UINT16 *entries;
		UINTN entries_count;

		if (!image_range_valid(offset, sizeof(*block), end))
			return EFI_COMPROMISED_DATA;
		block = (const void *)((const UINT8 *)image->base + offset);
		if (block->size_of_block < sizeof(*block) ||
		    !image_range_valid(offset, block->size_of_block, end) ||
		    ((block->size_of_block - sizeof(*block)) & 1U) != 0U)
			return EFI_COMPROMISED_DATA;
		entries = (const void *)(block + 1);
		entries_count = (block->size_of_block - sizeof(*block)) /
			sizeof(*entries);
		for (index = 0; index < entries_count; index++) {
			UINTN type = entries[index] >> 12;

			if (type == EFI_IMAGE_REL_BASED_ABSOLUTE)
				continue;
			if (type != EFI_IMAGE_REL_BASED_DIR64 && type != 3U)
				return EFI_UNSUPPORTED;
			if (count == MAX_UINTN)
				return EFI_OUT_OF_RESOURCES;
			count++;
		}
		offset += block->size_of_block;
	}
	if (count > (MAX_UINTN - 8U) / sizeof(UINT64))
		return EFI_OUT_OF_RESOURCES;
	size = count * sizeof(UINT64) + 8U;
	status = cdk2_dxe_allocate_pool(&core->memory, 6U, size, snapshot);
	if (EFI_ERROR(status))
		return status;
	output = *snapshot;
	offset = directory.virtual_address;
	while (offset < end) {
		const UINT16 *entries;
		UINTN entries_count;

		block = (const void *)((const UINT8 *)image->base + offset);
		entries = (const void *)(block + 1);
		entries_count = (block->size_of_block - sizeof(*block)) /
			sizeof(*entries);
		for (index = 0; index < entries_count; index++) {
			UINT64 target64 = (UINT64)block->virtual_address +
				(entries[index] & 0xfffU);
			UINTN target;
			UINTN type = entries[index] >> 12;

			if (type == EFI_IMAGE_REL_BASED_ABSOLUTE)
				continue;
			if (target64 > MAX_UINTN)
				goto compromised;
			target = (UINTN)target64;
			if (type == EFI_IMAGE_REL_BASED_DIR64) {
				output = (void *)(((UINTN)output + 7U) & ~(UINTN)7U);
				if (!image_range_valid(target, sizeof(UINT64), image->size))
					goto compromised;
				memcpy(output, (UINT8 *)image->base + target,
					sizeof(UINT64));
				output += sizeof(UINT64);
			} else {
				output = (void *)(((UINTN)output + 3U) & ~(UINTN)3U);
				if (!image_range_valid(target, sizeof(UINT32), image->size))
					goto compromised;
				memcpy(output, (UINT8 *)image->base + target,
					sizeof(UINT32));
				output += sizeof(UINT32);
			}
		}
		offset += block->size_of_block;
	}
	return EFI_SUCCESS;

compromised:
	(void)cdk2_dxe_free_pool(&core->memory, *snapshot);
	*snapshot = NULL;
	return EFI_COMPROMISED_DATA;
}

EFI_STATUS cdk2_dxe_runtime_image_register(struct cdk2_dxe_core *core,
	struct cdk2_dxe_image *image)
{
	struct cdk2_runtime_arch_protocol *runtime = NULL;
	struct runtime_image_entry *entry = NULL;
	UINTN index;
	EFI_STATUS status;

#ifdef CDK2_HOST_TEST
	runtime_image_register_test_calls++;
#endif
	if (core == NULL || image == NULL)
		return EFI_INVALID_PARAMETER;
	if (image->loaded_image.image_code_type != 5U)
		return EFI_SUCCESS;
	for (index = 0; index < core->database.protocol_count; index++)
		if (memcmp(&core->database.protocols[index].guid, &runtime_arch_guid,
		    sizeof(runtime_arch_guid)) == 0) {
			runtime = core->database.protocols[index].interface;
			break;
		}
	if (runtime == NULL)
		return EFI_SUCCESS;
	if (runtime->image_head.forward == NULL || runtime->image_head.back == NULL)
		return EFI_COMPROMISED_DATA;
	status = snapshot_runtime_relocations(core, image,
		&image->runtime_relocation);
	if (EFI_ERROR(status)) {
		CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_022, status);
		return status;
	}
	status = cdk2_dxe_allocate_pool(&core->memory, 6U, sizeof(*entry),
		(void **)&entry);
	if (EFI_ERROR(status)) {
		CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_022, status);
		(void)cdk2_dxe_free_pool(&core->memory, image->runtime_relocation);
		image->runtime_relocation = NULL;
		return status;
	}
	*entry = (struct runtime_image_entry){
		.image_base = image->base, .image_size = image->size,
		.relocation_data = image->runtime_relocation, .handle = image->handle
	};
	runtime_list_insert(&runtime->image_head, &entry->link);
	image->runtime_entry = entry;
	CDK2_DXE_DIAG(CDK2_DIAG_INFO, CDK2_DXE_070, EFI_SUCCESS);
	CDK2_DXE_DIAG(CDK2_DIAG_DEBUG, CDK2_DXE_072, EFI_SUCCESS);
	CDK2_DXE_DIAG(CDK2_DIAG_DEBUG, CDK2_DXE_073, EFI_SUCCESS);
	return EFI_SUCCESS;
}

#ifdef CDK2_HOST_TEST
UINTN cdk2_dxe_test_runtime_image_register_calls(void)
{
	return runtime_image_register_test_calls;
}

UINTN cdk2_dxe_test_image_service_trace_depth(void)
{
#ifdef CDK2_DEBUG
	return image_service_trace_depth;
#else
	return 0U;
#endif
}
#endif

static void release_runtime_image(struct cdk2_dxe_core *core,
	struct runtime_image_entry *entry, void *relocation)
{
	if (core == NULL || entry == NULL)
		return;
	runtime_list_remove(&entry->link);
	(void)cdk2_dxe_free_pool(&core->memory, entry);
	(void)cdk2_dxe_free_pool(&core->memory, relocation);
}

void cdk2_dxe_runtime_image_unregister(struct cdk2_dxe_core *core,
	struct cdk2_dxe_image *image)
{
	if (core == NULL || image == NULL || image->runtime_entry == NULL) {
		if (core != NULL && image != NULL &&
		    image->loaded_image.image_code_type == 5U) {
			UINTN index;

			for (index = 0; index < core->database.protocol_count; index++)
				if (memcmp(&core->database.protocols[index].guid,
				    &runtime_arch_guid, sizeof(runtime_arch_guid)) == 0) {
					CDK2_DXE_DIAG(CDK2_DIAG_ERROR,
						CDK2_DXE_079, EFI_NOT_FOUND);
					break;
				}
		}
		return;
	}
	CDK2_DXE_DIAG(CDK2_DIAG_DEBUG, CDK2_DXE_077, EFI_SUCCESS);
	CDK2_DXE_DIAG(CDK2_DIAG_DEBUG, CDK2_DXE_078, image->size);
	release_runtime_image(core, image->runtime_entry,
		image->runtime_relocation);
	image->runtime_entry = NULL;
	image->runtime_relocation = NULL;
}

static EFI_STATUS register_runtime_events(struct cdk2_dxe_core *core,
	struct cdk2_runtime_arch_protocol *runtime)
{
	struct cdk2_dxe_event *registered[CDK2_DXE_MAX_EVENTS];
	UINTN index, registered_count = 0;
	EFI_STATUS status = EFI_SUCCESS;

	if (core == NULL || runtime == NULL || runtime->event_head.forward == NULL ||
	    runtime->event_head.back == NULL)
		return EFI_COMPROMISED_DATA;
	for (index = 0; index < core->events.count; index++) {
		struct cdk2_dxe_event *event = &core->events.events[index];
		struct runtime_event_entry *entry;

		if (event->closed || event->runtime_entry != NULL ||
		    (event->type != 0x60000202U && (!event->grouped ||
		    memcmp(&event->group, &virtual_address_change_guid,
		    sizeof(event->group)) != 0)))
			continue;
		status = cdk2_dxe_allocate_pool(&core->memory, 6U, sizeof(*entry),
			(void **)&entry);
		if (EFI_ERROR(status))
			break;
		*entry = (struct runtime_event_entry){
			.type = 0x60000202U, .notify_tpl = event->tpl,
			.notify = event->notify, .context = event->context,
			.event = event
		};
		runtime_list_insert(&runtime->event_head, &entry->link);
		event->runtime_entry = entry;
		registered[registered_count++] = event;
	}
	if (!EFI_ERROR(status))
		return EFI_SUCCESS;
	while (registered_count != 0U) {
		struct cdk2_dxe_event *event = registered[--registered_count];
		struct runtime_event_entry *entry = event->runtime_entry;

		runtime_list_remove(&entry->link);
		event->runtime_entry = NULL;
		(void)cdk2_dxe_free_pool(&core->memory, entry);
	}
	return status;
}

static void unregister_runtime_events(struct cdk2_dxe_core *core)
{
	UINTN index;

	for (index = 0; index < core->events.count; index++) {
		struct cdk2_dxe_event *event = &core->events.events[index];
		struct runtime_event_entry *entry = event->runtime_entry;

		if (entry == NULL)
			continue;
		runtime_list_remove(&entry->link);
		event->runtime_entry = NULL;
		(void)cdk2_dxe_free_pool(&core->memory, entry);
	}
}

static void unregister_runtime_state(struct cdk2_dxe_core *core)
{
	UINTN index;

	for (index = 0; index < core->images.count; index++)
		cdk2_dxe_runtime_image_unregister(core, &core->images.images[index]);
	unregister_runtime_events(core);
}

static EFI_STATUS register_runtime_images(struct cdk2_dxe_core *core,
	struct cdk2_dxe_image **registered, UINTN *registered_count)
{
	UINTN index;
	EFI_STATUS status = EFI_SUCCESS;

	if (core == NULL || registered == NULL || registered_count == NULL)
		return EFI_INVALID_PARAMETER;
	*registered_count = 0;
	for (index = 0; index < core->images.count; index++) {
		struct cdk2_dxe_image *image = &core->images.images[index];

		if (image->handle == NULL || image->runtime_entry != NULL ||
		    image->loaded_image.image_code_type != 5U)
			continue;
		status = cdk2_dxe_runtime_image_register(core, image);
		if (EFI_ERROR(status))
			break;
		registered[(*registered_count)++] = image;
	}
	if (!EFI_ERROR(status))
		return EFI_SUCCESS;
	while (*registered_count != 0U)
		cdk2_dxe_runtime_image_unregister(core,
			registered[--(*registered_count)]);
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_locate_protocol(const EFI_GUID *guid,
	void *registration, void **interface);

static EFI_STATUS load_pe(const void *source, UINTN source_size,
			  void *destination, UINTN destination_size, void **entry, UINTN *image_size,
	void *context)
{
	unsigned long long base, size, point;
	EFI_STATUS status;

	(void)context;
	status = cdk2_native_load_pe32_plus(source, source_size,
					    (UINTN)destination, destination_size, &base, &size, &point);
	if (!EFI_ERROR(status)) {
		*entry = (void *)(UINTN)point;
		*image_size = size;
	}
	return status;
}

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
#ifdef CDK2_HOST_TEST
extern bool cdk2_dxe_policy_interrupts_get(void);
extern void cdk2_dxe_policy_interrupts_set(bool enabled);
#endif

static bool policy_interrupts_enabled(void)
{
#ifdef CDK2_HOST_TEST
	return cdk2_dxe_policy_interrupts_get();
#elif defined(__x86_64__)
	uint64_t flags;

	__asm__ volatile("pushfq; popq %0" : "=r"(flags) : : "memory");
	return (flags & (1ULL << 9)) != 0U;
#else
#error "Canonical native image authorization requires x86-64 interrupt admission"
#endif
}

static void policy_interrupts_set(bool enabled)
{
#ifdef CDK2_HOST_TEST
	cdk2_dxe_policy_interrupts_set(enabled);
#elif defined(__x86_64__)
	if (enabled)
		__asm__ volatile("sti" : : : "memory");
	else
		__asm__ volatile("cli" : : : "memory");
#else
#error "Canonical native image authorization requires x86-64 interrupt admission"
#endif
}
#endif

static struct cdk2_dxe_image *core_image(void *handle)
{
	UINTN index;

	for (index = 0; index < active_core->images.count; index++)
		if (active_core->images.images[index].handle == handle)
			return &active_core->images.images[index];
	return NULL;
}

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static bool image_transaction_published(const struct cdk2_dxe_image *image)
{
	return !EFI_ERROR(cdk2_dxe_image_transaction_validate_owned(&active_core->images,
		image->transaction, image->transaction_allocation_generation)) &&
		image->transaction->state == CDK2_DXE_IMAGE_PUBLISHED;
}
#endif

#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
static EFI_STATUS presence_image_identity(const struct cdk2_dxe_image *image,
	struct cdk2_authvar_presence_external_image_identity *identity)
{
	EFI_STATUS status;

	if (image == NULL || identity == NULL || image->transaction == NULL)
		return EFI_SECURITY_VIOLATION;
	status = cdk2_dxe_image_transaction_validate_owned(&active_core->images,
		image->transaction, image->transaction_allocation_generation);
	if (EFI_ERROR(status))
		return EFI_SECURITY_VIOLATION;
	*identity = (struct cdk2_authvar_presence_external_image_identity) {
		.handle = image->handle,
		.load_generation = image->load_generation,
		.transaction = image->transaction,
		.transaction_allocation_generation =
			image->transaction_allocation_generation,
		.transaction_generation = image->transaction == NULL ? 0U :
			image->transaction->generation,
		.base = image->base,
		.size = image->size,
		.entry = image->entry,
	};
	return EFI_SUCCESS;
}
#endif

static void signal_protocol(const EFI_GUID *guid, void *handle)
{
	UINT64 max_generation = active_core->next_notification_generation;
	UINTN index;

	for (index = 0; index < CDK2_DXE_MAX_NOTIFICATIONS; index++)
		if (active_core->notifications[index].active &&
		    active_core->notifications[index].generation <= max_generation &&
		    memcmp(guid, &active_core->notifications[index].guid,
			   sizeof(*guid)) == 0) {
			if (active_core->notifications[index].pending_count <
			    CDK2_DXE_MAX_HANDLES)
				active_core->notifications[index].pending[
					active_core->notifications[index].pending_count++] = handle;
			(void)cdk2_dxe_event_signal(&active_core->events,
				active_core->notifications[index].event);
		}
}

static UINT32 crc32(const void *buffer, UINTN size)
{
	const UINT8 *bytes = buffer;
	UINT32 crc = 0xffffffffU;
	UINTN index;
	UINT8 bit;

	for (index = 0; index < size; index++) {
		crc ^= bytes[index];
		for (bit = 0; bit < 8; bit++)
			crc = (crc >> 1) ^ (0xedb88320U &
				(0U - (crc & 1U)));
	}
	return ~crc;
}

static void refresh_service_table_crcs(void)
{
	if (active_core == NULL)
		return;
	active_core->boot_services.header.crc32 = 0;
	active_core->boot_services.header.crc32 = crc32(
		&active_core->boot_services,
		active_core->boot_services.header.header_size);
	active_core->runtime_storage->runtime_services.header.crc32 = 0;
	active_core->runtime_storage->runtime_services.header.crc32 = crc32(
		&active_core->runtime_storage->runtime_services,
		active_core->runtime_storage->runtime_services.header.header_size);
	active_core->dxe_services.header.crc32 = 0;
	active_core->dxe_services.header.crc32 = crc32(
		&active_core->dxe_services,
		active_core->dxe_services.header.header_size);
	active_core->runtime_storage->system_table.header.crc32 = 0;
	active_core->runtime_storage->system_table.header.crc32 = crc32(
		&active_core->runtime_storage->system_table,
		active_core->runtime_storage->system_table.header.header_size);
}

static void *database_allocate(UINTN size, void *context)
{
	struct cdk2_dxe_core *core = context;
	void *buffer = NULL;

	if (EFI_ERROR(cdk2_dxe_allocate_pool(&core->memory, 4, size, &buffer)))
		return NULL;
	return buffer;
}

static EFI_STATUS database_span(const void *address, UINTN *size,
	UINT64 *generation, void *context)
{
	struct cdk2_dxe_core *core = context;

	EFI_STATUS status = cdk2_dxe_memory_readable_span(&core->memory, address,
		size, generation);

	if (!EFI_ERROR(status))
		return status;
	for (UINTN index = 0U; index < core->images.count; index++) {
		struct cdk2_dxe_image *image = &core->images.images[index];
		UINTN base = (UINTN)image->base, point = (UINTN)address;

		if (image->handle == NULL || image->base == NULL || image->size == 0U ||
		    image->load_generation == 0U ||
		    base > MAX_UINTN - image->size || point < base ||
		    point >= base + image->size)
			continue;
		*size = base + image->size - point;
		*generation = image->load_generation;
		return EFI_SUCCESS;
	}
	return status;
}

static EFI_STATUS pin_image_protocol(void *handle, const EFI_GUID *guid,
	void *interface)
{
	for (UINTN image_index = 0U; image_index < active_core->images.count;
	     image_index++) {
		struct cdk2_dxe_image *image = &active_core->images.images[image_index];
		UINTN base = (UINTN)image->base, point = (UINTN)interface;

		if (image->handle == NULL || image->load_generation == 0U ||
		    base > MAX_UINTN - image->size ||
		    point < base || point >= base + image->size)
			continue;
		if (base + image->size - point < sizeof(void *))
			return EFI_COMPROMISED_DATA;
		if (image->protocol_pins == MAX_UINTN)
			return EFI_OUT_OF_RESOURCES;
		for (UINTN index = 0U; index < active_core->database.protocol_count;
		     index++) {
			struct cdk2_dxe_protocol *protocol =
				&active_core->database.protocols[index];

			if (protocol->handle != handle || protocol->interface != interface ||
			    memcmp(&protocol->guid, guid, sizeof(*guid)) != 0)
				continue;
			protocol->owner_image = image->handle;
			protocol->owner_generation = image->load_generation;
			image->protocol_pins++;
			return EFI_SUCCESS;
		}
		return EFI_NOT_FOUND;
	}
	return EFI_SUCCESS;
}

static EFI_STATUS protocol_owner_image(void *handle, const EFI_GUID *guid,
	void *interface, struct cdk2_dxe_image **owner)
{
	if (owner == NULL)
		return EFI_INVALID_PARAMETER;
	*owner = NULL;
	for (UINTN index = 0U; index < active_core->database.protocol_count; index++) {
		struct cdk2_dxe_protocol *protocol =
			&active_core->database.protocols[index];

		if (protocol->handle != handle || protocol->interface != interface ||
		    memcmp(&protocol->guid, guid, sizeof(*guid)) != 0)
			continue;
		if (protocol->owner_image == NULL)
			return protocol->owner_generation == 0U ? EFI_SUCCESS :
				EFI_COMPROMISED_DATA;
		for (UINTN image_index = 0U; image_index < active_core->images.count;
		     image_index++) {
			struct cdk2_dxe_image *image =
				&active_core->images.images[image_index];

			if (image->handle == protocol->owner_image &&
			    image->load_generation == protocol->owner_generation &&
			    image->protocol_pins != 0U) {
				*owner = image;
				return EFI_SUCCESS;
			}
		}
		return EFI_COMPROMISED_DATA;
	}
	return EFI_NOT_FOUND;
}

static EFI_STATUS set_owned_device_path(void *handle, const EFI_GUID *guid,
	void *interface)
{
	void *checked;
	UINTN available, exact;
	EFI_STATUS status = cdk2_dxe_protocol_span_set_owned(&active_core->database,
		handle, guid, interface);

	if (!EFI_ERROR(status))
		status = cdk2_dxe_handle_span(&active_core->database, handle, guid,
			&checked, &available);
	if (!EFI_ERROR(status) && checked != interface)
		status = EFI_COMPROMISED_DATA;
	if (!EFI_ERROR(status))
		status = cdk2_dxe_device_path_size(interface,
			available < 4096U ? available : 4096U, &exact);
	if (!EFI_ERROR(status))
		status = cdk2_dxe_protocol_span_shrink(&active_core->database, handle,
			guid, interface, exact);
	return status;
}

static EFI_STATUS image_interface_owner(void *interface,
	struct cdk2_dxe_image **owner, UINTN *available)
{
	UINTN point = (UINTN)interface;

	if (owner == NULL || available == NULL)
		return EFI_INVALID_PARAMETER;
	*owner = NULL;
	*available = 0U;
	for (UINTN index = 0U; index < active_core->images.count; index++) {
		struct cdk2_dxe_image *image = &active_core->images.images[index];
		UINTN base = (UINTN)image->base;

		if (image->handle == NULL || image->load_generation == 0U ||
		    image->size == 0U || base > MAX_UINTN - image->size ||
		    point < base || point >= base + image->size)
			continue;
		*available = base + image->size - point;
		if (*available < sizeof(void *))
			return EFI_COMPROMISED_DATA;
		*owner = image;
		return EFI_SUCCESS;
	}
	return EFI_SUCCESS;
}

static UINTN CDK2_MS_ABI service_raise_tpl(UINTN tpl)
{
	UINTN previous = active_core->events.current_tpl;
	if (previous > tpl)
		CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_153,
			EFI_INVALID_PARAMETER);

	if (tpl > previous) {
		if (previous < 31U && tpl >= 31U &&
		    !EFI_ERROR(service_locate_protocol(&cpu_arch_guid, NULL,
		    (void **)&tpl_cpu)) && tpl_cpu != NULL &&
		    tpl_cpu->get_interrupt_state != NULL &&
		    !EFI_ERROR(tpl_cpu->get_interrupt_state(tpl_cpu,
		    &high_tpl_interrupts_enabled)) && high_tpl_interrupts_enabled &&
		    tpl_cpu->disable_interrupt != NULL)
			(void)tpl_cpu->disable_interrupt(tpl_cpu);
		active_core->events.current_tpl = tpl;
	}
	return previous;
}

static void CDK2_MS_ABI service_restore_tpl(UINTN tpl)
{
	UINTN previous = active_core->events.current_tpl;

	if (tpl > active_core->events.current_tpl)
		CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_154,
			EFI_INVALID_PARAMETER);
	active_core->events.current_tpl = tpl;
	if (previous >= 31U && tpl < 31U && high_tpl_interrupts_enabled &&
	    tpl_cpu != NULL && tpl_cpu->enable_interrupt != NULL)
		(void)tpl_cpu->enable_interrupt(tpl_cpu);
	high_tpl_interrupts_enabled = FALSE;
	cdk2_dxe_event_dispatch_pending(&active_core->events);
}

static EFI_STATUS CDK2_MS_ABI service_allocate_pages(UINTN allocation,
						     UINT32 type, UINTN pages, UINT64 *address)
{
	if (address == NULL || allocation > 2U)
		return EFI_INVALID_PARAMETER;
	return cdk2_dxe_allocate_pages_policy(&active_core->memory, type, pages,
		allocation, address);
}

static EFI_STATUS CDK2_MS_ABI service_free_pages(UINT64 address, UINTN pages)
{
	return cdk2_dxe_free_pages(&active_core->memory, (void *)(UINTN)address,
		pages);
}

static EFI_STATUS CDK2_MS_ABI service_get_memory_map(UINTN *size, void *map,
						     UINTN *key, UINTN *descriptor_size, UINT32 *descriptor_version)
{
	return cdk2_dxe_get_memory_map(&active_core->memory, size, map, key,
		descriptor_size, descriptor_version);
}

static EFI_STATUS CDK2_MS_ABI service_allocate_pool(UINT32 type, UINTN size,
						    void **buffer)
{
	return cdk2_dxe_allocate_pool(&active_core->memory, type, size, buffer);
}

static EFI_STATUS CDK2_MS_ABI service_free_pool(void *buffer)
{
	return cdk2_dxe_free_pool(&active_core->memory, buffer);
}

static EFI_STATUS CDK2_MS_ABI service_create_event(UINT32 type, UINTN tpl,
						    cdk2_dxe_notify_fn notify, void *context, void **event)
{
	struct cdk2_runtime_arch_protocol *runtime = NULL;
	EFI_STATUS status;

	status = cdk2_dxe_event_create(&active_core->events, type, tpl, notify,
		context, NULL, event);
	if (EFI_ERROR(status) || type != 0x60000202U)
		return status;
	status = service_locate_protocol(&runtime_arch_guid, NULL,
		(void **)&runtime);
	if (status == EFI_NOT_FOUND)
		return EFI_SUCCESS;
	if (!EFI_ERROR(status) && runtime != NULL)
		status = register_runtime_events(active_core, runtime);
	if (EFI_ERROR(status) || runtime == NULL) {
		(void)cdk2_dxe_event_close(&active_core->events, *event);
		*event = NULL;
		return EFI_ERROR(status) ? status : EFI_NOT_FOUND;
	}
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_create_event_ex(UINT32 type, UINTN tpl,
						      cdk2_dxe_notify_fn notify, const void *context, const EFI_GUID *group,
	void **event)
{
	struct cdk2_runtime_arch_protocol *runtime = NULL;
	EFI_STATUS status;

	status = cdk2_dxe_event_create(&active_core->events, type, tpl, notify,
		(void *)context, group, event);
	if (EFI_ERROR(status) || group == NULL || memcmp(group,
	    &virtual_address_change_guid, sizeof(*group)) != 0)
		return status;
	status = service_locate_protocol(&runtime_arch_guid, NULL,
		(void **)&runtime);
	if (status == EFI_NOT_FOUND)
		return EFI_SUCCESS;
	if (EFI_ERROR(status) || runtime == NULL) {
		(void)cdk2_dxe_event_close(&active_core->events, *event);
		*event = NULL;
		return EFI_ERROR(status) ? status : EFI_NOT_FOUND;
	}
	status = register_runtime_events(active_core, runtime);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_event_close(&active_core->events, *event);
		*event = NULL;
	}
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_set_timer(void *event, UINTN type,
						UINT64 trigger)
{
	return cdk2_dxe_event_timer(&active_core->events, event, type, trigger);
}

static EFI_STATUS CDK2_MS_ABI service_stall(UINTN microseconds);

static EFI_STATUS CDK2_MS_ABI service_wait(UINTN count, void **events,
					   UINTN *index)
{
	EFI_STATUS status;
	UINTN current;

	if (count == 0U || events == NULL || index == NULL ||
	    active_core->events.current_tpl != 4U)
		return EFI_INVALID_PARAMETER;
	for (;;) {
		for (current = 0; current < count; current++) {
			EFI_STATUS check = cdk2_dxe_event_check(&active_core->events,
				events[current]);

			if (check == EFI_SUCCESS) {
				*index = current;
				return EFI_SUCCESS;
			}
			if (check != EFI_NOT_READY)
				return check;
		}
		status = service_stall(100U);
		if (EFI_ERROR(status))
			return status;
	}
}

static EFI_STATUS CDK2_MS_ABI service_signal(void *event)
{
	return cdk2_dxe_event_signal(&active_core->events, event);
}

static EFI_STATUS CDK2_MS_ABI service_close_event(void *event)
{
	struct cdk2_dxe_event *target = event;
	struct runtime_event_entry *runtime_entry;
	UINTN index;
	EFI_STATUS status;

	status = cdk2_dxe_event_close(&active_core->events, event);
	if (EFI_ERROR(status))
		return status;
	runtime_entry = target->runtime_entry;
	if (runtime_entry != NULL) {
		runtime_list_remove(&runtime_entry->link);
		target->runtime_entry = NULL;
		(void)cdk2_dxe_free_pool(&active_core->memory, runtime_entry);
	}
	for (index = 0; index < CDK2_DXE_MAX_NOTIFICATIONS; index++)
		if (active_core->notifications[index].active &&
		    active_core->notifications[index].event == event)
			memset(&active_core->notifications[index], 0,
				sizeof(active_core->notifications[index]));
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_check_event(void *event)
{
	return cdk2_dxe_event_check(&active_core->events, event);
}

static EFI_STATUS CDK2_MS_ABI service_install(void **handle,
					      const EFI_GUID *guid, UINTN type, void *interface)
{
	struct cdk2_dxe_image *registered_images[CDK2_DXE_MAX_IMAGES];
	UINTN registered_image_count = 0;
	EFI_STATUS status;

	if (type != 0)
		return EFI_INVALID_PARAMETER;
	status = cdk2_dxe_install(&active_core->database, handle, guid, interface);
	if (EFI_ERROR(status))
		return status;
	status = pin_image_protocol(*handle, guid, interface);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_uninstall(&active_core->database, *handle, guid,
			interface);
		return status;
	}
	if (memcmp(guid, &device_path_guid, sizeof(*guid)) == 0)
		status = set_owned_device_path(*handle, guid, interface);
#if CONFIG_CDK2_LINEAR_BOOT
	if (memcmp(guid, &xhci_control_guid, sizeof(*guid)) == 0)
		status = cdk2_dxe_protocol_span_set_owned(&active_core->database,
			*handle, guid, interface);
#endif
	if (EFI_ERROR(status)) {
		struct cdk2_dxe_image *owner = NULL;
		EFI_STATUS owner_status = protocol_owner_image(*handle, guid,
			interface, &owner);
		if (EFI_ERROR(owner_status))
			return owner_status;
		if (!EFI_ERROR(cdk2_dxe_uninstall(&active_core->database, *handle,
		    guid, interface)) && owner != NULL && owner->protocol_pins != 0U)
			owner->protocol_pins--;
		return status;
	}
	if (!EFI_ERROR(status) && memcmp(guid, &runtime_arch_guid,
	    sizeof(*guid)) == 0) {
		status = register_runtime_images(active_core, registered_images,
			&registered_image_count);
		if (!EFI_ERROR(status))
			status = register_runtime_events(active_core, interface);
		if (EFI_ERROR(status)) {
			while (registered_image_count != 0U)
				cdk2_dxe_runtime_image_unregister(active_core,
					registered_images[--registered_image_count]);
			struct cdk2_dxe_image *owner = NULL;
			EFI_STATUS owner_status = protocol_owner_image(*handle, guid,
				interface, &owner);
			if (EFI_ERROR(owner_status))
				return owner_status;
			if (!EFI_ERROR(cdk2_dxe_uninstall(&active_core->database, *handle,
			    guid, interface)) && owner != NULL && owner->protocol_pins != 0U)
				owner->protocol_pins--;
		}
	}
	if (!EFI_ERROR(status)) {
		if (memcmp(guid, &timer_arch_guid, sizeof(*guid)) == 0 &&
		    interface != NULL &&
		    ((struct cdk2_timer_arch_protocol *)interface)->register_handler != NULL)
			(void)((struct cdk2_timer_arch_protocol *)interface)->register_handler(
				interface, event_timer_tick);
		signal_protocol(guid, *handle);
		refresh_service_table_crcs();
	}
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_reinstall(void *handle,
						const EFI_GUID *guid, void *old_interface, void *new_interface)
{
	struct cdk2_dxe_image *registered_images[CDK2_DXE_MAX_IMAGES];
	struct cdk2_dxe_protocol previous = { 0 };
	UINTN registered_image_count = 0;
	BOOLEAN runtime;
	EFI_STATUS status;
	struct cdk2_dxe_image *old_owner = NULL, *new_owner = NULL;
	UINTN new_available, device_path_exact = 0U;

	if (guid == NULL)
		return EFI_INVALID_PARAMETER;
#if CONFIG_CDK2_LINEAR_BOOT
	/* Private controls have one installation lifetime, not a replaceable ABI. */
	{
		static const EFI_GUID timer_guid = CDK2_LOCAL_APIC_TIMER_CONTROL_GUID;

		if (memcmp(guid, &xhci_control_guid, sizeof(*guid)) == 0 ||
		    memcmp(guid, &timer_guid, sizeof(*guid)) == 0
#if CONFIG_PAYLOAD_DMA_HANDOFF
		    || memcmp(guid, &pci_dma_control_guid, sizeof(*guid)) == 0
#endif
		    )
			return EFI_UNSUPPORTED;
	}
#endif
	for (UINTN index = 0U; index < active_core->database.protocol_count; index++)
		if (active_core->database.protocols[index].handle == handle &&
		    memcmp(&active_core->database.protocols[index].guid, guid,
			sizeof(*guid)) == 0 &&
		    active_core->database.protocols[index].interface == old_interface) {
			previous = active_core->database.protocols[index];
			break;
		}
	runtime = memcmp(guid, &runtime_arch_guid, sizeof(*guid)) == 0;
	status = protocol_owner_image(handle, guid, old_interface, &old_owner);
	if (EFI_ERROR(status))
		return status;
	status = image_interface_owner(new_interface, &new_owner, &new_available);
	if (EFI_ERROR(status))
		return status;
	(void)new_available;
	if ((old_owner != NULL || new_owner != NULL) && runtime)
		return EFI_UNSUPPORTED;
	if (new_owner != NULL && new_owner != old_owner &&
	    new_owner->protocol_pins == MAX_UINTN)
		return EFI_OUT_OF_RESOURCES;
	if (memcmp(guid, &device_path_guid, sizeof(*guid)) == 0) {
		UINT64 generation;
		UINTN available;

		status = database_span(new_interface, &available, &generation,
			active_core);
		if (!EFI_ERROR(status))
			status = cdk2_dxe_device_path_size(new_interface,
				available < 4096U ? available : 4096U,
				&device_path_exact);
		if (EFI_ERROR(status))
			return status;
	}
	if (!runtime) {
		status = cdk2_dxe_reinstall(&active_core->database, handle, guid,
			old_interface, new_interface);
		if (EFI_ERROR(status))
			return status;
		for (UINTN index = 0U; index < active_core->database.protocol_count;
		     index++) {
			struct cdk2_dxe_protocol *protocol =
				&active_core->database.protocols[index];

			if (protocol->handle != handle ||
			    protocol->interface != new_interface ||
			    memcmp(&protocol->guid, guid, sizeof(*guid)) != 0)
				continue;
			if (new_owner != NULL) {
				protocol->owner_image = new_owner->handle;
				protocol->owner_generation = new_owner->load_generation;
			}
			if (device_path_exact != 0U) {
				UINT64 generation;
				UINTN available;

				(void)database_span(new_interface, &available, &generation,
					active_core);
				protocol->interface_size = device_path_exact;
				protocol->interface_generation = generation;
				protocol->interface_dynamic = TRUE;
			}
			break;
		}
		if (old_owner != new_owner) {
			if (old_owner != NULL)
				old_owner->protocol_pins--;
			if (new_owner != NULL)
				new_owner->protocol_pins++;
		}
		signal_protocol(guid, handle);
		refresh_service_table_crcs();
		return EFI_SUCCESS;
	}
	status = cdk2_dxe_reinstall(&active_core->database, handle, guid,
		old_interface, new_interface);
	if (EFI_ERROR(status))
		return status;
	if (runtime)
		unregister_runtime_state(active_core);
	status = EFI_SUCCESS;
	if (memcmp(guid, &device_path_guid, sizeof(*guid)) == 0)
		status = set_owned_device_path(handle, guid, new_interface);
	if (!EFI_ERROR(status) && runtime) {
		status = register_runtime_images(active_core, registered_images,
			&registered_image_count);
		if (!EFI_ERROR(status))
			status = register_runtime_events(active_core, new_interface);
	}
	if (EFI_ERROR(status)) {
		struct cdk2_dxe_image *new_owner = NULL;
		while (registered_image_count != 0U)
			cdk2_dxe_runtime_image_unregister(active_core,
				registered_images[--registered_image_count]);
		EFI_STATUS owner_status = protocol_owner_image(handle, guid,
			new_interface, &new_owner);
		if (EFI_ERROR(owner_status))
			return owner_status;
		EFI_STATUS rollback = cdk2_dxe_reinstall(&active_core->database,
			handle, guid, new_interface, old_interface);

		if (!EFI_ERROR(rollback)) {
			if (new_owner != NULL && new_owner->protocol_pins != 0U)
				new_owner->protocol_pins--;
			if (previous.owner_image != NULL)
				for (UINTN owner_index = 0U;
				     owner_index < active_core->images.count; owner_index++)
					if (active_core->images.images[owner_index].handle ==
					    previous.owner_image &&
					    active_core->images.images[owner_index].load_generation ==
					    previous.owner_generation)
						active_core->images.images[owner_index].protocol_pins++;
			for (UINTN index = 0U;
			     index < active_core->database.protocol_count; index++)
				if (active_core->database.protocols[index].handle == handle &&
				    memcmp(&active_core->database.protocols[index].guid, guid,
					sizeof(*guid)) == 0 &&
				    active_core->database.protocols[index].interface ==
					old_interface) {
					active_core->database.protocols[index].interface_size =
						previous.interface_size;
					active_core->database.protocols[index].interface_generation =
						previous.interface_generation;
					active_core->database.protocols[index].interface_dynamic =
						previous.interface_dynamic;
					active_core->database.protocols[index].owner_image =
						previous.owner_image;
					active_core->database.protocols[index].owner_generation =
						previous.owner_generation;
					break;
				}
		}
		if (runtime && !EFI_ERROR(rollback)) {
			registered_image_count = 0;
			(void)register_runtime_images(active_core, registered_images,
				&registered_image_count);
			(void)register_runtime_events(active_core, old_interface);
		}
		return status;
	}
	signal_protocol(guid, handle);
	refresh_service_table_crcs();
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_uninstall(void *handle,
						const EFI_GUID *guid, void *interface)
{
	EFI_STATUS status;

	struct cdk2_dxe_image *owner = NULL;
	EFI_STATUS owner_status = protocol_owner_image(handle, guid, interface,
		&owner);
	if (EFI_ERROR(owner_status))
		return owner_status;
	status = cdk2_dxe_uninstall(&active_core->database, handle, guid,
		interface);
	if (!EFI_ERROR(status) && owner != NULL && owner->protocol_pins != 0U)
		owner->protocol_pins--;
	if (!EFI_ERROR(status)) {
		if (memcmp(guid, &runtime_arch_guid, sizeof(*guid)) == 0)
			unregister_runtime_state(active_core);
		refresh_service_table_crcs();
	}
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_handle(void *handle,
					     const EFI_GUID *guid, void **interface)
{
	EFI_STATUS status = cdk2_dxe_handle(&active_core->database, handle, guid,
		interface);

	if (status == EFI_NOT_FOUND)
		trace_image_not_found(0x1830U, guid, handle);
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_open(void *handle, const EFI_GUID *guid,
					   void **interface, void *agent, void *controller, UINT32 attributes)
{
	EFI_STATUS status = cdk2_dxe_open(&active_core->database, handle, guid, interface,
		agent, controller, attributes);

	if (status == EFI_NOT_FOUND)
		trace_image_not_found(0x1831U, guid, handle);
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_close(void *handle, const EFI_GUID *guid,
					    void *agent, void *controller)
{
	return cdk2_dxe_close(&active_core->database, handle, guid, agent,
		controller);
}

static EFI_STATUS CDK2_MS_ABI service_register_notify(const EFI_GUID *guid,
						      void *event, void **registration)
{
	UINTN index;

	if (guid == NULL || event == NULL || registration == NULL)
		return EFI_INVALID_PARAMETER;
	if (cdk2_dxe_event_check(&active_core->events, event) ==
	    EFI_INVALID_PARAMETER)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < CDK2_DXE_MAX_NOTIFICATIONS; index++)
		if (!active_core->notifications[index].active)
			break;
	if (index == CDK2_DXE_MAX_NOTIFICATIONS ||
	    active_core->next_notification_generation == MAX_UINT64)
		return EFI_OUT_OF_RESOURCES;
	active_core->notifications[index].guid = *guid;
	active_core->notifications[index].event = event;
	active_core->notifications[index].cursor = 0;
	active_core->notifications[index].pending_count = 0U;
	active_core->notifications[index].generation =
		++active_core->next_notification_generation;
	for (UINTN protocol = 0U;
	     protocol < active_core->database.protocol_count; protocol++)
		if (memcmp(guid, &active_core->database.protocols[protocol].guid,
		    sizeof(*guid)) == 0 &&
		    active_core->notifications[index].pending_count <
		    CDK2_DXE_MAX_HANDLES)
			active_core->notifications[index].pending[
				active_core->notifications[index].pending_count++] =
				active_core->database.protocols[protocol].handle;
	active_core->notifications[index].active = TRUE;
	*registration = &active_core->notifications[index];
	return EFI_SUCCESS;
}

static EFI_STATUS locate_fill(UINTN search, const EFI_GUID *guid, void *key,
			      UINTN *size, void **buffer)
{
	UINTN index, found = 0, start = 0, notification = MAX_UINTN;
	UINTN next_cursor = 0;

	if (size == NULL || (buffer == NULL && *size != 0))
		return EFI_INVALID_PARAMETER;
	if (search == 0) {
		found = active_core->database.handle_count;
	} else if (search == 2 && guid != NULL) {
		for (index = 0; index < active_core->database.protocol_count; index++)
			if (memcmp(guid,
			    &active_core->database.protocols[index].guid,
			    sizeof(*guid)) == 0)
				found++;
	} else if (search == 1 && key != NULL) {
		UINTN base = (UINTN)&active_core->notifications[0];
		UINTN address = (UINTN)key;

		if (address < base || address - base >=
		    sizeof(active_core->notifications) || (address - base) %
		    sizeof(active_core->notifications[0]) != 0)
			return EFI_INVALID_PARAMETER;
		notification = (address - base) /
			sizeof(active_core->notifications[0]);
		if (notification >= CDK2_DXE_MAX_NOTIFICATIONS ||
		    !active_core->notifications[notification].active)
			return EFI_INVALID_PARAMETER;
		guid = &active_core->notifications[notification].guid;
		start = active_core->notifications[notification].cursor;
		if (start < active_core->notifications[notification].pending_count) {
			found = 1U;
			next_cursor = start + 1U;
		}
	} else {
		return EFI_INVALID_PARAMETER;
	}
	if (found == 0)
		return EFI_NOT_FOUND;
	if (*size < found * sizeof(*buffer)) {
		*size = found * sizeof(*buffer);
		return EFI_BUFFER_TOO_SMALL;
	}
	found = 0;
	if (search == 1) {
		buffer[0] = active_core->notifications[notification].pending[start];
		found = 1U;
	} else if (search == 2) {
		for (index = 0; index < active_core->database.protocol_count; index++)
			if (memcmp(guid,
			    &active_core->database.protocols[index].guid,
			    sizeof(*guid)) == 0)
				buffer[found++] =
					active_core->database.protocols[index].handle;
	} else {
		for (index = start; index < active_core->database.handle_count; index++) {
			if (search == 0)
				buffer[found++] = active_core->database.handles[index];
			if (search == 1 && found == 1)
				break;
		}
	}
	*size = found * sizeof(*buffer);
	if (notification != MAX_UINTN) {
		active_core->notifications[notification].cursor = next_cursor;
		if (next_cursor == active_core->notifications[notification].pending_count) {
			active_core->notifications[notification].cursor = 0U;
			active_core->notifications[notification].pending_count = 0U;
		}
	}
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_locate_handle(UINTN search,
						    const EFI_GUID *guid, void *key, UINTN *size, void **buffer)
{
	EFI_STATUS status = locate_fill(search, guid, key, size, buffer);

	if (status == EFI_NOT_FOUND)
		trace_image_not_found(0x1832U, guid, NULL);
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_locate_handle_buffer(UINTN search,
							   const EFI_GUID *guid, void *key, UINTN *count, void ***handles)
{
	UINTN size = 0;
	EFI_STATUS status;

	if (count == NULL || handles == NULL)
		return EFI_INVALID_PARAMETER;
	status = locate_fill(search, guid, key, &size, NULL);
	if (status != EFI_BUFFER_TOO_SMALL) {
		if (status == EFI_NOT_FOUND)
			trace_image_not_found(0x1833U, guid, NULL);
		return status;
	}
	status = cdk2_dxe_allocate_pool(&active_core->memory, 4, size,
					(void **)handles);
	if (EFI_ERROR(status))
		return status;
	status = locate_fill(search, guid, key, &size, *handles);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_free_pool(&active_core->memory, *handles);
		return status;
	}
	*count = size / sizeof(**handles);
	return EFI_SUCCESS;
}

static BOOLEAN device_path_prefix(const UINT8 *candidate, const UINT8 *path,
	UINTN *prefix)
{
	UINTN offset = 0;

	while (offset <= 4096U - 4U) {
		UINTN candidate_length = candidate[offset + 2] |
			((UINTN)candidate[offset + 3] << 8);
		UINTN path_length = path[offset + 2] |
			((UINTN)path[offset + 3] << 8);

		if (candidate_length < 4U || candidate_length > 4096U - offset ||
		    path_length < 4U || path_length > 4096U - offset)
			return FALSE;
		if (candidate[offset] == 0x7f && candidate[offset + 1] == 0xff) {
			*prefix = offset;
			return TRUE;
		}
		if (path_length != candidate_length)
			return FALSE;
		if ((path[offset] == 0x7f && path[offset + 1] == 0xff) ||
		    memcmp(candidate + offset, path + offset, candidate_length) != 0)
			return FALSE;
		offset += candidate_length;
	}
	return FALSE;
}

static EFI_STATUS CDK2_MS_ABI service_locate_device_path(
	const EFI_GUID *guid, void **path, void **handle)
{
	UINTN index, best = 0;
	void *best_handle = NULL;

	if (guid == NULL || path == NULL || *path == NULL || handle == NULL)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < active_core->database.handle_count; index++) {
		void *interface, *candidate;
		UINTN prefix;

		if (cdk2_dxe_handle(&active_core->database,
		    active_core->database.handles[index], guid, &interface) != EFI_SUCCESS ||
		    cdk2_dxe_handle(&active_core->database,
		    active_core->database.handles[index], &device_path_guid,
		    &candidate) != EFI_SUCCESS)
			continue;
		if (!device_path_prefix(candidate, *path, &prefix))
			continue;
		if (best_handle == NULL || prefix > best) {
			best = prefix;
			best_handle = active_core->database.handles[index];
		}
	}
	if (best_handle == NULL) {
		trace_image_not_found(0x1834U, guid, NULL);
		return EFI_NOT_FOUND;
	}
	*handle = best_handle;
	*path = (UINT8 *)*path + best;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_protocols_per_handle(void *handle,
							   EFI_GUID ***protocols, UINTN *count)
{
	EFI_GUID **result;
	UINTN index, found = 0;
	EFI_STATUS status;

	if (handle == NULL || protocols == NULL || count == NULL)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < active_core->database.protocol_count; index++)
		if (active_core->database.protocols[index].handle == handle)
			found++;
	if (found == 0)
		return EFI_NOT_FOUND;
	status = cdk2_dxe_allocate_pool(&active_core->memory, 4,
					found * sizeof(*result), (void **)&result);
	if (EFI_ERROR(status))
		return status;
	found = 0;
	for (index = 0; index < active_core->database.protocol_count; index++)
		if (active_core->database.protocols[index].handle == handle)
			result[found++] = &active_core->database.protocols[index].guid;
	*protocols = result;
	*count = found;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_open_information(void *handle,
						       const EFI_GUID *guid, struct open_information **information, UINTN *count)
{
	struct open_information *result;
	UINTN index, found = 0;
	EFI_STATUS status;

	if (handle == NULL || guid == NULL || information == NULL || count == NULL)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < active_core->database.open_count; index++)
		if (active_core->database.opens[index].handle == handle &&
		    memcmp(guid, &active_core->database.opens[index].guid,
			   sizeof(*guid)) == 0)
			found++;
	if (found == 0)
		return EFI_NOT_FOUND;
	status = cdk2_dxe_allocate_pool(&active_core->memory, 4,
					found * sizeof(*result), (void **)&result);
	if (EFI_ERROR(status))
		return status;
	found = 0;
	for (index = 0; index < active_core->database.open_count; index++) {
		struct cdk2_dxe_open *open = &active_core->database.opens[index];

		if (open->handle != handle || memcmp(guid, &open->guid,
						     sizeof(*guid)) != 0)
			continue;
		result[found++] = (struct open_information){ open->agent,
			open->controller, open->attributes, open->count };
	}
	*information = result;
	*count = found;
	return EFI_SUCCESS;
}

#if defined(__x86_64__)
#define MS_VA_LIST __builtin_ms_va_list
#define MS_VA_START(list, last) __builtin_ms_va_start(list, last)
#define MS_VA_END(list) __builtin_ms_va_end(list)
#define MS_VA_ARG(list, type) __builtin_va_arg(list, type)
#else
#define MS_VA_LIST va_list
#define MS_VA_START(list, last) va_start(list, last)
#define MS_VA_END(list) va_end(list)
#define MS_VA_ARG(list, type) va_arg(list, type)
#endif

static EFI_STATUS CDK2_MS_ABI service_install_multiple(void **handle, ...)
{
	const EFI_GUID *guids[64];
	void *interfaces[64];
	MS_VA_LIST arguments;
	UINTN count = 0, index;
	EFI_STATUS status = EFI_SUCCESS;
	void *original_handle;

	if (handle == NULL)
		return EFI_INVALID_PARAMETER;
	original_handle = *handle;
	MS_VA_START(arguments, handle);
	while (count < 64 && (guids[count] =
	    MS_VA_ARG(arguments, const EFI_GUID *)) != NULL) {
		interfaces[count] = MS_VA_ARG(arguments, void *);
		count++;
	}
	MS_VA_END(arguments);
	if (count == 0 || count == 64)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < count; index++) {
		status = service_install(handle, guids[index], 0, interfaces[index]);
		if (EFI_ERROR(status))
			break;
	}
	if (EFI_ERROR(status))
		while (index != 0) {
			index--;
			(void)service_uninstall(*handle, guids[index], interfaces[index]);
		}
	if (EFI_ERROR(status))
		*handle = original_handle;
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_uninstall_multiple(void *handle, ...)
{
	const EFI_GUID *guids[64];
	void *interfaces[64];
	struct cdk2_dxe_protocol removed[64];
	MS_VA_LIST arguments;
	UINTN count = 0, index;
	EFI_STATUS status = EFI_SUCCESS;

	if (handle == NULL)
		return EFI_INVALID_PARAMETER;
	MS_VA_START(arguments, handle);
	while (count < 64 && (guids[count] =
	    MS_VA_ARG(arguments, const EFI_GUID *)) != NULL) {
		interfaces[count] = MS_VA_ARG(arguments, void *);
		count++;
	}
	MS_VA_END(arguments);
	if (count == 0 || count == 64)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < count; index++) {
		UINTN protocol;

		for (protocol = 0U; protocol < active_core->database.protocol_count;
		     protocol++)
			if (active_core->database.protocols[protocol].handle == handle &&
			    memcmp(&active_core->database.protocols[protocol].guid,
				guids[index], sizeof(*guids[index])) == 0 &&
			    active_core->database.protocols[protocol].interface ==
				interfaces[index])
				break;
		if (protocol == active_core->database.protocol_count) {
			status = EFI_NOT_FOUND;
			break;
		}
		removed[index] = active_core->database.protocols[protocol];
		status = service_uninstall(handle, guids[index], interfaces[index]);
		if (EFI_ERROR(status))
			break;
	}
	if (EFI_ERROR(status))
		while (index != 0) {
			index--;
			if (!EFI_ERROR(cdk2_dxe_restore(&active_core->database,
			    handle, guids[index], interfaces[index]))) {
				struct cdk2_dxe_protocol *restored =
					&active_core->database.protocols[
						active_core->database.protocol_count - 1U];

				restored->interface_size = removed[index].interface_size;
				restored->interface_generation =
					removed[index].interface_generation;
				restored->interface_dynamic = removed[index].interface_dynamic;
				signal_protocol(guids[index], handle);
			}
		}
	if (EFI_ERROR(status))
		refresh_service_table_crcs();
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_locate_protocol(const EFI_GUID *guid,
					       void *registration, void **interface)
{
	UINTN index, start = 0, notification = MAX_UINTN;

	if (guid == NULL || interface == NULL)
		return EFI_INVALID_PARAMETER;
	if (registration != NULL) {
		UINTN base = (UINTN)&active_core->notifications[0];
		UINTN address = (UINTN)registration;

		if (address < base || address - base >=
		    sizeof(active_core->notifications) || (address - base) %
		    sizeof(active_core->notifications[0]) != 0)
			return EFI_INVALID_PARAMETER;
		notification = (address - base) /
			sizeof(active_core->notifications[0]);
		if (!active_core->notifications[notification].active ||
		    memcmp(guid, &active_core->notifications[notification].guid,
		    sizeof(*guid)) != 0)
			return EFI_INVALID_PARAMETER;
		start = active_core->notifications[notification].cursor;
		if (start >= active_core->notifications[notification].pending_count)
			return EFI_NOT_FOUND;
		if (EFI_ERROR(cdk2_dxe_handle(&active_core->database,
		    active_core->notifications[notification].pending[start], guid,
		    interface)))
			return EFI_NOT_FOUND;
		active_core->notifications[notification].cursor++;
		if (active_core->notifications[notification].cursor ==
		    active_core->notifications[notification].pending_count) {
			active_core->notifications[notification].cursor = 0U;
			active_core->notifications[notification].pending_count = 0U;
		}
		return EFI_SUCCESS;
	}
	for (index = start; index < active_core->database.protocol_count; index++)
		if (memcmp(guid, &active_core->database.protocols[index].guid,
			   sizeof(*guid)) == 0) {
			*interface = active_core->database.protocols[index].interface;
			if (notification != MAX_UINTN)
				active_core->notifications[notification].cursor = index + 1U;
			return EFI_SUCCESS;
		}
	trace_image_not_found(0x1835U, guid, NULL);
	return EFI_NOT_FOUND;
}

static EFI_STATUS CDK2_MS_ABI
service_install_configuration_table(const EFI_GUID *guid, void *table)
{
	UINTN index;
	EFI_STATUS status = EFI_SUCCESS;

	if (guid == NULL)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < active_core->runtime_storage->system_table.number_of_table_entries;
	    index++)
		if (memcmp(guid, &active_core->runtime_storage->configuration_tables[index].guid,
			   sizeof(*guid)) == 0) {
			if (table == NULL) {
				memmove(&active_core->runtime_storage->configuration_tables[index],
					&active_core->runtime_storage->configuration_tables[index + 1],
					(active_core->runtime_storage->system_table.number_of_table_entries -
					index - 1U) * sizeof(active_core->runtime_storage->configuration_tables[0]));
				active_core->runtime_storage->system_table.number_of_table_entries--;
			} else {
				active_core->runtime_storage->configuration_tables[index].table = table;
			}
			goto update_crc;
		}
	if (table == NULL)
		return EFI_NOT_FOUND;
	if (index == CDK2_DXE_MAX_CONFIGURATION_TABLES)
		return EFI_OUT_OF_RESOURCES;
	active_core->runtime_storage->configuration_tables[index] =
		(struct cdk2_dxe_configuration_table){ *guid, table };
	active_core->runtime_storage->system_table.number_of_table_entries++;
update_crc:
	refresh_service_table_crcs();
	return status;
}

EFI_STATUS cdk2_dxe_load_image(struct cdk2_dxe_core *core, bool boot_policy,
	void *parent, void *path, void *source, UINTN source_size, void **handle,
	const struct cdk2_dxe_driver *linked_driver)
{
	struct security2_protocol *security2 = NULL;
	struct cdk2_dxe_image *image;
	struct cdk2_dxe_image_transaction *transaction = NULL;
	UINT64 transaction_allocation_generation = 0U;
	void *owned_source = NULL;
	void *owned_path = NULL;
	void *owned_device_path = NULL;
	void *verification_source = NULL;
	void *verification_path = NULL;
	UINT64 verification_source_generation = 0U;
	UINT64 verification_path_generation = 0U;
	void *device_handle = active_core->firmware_volume_handle;
	UINTN path_size = 0;
	UINTN file_path_offset = 0;
	bool native_load_attempted = false;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	struct cdk2_security_router *policy_router = NULL;
	bool policy_interrupts = false;
	UINTN policy_tpl = 0U;
	bool policy_scope = false;
#endif
#if !CONFIG_CDK2_STRICT_DIRECT_RUNTIME
	UINT32 authentication;
#endif
	EFI_STATUS status;
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	BOOLEAN security2_authenticated = FALSE;
#endif

	if (core == NULL || core != active_core)
		return EFI_INVALID_PARAMETER;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (core->images.load != load_pe || core->images.load_context != NULL)
		return EFI_UNSUPPORTED;
#endif
	if (linked_driver != NULL) {
		bool admitted = false;

		if (boot_policy || core->dispatcher.count > CDK2_DXE_MAX_DRIVERS ||
		    core->dispatcher.count != core->dispatcher.direct_count)
			return EFI_COMPROMISED_DATA;
		for (size_t index = 0U; index < core->dispatcher.count; index++) {
			const struct cdk2_dxe_driver *driver = &core->dispatcher.drivers[index];

			if (driver == linked_driver) {
				admitted = driver->direct && !driver->started && !driver->failed &&
					driver->direct_disposition == CDK2_DXE_DIRECT_PENDING &&
					driver->image == source && driver->image_size == source_size;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
				struct cdk2_direct_image_record record;

				if (core->dispatcher.direct_table.record_count !=
				    core->dispatcher.count + 1U ||
				    EFI_ERROR(cdk2_direct_image_table_record(
					&core->dispatcher.direct_table, (uint32_t)index + 1U,
					&record)) || record.source != source ||
				    record.source_size != source_size ||
				    memcmp(&record.guid, &driver->guid, sizeof(record.guid)) ||
				    record.role != driver->direct_role ||
				    (record.role != CDK2_DIRECT_IMAGE_ROLE_BOOT_SERVICE_DRIVER &&
				     record.role != CDK2_DIRECT_IMAGE_ROLE_RUNTIME_DRIVER) ||
				    core->images.count == 0U || core->images.images[0].handle != parent ||
				    !core->images.images[0].started)
					admitted = false;
#endif
			}
		}
		if (!admitted)
			return EFI_COMPROMISED_DATA;
	}

#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
#else
	status = cdk2_authvar_presence_lifecycle_seal();
	if (EFI_ERROR(status))
		return status;
#endif

#ifdef CDK2_DEBUG
	if (parent != NULL && core_image(parent) == NULL) {
		CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_144,
			EFI_INVALID_PARAMETER);
		return EFI_INVALID_PARAMETER;
	}
#endif
	if (path == NULL && source == NULL)
		return EFI_INVALID_PARAMETER;
	if (source == NULL) {
		UINT8 *node = path;
		UINTN offset = 0;
		EFI_GUID *file_guid = NULL;
		CHAR16 *file_path = NULL;
		void *file_path_node = NULL;

		while (offset <= 4096U - 4U) {
			UINTN length = node[offset + 2] |
				((UINTN)node[offset + 3] << 8);

			if (length < 4 || length > 4096U - offset)
				return EFI_INVALID_PARAMETER;
			if (node[offset] == 4 && node[offset + 1] == 6 &&
			    length == 20)
				file_guid = (void *)(node + offset + 4);
			if (node[offset] == 4 && node[offset + 1] == 4 && length >= 6) {
				file_path = (void *)(node + offset + 4);
				file_path_node = node + offset;
			}
			if (node[offset] == 0x7f && node[offset + 1] == 0xff) {
				path_size = offset + length;
				break;
			}
			offset += length;
		}
		if (path_size == 0)
			return EFI_INVALID_PARAMETER;
		if (file_guid != NULL) {
#if CONFIG_CDK2_STRICT_DIRECT_RUNTIME
			return EFI_UNSUPPORTED;
#else
			struct cdk2_dxe_fv_protocol *volume = NULL;
			void *remaining = path;

			status = service_locate_device_path(&fv2_guid, &remaining,
				&device_handle);
			if (!EFI_ERROR(status))
				status = service_handle(device_handle, &fv2_guid,
					(void **)&volume);
			if (!EFI_ERROR(status) && (volume == NULL ||
			    volume->read_section == NULL))
				status = EFI_UNSUPPORTED;
			if (!EFI_ERROR(status))
				status = volume->read_section(volume, file_guid, 0x10, 0,
					&owned_source, &source_size, &authentication);
#endif
		} else if (file_path != NULL) {
			struct cdk2_fat_simple_fs_protocol *fs = NULL;
			struct cdk2_fat_file_protocol *root = NULL, *file = NULL;
			void *info = NULL;
			void *remaining = path;
			UINTN info_size = 0;

			status = service_locate_device_path(&simple_fs_guid, &remaining,
				&device_handle);
#ifdef CDK2_DEBUG
			cdk2_diag_phase("LoadImage simple filesystem", "locate",
				status, 0U);
#endif
			if (!EFI_ERROR(status) && remaining != file_path_node)
				status = EFI_NOT_FOUND;
			if (!EFI_ERROR(status))
				status = cdk2_dxe_handle(&active_core->database,
					device_handle, &simple_fs_guid, (void **)&fs);
#ifdef CDK2_DEBUG
			cdk2_diag_phase("LoadImage simple filesystem", "handle",
				status, 0U);
#endif
			if (!EFI_ERROR(status) && fs != NULL)
				status = fs->open_volume(fs, &root);

#ifdef CDK2_DEBUG
			cdk2_diag_phase("LoadImage FAT volume", "open", status, 0U);
#endif
			if (!EFI_ERROR(status))
				status = root->open(root, &file, file_path, 1, 0);

#ifdef CDK2_DEBUG
			cdk2_diag_phase("LoadImage boot file", "open", status, 0U);
#endif
			if (!EFI_ERROR(status)) {
				status = file->get_info(file, (EFI_GUID *)&file_info_guid,
					&info_size, NULL);
				if (status == EFI_BUFFER_TOO_SMALL)
					status = cdk2_dxe_allocate_pool(&active_core->memory,
						4, info_size, &info);
				if (!EFI_ERROR(status))
					status = file->get_info(file,
						(EFI_GUID *)&file_info_guid, &info_size, info);
				if (!EFI_ERROR(status)) {
					source_size = ((UINT64 *)info)[1];
					cdk2_diag_value(CDK2_DIAG_DXE_MAIN,
						"LoadImage boot file bytes", source_size);
					status = cdk2_dxe_allocate_pool(&active_core->memory,
						4, source_size, &owned_source);
				}
				if (!EFI_ERROR(status))
					status = file->read(file, &source_size, owned_source);

#ifdef CDK2_DEBUG
				cdk2_diag_phase("LoadImage boot file", "read", status, 0U);
#endif
			}
			if (info != NULL)
				(void)cdk2_dxe_free_pool(&active_core->memory, info);
			if (file != NULL)
				(void)file->close(file);
			if (root != NULL)
				(void)root->close(root);
		} else {
			return EFI_NOT_FOUND;
		}
		if (EFI_ERROR(status))
			if (owned_source != NULL)
				(void)cdk2_dxe_free_pool(&active_core->memory,
					owned_source);
		if (EFI_ERROR(status))
			return status;
		source = owned_source;
	} else if (path != NULL) {
		void *remaining = path;

		status = service_locate_device_path(&device_path_guid, &remaining,
			&device_handle);
		if (EFI_ERROR(status) && status != EFI_NOT_FOUND)
			return status;
	}
	if (path != NULL && path_size == 0U) {
		const UINT8 *node = path;
		UINTN offset = 0U;

		while (offset <= 4096U - 4U) {
			UINTN length = node[offset + 2U] |
				((UINTN)node[offset + 3U] << 8U);

			if (length < 4U || length > 4096U - offset)
				break;
			if (node[offset] == 0x7fU && node[offset + 1U] == 0xffU) {
				path_size = offset + length;
				break;
			}
			offset += length;
		}
		if (path_size == 0U) {
			status = EFI_INVALID_PARAMETER;
			goto transaction_fail;
		}
	}
	status = cdk2_dxe_image_transaction_prepare(&active_core->images,
		source, source_size, path, path_size, &transaction,
		&transaction_allocation_generation);
	if (EFI_ERROR(status))
		goto transaction_fail;
	if (owned_source != NULL) {
		(void)cdk2_dxe_free_pool(&active_core->memory, owned_source);
		owned_source = NULL;
	}
	status = service_locate_protocol(&security2_guid, NULL,
		(void **)&security2);
	if (!EFI_ERROR(status)) {
		EFI_STATUS source_release_status = EFI_SUCCESS;
		EFI_STATUS path_release_status = EFI_SUCCESS;
		UINT64 current_generation;

		if (security2 == NULL || security2->file_authentication == NULL)
			status = EFI_DEVICE_ERROR;
		else
			status = cdk2_dxe_allocate_pool(&active_core->memory, 4U,
				transaction->source_size, &verification_source);
		if (!EFI_ERROR(status))
			status = cdk2_dxe_memory_allocation_generation(
				&active_core->memory, verification_source,
				transaction->source_size,
				&verification_source_generation);
		if (!EFI_ERROR(status)) {
			memcpy(verification_source, transaction->source,
				transaction->source_size);
			status = cdk2_dxe_allocate_pool(&active_core->memory, 4U,
				transaction->device_path_size, &verification_path);
		}
		if (!EFI_ERROR(status))
			status = cdk2_dxe_memory_allocation_generation(
				&active_core->memory, verification_path,
				transaction->device_path_size,
				&verification_path_generation);
		if (!EFI_ERROR(status)) {
			memcpy(verification_path, transaction->device_path,
				transaction->device_path_size);
			status = security2->file_authentication(security2,
				verification_path, verification_source,
				transaction->source_size, boot_policy);
		}
		if (verification_path != NULL) {
			path_release_status =
				cdk2_dxe_memory_allocation_generation(
					&active_core->memory, verification_path,
					transaction->device_path_size,
					&current_generation);
			if (!EFI_ERROR(path_release_status) && current_generation ==
			    verification_path_generation)
				path_release_status = cdk2_dxe_free_pool(
					&active_core->memory, verification_path);
			else
				path_release_status = EFI_COMPROMISED_DATA;
			verification_path = NULL;
		}
		if (verification_source != NULL) {
			source_release_status =
				cdk2_dxe_memory_allocation_generation(
					&active_core->memory, verification_source,
					transaction->source_size,
					&current_generation);
			if (!EFI_ERROR(source_release_status) && current_generation ==
			    verification_source_generation)
				source_release_status = cdk2_dxe_free_pool(
					&active_core->memory, verification_source);
			else
				source_release_status = EFI_COMPROMISED_DATA;
			verification_source = NULL;
		}
		if (EFI_ERROR(path_release_status) ||
		    EFI_ERROR(source_release_status))
			status = EFI_COMPROMISED_DATA;
		if (EFI_ERROR(status))
			goto transaction_fail;
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
		security2_authenticated = TRUE;
#endif
	} else if (status != EFI_NOT_FOUND) {
		goto transaction_fail;
	}
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	else if (boot_policy) {
		status = EFI_SECURITY_VIOLATION;
		goto transaction_fail;
	}
#endif

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (linked_driver == NULL) {
		/* Protocol identity is local: SecurityStub is a separately linked PE. */
		static const EFI_GUID router_guid = {
			0x3159cc63, 0x8e41, 0x4cb8,
			{ 0x86, 0x02, 0x9e, 0x3c, 0x63, 0x22, 0x44, 0x31 }
		};

		status = service_locate_protocol(&router_guid, NULL,
			(void **)&policy_router);
		if (EFI_ERROR(status) || policy_router == NULL ||
		    policy_router->authorize_policy == NULL ||
		    active_core->images.load != load_pe || active_core->images.load_context != NULL) {
			status = EFI_UNSUPPORTED;
			goto transaction_fail;
		}
		if (active_core->events.current_tpl > 31U) {
			status = EFI_UNSUPPORTED;
			goto transaction_fail;
		}
		policy_interrupts = policy_interrupts_enabled();
		policy_tpl = active_core->events.current_tpl;
		active_core->events.current_tpl = 31U;
		policy_scope = true;
		policy_interrupts_set(false);
		if (policy_interrupts_enabled()) {
			status = EFI_DEVICE_ERROR;
			goto transaction_fail;
		}
		status = cdk2_dxe_image_transaction_validate_owned(&active_core->images,
			transaction, transaction_allocation_generation);
		if (EFI_ERROR(status))
			goto transaction_fail;
		status = policy_router->authorize_policy(transaction->source, transaction->source_size);
		if (EFI_ERROR(status))
			goto transaction_fail;
		if (policy_interrupts_enabled() ||
		    active_core->events.current_tpl != 31U ||
		    active_core->images.load != load_pe || active_core->images.load_context != NULL) {
			status = EFI_COMPROMISED_DATA;
			goto transaction_fail;
		}
	}
#endif
	status = cdk2_dxe_image_transaction_validate_owned(&active_core->images,
		transaction, transaction_allocation_generation);
	if (EFI_ERROR(status))
		goto transaction_fail;
	status = cdk2_dxe_image_transaction_advance(&active_core->images,
		transaction, transaction_allocation_generation,
		CDK2_DXE_IMAGE_AUTHENTICATED);
	if (EFI_ERROR(status))
		goto transaction_fail;
	status = cdk2_dxe_image_transaction_validate_owned(&active_core->images,
		transaction, transaction_allocation_generation);
	if (EFI_ERROR(status))
		goto transaction_fail;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	/* Trusted inventory bypasses the policy slot, never fixed PE consumption. */
	if (core->images.load != load_pe || core->images.load_context != NULL) {
		status = EFI_UNSUPPORTED;
		goto transaction_fail;
	}
#endif
	native_load_attempted = true;
	status = cdk2_dxe_image_load(&active_core->images, parent,
		transaction->source, transaction->source_size, handle);
	if (EFI_ERROR(status))
		goto transaction_fail;
	status = cdk2_dxe_image_transaction_validate_owned(&active_core->images,
		transaction, transaction_allocation_generation);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		*handle = NULL;
		goto transaction_fail;
	}
	image = core_image(*handle);
	if (image == NULL) {
		status = EFI_DEVICE_ERROR;
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		*handle = NULL;
		goto transaction_fail;
	}
	image->transaction = transaction;
	image->linked_primary_driver = linked_driver;
	image->transaction_allocation_generation =
		transaction_allocation_generation;
	transaction = NULL;
	transaction_allocation_generation = 0U;
	status = cdk2_dxe_image_transaction_advance(&active_core->images,
		image->transaction, image->transaction_allocation_generation,
		CDK2_DXE_IMAGE_LOADED_PRIVATE);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		*handle = NULL;
		goto transaction_fail;
	}
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	/* The private image is transaction-bound before any callback can resume. */
	if (policy_scope) {
		active_core->events.current_tpl = policy_tpl;
		policy_scope = false;
		policy_interrupts_set(policy_interrupts);
		if (policy_interrupts_enabled() != policy_interrupts) {
			(void)cdk2_dxe_image_unload(&active_core->images, *handle);
			*handle = NULL;
			status = EFI_DEVICE_ERROR;
			goto transaction_fail;
		}
	}
#endif
	CDK2_DXE_DIAG(CDK2_DIAG_INFO, CDK2_DXE_020, EFI_SUCCESS);
	CDK2_DXE_DIAG(CDK2_DIAG_INFO, CDK2_DXE_021, image->size);
	status = cdk2_dxe_runtime_image_register(active_core, image);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		goto load_finished;
	}
	status = cdk2_dxe_image_transaction_validate_owned(&active_core->images,
		image->transaction, image->transaction_allocation_generation);
	if (EFI_ERROR(status)) {
		cdk2_dxe_runtime_image_unregister(active_core, image);
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		goto load_finished;
	}
	if (path != NULL) {
		const UINT8 *node = image->transaction->device_path;
		UINTN offset = 0;

		while (offset <= path_size - 4U) {
			UINTN length = node[offset + 2U] |
				((UINTN)node[offset + 3U] << 8U);

			if (length < 4U || length > path_size - offset)
				break;
			if (node[offset] == 4U && node[offset + 1U] == 4U) {
				file_path_offset = offset;
				break;
			}
			offset += length;
		}
		owned_device_path = image->transaction->device_path;
		owned_path = (UINT8 *)image->transaction->device_path + file_path_offset;
	}
	image->owned_file_path = owned_path;
	image->owned_device_path = owned_device_path;
	image->loaded_image.file_path = owned_path;
	image->loaded_image.device_handle = device_handle;
	status = cdk2_dxe_image_transaction_validate_owned(&active_core->images,
		image->transaction, image->transaction_allocation_generation);
	if (EFI_ERROR(status)) {
		cdk2_dxe_runtime_image_unregister(active_core, image);
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		goto load_finished;
	}
	/* LoadImage creates the image handle before publishing its first protocol.
	 * Register that core-owned handle explicitly; public protocol installation
	 * must reject arbitrary non-null handles. */
	if (active_core->database.handle_count == CDK2_DXE_MAX_HANDLES) {
		cdk2_dxe_runtime_image_unregister(active_core, image);
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		status = EFI_OUT_OF_RESOURCES;
		goto load_finished;
	}
	active_core->database.handles[active_core->database.handle_count++] = *handle;
	status = cdk2_dxe_install(&active_core->database, handle,
				  &loaded_image_guid, &image->loaded_image);
	if (!EFI_ERROR(status) && owned_device_path != NULL)
		status = cdk2_dxe_install(&active_core->database, handle,
			&loaded_image_device_path_guid, owned_device_path);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_uninstall(&active_core->database, *handle,
			&loaded_image_guid, &image->loaded_image);
		active_core->database.handle_count--;
		cdk2_dxe_runtime_image_unregister(active_core, image);
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		goto load_finished;
	}
	status = cdk2_dxe_image_transaction_advance(&active_core->images,
		image->transaction, image->transaction_allocation_generation,
		CDK2_DXE_IMAGE_PUBLISHED);
	if (EFI_ERROR(status)) {
		if (owned_device_path != NULL)
			(void)cdk2_dxe_uninstall(&active_core->database, *handle,
				&loaded_image_device_path_guid, owned_device_path);
		(void)cdk2_dxe_uninstall(&active_core->database, *handle,
			&loaded_image_guid, &image->loaded_image);
		active_core->database.handle_count--;
		cdk2_dxe_runtime_image_unregister(active_core, image);
		(void)cdk2_dxe_image_unload(&active_core->images, *handle);
		goto load_finished;
	}
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	if (boot_policy && security2_authenticated) {
		struct cdk2_authvar_presence_external_image_identity identity;

		status = presence_image_identity(image, &identity);
		if (!EFI_ERROR(status))
			status = cdk2_authvar_presence_lifecycle_close_composition_claim(
				&identity);
		if (EFI_ERROR(status)) {
			if (owned_device_path != NULL)
				(void)cdk2_dxe_uninstall(&active_core->database,
					*handle, &loaded_image_device_path_guid,
					owned_device_path);
			(void)cdk2_dxe_uninstall(&active_core->database, *handle,
				&loaded_image_guid, &image->loaded_image);
			active_core->database.handle_count--;
			cdk2_dxe_runtime_image_unregister(active_core, image);
			(void)cdk2_dxe_image_unload(&active_core->images, *handle);
			goto load_finished;
		}
	}
#endif
	CDK2_DXE_DIAG(CDK2_DIAG_DEBUG, CDK2_DXE_139, EFI_SUCCESS);
	CDK2_DXE_DIAG(CDK2_DIAG_DEBUG, CDK2_DXE_141, EFI_SUCCESS);
	CDK2_DXE_DIAG(CDK2_DIAG_DEBUG, CDK2_DXE_142, EFI_SUCCESS);
	signal_protocol(&loaded_image_guid, *handle);
	if (owned_device_path != NULL)
		signal_protocol(&loaded_image_device_path_guid, *handle);
	status = EFI_SUCCESS;
	goto load_finished;

transaction_fail:
	*handle = NULL;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (policy_scope) {
		active_core->events.current_tpl = policy_tpl;
		policy_interrupts_set(policy_interrupts);
		if (policy_interrupts_enabled() != policy_interrupts)
			status = EFI_DEVICE_ERROR;
	}
#endif
	if (native_load_attempted) {
#ifdef CDK2_DEBUG
		struct cdk2_pe_image_view view;
		bool unsupported_machine = false;

		if (status == EFI_UNSUPPORTED && transaction != NULL &&
		    !EFI_ERROR(cdk2_dxe_image_transaction_validate_owned(&core->images,
			transaction, transaction_allocation_generation)) &&
		    !EFI_ERROR(cdk2_pe_image_view_open(transaction->source,
			transaction->source_size, &view)) && view.machine != 0x8664U)
			unsupported_machine = true;
#endif
		CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_139, status);
#ifdef CDK2_DEBUG
		if (unsupported_machine) {
			CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_145, status);
			CDK2_DXE_DIAG(CDK2_DIAG_ERROR, CDK2_DXE_146, status);
		}
#endif
	}
	if (owned_source != NULL)
		(void)cdk2_dxe_free_pool(&active_core->memory, owned_source);
	cdk2_dxe_image_transaction_release(&active_core->images, transaction,
		transaction_allocation_generation);
load_finished:
	if (EFI_ERROR(status))
		*handle = NULL;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (policy_router != NULL)
		cdk2_dxe_event_dispatch_pending(&active_core->events);
#endif
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_unload_image(void *handle);

EFI_STATUS cdk2_dxe_start_image(struct cdk2_dxe_core *core, void *handle,
	UINTN *exit_data_size, CHAR16 **exit_data)
{
	struct cdk2_dxe_image *image;
	BOOLEAN unload;
	EFI_STATUS status;
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	BOOLEAN presence_pre = FALSE;
	struct cdk2_authvar_presence_external_image_identity presence_identity;
	EFI_STATUS presence_return_status = EFI_SUCCESS;
#endif

	if (core == NULL || core != active_core)
		return EFI_INVALID_PARAMETER;
	image = core_image(handle);
	if (image != NULL && image->linked_primary_driver != NULL)
		return EFI_NOT_READY;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (image != NULL && !image->started && !image_transaction_published(image))
		return EFI_NOT_READY;
#endif

#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
#else
	status = cdk2_authvar_presence_lifecycle_seal();
	if (EFI_ERROR(status))
		return status;
#endif

	if ((exit_data_size == NULL) != (exit_data == NULL))
		return EFI_INVALID_PARAMETER;
	if (exit_data_size != NULL) {
		*exit_data_size = 0;
		*exit_data = NULL;
	}
#ifdef CDK2_DEBUG
	if (image_service_trace_depth == 0U)
		image_service_trace_count = 0U;
	image_service_trace_depth++;
#endif
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	if (image != NULL && !image->started) {
		status = presence_image_identity(image, &presence_identity);
		if (!EFI_ERROR(status))
			status =
			cdk2_authvar_presence_lifecycle_close_composition_pre_external(
				&presence_identity, &presence_pre);
		if (EFI_ERROR(status)) {
#ifdef CDK2_DEBUG
			image_service_trace_depth--;
#endif
			return status;
		}
	}
#endif
	status = cdk2_dxe_image_start(&active_core->images, handle, &status);
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	if (presence_pre) {
		presence_return_status =
			cdk2_authvar_presence_lifecycle_close_composition_payload_return(
				&presence_identity);
	}
#endif
#ifdef CDK2_DEBUG
	image_service_trace_depth--;
	if (image_service_trace_depth == 0U)
		cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "image not-found trace count",
			image_service_trace_count);
#endif
	image = core_image(handle);
	/* RuntimeDxe publishes RuntimeArch from its own entry point.  Retry the
	 * registration after StartImage so that this first runtime image is not
	 * omitted merely because the architectural protocol did not exist when
	 * LoadImage completed. */
	if (image != NULL &&
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	    !EFI_ERROR(presence_return_status) &&
#endif
	    image->runtime_entry == NULL &&
	    image->loaded_image.image_code_type == 5U) {
		EFI_STATUS register_status =
			cdk2_dxe_runtime_image_register(active_core, image);

#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
		if (EFI_ERROR(register_status))
			status = register_status;
#else
		if (EFI_ERROR(register_status))
			return register_status;
#endif
	}
	unload = image != NULL && (EFI_ERROR(status) ||
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
		EFI_ERROR(presence_return_status) ||
#endif
		image->loaded_image.image_code_type == 1U);
	if (image != NULL && image->exited) {
		if (exit_data_size != NULL) {
			*exit_data_size = image->exit_data_size;
			*exit_data = image->exit_data;
		} else if (image->exit_data != NULL) {
			(void)cdk2_dxe_free_pool(&active_core->memory,
				image->exit_data);
		}
		image->exit_data = NULL;
		image->exit_data_size = 0U;
		if (unload) {
			image->started = FALSE;
			(void)service_unload_image(handle);
		}
	}
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	if (EFI_ERROR(presence_return_status))
		status = presence_return_status;
#endif
	return status;
}

static EFI_STATUS CDK2_MS_ABI service_load_image(BOOLEAN boot_policy,
	void *parent, void *path, void *source, UINTN source_size, void **handle)
{
	return cdk2_dxe_load_image(active_core, boot_policy, parent, path,
		source, source_size, handle, NULL);
}

static EFI_STATUS CDK2_MS_ABI service_start_image(void *handle,
	UINTN *exit_data_size, CHAR16 **exit_data)
{
	return cdk2_dxe_start_image(active_core, handle, exit_data_size, exit_data);
}

static EFI_STATUS CDK2_MS_ABI service_exit(void *handle, EFI_STATUS status,
					   UINTN exit_data_size, CHAR16 *exit_data)
{
	struct cdk2_dxe_image *image = core_image(handle);
	CHAR16 *owned_exit_data = NULL;
	EFI_STATUS copy_status;

	if (image == NULL || (exit_data_size != 0 && exit_data == NULL))
		return EFI_INVALID_PARAMETER;
	if (exit_data_size != 0) {
		copy_status = cdk2_dxe_allocate_pool(&active_core->memory, 4,
			exit_data_size, (void **)&owned_exit_data);
		if (EFI_ERROR(copy_status))
			return copy_status;
		memcpy(owned_exit_data, exit_data, exit_data_size);
	}
	image->exit_data_size = exit_data_size;
	image->exit_data = owned_exit_data;
	return cdk2_dxe_image_exit(&active_core->images, handle, status);
}

static EFI_STATUS unload_image(struct cdk2_dxe_core *core, void *handle,
	BOOLEAN require_unload_handler)
{
	typedef EFI_STATUS CDK2_MS_ABI unload_fn(void *);
	struct cdk2_dxe_image *image;
	struct runtime_image_entry *runtime_entry;
	void *runtime_relocation;
	void *owned_path;
	void *owned_device_path;
	BOOLEAN transaction_paths;
	EFI_STATUS status;

	if (core == NULL)
		return EFI_INVALID_PARAMETER;
	image = NULL;
	for (UINTN index = 0; index < core->images.count; index++)
		if (core->images.images[index].handle == handle) {
			image = &core->images.images[index];
			break;
		}
	if (image == NULL)
		return EFI_INVALID_PARAMETER;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (require_unload_handler && !image_transaction_published(image))
		return EFI_NOT_READY;
#endif
	owned_path = image->owned_file_path;
	owned_device_path = image->owned_device_path;
	transaction_paths = image->transaction != NULL;
	runtime_entry = image->runtime_entry;
	runtime_relocation = image->runtime_relocation;
	if (require_unload_handler && image->started &&
	    image->loaded_image.unload == NULL)
		return EFI_UNSUPPORTED;
	if (require_unload_handler && image->started) {
		status = ((unload_fn *)image->loaded_image.unload)(handle);
		if (EFI_ERROR(status))
			return status;
	}
	if (owned_device_path != NULL) {
		status = cdk2_dxe_uninstall(&core->database, handle,
			&loaded_image_device_path_guid, owned_device_path);
		if (EFI_ERROR(status))
			return status;
	}
	status = cdk2_dxe_uninstall(&core->database, handle,
				    &loaded_image_guid, &image->loaded_image);
	if (EFI_ERROR(status)) {
		if (owned_device_path != NULL)
			(void)cdk2_dxe_restore(&core->database, handle,
				&loaded_image_device_path_guid, owned_device_path);
		return status;
	}
	status = cdk2_dxe_image_unload(&core->images, handle);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_restore(&core->database, handle,
			&loaded_image_guid, &image->loaded_image);
		if (owned_device_path != NULL)
			(void)cdk2_dxe_restore(&core->database, handle,
				&loaded_image_device_path_guid, owned_device_path);
	} else {
		release_runtime_image(core, runtime_entry,
			runtime_relocation);
		if (!transaction_paths && owned_path != NULL)
			(void)cdk2_dxe_free_pool(&core->memory, owned_path);
		if (!transaction_paths && owned_device_path != NULL)
			(void)cdk2_dxe_free_pool(&core->memory, owned_device_path);
	}
	return status;
}

EFI_STATUS cdk2_dxe_discard_failed_image(struct cdk2_dxe_core *core,
	void *handle)
{
	return unload_image(core, handle, FALSE);
}

static EFI_STATUS CDK2_MS_ABI service_unload_image(void *handle)
{
	return unload_image(active_core, handle, TRUE);
}

static EFI_STATUS CDK2_MS_ABI service_crc32(const void *data, UINTN size,
					    UINT32 *result)
{
	if (data == NULL || size == 0 || result == NULL)
		return EFI_INVALID_PARAMETER;
	*result = crc32(data, size);
	return EFI_SUCCESS;
}

static void CDK2_MS_ABI service_copy(void *destination, const void *source,
				     UINTN size)
{
	memmove(destination, source, size);
}

static void CDK2_MS_ABI service_set(void *buffer, UINTN size, UINT8 value)
{
	memset(buffer, value, size);
}

static EFI_STATUS CDK2_MS_ABI service_stall(UINTN microseconds)
{
	struct cdk2_metronome *metronome = NULL;
	UINT64 ticks;
	EFI_STATUS status;

	if (microseconds > MAX_UINT64 / 10U)
		return EFI_INVALID_PARAMETER;
	if (microseconds == 0U)
		return EFI_SUCCESS;
	status = service_locate_protocol(&metronome_guid, NULL,
		(void **)&metronome);
	if (EFI_ERROR(status))
		return status;
	if (metronome == NULL || metronome->wait_for_tick == NULL ||
	    metronome->tick_period == 0U)
		return EFI_DEVICE_ERROR;
	ticks = ((UINT64)microseconds * 10U + metronome->tick_period - 1U) /
		metronome->tick_period;
	while (ticks != 0U) {
		UINT32 chunk = ticks > MAX_UINT32 ? MAX_UINT32 : (UINT32)ticks;

		status = metronome->wait_for_tick(metronome, chunk);
		if (EFI_ERROR(status))
			return status;
		ticks -= chunk;
	}
	cdk2_dxe_event_advance(&active_core->events, microseconds * 10U);
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_exit_boot_services(void *image,
	UINTN map_key)
{
	struct cdk2_runtime_arch_protocol *runtime_arch = NULL;
	struct cdk2_runtime_arch_protocol *expected_runtime_arch;
	BOOLEAN group_signaled = FALSE;
	EFI_STATUS status;
	UINTN index;
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	struct cdk2_dxe_image *started_image;
	struct cdk2_authvar_presence_external_image_identity presence_identity;
#endif
#if CONFIG_CDK2_LINEAR_BOOT
	UINTN previous_tpl;
	struct cdk2_local_apic_timer_control *timer = NULL;
	struct cdk2_xhci_control *xhci = NULL;
#if CONFIG_PAYLOAD_DMA_HANDOFF
	struct cdk2_pci_dma_control *pci_dma = NULL;
#endif
#endif
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	started_image = core_image(image);
	if (started_image == NULL || !started_image->started)
#else
	if (core_image(image) == NULL || !core_image(image)->started)
#endif
		return EFI_INVALID_PARAMETER;
#if CONFIG_CDK2_LINEAR_BOOT
	/* Freeze notifications before checking the key and ownership, including
	 * when a loader has explicitly enabled the public timer and interrupts. */
	previous_tpl = active_core->events.current_tpl;
	active_core->events.current_tpl = 31U;
	__atomic_signal_fence(__ATOMIC_SEQ_CST);
#endif
	if (map_key != active_core->memory.map_key) {
#if CONFIG_CDK2_LINEAR_BOOT
		active_core->events.current_tpl = previous_tpl;
#endif
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
#else
		status = cdk2_authvar_presence_lifecycle_seal();
		if (EFI_ERROR(status))
			return status;
#endif
		for (index = 0U; index < active_core->events.count; index++)
			if (!active_core->events.events[index].closed &&
			    active_core->events.events[index].grouped &&
			    memcmp(&active_core->events.events[index].group,
			    &exit_boot_services_failed_guid,
			    sizeof(exit_boot_services_failed_guid)) == 0) {
				(void)cdk2_dxe_event_signal(&active_core->events,
					&active_core->events.events[index]);
				break;
			}
		return EFI_INVALID_PARAMETER;
	}
	status = service_locate_protocol(&runtime_arch_guid, NULL,
		(void **)&runtime_arch);
	if (EFI_ERROR(status) || runtime_arch == NULL) {
#if CONFIG_CDK2_LINEAR_BOOT
		active_core->events.current_tpl = previous_tpl;
#endif
		return EFI_NOT_FOUND;
	}
	expected_runtime_arch = runtime_arch;
#if CONFIG_CDK2_LINEAR_BOOT
	status = private_timer_control(active_core, &timer);
	if (status == EFI_SUCCESS) {
		status = private_xhci_control(active_core, NULL, NULL, &xhci);
		if (status == EFI_NOT_FOUND)
			status = EFI_SUCCESS;
	}
#if CONFIG_PAYLOAD_DMA_HANDOFF
	if (status == EFI_SUCCESS)
		status = private_pci_dma_control(active_core, &pci_dma);
#endif
	if (status != EFI_SUCCESS) {
		active_core->events.current_tpl = previous_tpl;
		return EFI_ERROR(status) ? status : EFI_DEVICE_ERROR;
	}
#endif
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION && \
	CONFIG_CDK2_LINEAR_BOOT
	{
		/* Finish every fallible platform quiesce before consuming the
		 * one-shot runtime reproof. */
		status = timer->deactivate(timer);
		if (status == EFI_SUCCESS && xhci != NULL)
			status = xhci->quiesce(xhci, xhci->controller);
#if CONFIG_PAYLOAD_DMA_HANDOFF
		if (status == EFI_SUCCESS)
			status = pci_dma->quiesce_all(pci_dma);
#endif
		active_core->events.current_tpl = previous_tpl;
		if (status != EFI_SUCCESS)
			return EFI_ERROR(status) ? status : EFI_DEVICE_ERROR;
	}
#endif
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	runtime_arch = NULL;
	status = service_locate_protocol(&runtime_arch_guid, NULL,
		(void **)&runtime_arch);
	if (EFI_ERROR(status) || runtime_arch == NULL ||
	    runtime_arch != expected_runtime_arch)
		return EFI_SECURITY_VIOLATION;
	status = presence_image_identity(started_image, &presence_identity);
	if (!EFI_ERROR(status))
		status =
			cdk2_authvar_presence_lifecycle_close_composition_successful_ebs_reproof(
				&presence_identity);
#else
	status = cdk2_authvar_presence_lifecycle_enter_runtime();
#endif
	if (EFI_ERROR(status)) {
#if CONFIG_CDK2_LINEAR_BOOT
		active_core->events.current_tpl = previous_tpl;
#endif
		return status;
	}
#if CONFIG_CDK2_LINEAR_BOOT && \
	!CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	{
		/* XHCI's bounded halt may Stall. Suppress timer notifications during
		 * that wait so loader callbacks cannot allocate inside quiescence. */
		status = timer->deactivate(timer);
		if (status == EFI_SUCCESS && xhci != NULL)
			status = xhci->quiesce(xhci, xhci->controller);
#if CONFIG_PAYLOAD_DMA_HANDOFF
		if (status == EFI_SUCCESS)
			status = pci_dma->quiesce_all(pci_dma);
#endif
		/* Do not dispatch queued notifications as part of the private call. */
		active_core->events.current_tpl = previous_tpl;
		if (status != EFI_SUCCESS)
			return EFI_ERROR(status) ? status : EFI_DEVICE_ERROR;
	}
#endif
	for (index = 0U; index < active_core->events.count; index++)
		if (!active_core->events.events[index].closed &&
		    active_core->events.events[index].grouped &&
		    memcmp(&active_core->events.events[index].group,
		    &before_exit_boot_services_guid,
		    sizeof(before_exit_boot_services_guid)) == 0)
			(void)cdk2_dxe_event_signal(&active_core->events,
				&active_core->events.events[index]);
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
#else
	runtime_arch = NULL;
	status = service_locate_protocol(&runtime_arch_guid, NULL,
		(void **)&runtime_arch);
	if (EFI_ERROR(status) || runtime_arch == NULL ||
	    runtime_arch != expected_runtime_arch)
		return EFI_SECURITY_VIOLATION;
#endif
	runtime_arch->at_runtime = TRUE;
	for (index = 0; index < active_core->events.count; index++)
		if (!active_core->events.events[index].closed &&
		    ((active_core->events.events[index].grouped && !group_signaled &&
		    memcmp(&active_core->events.events[index].group,
			   &exit_boot_services_guid,
			   sizeof(exit_boot_services_guid)) == 0) ||
		    (!active_core->events.events[index].grouped &&
		    active_core->events.events[index].type == 0x00000201U))) {
			if (active_core->events.events[index].grouped)
				group_signaled = TRUE;
			(void)cdk2_dxe_event_signal(&active_core->events,
				&active_core->events.events[index]);
		}
	active_core->runtime_storage->system_table.boot_services = NULL;
	active_core->runtime_storage->system_table.header.crc32 = 0;
	active_core->runtime_storage->system_table.header.crc32 = crc32(
		&active_core->runtime_storage->system_table,
		active_core->runtime_storage->system_table.header.header_size);
	{
		struct cdk2_cpu_arch *cpu = NULL;

		if (!EFI_ERROR(service_locate_protocol(&cpu_arch_guid, NULL,
		    (void **)&cpu)) && cpu != NULL && cpu->disable_interrupt != NULL)
			(void)cpu->disable_interrupt(cpu);
	}
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_monotonic(UINT64 *count)
{
	if (count == NULL)
		return EFI_INVALID_PARAMETER;
	*count = active_core->monotonic_count++;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI service_watchdog(UINTN timeout, UINT64 code,
					       UINTN size, CHAR16 *data)
{
	struct cdk2_watchdog *watchdog = NULL;
	EFI_STATUS status;

	(void)code;
	(void)size;
	(void)data;
	status = service_locate_protocol(&watchdog_guid, NULL, (void **)&watchdog);
	if (EFI_ERROR(status))
		return status;
	if (watchdog == NULL || watchdog->set_timer_period == NULL ||
	    timeout > MAX_UINT64 / 10000000U)
		return EFI_INVALID_PARAMETER;
	return watchdog->set_timer_period(watchdog, timeout * 10000000U);
}

struct driver_binding_protocol;
typedef EFI_STATUS CDK2_MS_ABI driver_supported_fn(
	struct driver_binding_protocol *, void *, void *);
typedef EFI_STATUS CDK2_MS_ABI driver_start_fn(
	struct driver_binding_protocol *, void *, void *);
typedef EFI_STATUS CDK2_MS_ABI driver_stop_fn(
	struct driver_binding_protocol *, void *, UINTN, void **);
struct driver_binding_protocol {
	driver_supported_fn *supported;
	driver_start_fn *start;
	driver_stop_fn *stop;
	UINT32 version;
	UINT32 padding;
	void *image;
	void *binding;
};

static const EFI_GUID driver_binding_guid = { 0x18a031ab, 0xb443, 0x4d1a,
	{ 0xa5, 0xc0, 0x0c, 0x09, 0x26, 0x1e, 0x9f, 0x71 } };

static void remove_connected_pair(void *controller,
	struct driver_binding_protocol *binding)
{
	UINTN index;

	for (index = 0; index < connected_pair_count; index++)
		if (connected_pairs[index].controller == controller &&
		    connected_pairs[index].driver == binding) {
			UINTN move;

			for (move = index + 1U; move < connected_pair_count; move++)
				connected_pairs[move - 1U] = connected_pairs[move];
			connected_pair_count--;
			return;
		}
}

static EFI_STATUS service_connect_impl(void *controller, void **drivers,
	void *remaining, BOOLEAN recursive, BOOLEAN exact)
{
	UINTN index, protocol_count, priorities = 1U;
	BOOLEAN connected = FALSE;
	BOOLEAN already_connected = FALSE;
	EFI_STATUS failure = EFI_NOT_FOUND;

	if (controller == NULL)
		return EFI_INVALID_PARAMETER;
#ifdef CDK2_DEBUG
	if (connect_trace_count < CONNECT_TRACE_LIMIT) {
		connect_trace_count++;
		cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "connect controller",
			(UINTN)controller);
		cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "connect recursive", recursive);
		trace_handle_path("controller device-path bytes", controller);
		{
			struct cdk2_efi_pci_io_protocol *pci = NULL;
			UINTN span = 0U, segment, bus, device, function;
			UINT32 identity, command_status, class_revision;

			if (!EFI_ERROR(cdk2_dxe_handle_span(&active_core->database,
			    controller, &pci_io_guid, (void **)&pci, &span)) &&
			    span >= sizeof(*pci) && pci->get_location != NULL &&
			    pci->pci.read != NULL &&
			    !EFI_ERROR(pci->get_location(pci, &segment, &bus, &device,
				&function))) {
				cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "PCI segment-bus-device-function",
					((UINT64)segment << 24) | ((UINT64)bus << 16) |
					((UINT64)device << 8) | function);
				if (!EFI_ERROR(pci->pci.read(pci, 2U, 0U, 1U,
				    &identity)))
					cdk2_diag_value(CDK2_DIAG_DXE_MAIN,
						"PCI device-vendor", identity);
				if (!EFI_ERROR(pci->pci.read(pci, 2U, 4U, 1U,
				    &command_status)))
					cdk2_diag_value(CDK2_DIAG_DXE_MAIN,
						"PCI status-command", command_status);
				if (!EFI_ERROR(pci->pci.read(pci, 2U, 8U, 1U,
				    &class_revision)))
					cdk2_diag_value(CDK2_DIAG_DXE_MAIN,
						"PCI class-revision", class_revision);
			}
		}
	}
#endif
	for (index = 0; index < connect_depth; index++)
		if (connect_stack[index] == controller)
			return EFI_ALREADY_STARTED;
	if (connect_depth == ARRAY_SIZE(connect_stack))
		return EFI_OUT_OF_RESOURCES;
	connect_stack[connect_depth++] = controller;
	protocol_count = active_core->database.protocol_count;
	if (drivers != NULL)
		for (priorities = 0U; drivers[priorities] != NULL; priorities++)
			;
	for (UINTN priority = 0U; priority < priorities; priority++) {
		for (index = 0; index < protocol_count; index++) {
			struct cdk2_dxe_protocol *record =
				&active_core->database.protocols[index];
			struct driver_binding_protocol *binding;
			UINTN driver_index;
			EFI_STATUS status;

			if (memcmp(&record->guid, &driver_binding_guid,
			    sizeof(driver_binding_guid)) != 0)
				continue;
			binding = record->interface;
			if (binding == NULL || binding->supported == NULL ||
			    binding->start == NULL)
				continue;
			if (drivers != NULL && binding->image != drivers[priority])
				continue;
			for (driver_index = 0; driver_index < connected_pair_count;
			    driver_index++)
				if (connected_pairs[driver_index].controller == controller &&
				    connected_pairs[driver_index].driver == binding)
					break;
			if (driver_index != connected_pair_count) {
				if (exact) {
					already_connected = TRUE;
					goto connect_complete;
				}
				continue;
			}
			for (driver_index = 0; driver_index < connect_depth - 1U;
			    driver_index++)
				if (connect_driver_stack[driver_index] == binding)
					break;
			if (driver_index != connect_depth - 1U)
				continue;
			if (connected_pair_count == sizeof(connected_pairs) /
			    sizeof(connected_pairs[0])) {
				if (exact && failure == EFI_NOT_FOUND)
					failure = EFI_OUT_OF_RESOURCES;
				continue;
			}
			connected_pairs[connected_pair_count].controller = controller;
			connected_pairs[connected_pair_count].driver = binding;
			connected_pairs[connected_pair_count].image = binding->image;
			connected_pairs[connected_pair_count].started = FALSE;
			connected_pair_count++;
			connect_driver_stack[connect_depth - 1U] = binding;
			status = binding->supported(binding, controller, remaining);
#ifdef CDK2_DEBUG
			if (connect_trace_count < CONNECT_TRACE_LIMIT) {
				connect_trace_count++;
				cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "binding image",
					(UINTN)binding->image);
				cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "binding handle",
					(UINTN)record->handle);
				cdk2_diag_value(CDK2_DIAG_DXE_MAIN, "binding version",
					binding->version);
				{
					struct cdk2_dxe_image *binding_image =
						core_image(binding->image);

					if (binding_image != NULL) {
						cdk2_diag_value(CDK2_DIAG_DXE_MAIN,
							"binding load generation",
							binding_image->load_generation);
						/* Loaded image paths are core-owned, validated copies. */
						trace_path("binding image-path bytes",
							binding_image->loaded_image.file_path, 4096U);
					}
				}
				cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_DEBUG :
					CDK2_DIAG_INFO, CDK2_DIAG_DXE_MAIN, 0x1836U,
					status);
			}
#endif
			if (exact && status == EFI_ALREADY_STARTED) {
				already_connected = TRUE;
				connect_driver_stack[connect_depth - 1U] = NULL;
				remove_connected_pair(controller, binding);
				goto connect_complete;
			}
			if (status != EFI_SUCCESS && status != EFI_ALREADY_STARTED) {
				if (exact && failure == EFI_NOT_FOUND &&
				    status != EFI_NOT_FOUND && status != EFI_UNSUPPORTED)
					failure = EFI_ERROR(status) ? status : EFI_COMPROMISED_DATA;
				connect_driver_stack[connect_depth - 1U] = NULL;
				remove_connected_pair(controller, binding);
				continue;
			}
			status = binding->start(binding, controller, remaining);
#ifdef CDK2_DEBUG
			if (connect_trace_count < CONNECT_TRACE_LIMIT) {
				connect_trace_count++;
				cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_ERROR :
					CDK2_DIAG_INFO, CDK2_DIAG_DXE_MAIN, 0x1837U,
					status);
			}
#endif
			connect_driver_stack[connect_depth - 1U] = NULL;
			if (exact && status == EFI_ALREADY_STARTED) {
				already_connected = TRUE;
				remove_connected_pair(controller, binding);
				goto connect_complete;
			} else if (status == EFI_SUCCESS || status == EFI_ALREADY_STARTED) {
				for (driver_index = 0U; driver_index < connected_pair_count;
				     driver_index++)
					if (connected_pairs[driver_index].controller == controller &&
					    connected_pairs[driver_index].driver == binding)
						connected_pairs[driver_index].started = TRUE;
				connected = TRUE;
			} else {
				if (exact && failure == EFI_NOT_FOUND &&
				    status != EFI_NOT_FOUND && status != EFI_UNSUPPORTED)
					failure = EFI_ERROR(status) ? status : EFI_COMPROMISED_DATA;
				remove_connected_pair(controller, binding);
			}
		}
	}
connect_complete:
	connect_depth--;
	/* A driver can publish the protocol consumed by a binding that appeared
	 * earlier in the database.  Recursive connection therefore continues to a
	 * fixed point instead of making only one order-dependent pass. */
	if (recursive && connected)
		while (service_connect_impl(controller, drivers, remaining, FALSE,
		       exact) ==
		       EFI_SUCCESS)
			connected = TRUE;
	if (recursive) {
		UINTN open;

		for (open = 0; open < active_core->database.open_count; open++)
			if (active_core->database.opens[open].handle == controller &&
			    (active_core->database.opens[open].attributes & 0x08U) != 0)
				(void)service_connect_impl(
					active_core->database.opens[open].controller,
					drivers, NULL, TRUE, exact);
	}
	{
		EFI_STATUS result = connected ? EFI_SUCCESS :
			(exact && already_connected ? EFI_ALREADY_STARTED : failure);
#ifdef CDK2_DEBUG
		if (connect_trace_count < CONNECT_TRACE_LIMIT) {
			connect_trace_count++;
			cdk2_diag_emit(EFI_ERROR(result) ? CDK2_DIAG_DEBUG :
				CDK2_DIAG_INFO, CDK2_DIAG_DXE_MAIN, 0x1838U, result);
		}
#endif
		return result;
	}
}

static EFI_STATUS CDK2_MS_ABI service_connect(void *controller,
	void **drivers, void *remaining, BOOLEAN recursive)
{
	return service_connect_impl(controller, drivers, remaining, recursive, FALSE);
}

EFI_STATUS cdk2_dxe_connect_exact(void *controller, void *driver,
	void *remaining)
{
	void *drivers[2] = { driver, NULL };

	if (driver == NULL)
		return EFI_INVALID_PARAMETER;
	return service_connect_impl(controller, drivers, remaining, FALSE, TRUE);
}

BOOLEAN cdk2_dxe_connection_present(void *controller, void *image)
{
	for (UINTN index = 0U; index < connected_pair_count; index++)
		if (connected_pairs[index].controller == controller &&
		    connected_pairs[index].image == image)
			return TRUE;
	return FALSE;
}

static BOOLEAN binding_owns_relationship(void *controller,
	const struct driver_binding_protocol *binding, void *child)
{
	for (UINTN index = 0U; index < active_core->database.open_count; index++) {
		const struct cdk2_dxe_open *open = &active_core->database.opens[index];

		if (open->handle != controller || open->agent != binding->binding)
			continue;
		if (child == NULL && (open->attributes & 0x10U) != 0U)
			return TRUE;
		if ((open->attributes & 0x08U) != 0U && open->controller != NULL &&
		    (child == NULL || open->controller == child))
			return TRUE;
	}
	for (UINTN index = 0U; child == NULL && index < connected_pair_count; index++)
		if (connected_pairs[index].controller == controller &&
		    connected_pairs[index].driver == binding && connected_pairs[index].started)
			return TRUE;
	return FALSE;
}

struct disconnect_binding {
	void *handle, *image, *agent;
	UINT64 registration;
	struct driver_binding_protocol *interface;
	driver_stop_fn *stop;
};

static struct driver_binding_protocol *revalidate_disconnect_binding(
	const struct disconnect_binding *snapshot)
{
	for (UINTN index = 0U; index < active_core->database.protocol_count; index++) {
		const struct cdk2_dxe_protocol *record = &active_core->database.protocols[index];
		struct driver_binding_protocol *binding;

		if (record->handle != snapshot->handle ||
		    record->registration != snapshot->registration ||
		    memcmp(&record->guid, &driver_binding_guid, sizeof(driver_binding_guid)) != 0)
			continue;
		binding = record->interface;
		if (binding != snapshot->interface || binding->image != snapshot->image ||
		    binding->binding != snapshot->agent || binding->stop != snapshot->stop)
			return NULL;
		return binding;
	}
	return NULL;
}

static EFI_STATUS CDK2_MS_ABI service_disconnect(void *controller,
	void *driver, void *child)
{
	struct disconnect_binding snapshots[CDK2_DXE_MAX_HANDLES];
	void *children[CDK2_DXE_MAX_HANDLES];
	UINTN snapshot_count = 0U;
	BOOLEAN stopped = FALSE;
	EFI_STATUS failure = EFI_SUCCESS;

	if (controller == NULL)
		return EFI_INVALID_PARAMETER;
	for (UINTN index = 0U; index < disconnect_depth; index++)
		if (disconnect_stack[index] == controller)
			return EFI_ALREADY_STARTED;
	if (disconnect_depth == ARRAY_SIZE(disconnect_stack))
		return EFI_OUT_OF_RESOURCES;
	/* Stop may remove protocol records or disconnect a different controller.
	 * Freeze eligible identities before callbacks can compact the database. */
	for (UINTN index = 0U; index < active_core->database.protocol_count; index++) {
		const struct cdk2_dxe_protocol *record = &active_core->database.protocols[index];
		struct driver_binding_protocol *binding = record->interface;

		if (memcmp(&record->guid, &driver_binding_guid, sizeof(driver_binding_guid)) != 0 ||
		    binding == NULL || binding->stop == NULL ||
		    (driver != NULL && binding->image != driver) ||
		    !binding_owns_relationship(controller, binding, child))
			continue;
		if (snapshot_count == ARRAY_SIZE(snapshots))
			return EFI_OUT_OF_RESOURCES;
		snapshots[snapshot_count++] = (struct disconnect_binding) {
			.handle = record->handle, .registration = record->registration,
			.interface = binding, .image = binding->image, .agent = binding->binding,
			.stop = binding->stop,
		};
	}
	disconnect_stack[disconnect_depth++] = controller;
	for (UINTN index = 0U; index < snapshot_count; index++) {
		const struct disconnect_binding *snapshot = &snapshots[index];
		struct driver_binding_protocol *binding = revalidate_disconnect_binding(snapshot);
		UINTN child_count = 0U;
		EFI_STATUS status = EFI_COMPROMISED_DATA;

		if (binding == NULL)
			goto record_status;
		if (!binding_owns_relationship(controller, binding, child))
			continue;
		if (child != NULL) {
			status = snapshot->stop(binding, controller, 1U, &child);
			if (status == EFI_SUCCESS &&
			    revalidate_disconnect_binding(snapshot) == NULL)
				status = EFI_COMPROMISED_DATA;
			goto record_status;
		}
		for (UINTN open = 0U; open < active_core->database.open_count; open++) {
			const struct cdk2_dxe_open *record = &active_core->database.opens[open];
			BOOLEAN duplicate = FALSE;

			if (record->handle != controller || record->agent != snapshot->agent ||
			    (record->attributes & 0x08U) == 0U || record->controller == NULL)
				continue;
			for (UINTN known = 0U; known < child_count; known++)
				duplicate |= children[known] == record->controller;
			if (!duplicate) {
				if (child_count == ARRAY_SIZE(children)) {
					status = EFI_OUT_OF_RESOURCES;
					goto record_status;
				}
				children[child_count++] = record->controller;
			}
		}
		status = child_count == 0U ? EFI_SUCCESS :
			snapshot->stop(binding, controller, child_count, children);
		if (status == EFI_SUCCESS) {
			binding = revalidate_disconnect_binding(snapshot);
			status = binding == NULL ? EFI_COMPROMISED_DATA :
				snapshot->stop(binding, controller, 0U, NULL);
		}
		if (status == EFI_SUCCESS)
			remove_connected_pair(controller, snapshot->interface);
record_status:
		if (status == EFI_SUCCESS) {
			stopped = TRUE;
		} else {
			if (!EFI_ERROR(status))
				status = EFI_DEVICE_ERROR;
			if (failure == EFI_SUCCESS)
				failure = status;
		}
	}
	disconnect_stack[--disconnect_depth] = NULL;
	return failure != EFI_SUCCESS ? failure : (stopped ? EFI_SUCCESS : EFI_NOT_FOUND);
}

static EFI_STATUS CDK2_MS_ABI runtime_convert_pointer(UINTN debug,
						      void **address)
{
	(void)debug;
	return address == NULL ? EFI_INVALID_PARAMETER : EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI runtime_high_monotonic(UINT32 *count)
{
	if (count == NULL)
		return EFI_INVALID_PARAMETER;
	active_core->monotonic_count =
		((active_core->monotonic_count >> 32) + 1U) << 32;
	*count = (UINT32)(active_core->monotonic_count >> 32);
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_dxe_core_initialize(struct cdk2_dxe_core *core, void *memory,
				    UINTN pages)
{
	static CHAR16 vendor[] = u"cdk2";
	EFI_STATUS status;

	if (core == NULL)
		return EFI_INVALID_PARAMETER;
#ifdef CDK2_DEBUG
	connect_trace_count = 0U;
#endif
	connect_depth = 0;
	disconnect_depth = 0U;
	connected_pair_count = 0;
#ifdef CDK2_HOST_TEST
	runtime_image_register_test_calls = 0U;
#endif
	memset(connect_stack, 0, sizeof(connect_stack));
	memset(connect_driver_stack, 0, sizeof(connect_driver_stack));
	memset(core, 0, sizeof(*core));
	status = cdk2_dxe_memory_initialize(&core->memory, memory, pages);
	if (EFI_ERROR(status))
		return status;
	(void)cdk2_dxe_database_initialize(&core->database);
	(void)cdk2_dxe_database_set_allocator(&core->database,
		database_allocate, core);
	(void)cdk2_dxe_database_set_span_resolver(&core->database,
		database_span, core);
	(void)cdk2_dxe_events_initialize(&core->events);
	active_core = core;
	status = cdk2_dxe_allocate_pool(&core->memory, 6U,
		sizeof(*core->runtime_storage), (void **)&core->runtime_storage);
	if (EFI_ERROR(status))
		return status;
	memset(core->runtime_storage, 0, sizeof(*core->runtime_storage));
	memcpy(core->runtime_storage->vendor, u"cdk2",
		sizeof(core->runtime_storage->vendor));
	status = cdk2_dxe_allocate_pool(&core->memory, 5U, 16U,
		&core->runtime_unsupported_stub);
	if (EFI_ERROR(status)) {
		(void)cdk2_dxe_free_pool(&core->memory, core->runtime_storage);
		core->runtime_storage = NULL;
		return status;
	}
	/* movabs $EFI_UNSUPPORTED,%rax; ret.  Keep the fallback entry point in
	 * RuntimeServicesCode so every published runtime slot survives EBS. */
	memcpy(core->runtime_unsupported_stub,
		(const UINT8[]) { 0x48, 0xb8, 0x03, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x80, 0xc3 }, 11U);
	core->boot_services = (struct cdk2_dxe_boot_services){
		.header = { 0x56524553544f4f42ULL, 0x2001f, 376, 0, 0 },
		.raise_tpl = service_raise_tpl, .restore_tpl = service_restore_tpl,
		.allocate_pages = service_allocate_pages,
		.free_pages = service_free_pages, .get_memory_map = service_get_memory_map,
		.allocate_pool = service_allocate_pool, .free_pool = service_free_pool,
		.create_event = service_create_event, .set_timer = service_set_timer,
		.wait_for_event = service_wait, .signal_event = service_signal,
		.close_event = service_close_event, .check_event = service_check_event,
		.install_protocol = service_install, .reinstall_protocol = service_reinstall,
		.uninstall_protocol = service_uninstall,
		.handle_protocol = service_handle,
		.register_protocol_notify = service_register_notify,
		.locate_handle = service_locate_handle,
		.locate_device_path = service_locate_device_path,
		.install_configuration_table = service_install_configuration_table,
		.get_next_monotonic_count = service_monotonic, .stall = service_stall,
		.set_watchdog_timer = service_watchdog, .open_protocol = service_open,
		.connect_controller = service_connect,
		.disconnect_controller = service_disconnect,
		.close_protocol = service_close,
		.open_protocol_information = service_open_information,
		.protocols_per_handle = service_protocols_per_handle,
		.locate_handle_buffer = service_locate_handle_buffer,
		.locate_protocol = service_locate_protocol,
		.install_multiple = service_install_multiple,
		.uninstall_multiple = service_uninstall_multiple,
		.calculate_crc32 = service_crc32,
		.exit_boot_services = service_exit_boot_services,
		.copy_mem = service_copy, .set_mem = service_set,
		.create_event_ex = service_create_event_ex
	};
	core->boot_services.header.crc32 = crc32(&core->boot_services,
						 core->boot_services.header.header_size);
	core->system_table = (struct cdk2_dxe_system_table){
		.header = { 0x5453595320494249ULL, 0x2001f, 120, 0, 0 },
		.firmware_vendor = vendor, .firmware_revision = 1,
		.runtime_services = &core->runtime_services,
		.boot_services = &core->boot_services,
		.configuration_table = core->configuration_tables
	};
	void *runtime_unsupported = core->runtime_unsupported_stub;
	core->runtime_services = (struct cdk2_dxe_runtime_services){
		.header = { 0x56524553544e5552ULL, 0x2001f, 136, 0, 0 },
		.get_time = runtime_unsupported, .set_time = runtime_unsupported,
		.get_wakeup_time = runtime_unsupported,
		.set_wakeup_time = runtime_unsupported,
		.set_virtual_address_map = runtime_unsupported,
		.convert_pointer = runtime_convert_pointer,
		.get_variable = runtime_unsupported,
		.get_next_variable_name = runtime_unsupported,
		.set_variable = runtime_unsupported,
		.get_next_high_monotonic_count = runtime_high_monotonic,
		.reset_system = runtime_unsupported,
		.update_capsule = runtime_unsupported,
		.query_capsule_capabilities = runtime_unsupported,
		.query_variable_info = runtime_unsupported
	};
	core->runtime_services.header.crc32 = crc32(&core->runtime_services,
						    core->runtime_services.header.header_size);
	core->system_table.header.crc32 = crc32(&core->system_table,
						core->system_table.header.header_size);
	core->runtime_storage->runtime_services = core->runtime_services;
	memcpy(core->runtime_storage->vendor, vendor, sizeof(vendor));
	core->runtime_storage->system_table = core->system_table;
	core->runtime_storage->system_table.firmware_vendor =
		core->runtime_storage->vendor;
	core->runtime_storage->system_table.runtime_services =
		&core->runtime_storage->runtime_services;
	core->runtime_storage->system_table.configuration_table =
		core->runtime_storage->configuration_tables;
	core->runtime_storage->system_table.header.crc32 = 0U;
	core->runtime_storage->system_table.header.crc32 = crc32(
		&core->runtime_storage->system_table,
		core->runtime_storage->system_table.header.header_size);
	status = cdk2_dxe_images_initialize(&core->images, &core->memory, load_pe,
					    NULL, &core->runtime_storage->system_table);
	if (EFI_ERROR(status))
		return status;
	status = cdk2_dxe_gcd_initialize(core);
	if (EFI_ERROR(status))
		return status;
	core->dxe_services.header.crc32 = crc32(&core->dxe_services,
						core->dxe_services.header.header_size);
	core->boot_services.load_image = service_load_image;
	core->boot_services.start_image = service_start_image;
	core->boot_services.exit = service_exit;
	core->boot_services.unload_image = service_unload_image;
	core->boot_services.header.crc32 = 0;
	core->boot_services.header.crc32 = crc32(&core->boot_services,
						 core->boot_services.header.header_size);
	return EFI_SUCCESS;
}
