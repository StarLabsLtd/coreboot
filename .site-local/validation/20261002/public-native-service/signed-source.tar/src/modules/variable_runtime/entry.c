/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#include <cdk2/variable_runtime.h>
#include <cdk2/diagnostic.h>

__weak void cdk2_diag_runtime_transition(void) { }
#ifdef CDK2_DIAG_RUNTIME_TRANSITION_TEST
void cdk2_diag_runtime_transition_test_after(void);
#endif
#include <cdk2/capsule_runtime_entry.h>
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
#include <cdk2/authvar_namespace.h>
#include <cdk2/authvar_native_x86.h>
#include <cdk2/authvar_runtime_owner.h>
#include <cdk2/dxe_core_abi.h>
#include <cdk2/protected_image_policy.h>
#endif

#include <stddef.h>
#include <string.h>

typedef EFI_STATUS CDK2_MS_ABI allocate_fn(UINTN, UINTN, void **);
typedef EFI_STATUS CDK2_MS_ABI free_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI locate_handles_fn(UINTN, EFI_GUID *, void *,
	UINTN *, void ***);
typedef EFI_STATUS CDK2_MS_ABI handle_fn(void *, EFI_GUID *, void **);
typedef EFI_STATUS CDK2_MS_ABI locate_fn(EFI_GUID *, void *, void **);
typedef EFI_STATUS CDK2_MS_ABI install_fn(void **, ...);
typedef EFI_STATUS CDK2_MS_ABI uninstall_fn(void *, ...);
typedef EFI_STATUS CDK2_MS_ABI close_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI create_ex_fn(UINT32, UINTN, void *, void *,
	const EFI_GUID *, void **);
typedef EFI_STATUS CDK2_MS_ABI convert_fn(UINTN, void **);
typedef void CDK2_MS_ABI notify_fn(void *, void *);
typedef EFI_STATUS CDK2_MS_ABI set_variable_fn(CHAR16 *, EFI_GUID *, UINT32,
	UINTN, void *);
typedef UINTN CDK2_MS_ABI raise_tpl_fn(UINTN);
typedef void CDK2_MS_ABI restore_tpl_fn(UINTN);

#define VARIABLE_POLICY_REVISION 0x00010000U
#define VARIABLE_POLICY_SLOTS 128U
#define VARIABLE_POLICY_BYTES 512U

struct variable_policy_entry {
	UINT32 version;
	UINT16 size, offset_to_name;
	EFI_GUID name_space;
	UINT32 min_size, max_size, attributes_must_have, attributes_cant_have;
	UINT8 lock_policy_type, padding[3];
} __packed;
struct variable_lock_state {
	EFI_GUID name_space;
	UINT8 value, padding;
} __packed;
_Static_assert(sizeof(struct variable_lock_state) == 18 &&
	offsetof(struct variable_lock_state, name_space) == 0 &&
	offsetof(struct variable_lock_state, value) == 16,
	"VariablePolicy lock-on-variable-state ABI");
struct variable_policy_protocol {
	UINT64 revision;
	EFI_STATUS (CDK2_MS_ABI *disable)(void);
	EFI_STATUS (CDK2_MS_ABI *is_enabled)(BOOLEAN *enabled);
	EFI_STATUS (CDK2_MS_ABI *register_policy)(const struct variable_policy_entry
		*policy);
	void *dump;
	EFI_STATUS (CDK2_MS_ABI *lock)(void);
	void *get_info, *get_lock_info;
};

struct variable_entry {
	struct cdk2_variable_service *service;
	struct cdk2_variable_backend *backend;
	struct cdk2_variable_store *imported, *persistent;
	struct cdk2_runtime_services_view *runtime;
	struct cdk2_boot_services_view *boot;
	void *arch_handle, *exit_event, *virtual_event;
	void *old_get, *old_next, *old_set, *old_query;
	volatile UINT8 locked;
	_Alignas(CHAR16) UINT8 policy[VARIABLE_POLICY_SLOTS][VARIABLE_POLICY_BYTES];
	UINTN policy_count;
	BOOLEAN policy_enabled, policy_locked;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	struct cdk2_authvar_runtime_owner *protected;
	struct cdk2_authvar_namespace namespace;
	CHAR16 *names;
	void *ready_event;
	struct cdk2_protected_image_policy *image_policy;
	size_t image_policy_size;
	struct cdk2_security_router *security_router;
	BOOLEAN failed, ready;
#endif
};

_Static_assert(offsetof(struct variable_entry, policy) % _Alignof(CHAR16) == 0,
	"Private policy names require native CHAR16 alignment");

#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static const EFI_GUID fvb_guid = { 0x8f644fa9U, 0xe850U, 0x4db1U,
	{ 0x9c, 0xe2, 0x0b, 0x44, 0x69, 0x8e, 0x8d, 0xa4 } };
static const EFI_GUID ftw_guid = { 0x3ebd9e82U, 0x2c78U, 0x4de6U,
	{ 0x97, 0x86, 0x8d, 0x4b, 0xfc, 0xb7, 0xc8, 0x81 } };
#endif
static const EFI_GUID variable_arch_guid = { 0x1e5668e2U, 0x8481U, 0x11d4U,
	{ 0xbc, 0xf1, 0, 0x80, 0xc7, 0x3c, 0x88, 0x81 } };
static const EFI_GUID variable_write_guid = { 0x6441f818U, 0x6362U, 0x4e44U,
	{ 0xb5, 0x70, 0x7d, 0xba, 0x31, 0xdd, 0x24, 0x53 } };
static const EFI_GUID variable_policy_guid = { 0x81d1675cU, 0x86f6U, 0x48dfU,
	{ 0xbd, 0x95, 0x9a, 0x6e, 0x4f, 0x09, 0x25, 0xc3 } };
static const EFI_GUID exit_guid = { 0x27abf055U, 0xb1b8U, 0x4c26U,
	{ 0x80, 0x48, 0x74, 0x8f, 0x37, 0xba, 0xa2, 0xdf } };
static const EFI_GUID virtual_guid = { 0x13fa7698U, 0xc831U, 0x49c7U,
	{ 0x87, 0xea, 0x8f, 0x43, 0xfc, 0xc2, 0x51, 0x96 } };
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static const EFI_GUID ready_guid = { 0x7ce88fb3U, 0x4bd7U, 0x4679U,
	{ 0x87, 0xa8, 0xa8, 0xd8, 0xde, 0xe5, 0x0d, 0x2b } };
static const EFI_GUID hob_guid = { 0x7739f24cU, 0x93d7U, 0x11d4U,
	{ 0x9a, 0x3a, 0, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
static struct cdk2_boot_services_view *preparing_boot;

static EFI_STATUS allocate_protected(size_t size, void **buffer)
{
	return ((allocate_fn *)preparing_boot->allocate_pool)(6U, size, buffer);
}

static void release_protected(void *buffer)
{
	(void)((free_fn *)preparing_boot->free_pool)(buffer);
}
#endif
#ifdef CDK2_DEBUG
static const EFI_GUID serial_guid = { 0xbb25cf6f, 0xf1d4, 0x11d2,
	{ 0x9a, 0x0c, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0xfd } };
struct serial_protocol {
	UINT32 revision;
	void *reset, *set_attributes, *set_control, *get_control;
	cdk2_variable_diagnostic_write_fn *write;
};
#endif

static struct variable_entry *active;
static volatile UINT8 policy_transaction_locked;

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static const EFI_GUID security_router_guid = {0x3159cc63, 0x8e41, 0x4cb8,
	{0x86, 0x02, 0x9e, 0x3c, 0x63, 0x22, 0x44, 0x31}};

static EFI_STATUS retire_image_policy(struct variable_entry *entry)
{
	EFI_STATUS status;
	free_fn *free_pool = entry->boot->free_pool;
	UINT8 expected = 0;

	if (entry->image_policy == NULL)
		return EFI_SUCCESS;
	if (!__atomic_compare_exchange_n(&entry->namespace.busy, &expected, 1, false,
	    __ATOMIC_ACQUIRE, __ATOMIC_RELAXED))
		return EFI_NOT_READY;
	if (entry->security_router != NULL) {
		status = entry->security_router->unregister_policy(
			cdk2_protected_image_policy_authorize, entry->image_policy);
		if (EFI_ERROR(status))
			goto release;
		entry->security_router = NULL;
	}
	if (__atomic_load_n(&entry->image_policy->busy, __ATOMIC_ACQUIRE)) {
		status = EFI_NOT_READY;
		goto release;
	}
	status = free_pool(entry->image_policy);
	if (EFI_ERROR(status))
		goto release;
	entry->image_policy = NULL;
	entry->image_policy_size = 0;
	entry->namespace.policy_owner_base = NULL;
	entry->namespace.policy_owner_size = 0;
release:
	__atomic_store_n(&entry->namespace.busy, 0, __ATOMIC_RELEASE);
	return status;
}

static bool protected_identity_current(struct variable_entry *entry,
	struct cdk2_authvar_runtime_owner *owner, bool converted)
{
	return active == entry && !entry->failed && entry->protected == owner &&
	    owner->converted == converted &&
	    entry->namespace.policy_owner_base == entry->image_policy &&
	    entry->namespace.policy_owner_size == entry->image_policy_size &&
	    (entry->image_policy ?
		entry->image_policy->allocation_size == entry->image_policy_size :
		entry->image_policy_size == 0) &&
	    owner->runtime.owner_base == owner && owner->runtime.owner_size == sizeof(*owner) &&
	    owner->runtime.entry_base == entry && owner->runtime.entry_size == sizeof(*entry);
}

static bool protected_call_current(struct variable_entry *entry,
	struct cdk2_authvar_runtime_owner *owner, bool converted)
{
	if (protected_identity_current(entry, owner, converted) && !owner->failed)
		return true;
	entry->failed = TRUE;
	return false;
}

static bool pending_runtime_control(struct variable_entry *entry,
	struct cdk2_authvar_runtime_owner *owner, UINT16 port, UINT8 value,
	const struct cdk2_authvar_service_frame *expected)
{
	const struct cdk2_authvar_client *client = &owner->client;
	const struct cdk2_authvar_service_frame *request = (const void *)client->scratch;

	return protected_identity_current(entry, owner, false) && entry->ready &&
		__atomic_load_n(&owner->failed, __ATOMIC_ACQUIRE) &&
		!__atomic_load_n(&owner->entered_runtime, __ATOMIC_ACQUIRE) &&
		__atomic_load_n(&owner->runtime.busy, __ATOMIC_ACQUIRE) &&
		__atomic_load_n(&client->busy, __ATOMIC_ACQUIRE) &&
		owner->runtime.client == client && client->endpoint.valid &&
		client->private_owner == &owner->runtime &&
		client->private_owner_size == sizeof(owner->runtime) &&
		owner->runtime.message_size == client->endpoint.descriptor.message_size &&
		client->scratch && client->scratch_size >= sizeof(*request) &&
		client->endpoint.descriptor.message_size >= sizeof(*request) &&
		client->scratch_size >= client->endpoint.descriptor.message_size &&
		client->endpoint.descriptor.trigger_address == port &&
		client->endpoint.descriptor.trigger_value == value &&
		!EFI_ERROR(cdk2_authvar_service_request_validate(&client->endpoint.descriptor,
			client->scratch, client->endpoint.descriptor.message_size)) &&
		request->operation == CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME &&
		request->completion == CDK2_AUTHVAR_SERVICE_PENDING &&
		request->status == CDK2_AUTHVAR_SERVICE_STATUS_PENDING &&
		request->request_id != 0 && request->request_id == client->last_request_id &&
		(!expected || !memcmp(request, expected, sizeof(*request)));
}

static EFI_STATUS protected_trigger(void *context, UINT16 port, UINT8 value)
{
	struct variable_entry *entry = active;
	struct cdk2_authvar_runtime_owner *owner;
	bool converted;
	EFI_STATUS status;
	struct cdk2_authvar_service_frame pending_request;
	const void *pending_scratch;
	size_t pending_scratch_size;

	(void)context;
	if (entry == NULL || entry->failed)
		return EFI_NOT_READY;
	owner = entry->protected;
	converted = owner->converted;
	/* Only the owned, claimed op8 may carry its already-published closure. */
	if (__atomic_load_n(&owner->failed, __ATOMIC_ACQUIRE)) {
		if (!pending_runtime_control(entry, owner, port, value, NULL)) {
			entry->failed = TRUE;
			return EFI_DEVICE_ERROR;
		}
		pending_scratch = owner->client.scratch;
		pending_scratch_size = owner->client.scratch_size;
		memcpy(&pending_request, owner->client.scratch, sizeof(pending_request));
		status = cdk2_authvar_native_x86_trigger(NULL, port, value);
		if (owner->client.scratch != pending_scratch ||
		    owner->client.scratch_size != pending_scratch_size ||
		    !pending_runtime_control(entry, owner, port, value, &pending_request)) {
			entry->failed = TRUE;
			return EFI_DEVICE_ERROR;
		}
		return status;
	}
	if (!protected_call_current(entry, owner, converted))
		return EFI_DEVICE_ERROR;
	status = cdk2_authvar_native_x86_trigger(NULL, port, value);
	return protected_call_current(entry, owner, converted) ? status : EFI_DEVICE_ERROR;
}
#endif

static EFI_STATUS policy_name_size(const CHAR16 *name, UINTN maximum,
	UINTN *bytes)
{
	for (UINTN index = 0U; index < maximum / sizeof(*name); index++)
		if (name[index] == 0U) {
			*bytes = (index + 1U) * sizeof(*name);
			return index == 0U ? EFI_INVALID_PARAMETER : EFI_SUCCESS;
		}
	return EFI_INVALID_PARAMETER;
}

static BOOLEAN policy_name_matches(const CHAR16 *policy, const CHAR16 *name,
	UINTN bytes)
{
	for (UINTN index = 0U; index + 1U < bytes / sizeof(CHAR16); index++) {
		BOOLEAN hexadecimal = (name[index] >= L'0' && name[index] <= L'9') ||
			(name[index] >= L'A' && name[index] <= L'F') ||
			(name[index] >= L'a' && name[index] <= L'f');

		if (policy[index] != name[index] &&
		    !(policy[index] == L'#' && hexadecimal))
			return FALSE;
	}
	return TRUE;
}

static const struct variable_policy_entry *best_policy(const CHAR16 *name,
	UINTN name_bytes, const EFI_GUID *guid, BOOLEAN literal_pattern)
{
	const struct variable_policy_entry *best = NULL;
	UINTN best_priority = MAX_UINT8;

	for (UINTN index = 0; index < active->policy_count; index++) {
		const struct variable_policy_entry *policy =
			(const void *)active->policy[index];
		const CHAR16 *target = (const void *)(active->policy[index] +
			policy->offset_to_name);
		UINTN priority = MAX_UINT8;
		UINTN target_bytes;

		if (memcmp(guid, &policy->name_space, sizeof(*guid)))
			continue;
		if (policy->offset_to_name != policy->size) {
			if (EFI_ERROR(policy_name_size(target,
			    policy->size - policy->offset_to_name, &target_bytes)) ||
			    target_bytes != name_bytes ||
			    (literal_pattern ? memcmp(target, name, name_bytes) != 0 :
			     !policy_name_matches(target, name, name_bytes)))
				continue;
			priority = 0;
			for (UINTN character = 0; character + 1 < name_bytes / sizeof(*name);
			     character++)
				priority += !literal_pattern && target[character] == L'#';
		}
		if (best == NULL || priority < best_priority) {
			best = policy;
			best_priority = priority;
		}
	}
	return best;
}

static EFI_STATUS check_policy(CHAR16 *name, EFI_GUID *guid, UINT32 attributes,
	UINTN size)
{
	UINTN name_bytes;
	const struct variable_policy_entry *policy;
	BOOLEAN locked;

	CDK2_VARIABLE_DIAG("[CDK2][variable][info] check variable policy\n");

	if (!active->policy_enabled)
		return EFI_SUCCESS;
	if (EFI_ERROR(policy_name_size(name, CDK2_VARIABLE_STORE_BYTES,
		&name_bytes)))
		return EFI_INVALID_PARAMETER;
	policy = best_policy(name, name_bytes, guid, FALSE);
	if (policy != NULL) {
		locked = policy->lock_policy_type == 1U;
		if (policy->lock_policy_type == 3U) {
			const struct variable_lock_state *state =
				(const void *)((const UINT8 *)policy + sizeof(*policy));
			const CHAR16 *state_name = (const void *)(state + 1);
			EFI_GUID state_namespace;
			UINT8 value;
			UINTN state_name_bytes;
#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
			struct cdk2_variable_store *store =
				&active->service->bank[active->service->active];
			struct cdk2_variable_record *record;
#endif

			memcpy(&state_namespace, &state->name_space,
				sizeof(state_namespace));
			locked = !EFI_ERROR(policy_name_size(state_name,
				policy->size - sizeof(*policy) - sizeof(*state),
				&state_name_bytes));
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
			UINTN value_size = sizeof(value);

			locked = locked && cdk2_authvar_namespace_get(&active->namespace,
				state_name, &state_namespace, NULL, &value_size, &value) ==
				EFI_SUCCESS && value_size == sizeof(value) && value == state->value;
#else
			record = !locked ? NULL : cdk2_variable_record_find(store,
				state_name, state_name_bytes, &state_namespace);
			locked = record != NULL && record->data_bytes == sizeof(value);
			if (locked) {
				value = *cdk2_variable_record_data(store, record);
				locked = value == state->value;
			}
#endif
		} else if (policy->lock_policy_type == 2U) {
			UINTN existing_size = 0U;

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
			EFI_STATUS status = cdk2_authvar_namespace_get(&active->namespace,
				name, guid, NULL, &existing_size, NULL);

			locked = status == EFI_BUFFER_TOO_SMALL || status == EFI_SUCCESS;
#else
			locked = cdk2_variable_service_get(active->service, name, guid,
				NULL, &existing_size, NULL) == EFI_BUFFER_TOO_SMALL ||
				!EFI_ERROR(cdk2_variable_service_get(active->service, name,
					guid, NULL, &existing_size, NULL));
#endif
		}
		if (locked) {
			CDK2_VARIABLE_DIAG("[CDK2][variable][warn] variable policy locked write\n");
			return EFI_WRITE_PROTECTED;
		}
		/* Policy constrains this request, not the accumulated stored value.
		 * A zero-byte APPEND is still a write, unlike a zero-byte delete. */
		if ((size != 0U || (attributes & CDK2_VARIABLE_APPEND_WRITE)) &&
		    (size < policy->min_size || size > policy->max_size ||
		    (attributes & policy->attributes_must_have) !=
			policy->attributes_must_have ||
		    (attributes & policy->attributes_cant_have) != 0U)) {
			CDK2_VARIABLE_DIAG("[CDK2][variable][warn] variable policy rejected write\n");
			return EFI_INVALID_PARAMETER;
		}
	}
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI disable_policy(void)
{
	/* EDK2's default PcdAllowVariablePolicyEnforcementDisable is false. */
	return active == NULL ? EFI_NOT_READY : EFI_WRITE_PROTECTED;
}

static EFI_STATUS CDK2_MS_ABI policy_enabled(BOOLEAN *enabled)
{
	if (active == NULL || enabled == NULL)
		return EFI_INVALID_PARAMETER;
	*enabled = active->policy_enabled;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI register_policy(
	const struct variable_policy_entry *policy)
{
	UINTN name_bytes;
	UINTN minimum_name_offset;
	EFI_GUID policy_namespace;
	const struct variable_policy_entry *existing;
	EFI_STATUS status = EFI_SUCCESS;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	struct variable_entry *entry = active;
	struct cdk2_authvar_runtime_owner *owner;
	bool was_converted;
	UINTN policy_tpl = ~(UINTN)0U;
	union {
		struct variable_policy_entry header;
		uint8_t bytes[VARIABLE_POLICY_BYTES];
	} snapshot;
#endif

	CDK2_VARIABLE_DIAG("[CDK2][variable][info] register variable policy\n");

	if (active == NULL)
		return EFI_NOT_READY;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (active->failed)
		return EFI_DEVICE_ERROR;
	owner = entry->protected;
	was_converted = owner->converted;
	if (owner->failed || !protected_call_current(entry, owner, was_converted))
		return EFI_DEVICE_ERROR;
	if (!entry->service->bank[entry->service->active].runtime &&
	    entry->boot->raise_tpl && entry->boot->restore_tpl)
		policy_tpl = ((raise_tpl_fn *)entry->boot->raise_tpl)(16U);
	if (__atomic_test_and_set(&policy_transaction_locked, __ATOMIC_ACQUIRE)) {
		if (policy_tpl != ~(UINTN)0U)
			((restore_tpl_fn *)entry->boot->restore_tpl)(policy_tpl);
		return EFI_NOT_READY;
	}
#endif
	if (active->policy_locked) {
		status = EFI_WRITE_PROTECTED;
		goto out;
	}
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (policy == NULL || !cdk2_authvar_namespace_outside_private(&entry->namespace,
	    policy, sizeof(*policy)))
		goto invalid;
	size_t policy_bytes = policy->size;

	if (policy_bytes < sizeof(*policy) || policy_bytes > sizeof(snapshot) ||
	    !cdk2_authvar_namespace_outside_private(&entry->namespace, policy, policy_bytes))
		goto invalid;
	memcpy(snapshot.bytes, policy, policy_bytes);
	policy = &snapshot.header;
	if (policy->size != policy_bytes)
		goto invalid;
#endif
	if (policy == NULL || policy->version != VARIABLE_POLICY_REVISION ||
	    policy->size < sizeof(*policy) ||
	    policy->size > VARIABLE_POLICY_BYTES ||
	    (policy->size & 1U) || (policy->offset_to_name & 1U) ||
	    policy->offset_to_name < sizeof(*policy) ||
	    policy->offset_to_name > policy->size || !policy->max_size ||
	    policy->min_size > policy->max_size ||
	    policy->lock_policy_type > 3U)
		goto invalid;
	minimum_name_offset = sizeof(*policy);
	if (policy->lock_policy_type == 3U) {
		minimum_name_offset += sizeof(struct variable_lock_state);
		if (policy->offset_to_name <= minimum_name_offset ||
		    EFI_ERROR(policy_name_size((const void *)((const UINT8 *)policy +
			minimum_name_offset), policy->offset_to_name - minimum_name_offset,
			&name_bytes)) ||
		    name_bytes != policy->offset_to_name - minimum_name_offset)
			goto invalid;
	} else if (policy->offset_to_name != minimum_name_offset) {
		goto invalid;
	}
	if (policy->offset_to_name != policy->size) {
		const CHAR16 *name = (const void *)((const UINT8 *)policy +
			policy->offset_to_name);
		UINTN wildcards = 0;

		if (EFI_ERROR(policy_name_size(name, policy->size - policy->offset_to_name,
		    &name_bytes)) || name_bytes != (UINTN)(policy->size - policy->offset_to_name))
			goto invalid;
		for (UINTN index = 0; index + 1 < name_bytes / sizeof(*name); index++)
			wildcards += name[index] == L'#';
		if (wildcards > MAX_UINT8)
			goto invalid;
	}
	memcpy(&policy_namespace, &policy->name_space, sizeof(policy_namespace));
	existing = best_policy((const void *)((const UINT8 *)policy + policy->offset_to_name),
		policy->size - policy->offset_to_name, &policy_namespace, TRUE);
	if (existing != NULL && existing->size - existing->offset_to_name ==
	    policy->size - policy->offset_to_name) {
		status = EFI_ALREADY_STARTED;
		goto out;
	}
	if (active->policy_count == VARIABLE_POLICY_SLOTS) {
		status = EFI_OUT_OF_RESOURCES;
		goto out;
	}
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (policy->lock_policy_type == 3U) {
		/* No contract pins this predicate key's class across delete/recreate. */
		status = EFI_UNSUPPORTED;
		goto out;
	}
	status = cdk2_authvar_runtime_register_policy(
		&owner->runtime, policy, policy->size);

	if (!protected_call_current(entry, owner, was_converted)) {
		status = EFI_DEVICE_ERROR;
		goto out;
	}
	if (EFI_ERROR(status))
		goto out;
#endif
	memcpy(active->policy[active->policy_count], policy, policy->size);
	active->policy_count++;
	goto out;
invalid:
	status = EFI_INVALID_PARAMETER;
out:
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	__atomic_clear(&policy_transaction_locked, __ATOMIC_RELEASE);
	if (policy_tpl != ~(UINTN)0U)
		((restore_tpl_fn *)entry->boot->restore_tpl)(policy_tpl);
#endif
	return status;
}

static EFI_STATUS CDK2_MS_ABI lock_policy(void)
{
	if (active == NULL)
		return EFI_NOT_READY;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	struct variable_entry *entry = active;
	struct cdk2_authvar_runtime_owner *owner = entry->protected;
	const bool was_converted = owner->converted;
	EFI_STATUS status;

	if (active->failed || owner->failed ||
	    !protected_call_current(entry, owner, was_converted))
		return EFI_DEVICE_ERROR;
	if (__atomic_test_and_set(&policy_transaction_locked, __ATOMIC_ACQUIRE))
		return EFI_NOT_READY;
	status = entry->policy_locked ? EFI_WRITE_PROTECTED :
		cdk2_authvar_runtime_lock_policy(&owner->runtime);
	if (!protected_call_current(entry, owner, was_converted)) {
		status = EFI_DEVICE_ERROR;
	}
	if (!EFI_ERROR(status))
		entry->policy_locked = TRUE;
	__atomic_clear(&policy_transaction_locked, __ATOMIC_RELEASE);

	if (EFI_ERROR(status))
		return status;
#else
	if (active->policy_locked)
		return EFI_WRITE_PROTECTED;
	active->policy_locked = TRUE;
#endif
	CDK2_VARIABLE_DIAG("[CDK2][variable][info] lock variable policy\n");
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI unsupported_policy_method(void)
{
	return EFI_UNSUPPORTED;
}

static struct variable_policy_protocol policy_protocol = {
	VARIABLE_POLICY_REVISION, disable_policy, policy_enabled, register_policy,
	unsupported_policy_method, lock_policy, unsupported_policy_method,
	unsupported_policy_method
};

#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static UINT64 read64(const UINT8 *bytes)
{
	UINT64 value = 0U;

	for (UINTN index = 0U; index < sizeof(value); index++)
		value |= (UINT64)bytes[index] << (index * 8U);
	return value;
}
#endif

static UINTN service_lock(void *context)
{
	struct variable_entry *entry = context;
	UINTN old_tpl = ~(UINTN)0U;

	if (!entry->service->bank[entry->service->active].runtime &&
	    entry->boot->raise_tpl != NULL && entry->boot->restore_tpl != NULL)
		old_tpl = ((raise_tpl_fn *)entry->boot->raise_tpl)(16U);

	while (__atomic_test_and_set(&entry->locked, __ATOMIC_ACQUIRE))
		;
	return old_tpl;
}

static void service_unlock(void *context, UINTN state)
{
	struct variable_entry *entry = context;

	__atomic_clear(&entry->locked, __ATOMIC_RELEASE);
	if (state != ~(UINTN)0U)
		((restore_tpl_fn *)entry->boot->restore_tpl)(state);
}

#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static EFI_STATUS persist(void *context,
	const struct cdk2_variable_store *store)
{
	return cdk2_variable_backend_persist(
		((struct variable_entry *)context)->backend, store);
}
#endif

static EFI_STATUS CDK2_MS_ABI get_variable(CHAR16 *name, EFI_GUID *guid,
	UINT32 *attributes, UINTN *size, void *data)
{
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (active == NULL || active->failed || active->protected->failed)
		return EFI_NOT_READY;
	struct variable_entry *entry = active;
	struct cdk2_authvar_runtime_owner *owner = entry->protected;
	bool converted = owner->converted;
	EFI_STATUS status;

	if (!protected_call_current(entry, owner, converted))
		return EFI_DEVICE_ERROR;
	status = cdk2_authvar_namespace_get(&entry->namespace, name, guid,
		attributes, size, data);

	return protected_call_current(entry, owner, converted) ? status : EFI_DEVICE_ERROR;
#else
	return active == NULL ? EFI_NOT_READY : cdk2_variable_service_get(
		active->service, name, guid, attributes, size, data);
#endif
}

static EFI_STATUS CDK2_MS_ABI get_next(UINTN *size, CHAR16 *name,
	EFI_GUID *guid)
{
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (active == NULL || active->failed || active->protected->failed)
		return EFI_NOT_READY;
	struct variable_entry *entry = active;
	struct cdk2_authvar_runtime_owner *owner = entry->protected;
	bool converted = owner->converted;
	EFI_STATUS status;

	if (!protected_call_current(entry, owner, converted))
		return EFI_DEVICE_ERROR;
	status = cdk2_authvar_namespace_next(&entry->namespace, size, name, guid);

	return protected_call_current(entry, owner, converted) ? status : EFI_DEVICE_ERROR;
#else
	return active == NULL ? EFI_NOT_READY : cdk2_variable_service_next(
		active->service, size, name, guid);
#endif
}

static EFI_STATUS CDK2_MS_ABI set_variable(CHAR16 *name, EFI_GUID *guid,
	UINT32 attributes, UINTN size, void *data)
{
	EFI_STATUS status = EFI_DEVICE_ERROR;
	EFI_STATUS policy_status;
	UINTN policy_tpl = ~(UINTN)0U;
	struct variable_entry *entry = active;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	struct cdk2_authvar_runtime_owner *owner;
	bool converted;
	uint32_t key_bytes;
#endif

	if (active == NULL)
		return EFI_NOT_READY;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (active->failed || active->protected->failed)
		return EFI_NOT_READY;
	owner = entry->protected;
	converted = owner->converted;
#endif
	if (name == NULL || guid == NULL || (size != 0U && data == NULL))
		return EFI_INVALID_PARAMETER;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if ((uintptr_t)name % _Alignof(CHAR16) || (uintptr_t)guid % _Alignof(EFI_GUID))
		return EFI_INVALID_PARAMETER;
	if (!protected_call_current(entry, owner, converted))
		return EFI_DEVICE_ERROR;
	if (!cdk2_authvar_namespace_outside_private(&entry->namespace, data, size))
		return EFI_INVALID_PARAMETER;
	status = cdk2_authvar_namespace_key_size(&entry->namespace, name, guid,
		owner->client.endpoint.descriptor.maximum_name_size, 0, &key_bytes);
	if (EFI_ERROR(status))
		return status;
#endif
	if (!active->service->bank[active->service->active].runtime &&
	    active->boot->raise_tpl != NULL && active->boot->restore_tpl != NULL)
		policy_tpl = ((raise_tpl_fn *)active->boot->raise_tpl)(16U);
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (__atomic_test_and_set(&policy_transaction_locked, __ATOMIC_ACQUIRE)) {
		if (policy_tpl != ~(UINTN)0U)
			((restore_tpl_fn *)entry->boot->restore_tpl)(policy_tpl);
		return EFI_NOT_READY;
	}
#else
	while (__atomic_test_and_set(&policy_transaction_locked,
	    __ATOMIC_ACQUIRE))
		;
#endif
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	struct cdk2_authvar_key_classification classification;

	policy_status = cdk2_authvar_runtime_classify(&active->protected->runtime,
		name, guid, &classification);
	if (!protected_call_current(entry, owner, converted)) {
		policy_status = EFI_DEVICE_ERROR;
		goto policy_done;
	}
	if (policy_status == EFI_NOT_FOUND) {
		/* Protected mutations enforce policy inside the actual SMM transaction. */
		policy_status = attributes & (CDK2_VARIABLE_NON_VOLATILE |
			CDK2_VARIABLE_AUTHENTICATED_WRITE_ACCESS |
			CDK2_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS) ?
			EFI_SUCCESS : check_policy(name, guid, attributes, size);
	}
	status = policy_status;
	if (!protected_call_current(entry, owner, converted)) {
		policy_status = EFI_DEVICE_ERROR;
		goto policy_done;
	}
	if (!EFI_ERROR(policy_status))
		status = cdk2_authvar_namespace_set(&entry->namespace, name, guid,
			attributes, size, data);
	if (!protected_call_current(entry, owner, converted))
		policy_status = EFI_DEVICE_ERROR;
policy_done:
#else
	policy_status = check_policy(name, guid, attributes, size);
	status = policy_status;
	if (!EFI_ERROR(policy_status))
		status = cdk2_variable_service_set(active->service, name, guid,
			attributes, size, data);
#endif
	__atomic_clear(&policy_transaction_locked, __ATOMIC_RELEASE);
	if (policy_tpl != ~(UINTN)0U)
		((restore_tpl_fn *)entry->boot->restore_tpl)(policy_tpl);
	if (EFI_ERROR(policy_status))
		return policy_status;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	return status;
#else
	if ((attributes & (CDK2_VARIABLE_AUTHENTICATED_WRITE_ACCESS |
	    CDK2_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS)) == 0U &&
	    status != EFI_SECURITY_VIOLATION)
		return status;
	/* This native driver deliberately does not pretend that the replaced
	 * SetVariable slot authenticates PKCS#7 payloads.  Secure Boot selects the
	 * retained authenticated variable driver in Kconfig; non-Secure-Boot
	 * native builds reject authenticated writes explicitly. */
	return EFI_UNSUPPORTED;
#endif
}

static EFI_STATUS CDK2_MS_ABI query_variable(UINT32 attributes,
	UINT64 *maximum, UINT64 *remaining, UINT64 *variable)
{
#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	EFI_STATUS status;
#endif

	if (active == NULL)
		return EFI_NOT_READY;
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (active->failed || active->protected->failed)
		return EFI_NOT_READY;
	struct variable_entry *entry = active;
	struct cdk2_authvar_runtime_owner *owner = entry->protected;
	bool converted = owner->converted;
	EFI_STATUS status;

	if (!protected_call_current(entry, owner, converted))
		return EFI_DEVICE_ERROR;
	status = cdk2_authvar_namespace_query(&entry->namespace, attributes,
		maximum, remaining, variable);

	return protected_call_current(entry, owner, converted) ? status : EFI_DEVICE_ERROR;
#else
	status = cdk2_variable_service_query(active->service, attributes, maximum,
		remaining, variable);
	if (!EFI_ERROR(status) &&
	    (attributes & CDK2_VARIABLE_NON_VOLATILE) != 0U &&
	    active->service->bank[active->service->active].runtime) {
		UINTN appendable = cdk2_variable_backend_runtime_remaining(active->backend);

		if (*remaining > appendable)
			*remaining = appendable;
		if (*variable > appendable)
			*variable = appendable;
	}
	return status;
#endif
}

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static void CDK2_MS_ABI ready_to_boot(void *event, void *context)
{
	struct variable_entry *entry = context;
	struct cdk2_authvar_runtime_owner *owner = entry->protected;
	const bool converted = owner->converted;
	EFI_STATUS status;

	(void)event;
	if (entry->failed || entry->ready)
		return;
	if (!protected_call_current(entry, owner, converted) ||
	    entry->protected->failed ||
	    __atomic_load_n(&entry->namespace.busy, __ATOMIC_ACQUIRE) ||
	    __atomic_load_n(&policy_transaction_locked, __ATOMIC_ACQUIRE)) {
		entry->failed = TRUE;
		return;
	}
	status = cdk2_authvar_runtime_ready_to_boot(&owner->runtime);
	entry->failed = entry->failed || EFI_ERROR(status) ||
		!protected_call_current(entry, owner, converted);
	entry->ready = !entry->failed;
}
#endif

static void CDK2_MS_ABI exit_boot(void *event, void *context)
{
	struct variable_entry *entry = context;

	(void)event;
	CDK2_VARIABLE_DIAG("[CDK2][variable][info] enter runtime phase\n");
#ifdef CDK2_DEBUG
	cdk2_variable_diagnostic_set(NULL, NULL);
#endif
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (!entry->ready)
		ready_to_boot(NULL, entry);
	if (!protected_call_current(entry, entry->protected, entry->protected->converted))
		goto retire;
	if (__atomic_load_n(&entry->namespace.busy, __ATOMIC_ACQUIRE) ||
	    __atomic_load_n(&policy_transaction_locked, __ATOMIC_ACQUIRE))
		entry->failed = TRUE;
	if (entry->failed || entry->protected->entered_runtime)
		goto retire;
	entry->failed = EFI_ERROR(cdk2_authvar_runtime_owner_enter_runtime(entry->protected));
	if (!entry->failed)
#endif
		cdk2_variable_service_enter_runtime(entry->service);
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
retire:
	if (EFI_ERROR(retire_image_policy(entry)))
		entry->failed = TRUE;
#endif
}

#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static void convert(struct variable_entry *entry, void **pointer)
{
	convert_fn *convert_pointer = entry->runtime->convert_pointer;

	if (EFI_ERROR(convert_pointer(0U, pointer)))
		CDK2_VARIABLE_DIAG("[CDK2][variable][error] pointer conversion failed\n");
}
#endif

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static convert_fn *converting;

static EFI_STATUS convert_protected(void **pointer)
{
	return converting(0U, pointer);
}

static void protected_virtual_change(struct variable_entry *entry)
{
	struct cdk2_authvar_runtime_owner *owner = entry->protected;
	void *pointers[] = { entry, entry->service, entry->names,
		(void *)entry->service->lock, (void *)entry->service->unlock };
	const size_t sizes[] = { sizeof(*entry), sizeof(*entry->service),
		entry->namespace.names_size, 1, 1 };
	const BOOLEAN was_failed = entry->failed;

	entry->failed = TRUE;
	if (was_failed || __atomic_load_n(&entry->namespace.busy, __ATOMIC_ACQUIRE) ||
	    __atomic_load_n(&policy_transaction_locked, __ATOMIC_ACQUIRE) ||
	    EFI_ERROR(retire_image_policy(entry)) ||
	    entry->namespace.protected_owner != &owner->runtime ||
	    entry->namespace.ram_owner != entry->service ||
	    entry->namespace.names != entry->names ||
	    owner->runtime.owner_base != owner || owner->runtime.owner_size != sizeof(*owner) ||
	    owner->runtime.entry_base != entry || owner->runtime.entry_size != sizeof(*entry) ||
	    entry->service->context != entry || entry->service->persist != NULL)
		goto failed;
	converting = entry->runtime->convert_pointer;
	if (converting == NULL || EFI_ERROR(cdk2_authvar_runtime_owner_convert(&owner,
	    convert_protected)))
		goto failed;
	for (size_t index = 0; index < ARRAY_SIZE(pointers); index++)
		if (EFI_ERROR(convert_protected(&pointers[index])) || pointers[index] == NULL)
			goto failed;
	for (size_t index = 0; index < 3; index++) {
		const uintptr_t address = (uintptr_t)pointers[index];
		const void *protected_bases[] = { owner, owner->runtime.message,
			owner->client.scratch, owner->client.mailbox_alias };
		const size_t protected_sizes[] = { sizeof(*owner), owner->runtime.message_size,
			owner->client.scratch_size, owner->client.endpoint.descriptor.communication_size };

		if (!sizes[index] || sizes[index] - 1 > UINTPTR_MAX - address)
			goto failed;
		for (size_t region = 0; region < ARRAY_SIZE(protected_bases); region++) {
			const uintptr_t base = (uintptr_t)protected_bases[region];

			if (!protected_sizes[region] || protected_sizes[region] - 1 > UINTPTR_MAX - base ||
			    (address <= base ? base - address < sizes[index] :
			     address - base < protected_sizes[region]))
				goto failed;
		}
		for (size_t other = 0; other < index; other++) {
			const uintptr_t prior = (uintptr_t)pointers[other];

			if (address <= prior ? prior - address < sizes[index] :
			    address - prior < sizes[other])
				goto failed;
		}
	}
	if ((uintptr_t)pointers[0] % _Alignof(struct variable_entry) ||
	    (uintptr_t)pointers[1] % _Alignof(struct cdk2_variable_service) ||
	    (uintptr_t)pointers[2] % _Alignof(CHAR16))
		goto failed;
	entry->protected = owner;
	owner->runtime.entry_base = pointers[0];
	entry->namespace.protected_owner = &owner->runtime;
	entry->namespace.ram_owner = pointers[1];
	entry->namespace.names = pointers[2];
	entry->service->context = pointers[0];
	entry->service->lock = pointers[3];
	entry->service->unlock = pointers[4];
	entry->service = pointers[1];
	entry->names = pointers[2];
	entry->failed = FALSE;
	active = pointers[0];
	converting = NULL;
	return;
failed:
	converting = NULL;
	active = NULL;
}
#endif

static void release_pool(free_fn *free_pool, void *buffer)
{
	if (buffer != NULL && EFI_ERROR(free_pool(buffer)))
		CDK2_VARIABLE_DIAG("[CDK2][variable][error] pool release failed\n");
}

static void CDK2_MS_ABI virtual_change(void *event, void *context)
{
	struct variable_entry *entry = context;

	(void)event;
	/* Serial I/O is a boot-time protocol and cannot be retained by runtime
	 * variable services after virtual address transition. */
	cdk2_diag_runtime_transition();
#ifdef CDK2_DIAG_RUNTIME_TRANSITION_TEST
	cdk2_diag_runtime_transition_test_after();
#endif
#ifdef CDK2_DEBUG
	cdk2_variable_diagnostic_set(NULL, NULL);
#endif
	CDK2_VARIABLE_DIAG("[CDK2][variable][info] convert runtime pointers\n");
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	protected_virtual_change(entry);
#else
	convert(entry, (void **)&entry->backend->fvb);
	convert(entry, &entry->backend->fvb_handle);
	convert(entry, (void **)&entry->backend->image);
	convert(entry, (void **)&entry->backend->scratch_current);
	convert(entry, (void **)&entry->backend->scratch_persistent);
	convert(entry, (void **)&entry->backend->scratch_image);
	convert(entry, (void **)&entry->service->context);
	convert(entry, (void **)&entry->service->persist);
	convert(entry, (void **)&entry->service->lock);
	convert(entry, (void **)&entry->service->unlock);
	if (entry->old_set != NULL)
		convert(entry, &entry->old_set);
	convert(entry, (void **)&entry->service);
	convert(entry, (void **)&entry->backend);
	convert(entry, (void **)&active);
#endif
}

#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
static EFI_STATUS find_backend(struct variable_entry *entry,
	struct cdk2_ftw_protocol_view *ftw, struct cdk2_variable_store *store)
{
	locate_handles_fn *locate_handles = entry->boot->locate_handle_buffer;
	handle_fn *handle_protocol = entry->boot->handle_protocol;
	allocate_fn *allocate = entry->boot->allocate_pool;
	free_fn *free_pool = entry->boot->free_pool;
	void **handles = NULL;
	UINTN count = 0U;
	EFI_STATUS status;

	status = locate_handles(2U, (EFI_GUID *)&fvb_guid, NULL, &count, &handles);
	if (EFI_ERROR(status))
		return status;
	status = EFI_NOT_FOUND;
	for (UINTN index = 0U; index < count; index++) {
		struct cdk2_fvb_protocol_view *fvb;
		UINT8 header[72];
		UINTN header_size = sizeof(header), block_size, blocks;
		UINT64 fv_size;
		void *image;

		if (EFI_ERROR(handle_protocol(handles[index], (EFI_GUID *)&fvb_guid,
		    (void **)&fvb)) || EFI_ERROR(fvb->get_block_size(fvb, 0U,
		    &block_size, &blocks)) || block_size < sizeof(header) ||
		    EFI_ERROR(fvb->read(fvb, 0U, 0U, &header_size, header)) ||
		    header_size != sizeof(header))
			continue;
		fv_size = read64(header + 32U);
		if (fv_size < sizeof(header) + 28U || fv_size > MAX_UINTN ||
		    ((UINT32)header[40] | (UINT32)header[41] << 8 |
		    (UINT32)header[42] << 16 | (UINT32)header[43] << 24) !=
			0x4856465fU)
			continue;
		status = cdk2_variable_store_init(store,
			(UINTN)fv_size - sizeof(header) - 28U <
				CDK2_VARIABLE_STORE_BYTES ?
			(UINTN)fv_size - sizeof(header) - 28U :
				CDK2_VARIABLE_STORE_BYTES);
		if (EFI_ERROR(status))
			continue;
		status = allocate(6U, (UINTN)fv_size, &image);
		if (EFI_ERROR(status))
			continue;
		status = cdk2_variable_backend_init(entry->backend, fvb,
			handles[index], ftw, image, (UINTN)fv_size, store);
		if (!EFI_ERROR(status))
			break;
		release_pool(free_pool, image);
		entry->backend->image = NULL;
	}
	release_pool(free_pool, handles);
	return status;
}
#endif

EFI_STATUS CDK2_MS_ABI cdk2_variable_runtime_entry(void *image, void *system)
{
	struct cdk2_system_table_view *table = system;
#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	struct cdk2_ftw_protocol_view *ftw;
#endif
	struct variable_entry *entry;
	allocate_fn *allocate;
	locate_fn *locate;
	install_fn *install;
	create_ex_fn *create;
	free_fn *free_pool;
	uninstall_fn *uninstall;
	close_fn *close_event;
	cdk2_crc32_fn *calculate_crc;
	EFI_STATUS status;

	(void)image;
	if (table == NULL || table->runtime == NULL || table->boot == NULL ||
	    active != NULL)
		return EFI_INVALID_PARAMETER;
	CDK2_DIAG_CONFIGURE_OPTIONAL_SYSTEM_TABLE(system);
	allocate = table->boot->allocate_pool;
	free_pool = table->boot->free_pool;
	locate = table->boot->locate_protocol;
	install = table->boot->install_multiple;
	create = table->boot->create_event_ex;
	uninstall = table->boot->uninstall_multiple;
	close_event = table->boot->close_event;
	calculate_crc = table->boot->calculate_crc32;
#ifdef CDK2_DEBUG
	if (locate != NULL) {
		struct serial_protocol *serial = NULL;

		if (!EFI_ERROR(locate((EFI_GUID *)&serial_guid, NULL,
		    (void **)&serial)) && serial != NULL)
			cdk2_variable_diagnostic_set(serial, serial->write);
	}
#endif
	CDK2_VARIABLE_DIAG("[CDK2][variable][info] driver entry\n");
	if (allocate == NULL || table->boot->free_pool == NULL || locate == NULL ||
#if !CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	    table->boot->locate_handle_buffer == NULL ||
	    table->boot->handle_protocol == NULL ||
#endif
	    install == NULL ||
	    uninstall == NULL || create == NULL || close_event == NULL ||
	    calculate_crc == NULL)
		return EFI_UNSUPPORTED;
	status = allocate(6U, sizeof(*entry), (void **)&entry);
	if (EFI_ERROR(status)) {
		CDK2_VARIABLE_DIAG("[CDK2][variable][error] runtime allocation failed\n");
		return status;
	}
	memset(entry, 0, sizeof(*entry));
	entry->policy_enabled = TRUE;
	entry->boot = table->boot;
	entry->runtime = table->runtime;
	status = allocate(6U, sizeof(*entry->service), (void **)&entry->service);
	if (!EFI_ERROR(status))
		memset(entry->service, 0, sizeof(*entry->service));
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	const struct cdk2_dxe_system_table *full_table = system;
	const void *hob_list = NULL;

	preparing_boot = table->boot;
	if (!EFI_ERROR(status) && (full_table->number_of_table_entries >
	    SIZE_MAX / sizeof(*full_table->configuration_table) ||
	    (full_table->number_of_table_entries && full_table->configuration_table == NULL)))
		status = EFI_COMPROMISED_DATA;
	if (!EFI_ERROR(status)) {
		for (UINTN index = 0; index < full_table->number_of_table_entries; index++) {
			const struct cdk2_dxe_configuration_table *config =
				&full_table->configuration_table[index];

			if (memcmp(&config->guid, &hob_guid, sizeof(hob_guid)))
				continue;
			if (hob_list != NULL || config->table == NULL) {
				status = EFI_COMPROMISED_DATA;
				break;
			}
			hob_list = config->table;
		}
	}
	if (!EFI_ERROR(status))
		status = cdk2_authvar_runtime_owner_prepare(hob_list, allocate_protected,
			release_protected, protected_trigger,
			cdk2_authvar_native_x86_cache, cdk2_authvar_native_x86_barrier,
			&entry->protected);
	if (!EFI_ERROR(status)) {
		CDK2_VARIABLE_DIAG("[CDK2][variable][info] protected variable endpoint validated\n");
		CDK2_VARIABLE_DIAG("[CDK2][variable][info] initialize volatile-only variable banks\n");
		status = cdk2_variable_service_init(entry->service,
			CDK2_VARIABLE_STORE_BYTES, entry, NULL, service_lock, service_unlock);
	}
	if (!EFI_ERROR(status))
		status = allocate(6U, entry->protected->client.endpoint.descriptor.maximum_name_size,
			(void **)&entry->names);
	if (!EFI_ERROR(status))
		status = cdk2_authvar_namespace_init(&entry->namespace,
			&entry->protected->runtime, entry->service, entry->names,
			entry->protected->client.endpoint.descriptor.maximum_name_size);
	if (!EFI_ERROR(status)) {
		entry->protected->runtime.entry_base = entry;
		entry->protected->runtime.entry_size = sizeof(*entry);
	}
	if (!EFI_ERROR(status)) {
		struct cdk2_security_router *router = NULL;
		const size_t bytes = cdk2_protected_image_policy_allocation_size(entry->protected);

		status = locate((EFI_GUID *)&security_router_guid, NULL, (void **)&router);
		if (!EFI_ERROR(status) && (!bytes || router == NULL ||
		    router->register_policy == NULL || router->unregister_policy == NULL ||
		    router->authorize_policy == NULL))
			status = EFI_UNSUPPORTED;
		if (!EFI_ERROR(status))
			status = allocate(6U, bytes, (void **)&entry->image_policy);
		if (!EFI_ERROR(status) && entry->image_policy == NULL)
			status = EFI_OUT_OF_RESOURCES;
		if (!EFI_ERROR(status)) {
			entry->image_policy_size = bytes;
			memset(entry->image_policy, 0, bytes);
		}
		if (!EFI_ERROR(status))
			status = cdk2_protected_image_policy_init(entry->image_policy, bytes,
				&entry->namespace, entry->protected);
		if (!EFI_ERROR(status)) {
			entry->namespace.policy_owner_base = entry->image_policy;
			entry->namespace.policy_owner_size = bytes;
			status = router->register_policy(cdk2_protected_image_policy_authorize,
				entry->image_policy);
			if (!EFI_ERROR(status))
				entry->security_router = router;
		}
	}
#else
	if (!EFI_ERROR(status))
		status = allocate(6U, sizeof(*entry->backend), (void **)&entry->backend);
	if (!EFI_ERROR(status))
		memset(entry->backend, 0, sizeof(*entry->backend));
	if (!EFI_ERROR(status))
		status = allocate(6U, sizeof(*entry->imported),
			(void **)&entry->imported);
	if (!EFI_ERROR(status))
		status = allocate(6U, sizeof(*entry->persistent),
			(void **)&entry->persistent);
	if (!EFI_ERROR(status))
		status = locate((EFI_GUID *)&ftw_guid, NULL, (void **)&ftw);
	if (!EFI_ERROR(status))
		status = find_backend(entry, ftw, entry->imported);
	if (!EFI_ERROR(status))
		status = allocate(6U, entry->backend->image_size,
			(void **)&entry->backend->scratch_image);
	if (!EFI_ERROR(status)) {
		entry->backend->scratch_current = entry->imported;
		entry->backend->scratch_persistent = entry->persistent;
	}
	if (!EFI_ERROR(status))
		status = cdk2_variable_backend_repair(entry->backend,
			entry->imported);
	if (!EFI_ERROR(status))
		status = cdk2_variable_service_init(entry->service,
			entry->imported->capacity,
			entry, persist, service_lock, service_unlock);
	if (!EFI_ERROR(status)) {
		entry->service->bank[0] = *entry->imported;
		entry->service->bank[1] = *entry->imported;
	}
#endif
	if (!EFI_ERROR(status)) {
		active = entry;
		entry->old_get = entry->runtime->get_variable;
		entry->old_next = entry->runtime->get_next_variable;
		entry->old_set = entry->runtime->set_variable;
		entry->old_query = entry->runtime->query_variable_info;
		entry->runtime->get_variable = get_variable;
		entry->runtime->get_next_variable = get_next;
		entry->runtime->set_variable = set_variable;
		entry->runtime->query_variable_info = query_variable;
		entry->runtime->header.crc32 = 0U;
		status = calculate_crc(entry->runtime, entry->runtime->header.size,
			&entry->runtime->header.crc32);
	}
	if (!EFI_ERROR(status))
		status = create(0x200U, 8U, exit_boot, entry, &exit_guid,
			&entry->exit_event);
	if (!EFI_ERROR(status))
		status = create(0x200U, 16U, virtual_change, entry, &virtual_guid,
			&entry->virtual_event);
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	if (!EFI_ERROR(status))
		status = create(0x200U, 8U, ready_to_boot, entry, &ready_guid,
			&entry->ready_event);
#endif
	if (!EFI_ERROR(status))
		status = install(&entry->arch_handle,
			(EFI_GUID *)&variable_arch_guid, NULL,
			(EFI_GUID *)&variable_write_guid, NULL,
			(EFI_GUID *)&variable_policy_guid, &policy_protocol, NULL);
	if (EFI_ERROR(status)) {
		CDK2_VARIABLE_DIAG("[CDK2][variable][error] driver initialization failed\n");
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
		if (entry->ready_event != NULL && EFI_ERROR(close_event(entry->ready_event)))
			CDK2_VARIABLE_DIAG("[CDK2][variable][error] event rollback failed\n");
#endif
		if (entry->virtual_event != NULL) {
			if (EFI_ERROR(close_event(entry->virtual_event)))
				CDK2_VARIABLE_DIAG("[CDK2][variable][error] event rollback failed\n");
		}
		if (entry->exit_event != NULL) {
			if (EFI_ERROR(close_event(entry->exit_event)))
				CDK2_VARIABLE_DIAG("[CDK2][variable][error] event rollback failed\n");
		}
		if (entry->arch_handle != NULL) {
			if (EFI_ERROR(uninstall(entry->arch_handle,
				(EFI_GUID *)&variable_arch_guid, NULL,
				(EFI_GUID *)&variable_write_guid, NULL,
				(EFI_GUID *)&variable_policy_guid, &policy_protocol, NULL)))
				CDK2_VARIABLE_DIAG("[CDK2][variable][error] protocol rollback failed\n");
		}
		if (active == entry) {
			entry->runtime->get_variable = entry->old_get;
			entry->runtime->get_next_variable = entry->old_next;
			entry->runtime->set_variable = entry->old_set;
			entry->runtime->query_variable_info = entry->old_query;
			entry->runtime->header.crc32 = 0U;
			if (EFI_ERROR(calculate_crc(entry->runtime,
				entry->runtime->header.size,
				&entry->runtime->header.crc32)))
				CDK2_VARIABLE_DIAG("[CDK2][variable][error] runtime CRC rollback failed\n");
			active = NULL;
		}
		if (entry->backend != NULL) {
			release_pool(free_pool, entry->backend->image);
			release_pool(free_pool, entry->backend->scratch_image);
		}
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
		if (EFI_ERROR(retire_image_policy(entry))) {
			entry->failed = TRUE;
			preparing_boot = NULL;
			return status;
		}
		cdk2_authvar_runtime_owner_destroy(entry->protected, release_protected);
		release_pool(free_pool, entry->names);
#endif
		release_pool(free_pool, entry->persistent);
		release_pool(free_pool, entry->imported);
		release_pool(free_pool, entry->backend);
		release_pool(free_pool, entry->service);
		release_pool(free_pool, entry);
	} else {
		CDK2_VARIABLE_DIAG("[CDK2][variable][info] driver published\n");
	}
#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
	preparing_boot = NULL;
#endif
	return status;
}

void cdk2_variable_runtime_reset_for_test(void)
{
	active = NULL;
}
