#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
config=${1:?resolved config header required}
build=${2:?isolated native service build directory required}
: "${PROTECTED_ENTRY_CRYPTO_SOURCES:?use the named native service Make gate}"
: "${PROTECTED_ENTRY_CRYPTO_FLAGS:?use the named native service Make gate}"
: "${NATIVE_PROBE_CFLAGS:?use the named native service Make gate}"
: "${NATIVE_UNSIGNED_PE:?actual compiled unsigned PE required}"
mkdir -p "$build"
output=$(mktemp -d "$build/run.XXXXXX")
printf 'Native service component artifacts: %s\n' "$output"
mkdir -p "$output/include/cdk2"
test "$(grep -c '^#define CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME ' "$config")" = 1
# Component source selection only; production Kconfig and boot guard unchanged.
sed 's/^#define CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME .*/#define CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME 1/' \
	"$config" > "$output/include/cdk2/config.h"
compiler=${HOSTCC:-cc}
public_ram=${NATIVE_SERVICE_PUBLIC_RAM:-0}
case "$public_ram" in
	0) native_flash_source="$root/tests/protected_variable_native_flash.c" ;;
	1) native_flash_source=; NATIVE_PROBE_CFLAGS="$NATIVE_PROBE_CFLAGS -DCDK2_NATIVE_SERVICE_PUBLIC_RAM" ;;
	*) echo 'Invalid public RAM profile' >&2; exit 1 ;;
esac
sh "$root/tests/protected_variable_native_service_auth_inputs.sh" "$output"
cp "$NATIVE_UNSIGNED_PE" "$output/unsigned.efi"
objects=
mutant_objects=
persistence_objects=
initialize_objects=
for input in unsigned.efi pk_auth.bin kek_auth.bin bad_kek_auth.bin db_auth.bin; do
	(cd "$output" && ${LD:-ld} -r -b binary -z noexecstack "$input" -o "$input.o")
	objects="$objects $output/$input.o"
	mutant_objects="$mutant_objects $output/$input.o"
	persistence_objects="$persistence_objects $output/$input.o"
	initialize_objects="$initialize_objects $output/$input.o"
done
sources="$root/tests/protected_variable_native_service_probe.c
$native_flash_source
$root/src/modules/dxe_core/core.c $root/src/modules/dxe_core/presence_lifecycle.c
$root/src/modules/dxe_core/database.c $root/src/modules/dxe_core/event.c
$root/src/modules/dxe_core/memory.c $root/src/modules/dxe_core/image.c
$root/src/modules/dxe_core/gcd.c $root/src/modules/security_stub/security_stub.c
$root/src/modules/variable_runtime/entry.c $root/src/modules/variable_runtime/model.c
$root/src/modules/variable_runtime/service.c $root/src/modules/variable_runtime/diagnostic.c
$root/src/modules/authvar_transport/image_policy.c $root/src/modules/authvar_transport/owner.c
$root/src/modules/authvar_transport/namespace.c $root/src/modules/authvar_transport/runtime.c
$root/src/modules/authvar_transport/transport.c $root/src/modules/authvar_transport/native_x86.c
$root/src/lib/payload_mm_authvar_service.c $root/src/lib/image_policy_snapshot.c
$root/src/lib/direct_image_table.c $root/src/lib/diagnostic.c $root/src/lib/mem.c
$root/src/boot/pe.c $root/src/boot/coreboot.c $root/src/boot/coreboot_checksum.c
$root/src/boot/coreboot_resource.c $root/src/boot/coreboot_hobs.c
${NATIVE_SERVICE_LIFECYCLE_SOURCES:-}
$PROTECTED_ENTRY_CRYPTO_SOURCES"
compile_source()
{
	"$compiler" $NATIVE_PROBE_CFLAGS $PROTECTED_ENTRY_CRYPTO_FLAGS \
		-I"$output/include" -I"$root/include" -I"$root/src/boot" \
		-I"$root/src/modules/dxe_core" -c "$1" -o "$2"
}
index=0
for source_file in $sources; do
	index=$((index + 1))
	object="$output/$index.o"
	compile_source "$source_file" "$object"
	objects="$objects $object"
	if test "$source_file" = "$root/src/modules/dxe_core/core.c"; then
		mutant_objects="$mutant_objects $output/cli-discard-core.o"
	else
		mutant_objects="$mutant_objects $object"
	fi
	if test "$source_file" = "$root/tests/protected_variable_native_service_probe.c"; then
		persistence_objects="$persistence_objects $output/persistence-probe.o"
		initialize_objects="$initialize_objects $output/initialize-probe.o"
	else
		persistence_objects="$persistence_objects $object"
		initialize_objects="$initialize_objects $object"
	fi
done
"$compiler" -m64 -c "$root/src/boot/entry32.S" -o "$output/entry32.o"
# Expose only the actual owned arrays in this test object, not assembly source.
if test "$public_ram" = 0; then
	${OBJCOPY:-objcopy} --globalize-symbol=cdk2_pml4 --globalize-symbol=cdk2_pdpt \
		--globalize-symbol=cdk2_pd "$output/entry32.o"
fi
link_probe()
{
	set -- "$1" "$2"
	if test "$public_ram" = 0; then
		set -- "$@" --wrap=cdk2_authvar_native_x86_trigger
	fi
	${LD:-ld} -m elf_x86_64 --gc-sections -T "$root/src/boot/cdk2.ld" \
		-e cdk2_coreboot_entry32 -u cdk2_authvar_native_x86_trigger \
		--wrap=cdk2_authvar_runtime_owner_image_policy_snapshot \
		--wrap=cdk2_native_load_pe32_plus -Map "$1.map" -o "$1.elf" \
		"$output/entry32.o" $2 ${3:-}
}
link_probe "$output/probe" "$objects"
${NM:-nm} "$output/probe.elf" > "$output/probe.symbols"
for symbol in cdk2_dxe_core_initialize cdk2_variable_runtime_entry \
	security_stub_initialize cdk2_authvar_native_x86_trigger \
	cdk2_authvar_runtime_owner_image_policy_snapshot cdk2_native_load_pe32_plus; do
	grep -Eq "[[:space:]][A-Z][[:space:]]$symbol\$" "$output/probe.symbols"
done
if test "$public_ram" = 0; then
	for symbol in __wrap_cdk2_authvar_native_x86_trigger cdk2_pml4 cdk2_pdpt cdk2_pd; do
		grep -Eq "[[:space:]][A-Z][[:space:]]$symbol\$" "$output/probe.symbols"
	done
else
	! grep -q '__wrap_cdk2_authvar_native_x86_trigger' "$output/probe.symbols"
fi
# An actual compiled CLI-discard negative. No modeled interrupt hooks.
awk '
/^static void policy_interrupts_set\(bool enabled\)/ { in_guard = 1 }
in_guard && $0 == "\t\t__asm__ volatile(\"cli\" : : : \"memory\");" {
	print "\t\t__asm__ volatile(\"\" : : : \"memory\");"
	changed++
	next
}
in_guard && $0 == "}" { in_guard = 0 }
{ print }
END { if (changed != 1) exit 1 }
' "$root/src/modules/dxe_core/core.c" > "$output/cli-discard-core.c"
compile_source "$output/cli-discard-core.c" "$output/cli-discard-core.o"
link_probe "$output/cli-discard" "$mutant_objects"
# Same real entry/core/backend closure; only the component's assertions differ.
"$compiler" $NATIVE_PROBE_CFLAGS $PROTECTED_ENTRY_CRYPTO_FLAGS \
	-DCDK2_NATIVE_SERVICE_PERSISTENCE_REPLAY \
	-I"$output/include" -I"$root/include" -I"$root/src/boot" \
	-I"$root/src/modules/dxe_core" -c "$root/tests/protected_variable_native_service_probe.c" \
	-o "$output/persistence-probe.o"
link_probe "$output/persistence" "$persistence_objects"
"$compiler" $NATIVE_PROBE_CFLAGS $PROTECTED_ENTRY_CRYPTO_FLAGS \
	-DCDK2_NATIVE_SERVICE_INITIALIZE_ONLY \
	-I"$output/include" -I"$root/include" -I"$root/src/boot" \
	-I"$root/src/modules/dxe_core" -c "$root/tests/protected_variable_native_service_probe.c" \
	-o "$output/initialize-probe.o"
link_probe "$output/initialize" "$initialize_objects"
sha256sum "$config" "$NATIVE_UNSIGNED_PE" "$output/probe.elf" \
	"$output/cli-discard.elf" "$output/persistence.elf" "$output/initialize.elf" \
	> "$output/compile.inputs.sha256"
if test "${NATIVE_SERVICE_BUILD_ONLY:-0}" = 1; then
	printf '%s\n' 'Native service component, persistence/initialization probes and actual CLI mutant compile: PASS (no native execution)'
	exit 0
fi

: "${COREBOOT_ROM:?actual service-capable Q35 ROM required}"
: "${CBFSTOOL:?matching coreboot cbfstool required}"
test -r "$COREBOOT_ROM" && test -x "$CBFSTOOL"
"$CBFSTOOL" "$COREBOOT_ROM" extract -n config -f "$output/coreboot.config"
for option in Q35_SMM_INVOCATION_NATIVE_COMPONENT \
	Q35_SMM_INVOCATION_NATIVE_CAUSE_COMPONENT Q35_SMM_INVOCATION_NATIVE_SERVICE_COMPONENT; do
	grep -qx "CONFIG_$option=y" "$output/coreboot.config"
done
if test "$public_ram" = 1; then
	grep -qx 'CONFIG_Q35_SMM_INVOCATION_NATIVE_PUBLIC_SERVICE_COMPONENT=y' "$output/coreboot.config"
fi
# Require the real source-built immutable leaf; never create a substitute leaf.
"$CBFSTOOL" "$COREBOOT_ROM" extract -n q35/native-apmc -f "$output/native-apmc.bin"
test "$(od -An -tx1 -v "$output/native-apmc.bin" | tr -d ' \n')" = 0fb6c20fb7d631c9ee31c0c3

run_probe()
{
	probe=$1
	cp "${2:-$COREBOOT_ROM}" "$probe.rom"
	"$CBFSTOOL" "$probe.rom" remove -n fallback/payload
	"$CBFSTOOL" "$probe.rom" add-payload -n fallback/payload -f "$probe.elf" -c lzma
	"$CBFSTOOL" "$probe.rom" read -r SMMSTORE -f "$probe.before-smmstore.bin"
	sha256sum "$probe.rom" "$probe.elf" > "$probe.inputs.sha256"
	set --
	if grep -qx 'CONFIG_Q35_VTD_DMA_TEST_BACKEND=y' "$output/coreboot.config"; then
		qemu-img create -q -f raw "$probe.nvme.raw" 16M
		set -- -device intel-iommu,pt=off -device VGA,bus=pcie.0,addr=01 \
			-drive "if=none,id=nvme0,format=raw,file=$probe.nvme.raw" \
			-device nvme,drive=nvme0,serial=CDK2SERVICE,bus=pcie.0,addr=03 \
			-device qemu-xhci,bus=pcie.0,addr=04 \
			-device edu,dma_mask=0xffffffff,bus=pcie.0,addr=05
	fi
	status=0
	timeout 60 ${QEMU:-qemu-system-x86_64} -machine q35,smm=on,accel=tcg -m 1024M \
		-cpu max -smp 1 -nodefaults "$@" \
		-global driver=cfi.pflash01,property=secure,value=on \
		-drive "if=pflash,format=raw,file=$probe.rom" \
		-display none -serial "file:$probe.serial.log" -no-reboot \
		-device isa-debug-exit,iobase=0xf4,iosize=0x04 > "$probe.qemu.log" 2>&1 || status=$?
	"$CBFSTOOL" "$probe.rom" read -r SMMSTORE -f "$probe.after-smmstore.bin"
}
run_probe "$output/probe"
if test "$status" != 3 ||
    ! grep -q '^CDK2_NATIVE_SERVICE_COMPONENT_PASS' "$output/probe.serial.log" ||
    grep -q '^CDK2_NATIVE_SERVICE_COMPONENT_FAIL' "$output/probe.serial.log"; then
	cat "$output/probe.qemu.log" >&2
	tail -n 45 "$output/probe.serial.log" >&2
	exit 1
fi
for stage in ACTUAL_MAILBOX_HOB REAL_CORE_READY ENTRY_INSTALLED \
	SETUP_UNSIGNED_ALLOWED_IRQ_RESTORED PK_SETUP_ENROLLED WRONG_SIGNER_KEK_REFUSED \
	PK_AUTHENTICATED_KEK KEK_AUTHENTICATED_DB ENROLLED_UNSIGNED_DENIED_IRQ_RESTORED; do
	grep -q "^CDK2_NATIVE_SERVICE_$stage" "$output/probe.serial.log"
done
if test "$public_ram" = 0; then
	grep -q '^CDK2_NATIVE_SERVICE_IMMUTABLE_FLASH_LEAF' "$output/probe.serial.log"
else
	for stage in PRODUCTION_RAM_TRIGGER PUBLIC_IF0_IF1_GET_RESTORED \
		PUBLIC_INVALID_REPLAY_REFUSED PUBLIC_IF1_SET_RESTORED; do
		grep -q "^CDK2_NATIVE_SERVICE_$stage" "$output/probe.serial.log"
	done
fi
if cmp -s "$output/probe.before-smmstore.bin" "$output/probe.after-smmstore.bin"; then
	echo 'Actual writable secure SMMSTORE did not change' >&2
	exit 1
fi
printf '%s\n' 'Native real SMM service Auth2/policy/PE/IRQ component: PASS (production boot guard held)'
# A genuine cold restart on the first run's media, not a new seeded backend.
run_probe "$output/persistence" "$output/probe.rom"
if test "$status" != 3 ||
    ! grep -q '^CDK2_NATIVE_SERVICE_ENROLLED_MEDIA_READBACK' "$output/persistence.serial.log" ||
    ! grep -q '^CDK2_NATIVE_SERVICE_PERSISTENCE_UNSIGNED_DENIED_IRQ_RESTORED' \
	"$output/persistence.serial.log" ||
    ! grep -q '^CDK2_NATIVE_SERVICE_PERSISTENCE_PASS' "$output/persistence.serial.log" ||
    grep -Eq '^CDK2_NATIVE_SERVICE_(PK_SETUP_ENROLLED|COMPONENT_PASS|COMPONENT_FAIL)' \
	"$output/persistence.serial.log"; then
	cat "$output/persistence.qemu.log" >&2
	tail -n 45 "$output/persistence.serial.log" >&2
	exit 1
fi
printf '%s\n' 'Native second-boot enrolled key media readback and unsigned-image denial: PASS'
# Canonical recovery may initialize defaults on early reads. Establish an actual
# SMM-initialized, PK-absent baseline before asserting the mutant changes no media.
run_probe "$output/initialize"
if test "$status" != 3 ||
    ! grep -q '^CDK2_NATIVE_SERVICE_INITIALIZED_UNENROLLED_PASS' \
	"$output/initialize.serial.log" ||
    grep -Eq '^CDK2_NATIVE_SERVICE_(SETUP_UNSIGNED_ALLOWED|PK_SETUP_ENROLLED|COMPONENT_PASS|COMPONENT_FAIL)' \
	"$output/initialize.serial.log"; then
	cat "$output/initialize.qemu.log" >&2
	tail -n 45 "$output/initialize.serial.log" >&2
	exit 1
fi
run_probe "$output/cli-discard" "$output/initialize.rom"
if test "$status" != 5 ||
    ! grep -q '^CDK2_NATIVE_SERVICE_ENTRY_INSTALLED' "$output/cli-discard.serial.log" ||
    ! grep -q '^CDK2_NATIVE_SERVICE_SETUP_LOAD_BAD' "$output/cli-discard.serial.log" ||
    ! grep -q '^CDK2_NATIVE_SERVICE_COMPONENT_FAIL' "$output/cli-discard.serial.log" ||
    grep -Eq '^CDK2_NATIVE_SERVICE_(SETUP_UNSIGNED_ALLOWED|PK_SETUP_ENROLLED|COMPONENT_PASS)' \
	"$output/cli-discard.serial.log"; then
	cat "$output/cli-discard.qemu.log" >&2
	tail -n 45 "$output/cli-discard.serial.log" >&2
	exit 1
fi
cmp "$output/cli-discard.before-smmstore.bin" "$output/cli-discard.after-smmstore.bin"
printf '%s\n' 'Native compiled CoreLoadImage CLI-discard mutant: correctly refused before enrollment'
