/* SPDX-License-Identifier: GPL-2.0-only */

#include <cdk2/authvar_presence_lifecycle_close_composition.h>
#include <cdk2/authvar_runtime_owner.h>
#include <cdk2/dxe_core.h>
#include <cdk2/image_policy_snapshot.h>
#include <guid/cbmem_table_hob.h>
#include <cdk2/authvar_native_x86.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#ifndef CDK2_NATIVE_SERVICE_PUBLIC_RAM
#include "protected_variable_native_flash.h"
#endif
/* Use actual table/HOB reservation, ACPI, IDT and legacy PIC initialization. */
#include "../src/boot/coreboot_handoff.c"

/* Controlled service component, not protected production boot admission. */
static struct cdk2_dxe_core core;
static uint8_t pool[8 * 1024 * 1024] __aligned(4096);
static uint8_t hob_storage[65536] __aligned(16);
static const EFI_GUID hob_guid = { 0x7739f24c, 0x93d7, 0x11d4,
	{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
static const EFI_GUID table_guid = { 0x9e0d4b6f, 0xa8e8, 0x4d7e,
	{ 0x9a, 0x2d, 0x31, 0x0d, 0x4c, 0x9a, 0x8f, 0x2b } };
static const EFI_GUID global_guid = { 0x8be4df61, 0x93ca, 0x11d2,
	{ 0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c } };
#ifndef CDK2_NATIVE_SERVICE_INITIALIZE_ONLY
static const EFI_GUID image_guid = { 0xd719b2cb, 0x3d3a, 0x4596,
	{ 0xa3, 0xbc, 0xda, 0xd0, 0x0e, 0x67, 0x65, 0x6f } };
#endif
static bool observing_load, observer_bad;
static size_t native_loads, snapshots;
static uint32_t latest_modes, latest_pk_bytes, latest_db_bytes;

extern const uint8_t _binary_unsigned_efi_start[], _binary_unsigned_efi_end[];
extern const uint8_t _binary_pk_auth_bin_start[], _binary_pk_auth_bin_end[];
extern const uint8_t _binary_kek_auth_bin_start[], _binary_kek_auth_bin_end[];
extern const uint8_t _binary_bad_kek_auth_bin_start[], _binary_bad_kek_auth_bin_end[];
extern const uint8_t _binary_db_auth_bin_start[], _binary_db_auth_bin_end[];
extern EFI_STATUS CDK2_MS_ABI security_stub_initialize(void *image, void *system);
extern EFI_STATUS CDK2_MS_ABI cdk2_variable_runtime_entry(void *image, void *system);
extern EFI_STATUS __real_cdk2_native_load_pe32_plus(const void *image,
	unsigned long long size, unsigned long long destination,
	unsigned long long destination_size, unsigned long long *base,
	unsigned long long *loaded_size, unsigned long long *entry);
extern EFI_STATUS __real_cdk2_authvar_runtime_owner_image_policy_snapshot(
	struct cdk2_authvar_runtime_owner *owner, void *data, size_t capacity, size_t *size);

typedef EFI_STATUS CDK2_MS_ABI install_table_fn(EFI_GUID *guid, void *table);
typedef EFI_STATUS CDK2_MS_ABI get_fn(CHAR16 *name, const EFI_GUID *guid,
	UINT32 *attributes, UINTN *bytes, void *data);
typedef EFI_STATUS CDK2_MS_ABI set_fn(CHAR16 *name, const EFI_GUID *guid,
	UINT32 attributes, UINTN bytes, const void *data);
typedef EFI_STATUS CDK2_MS_ABI load_fn(BOOLEAN boot_policy, void *parent, void *path,
	void *source, UINTN bytes, void **image);
typedef EFI_STATUS CDK2_MS_ABI unload_fn(void *image);

static void serial(const char *text)
{
	while (*text) {
		uint8_t ready;

		do {
			__asm__ volatile("inb %1, %0" : "=a"(ready) : "Nd"((uint16_t)0x3fd));
		} while (!(ready & 0x20));
		__asm__ volatile("outb %0, %1" : : "a"(*text++), "Nd"((uint16_t)0x3f8));
	}
}

static bool interrupts_enabled(void)
{
	uintptr_t flags;

	__asm__ volatile("pushfq; popq %0" : "=r"(flags) : : "memory");
	return (flags & (1U << 9)) != 0;
}

static void finish(bool passed)
{
	uint32_t value = passed ? 1 : 2;

	__asm__ volatile("outl %0, %1" : : "a"(value), "Nd"((uint16_t)0xf4));
	for (;;)
		__asm__ volatile("cli; hlt" : : : "memory");
}

static bool actual_ram(const struct cdk2_coreboot_handoff *handoff,
	const void *address, size_t size)
{
	uintptr_t base = (uintptr_t)address;

	if (size > UINTPTR_MAX - base)
		return false;
	for (size_t index = 0; index < handoff->memory_range_count; index++) {
		const struct cdk2_coreboot_memory_range *memory = &handoff->memory_ranges[index];

		if (memory->type == CB_MEM_RAM && memory->base <= base &&
		    base - memory->base <= memory->size && size <= memory->size - (base - memory->base))
			return true;
	}
	return false;
}

/* Observers delegate to the real functions; no modeled IRQ or producer reply. */
EFI_STATUS __wrap_cdk2_authvar_runtime_owner_image_policy_snapshot(
	struct cdk2_authvar_runtime_owner *owner, void *data, size_t capacity, size_t *size)
{
	struct cdk2_image_policy_snapshot_view view;
	EFI_STATUS status;

	if (observing_load && (interrupts_enabled() || core.events.current_tpl != 31))
		observer_bad = true;
	status = __real_cdk2_authvar_runtime_owner_image_policy_snapshot(owner, data, capacity, size);
	if (!EFI_ERROR(status)) {
		if (!cdk2_image_policy_snapshot_decode_shape(data, *size, &view)) {
			observer_bad = true;
		} else {
			snapshots++;
			latest_modes = view.modes;
			latest_pk_bytes = view.blobs[CDK2_IMAGE_POLICY_SNAPSHOT_PK].size;
			latest_db_bytes = view.blobs[CDK2_IMAGE_POLICY_SNAPSHOT_DB].size;
		}
	}
	return status;
}

EFI_STATUS __wrap_cdk2_native_load_pe32_plus(const void *image,
	unsigned long long size, unsigned long long destination,
	unsigned long long destination_size, unsigned long long *base,
	unsigned long long *loaded_size, unsigned long long *entry)
{
	if (!observing_load || interrupts_enabled() || core.events.current_tpl != 31)
		observer_bad = true;
	native_loads++;
	return __real_cdk2_native_load_pe32_plus(image, size, destination,
		destination_size, base, loaded_size, entry);
}

static bool mode(CHAR16 *name, uint8_t expected)
{
	UINTN bytes = 1;
	UINT32 attributes = 0;
	uint8_t value = 0xff;

	return ((get_fn *)core.runtime_storage->runtime_services.get_variable)(name,
		&global_guid, &attributes, &bytes, &value) == EFI_SUCCESS &&
		bytes == 1 && attributes == 6 && value == expected;
}

#ifdef CDK2_NATIVE_SERVICE_PUBLIC_RAM
static bool public_irq_reads(CHAR16 *setup, CHAR16 *secure, bool enrolled)
{
	bool enabled_result;

	if (interrupts_enabled() || !mode(setup, enrolled ? 0 : 1) ||
	    !mode(secure, enrolled ? 1 : 0) || interrupts_enabled())
		return false;
	__asm__ volatile("sti" : : : "memory");
	enabled_result = interrupts_enabled() && mode(setup, enrolled ? 0 : 1) &&
		mode(secure, enrolled ? 1 : 0) && interrupts_enabled();
	__asm__ volatile("cli" : : : "memory");
	return enabled_result && !interrupts_enabled();
}

/* Real deliberately invalid public I/O; never a private bootstrap claim. */
static void public_wrong_wire(void)
{
	__asm__ volatile("outb %%al, %%dx"
		: : "a"(UINT64_C(0x1000000fc)), "d"(UINT64_C(0xb2)), "c"(UINT64_C(0))
		: "memory");
}

static bool public_refusals(const struct cdk2_authvar_endpoint *endpoint)
{
	static uint8_t request[CDK2_AUTHVAR_SERVICE_MAX_MESSAGE_SIZE] __aligned(8);
	struct cdk2_authvar_service_frame *frame = (void *)request;
	void *mailbox = (void *)(uintptr_t)endpoint->communication_base;
	size_t bytes = endpoint->descriptor.message_size;

	if (!bytes || bytes > sizeof(request) || interrupts_enabled())
		return false;
	memset(request, 0, bytes);
	frame->revision = CDK2_AUTHVAR_SERVICE_REVISION;
	frame->header_size = sizeof(*frame);
	frame->operation = CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME;
	frame->generation = endpoint->generation;
	frame->request_id = 1;
	frame->status = CDK2_AUTHVAR_SERVICE_STATUS_PENDING;
	frame->completion = CDK2_AUTHVAR_SERVICE_PENDING;
	if (EFI_ERROR(cdk2_authvar_service_request_validate(&endpoint->descriptor, request, bytes)))
		return false;
	memcpy(mailbox, request, bytes);
	if (EFI_ERROR(cdk2_authvar_native_x86_cache(NULL, mailbox, bytes)))
		return false;
	public_wrong_wire();
	if (EFI_ERROR(cdk2_authvar_native_x86_cache(NULL, mailbox, bytes)) ||
	    memcmp(mailbox, request, bytes) || interrupts_enabled())
		return false;
	/* An unrelated latched APMC command must not execute the pending op6. */
	if (EFI_ERROR(cdk2_authvar_native_x86_trigger(NULL, 0xb2, 0xfb)) ||
	    EFI_ERROR(cdk2_authvar_native_x86_cache(NULL, mailbox, bytes)) ||
	    memcmp(mailbox, request, bytes) || interrupts_enabled())
		return false;
	frame->status = CDK2_AUTHVAR_STATUS_SUCCESS;
	frame->completion = CDK2_AUTHVAR_SERVICE_COMPLETE;
	if (!EFI_ERROR(cdk2_authvar_service_request_validate(&endpoint->descriptor, request, bytes)))
		return false;
	memcpy(mailbox, request, bytes);
	if (EFI_ERROR(cdk2_authvar_native_x86_cache(NULL, mailbox, bytes)) ||
	    EFI_ERROR(cdk2_authvar_native_x86_trigger(NULL, 0xb2, 0xfc)) ||
	    EFI_ERROR(cdk2_authvar_native_x86_cache(NULL, mailbox, bytes)) ||
	    memcmp(mailbox, request, bytes) || interrupts_enabled())
		return false;
	/* A later real CoreLoadImage snapshot proves these attempts did not enter runtime. */
	return true;
}
#endif

#ifndef CDK2_NATIVE_SERVICE_INITIALIZE_ONLY
static bool read_key(CHAR16 *name, const EFI_GUID *guid,
	const uint8_t *begin, const uint8_t *end)
{
	static uint8_t readback[8192];
	size_t bytes = end - begin;
	UINTN read_bytes = sizeof(readback);
	UINT32 attributes = 0, certificate_bytes;

	if (bytes < 40 || bytes > sizeof(readback))
		return false;
	memcpy(&certificate_bytes, begin + 16, sizeof(certificate_bytes));
	if (certificate_bytes < 24 || certificate_bytes > bytes - 16)
		return false;
	return ((get_fn *)core.runtime_storage->runtime_services.get_variable)(name,
		guid, &attributes, &read_bytes, readback) == EFI_SUCCESS && attributes == 0x27 &&
		read_bytes == bytes - 16 - certificate_bytes &&
		!memcmp(readback, begin + 16 + certificate_bytes, read_bytes);
}

#ifndef CDK2_NATIVE_SERVICE_PERSISTENCE_REPLAY
static bool write_key(CHAR16 *name, const EFI_GUID *guid,
	const uint8_t *begin, const uint8_t *end)
{
#ifdef CDK2_NATIVE_SERVICE_PUBLIC_RAM
	EFI_STATUS status;
	bool restored;

	if (interrupts_enabled())
		return false;
	__asm__ volatile("sti" : : : "memory");
	status = ((set_fn *)core.runtime_storage->runtime_services.set_variable)(name,
		guid, 0x27, end - begin, begin);
	restored = interrupts_enabled();
	__asm__ volatile("cli" : : : "memory");
	return status == EFI_SUCCESS && restored && !interrupts_enabled() &&
		read_key(name, guid, begin, end) && !interrupts_enabled();
#else
	return ((set_fn *)core.runtime_storage->runtime_services.set_variable)(name,
		guid, 0x27, end - begin, begin) == EFI_SUCCESS && read_key(name, guid, begin, end);
#endif
}
#endif

static bool load_unsigned(bool enrolled)
{
	void *image = NULL;
	size_t before_native = native_loads, before_snapshots = snapshots;
	EFI_STATUS status;
	bool restored;

	observing_load = true;
	/* Actual production IDT/PIC initialization has completed before enabling IF. */
	__asm__ volatile("sti" : : : "memory");
	if (!interrupts_enabled()) {
		__asm__ volatile("cli" : : : "memory");
		return false;
	}
	status = ((load_fn *)core.boot_services.load_image)(FALSE, NULL, NULL,
		(void *)_binary_unsigned_efi_start,
		_binary_unsigned_efi_end - _binary_unsigned_efi_start, &image);
	restored = interrupts_enabled() && core.events.current_tpl == 4;
	__asm__ volatile("cli" : : : "memory");
	observing_load = false;
	if (!restored || observer_bad || snapshots != before_snapshots + 1)
		return false;
	if (enrolled)
		return status == EFI_SECURITY_VIOLATION && image == NULL &&
			native_loads == before_native &&
			latest_modes == (CDK2_IMAGE_POLICY_SNAPSHOT_SECURE_BOOT |
				CDK2_IMAGE_POLICY_SNAPSHOT_VENDOR_KEYS) && latest_pk_bytes > 44 &&
			latest_db_bytes > 44;
	return status == EFI_SUCCESS && image != NULL && native_loads == before_native + 1 &&
		latest_modes == (CDK2_IMAGE_POLICY_SNAPSHOT_SETUP |
			CDK2_IMAGE_POLICY_SNAPSHOT_VENDOR_KEYS) && !latest_pk_bytes && !latest_db_bytes &&
		((unload_fn *)core.boot_services.unload_image)(image) == EFI_SUCCESS;
}
#endif

EFI_STATUS cdk2_native_stage_entry(UINTN bootloader_parameter)
{
	struct cdk2_coreboot_handoff handoff;
	struct cdk2_authvar_endpoint endpoint;
	struct cdk2_native_context native = {0};
	COREBOOT_TABLE_HOB table;
	void *hobs = NULL;
	CHAR16 setup[] = {'S', 'e', 't', 'u', 'p', 'M', 'o', 'd', 'e', 0};
	CHAR16 secure[] = {'S', 'e', 'c', 'u', 'r', 'e', 'B', 'o', 'o', 't', 0};
	CHAR16 pk[] = {'P', 'K', 0};
#ifndef CDK2_NATIVE_SERVICE_INITIALIZE_ONLY
	CHAR16 kek[] = {'K', 'E', 'K', 0}, db[] = {'d', 'b', 0};
#endif
#ifndef CDK2_NATIVE_SERVICE_PERSISTENCE_REPLAY
	UINTN bytes;
#endif

	serial("CDK2_NATIVE_SERVICE_BEGIN\r\n");
	if (EFI_ERROR(cdk2_coreboot_parse(bootloader_parameter, &handoff)) ||
	    !actual_ram(&handoff, pool, sizeof(pool)) ||
	    !actual_ram(&handoff, hob_storage, sizeof(hob_storage)) ||
	    EFI_ERROR(cdk2_coreboot_update_acpi_handoff(&handoff)) ||
	    EFI_ERROR(cdk2_coreboot_build_hobs(&handoff, hob_storage,
		hob_storage + sizeof(hob_storage), hob_storage, hob_storage + sizeof(hob_storage),
		FALSE, &hobs)))
		goto bad;
	table = (COREBOOT_TABLE_HOB) { .address = (uintptr_t)handoff.header,
		.size = handoff.table_size };
	if (EFI_ERROR(cdk2_coreboot_append_guid_hob(hobs, &table_guid, &table, sizeof(table))) ||
	    EFI_ERROR(cdk2_coreboot_append_authvar_mailbox_hob(hobs, &handoff)) ||
	    EFI_ERROR(cdk2_authvar_endpoint_from_hob(hobs, &endpoint))) {
		serial("CDK2_NATIVE_SERVICE_ENDPOINT_REFUSED\r\n");
		goto bad;
	}
	serial("CDK2_NATIVE_SERVICE_ACTUAL_MAILBOX_HOB\r\n");
#ifndef CDK2_NATIVE_SERVICE_PUBLIC_RAM
	if (EFI_ERROR(cdk2_native_flash_apmc_prepare(&handoff, &endpoint)))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_IMMUTABLE_FLASH_LEAF\r\n");
#else
	serial("CDK2_NATIVE_SERVICE_PRODUCTION_RAM_TRIGGER\r\n");
#endif
	if (EFI_ERROR(cdk2_coreboot_initialize_floating_point(&native)) ||
	    EFI_ERROR(cdk2_coreboot_mask_legacy_interrupts(&native)) ||
	    EFI_ERROR(cdk2_dxe_core_initialize(&core, pool, sizeof(pool) / EFI_PAGE_SIZE)) ||
	    EFI_ERROR(security_stub_initialize(NULL, &core.runtime_storage->system_table)) ||
	    EFI_ERROR(((install_table_fn *)core.boot_services.install_configuration_table)(
		(EFI_GUID *)&hob_guid, hobs)))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_REAL_CORE_READY\r\n");
#if CONFIG_CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION
	if (EFI_ERROR(cdk2_authvar_presence_lifecycle_close_composition_initialize(
		hobs, &core, &core.runtime_storage->runtime_services)))
		goto bad;
#endif
	if (EFI_ERROR(cdk2_variable_runtime_entry(NULL, &core.runtime_storage->system_table)))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_ENTRY_INSTALLED\r\n");
#ifdef CDK2_NATIVE_SERVICE_PUBLIC_RAM
	if (!public_irq_reads(setup, secure,
#ifdef CDK2_NATIVE_SERVICE_PERSISTENCE_REPLAY
	    true
#else
	    false
#endif
	    ) || !public_refusals(&endpoint) || !public_irq_reads(setup, secure,
#ifdef CDK2_NATIVE_SERVICE_PERSISTENCE_REPLAY
	    true
#else
	    false
#endif
	    ))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_PUBLIC_IF0_IF1_GET_RESTORED\r\n");
	serial("CDK2_NATIVE_SERVICE_PUBLIC_INVALID_REPLAY_REFUSED\r\n");
#endif
#ifdef CDK2_NATIVE_SERVICE_INITIALIZE_ONLY
	bytes = 0;
	if (!mode(setup, 1) || !mode(secure, 0) ||
	    ((get_fn *)core.runtime_storage->runtime_services.get_variable)(pk, &global_guid,
		NULL, &bytes, NULL) != EFI_NOT_FOUND)
		goto bad;
	serial("CDK2_NATIVE_SERVICE_INITIALIZED_UNENROLLED_PASS\r\n");
#elif defined(CDK2_NATIVE_SERVICE_PERSISTENCE_REPLAY)
	if (!mode(setup, 0) || !mode(secure, 1) ||
	    !read_key(pk, &global_guid, _binary_pk_auth_bin_start, _binary_pk_auth_bin_end) ||
	    !read_key(kek, &global_guid, _binary_kek_auth_bin_start, _binary_kek_auth_bin_end) ||
	    !read_key(db, &image_guid, _binary_db_auth_bin_start, _binary_db_auth_bin_end))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_ENROLLED_MEDIA_READBACK\r\n");
	if (!load_unsigned(true))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_PERSISTENCE_UNSIGNED_DENIED_IRQ_RESTORED\r\n");
	serial("CDK2_NATIVE_SERVICE_PERSISTENCE_PASS\r\n");
#else
	if (!mode(setup, 1) || !mode(secure, 0))
		goto bad;
	if (!load_unsigned(false)) {
		serial("CDK2_NATIVE_SERVICE_SETUP_LOAD_BAD\r\n");
		goto bad;
	}
	serial("CDK2_NATIVE_SERVICE_SETUP_UNSIGNED_ALLOWED_IRQ_RESTORED\r\n");
	/* Q35 deliberately uses the ordinary SetupMode PK trust bypass. */
	if (!write_key(pk, &global_guid, _binary_pk_auth_bin_start, _binary_pk_auth_bin_end) ||
	    !mode(setup, 0) || !mode(secure, 1))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_PK_SETUP_ENROLLED\r\n");
	if (((set_fn *)core.runtime_storage->runtime_services.set_variable)(kek, &global_guid,
	    0x27, _binary_bad_kek_auth_bin_end - _binary_bad_kek_auth_bin_start,
	    _binary_bad_kek_auth_bin_start) != EFI_SECURITY_VIOLATION)
		goto bad;
	bytes = 0;
	if (((get_fn *)core.runtime_storage->runtime_services.get_variable)(kek, &global_guid,
	    NULL, &bytes, NULL) != EFI_NOT_FOUND)
		goto bad;
	serial("CDK2_NATIVE_SERVICE_WRONG_SIGNER_KEK_REFUSED\r\n");
	if (!write_key(kek, &global_guid, _binary_kek_auth_bin_start, _binary_kek_auth_bin_end))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_PK_AUTHENTICATED_KEK\r\n");
	if (!write_key(db, &image_guid, _binary_db_auth_bin_start, _binary_db_auth_bin_end))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_KEK_AUTHENTICATED_DB\r\n");
#ifdef CDK2_NATIVE_SERVICE_PUBLIC_RAM
	serial("CDK2_NATIVE_SERVICE_PUBLIC_IF1_SET_RESTORED\r\n");
#endif
	if (!load_unsigned(true))
		goto bad;
	serial("CDK2_NATIVE_SERVICE_ENROLLED_UNSIGNED_DENIED_IRQ_RESTORED\r\n");
	serial("CDK2_NATIVE_SERVICE_COMPONENT_PASS\r\n");
#endif
	finish(true);
bad:
	serial("CDK2_NATIVE_SERVICE_COMPONENT_FAIL\r\n");
	finish(false);
	return EFI_DEVICE_ERROR;
}
