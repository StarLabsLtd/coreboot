#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

output=${1:?isolated output directory required}
mkdir -p "$output"
for identity in pk kek db; do
	openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days 2 \
		-subj "/CN=native-service-$identity" -keyout "$output/$identity.key.pem" \
		-out "$output/$identity.cert.pem" > "$output/$identity.certificate.log" 2>&1
	openssl x509 -in "$output/$identity.cert.pem" -outform DER \
		-out "$output/$identity.cert.der"
done

# Genuine Auth2 operands, not a pre-enrolled backend or a host producer pipe.
perl - "$output" <<-'PERL'
use strict;
use warnings;
my ($directory) = @ARGV;
my @updates = (['pk', 'PK', 'pk'], ['kek', 'KEK', 'kek'],
	['bad_kek', 'KEK', 'kek'], ['db', 'db', 'db']);
for my $index (0 .. $#updates) {
	my ($file, $name, $value) = @{$updates[$index]};
	open my $certificate, '<:raw', "$directory/$value.cert.der" or die $!;
	local $/;
	my $der = <$certificate>;
	my $esl = pack('H*', 'a159c0a5e494a74a87b5ab155c2bf072') .
		pack('V3', 44 + length($der), 0, 16 + length($der)) . ("\0" x 16) . $der;
	my $time = pack('vC6VvCC', 2024, 1, 1, 0, 0, $index + 1, 0, 0, 0, 0, 0);
	my $wide_name = join('', map { $_ . "\0" } split //, $name);
	my $guid = pack('H*', $name eq 'db' ? 'cbb219d73a3d9645a3bcdad00e67656f' :
		'61dfe48bca93d211aa0d00e098032b8c');
	for my $pair (["$file.signed.bin", $wide_name . $guid . pack('V', 0x27) . $time . $esl],
		["$file.time.bin", $time], ["$file.value.bin", $esl]) {
		open my $out, '>:raw', "$directory/$pair->[0]" or die $!;
		print {$out} $pair->[1] or die $!;
	}
}
PERL
for update in pk kek bad_kek db; do
	case $update in
		pk|kek) signer=pk ;;
		bad_kek) signer=db ;;
		db) signer=kek ;;
	esac
	openssl cms -sign -binary -in "$output/$update.signed.bin" \
		-signer "$output/$signer.cert.pem" -inkey "$output/$signer.key.pem" \
		-outform DER -out "$output/$update.pk7"
	openssl cms -verify -binary -inform DER -in "$output/$update.pk7" \
		-content "$output/$update.signed.bin" -CAfile "$output/$signer.cert.pem" \
		-out /dev/null
done
perl - "$output" <<-'PERL'
use strict;
use warnings;
my ($directory) = @ARGV;
for my $update ('pk', 'kek', 'bad_kek', 'db') {
	my @bytes;
	for my $name ("$update.time.bin", "$update.pk7", "$update.value.bin") {
		open my $in, '<:raw', "$directory/$name" or die $!;
		local $/;
		push @bytes, <$in>;
	}
	my ($time, $signature, $value) = @bytes;
	open my $out, '>:raw', "$directory/${update}_auth.bin" or die $!;
	print {$out} $time, pack('Vvv', 24 + length($signature), 0x200, 0xef1),
		pack('H*', '9dd2af4adf68ee498aa9347d375665a7'), $signature, $value;
}
PERL
printf '%s\n' 'Native service Auth2 inputs: PK setup bypass; PK-signed KEK; KEK-signed db; valid untrusted-signer KEK'
