/* SPDX-License-Identifier: GPL-2.0-only */

#include "vtd_registers.h"

#define VTD_POLL_LIMIT 100000U
#define VTD_INVALIDATE (1U << 31)
#define VTD_CONTEXT_GLOBAL (1U << 29)
#define VTD_IOTLB_GLOBAL (1U << 28)
#define VTD_DRAIN_READS (1U << 17)
#define VTD_DRAIN_WRITES (1U << 16)

static uint64_t read_pair(const struct q35_vtd_io *io, uint32_t offset)
{
	uint32_t low = io->read32(io->context, offset);
	uint32_t high = io->read32(io->context, offset + 4U);

	return ((uint64_t)high << 32) | low;
}

static int wait_for(const struct q35_vtd_io *io, uint32_t offset,
	uint32_t mask, uint32_t expected)
{
	for (unsigned int poll = 0; poll < VTD_POLL_LIMIT; poll++)
		if ((io->read32(io->context, offset) & mask) == expected)
			return 0;
	return -1;
}

static int invalidate(const struct q35_vtd_io *io, uint32_t iotlb)
{
	io->write32(io->context, Q35_VTD_CCMD, 0);
	io->write32(io->context, Q35_VTD_CCMD + 4U,
		VTD_INVALIDATE | VTD_CONTEXT_GLOBAL);
	if (wait_for(io, Q35_VTD_CCMD + 4U, VTD_INVALIDATE, 0) ||
	    (io->read32(io->context, Q35_VTD_CCMD + 4U) & (3U << 27)) !=
		(1U << 27))
		return -1;

	io->write32(io->context, iotlb, 0);
	io->write32(io->context, iotlb + 4U, VTD_INVALIDATE | VTD_IOTLB_GLOBAL);
	if (wait_for(io, iotlb + 4U, VTD_INVALIDATE, 0) ||
	    (io->read32(io->context, iotlb + 4U) & (3U << 25)) !=
		(1U << 25))
		return -1;
	return 0;
}

static int iotlb_offset(const struct q35_vtd_io *io, uint32_t *iotlb)
{
	uint64_t ecap = read_pair(io, Q35_VTD_ECAP);

	*iotlb = (uint32_t)((ecap >> 8) & 0x3ffU) * 16U + 8U;
	return *iotlb < 0x40U || *iotlb > 0xff0U ? -1 : 0;
}

int q35_vtd_invalidate(const struct q35_vtd_io *io)
{
	uint32_t iotlb;

	if (!io || !io->read32 || !io->write32 || iotlb_offset(io, &iotlb))
		return -1;
	return invalidate(io, iotlb);
}

int q35_vtd_invalidate_drain(const struct q35_vtd_io *io)
{
	const uint64_t required = Q35_VTD_DRAIN_READS_SUPPORTED |
		Q35_VTD_DRAIN_WRITES_SUPPORTED;
	const uint32_t active = Q35_VTD_ROOT_SET | Q35_VTD_TRANSLATION_ENABLE;
	uint64_t capability;
	uint64_t extended;
	uint64_t root;
	uint32_t status;
	uint32_t version;
	uint32_t iotlb;

	if (!io || !io->read32 || !io->write32)
		return -1;
	capability = read_pair(io, Q35_VTD_CAP);
	extended = read_pair(io, Q35_VTD_ECAP);
	root = read_pair(io, Q35_VTD_RTADDR);
	status = io->read32(io->context, Q35_VTD_GSTS);
	version = io->read32(io->context, Q35_VTD_VERSION);
	if ((capability & required) != required ||
	    (status & active) != active ||
	    (status & Q35_VTD_QUEUED_INVALIDATION_ENABLE) ||
	    !root || (root & 0xfffU) || version == UINT32_MAX ||
	    ((version >> 4) & 0xfU) != 1U || iotlb_offset(io, &iotlb) ||
	    (io->read32(io->context, Q35_VTD_CCMD + 4U) & VTD_INVALIDATE) ||
	    (io->read32(io->context, iotlb + 4U) & VTD_INVALIDATE))
		return -1;

	/* Preserve the existing global context/IOTLB invalidation contract. */
	if (q35_vtd_invalidate(io))
		return -1;
	/* IVT completion must include both requested architectural drains. */
	io->write32(io->context, iotlb, 0);
	io->write32(io->context, iotlb + 4U, VTD_INVALIDATE | VTD_IOTLB_GLOBAL |
		VTD_DRAIN_READS | VTD_DRAIN_WRITES);
	if (wait_for(io, iotlb + 4U, VTD_INVALIDATE, 0) ||
	    (io->read32(io->context, iotlb + 4U) & (3U << 25)) != (1U << 25) ||
	    read_pair(io, Q35_VTD_CAP) != capability ||
	    read_pair(io, Q35_VTD_ECAP) != extended ||
	    read_pair(io, Q35_VTD_RTADDR) != root ||
	    io->read32(io->context, Q35_VTD_GSTS) != status ||
	    io->read32(io->context, Q35_VTD_VERSION) != version)
		return -1;
	return 0;
}

int q35_vtd_default_deny(const struct q35_vtd_io *io, uint32_t root_phys)
{
	uint32_t iotlb;
	uint32_t version;

	if (!io || !io->read32 || !io->write32 || !io->commit_tables ||
	    !root_phys || (root_phys & 0xfffU))
		return -1;
	version = io->read32(io->context, Q35_VTD_VERSION);
	if (version == UINT32_MAX || ((version >> 4) & 0xfU) != 1U)
		return -2;
	if (io->read32(io->context, Q35_VTD_GSTS) &
	    (Q35_VTD_ROOT_SET | Q35_VTD_TRANSLATION_ENABLE))
		return -3;
	if (iotlb_offset(io, &iotlb))
		return -4;

	io->commit_tables(io->context);
	io->write32(io->context, Q35_VTD_RTADDR, root_phys);
	io->write32(io->context, Q35_VTD_RTADDR + 4U, 0);
	if (read_pair(io, Q35_VTD_RTADDR) != root_phys)
		return -5;
	io->write32(io->context, Q35_VTD_GCMD, Q35_VTD_ROOT_SET);
	if (wait_for(io, Q35_VTD_GSTS, Q35_VTD_ROOT_SET, Q35_VTD_ROOT_SET))
		return -6;
	if (q35_vtd_invalidate(io))
		return -7;
	io->write32(io->context, Q35_VTD_GCMD, Q35_VTD_TRANSLATION_ENABLE);
	if (wait_for(io, Q35_VTD_GSTS, Q35_VTD_TRANSLATION_ENABLE,
		Q35_VTD_TRANSLATION_ENABLE))
		return -8;
	return (io->read32(io->context, Q35_VTD_GSTS) &
		Q35_VTD_TRANSLATION_ENABLE) ? 0 : -9;
}

int q35_vtd_switch_root(const struct q35_vtd_io *io,
	uint32_t expected_root_phys, uint32_t root_phys)
{
	const uint32_t active = Q35_VTD_ROOT_SET | Q35_VTD_TRANSLATION_ENABLE;

	if (!io || !io->read32 || !io->write32 || !io->commit_tables ||
	    !expected_root_phys || (expected_root_phys & 0xfffU) || !root_phys ||
	    (root_phys & 0xfffU) || root_phys == expected_root_phys)
		return -1;
	if ((io->read32(io->context, Q35_VTD_GSTS) & active) != active ||
	    read_pair(io, Q35_VTD_RTADDR) != expected_root_phys)
		return -2;
	io->commit_tables(io->context);
	io->write32(io->context, Q35_VTD_RTADDR, root_phys);
	io->write32(io->context, Q35_VTD_RTADDR + 4U, 0);
	if (read_pair(io, Q35_VTD_RTADDR) != root_phys)
		return -3;
	/* Keep translation set while atomically adopting the replacement root. */
	io->write32(io->context, Q35_VTD_GCMD, active);
	if (wait_for(io, Q35_VTD_GSTS, active, active) ||
	    read_pair(io, Q35_VTD_RTADDR) != root_phys)
		return -4;
	if (q35_vtd_invalidate(io))
		return -5;
	if ((io->read32(io->context, Q35_VTD_GSTS) & active) != active ||
	    read_pair(io, Q35_VTD_RTADDR) != root_phys)
		return -6;
	return 0;
}
