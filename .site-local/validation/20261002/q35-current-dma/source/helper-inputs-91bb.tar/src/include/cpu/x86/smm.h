/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CPU_X86_SMM_H
#define CPU_X86_SMM_H

#include <arch/cpu.h>
#include <commonlib/cfr.h>
#include <commonlib/region.h>
#include <cpu/x86/apm.h>
#include <device/pci_type.h>
#include <device/resource.h>
#include <types.h>
#if CONFIG(PAYLOAD_MM_AUTHVAR_PRESENCE_TUPLE_SENDER) && CONFIG(SMM_INVOCATION_RUNTIME_BINDING)
#include <boot/payload_mm_authvar_presence_bootstrap.h>
#endif
#if CONFIG(SMM_INVOCATION_TOPOLOGY)
#include <cpu/x86/smm_invocation_topology.h>
#endif
#if CONFIG(SMM_INVOCATION_LOADER_INSTANCE)
#include <cpu/x86/smm_invocation_loader_instance.h>
#endif
#if CONFIG(SMM_INVOCATION_LOADER_COMPOSITION)
#include <cpu/x86/smm_invocation_loader_composition.h>
#endif
#if CONFIG(PAYLOAD_MM_AUTHVAR_SMM_BOOTSTRAP)
#include <boot/payload_mm_authvar_smm_loader.h>
#endif
#if CONFIG(PAYLOAD_MM_AUTHVAR_MOR_PRIVATE_SMI)
#include <boot/payload_mm_authvar_mor_private_smi.h>
#endif
#if CONFIG(PAYLOAD_MM_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BACKING_RECEIPT)
#include <bootmem_reservation_receipt.h>
#endif
#if CONFIG(SMM_AUTHVAR_PRESENCE_S3_BACKING_PROOF)
#include <boot/payload_mm_authvar_presence_s3_backing.h>
#endif

#define SMM_DEFAULT_BASE 0x30000
#define SMM_DEFAULT_SIZE 0x10000

/* used only by C programs so far */
#define SMM_BASE 0xa0000

#define SMM_ENTRY_OFFSET 0x8000
#define SMM_SAVE_STATE_BEGIN(x) (SMM_ENTRY_OFFSET + (x))

#define APM_CNT_NOOP_SMI	0x00
#define APM_CNT_ACPI_DISABLE	0x1e
#define APM_CNT_ACPI_ENABLE	0xe1
#define APM_CNT_ROUTE_ALL_XHCI	0xca
#define APM_CNT_FINALIZE	0xcb
#define APM_CNT_LEGACY		0xcc
#define APM_CNT_CFR_RUNTIME_APPLY	CFR_RUNTIME_APPLY_APM_CNT_COMMAND
#define APM_CNT_ROM_ARMOR	0xea
#define APM_CNT_MBI_UPDATE	0xeb
#define APM_CNT_SMMINFO		0xec
#define APM_CNT_SMMSTORE	0xed
#define APM_CNT_OPAL_S3_UNLOCK	0xe9
#define APM_CNT_OPAL_SVC	0xee
#define APM_CNT_ELOG_GSMI	0xef
#define APM_STS		0xb3

#define SMM_PCI_RESOURCE_STORE_NUM_RESOURCES 6

/*
 * SMI Transfer Monitor (STM) descriptor reserved in SMM save state.
 */
#if CONFIG(STM)
#define STM_PSD_SIZE ALIGN_UP(sizeof(TXT_PROCESSOR_SMM_DESCRIPTOR), 0x100)
#else
#define STM_PSD_SIZE 0
#endif

/* Send cmd to APM_CNT with HAVE_SMI_HANDLER checking. */
enum cb_err apm_control(u8 cmd);
u8 apm_get_apmc(void);

void io_trap_handler(int smif);
int mainboard_io_trap_handler(int smif);

void southbridge_smi_set_eos(void);

void global_smi_enable(void);
void global_smi_enable_no_pwrbtn(void);

void cpu_smi_handler(void);
void northbridge_smi_handler(void);
void southbridge_smi_handler(void);

void mainboard_smi_gpi(u32 gpi_sts);
int  mainboard_smi_apmc(u8 data);
void mainboard_smi_sleep(u8 slp_typ);
void mainboard_smi_sleep_finalize(u8 slp_typ);
void mainboard_smi_finalize(void);
int mainboard_set_smm_log_level(void);

void smm_soc_early_init(void);
void smm_soc_exit(void);

/* This is the SMM handler. */
extern unsigned char _binary_smm_start[];
extern unsigned char _binary_smm_end[];

struct smm_pci_resource_info {
	pci_devfn_t pci_addr;
	uint16_t vendor_id;
	uint16_t device_id;
	uint16_t class_device;
	uint8_t class_prog;
	struct resource resources[SMM_PCI_RESOURCE_STORE_NUM_RESOURCES];
};

#if CONFIG(STARLABS_STARBOOK_MTL_DMA_SMM_RECEIPT_PROVISION)
#define SMM_DMA_RECEIPT_MEMORY_REVISION 1U

struct smm_dma_receipt_range {
	uint64_t base;
	uint64_t size;
};

struct smm_dma_receipt_memory {
	uint32_t revision;
	uint32_t size;
	struct smm_dma_receipt_range frame;
	struct smm_dma_receipt_range dma;
	struct smm_dma_receipt_range mirror;
};
#endif

#if CONFIG(Q35_SMM_CAPSULE_BROKER_BUFFERS)
/* Loader-owned allocation geometry, not DMA protection evidence. */
struct smm_dma_owned_memory {
	uintptr_t table_base;
	size_t table_size;
	uintptr_t arena_base;
	size_t arena_size;
};
#endif

struct smm_runtime {
	u32 smbase;
	u32 smm_size;
	u32 save_state_size;
	u32 num_cpus;
	u32 gnvs_ptr;
	u32 cbmemc_size;
	void *cbmemc;
#if CONFIG(SMM_PCI_RESOURCE_STORE)
	struct smm_pci_resource_info pci_resources[CONFIG_SMM_PCI_RESOURCE_STORE_NUM_SLOTS];
#endif
#if CONFIG(SMM_INVOCATION_RUNTIME_VIEW)
	uintptr_t save_state_top[CONFIG_MAX_CPUS] __aligned(sizeof(uintptr_t));
#else
	uintptr_t save_state_top[CONFIG_MAX_CPUS];
#endif
	int smm_log_level;
	uintptr_t smmstore_com_buffer_base;
	size_t smmstore_com_buffer_size;
	uintptr_t payload_spi_console_buffer_base;
	size_t payload_spi_console_buffer_size;
#if CONFIG(SMM_OPAL_S3_SCRATCH_CBMEM)
	uintptr_t opal_s3_scratch_base;
	size_t opal_s3_scratch_size;
#endif
#if CONFIG(SMM_OPAL_S3_STATE_SMRAM)
	uintptr_t opal_s3_state_base;
	size_t opal_s3_state_size;
#endif
#if CONFIG(SMM_AUTHVAR_S3_STATE_SMRAM)
	uintptr_t authvar_s3_state_base __aligned(sizeof(uintptr_t));
	size_t authvar_s3_state_size;
#endif
#if CONFIG(CAPSULE_BROKER_FIXED_BUFFERS)
	uintptr_t capsule_communication_base;
	size_t capsule_communication_reserved_size;
	size_t capsule_communication_size;
	uintptr_t capsule_staging_base;
	size_t capsule_staging_size;
#endif
#if CONFIG(Q35_SMM_CAPSULE_BROKER_BUFFERS)
	struct smm_dma_owned_memory dma_owned_memory __aligned(sizeof(uintptr_t));
#endif
#if CONFIG(PAYLOAD_MM_AUTHVAR_SMM_BOOTSTRAP)
	struct payload_mm_authvar_smm_arena_slot authvar_arena;
#endif
#if CONFIG(PAYLOAD_MM_AUTHVAR_MOR_PRIVATE_SMI)
	struct payload_mm_authvar_mor_private_smi_slot authvar_mor_channel
		__aligned(8);
#endif
#if CONFIG(SMM_INVOCATION_TOPOLOGY)
	struct smm_invocation_topology invocation_topology __aligned(8);
#endif
#if CONFIG(SMM_INVOCATION_LOADER_INSTANCE)
	struct smm_invocation_loader_instance invocation_loader_instance __aligned(8);
#endif
#if CONFIG(SMM_INVOCATION_LOADER_COMPOSITION)
	struct smm_invocation_evidence invocation_evidence __aligned(8);
	struct smm_invocation_loader_composition invocation_composition __aligned(8);
#endif
#if CONFIG(PAYLOAD_MM_AUTHVAR_PRESENCE_TUPLE_SENDER) && CONFIG(SMM_INVOCATION_RUNTIME_BINDING)
	struct payload_mm_authvar_presence_bootstrap authvar_presence_bootstrap __aligned(8);
#endif
#if CONFIG(STARLABS_STARBOOK_MTL_DMA_SMM_RECEIPT_PROVISION)
	uintptr_t dma_receipt_frame_base;
	size_t dma_receipt_frame_size;
	struct smm_dma_receipt_memory dma_receipt_memory __aligned(8);
#endif
#if CONFIG(PAYLOAD_MM_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BACKING_RECEIPT)
	struct bootmem_reservation_receipt_authority
		authvar_presence_lifecycle_close_backing_verifier __aligned(8);
#endif
#if CONFIG(SMM_AUTHVAR_PRESENCE_S3_BACKING_PROOF)
	struct payload_mm_authvar_presence_s3_backing authvar_presence_s3_backing
		__aligned(8);
#endif
} __packed;

#if CONFIG(SMM_INVOCATION_RUNTIME_VIEW)
_Static_assert(offsetof(struct smm_runtime, save_state_size) %
	_Alignof(uint32_t) == 0, "SMM save-state size is not aligned");
_Static_assert(offsetof(struct smm_runtime, num_cpus) %
	_Alignof(uint32_t) == 0, "SMM runtime CPU count is not aligned");
_Static_assert(offsetof(struct smm_runtime, save_state_top) %
	_Alignof(uintptr_t) == 0, "SMM save-state tops are not aligned");
#endif

#if CONFIG(PAYLOAD_MM_AUTHVAR_MOR_PRIVATE_SMI)
_Static_assert(offsetof(struct smm_runtime, authvar_mor_channel) %
	_Alignof(struct payload_mm_authvar_mor_private_smi_slot) == 0,
	"MOR private SMI slot is not aligned in SMM parameters");
#endif

#if CONFIG(SMM_INVOCATION_LOADER_COMPOSITION)
_Static_assert(offsetof(struct smm_runtime, invocation_evidence) % 8 == 0,
	"SMM invocation evidence is not aligned");
_Static_assert(offsetof(struct smm_runtime, invocation_composition) % 8 == 0,
	"SMM invocation composition is not aligned");
#endif

#if CONFIG(SMM_INVOCATION_LOADER_INSTANCE)
_Static_assert(offsetof(struct smm_runtime, invocation_loader_instance) % 8 == 0,
	"SMM invocation loader instance is not aligned");
_Static_assert(_Alignof(struct smm_runtime) >= 8,
	"SMM runtime does not preserve loader instance alignment");
#endif

#if CONFIG(PAYLOAD_MM_AUTHVAR_PRESENCE_TUPLE_SENDER) && CONFIG(SMM_INVOCATION_RUNTIME_BINDING)
_Static_assert(offsetof(struct smm_runtime, authvar_presence_bootstrap) % 8 == 0,
	"Presence bootstrap is not aligned in SMM parameters");
#endif

#if CONFIG(SMM_INVOCATION_TOPOLOGY)
_Static_assert(offsetof(struct smm_runtime, invocation_topology) % 8 == 0,
	"SMM invocation topology is not aligned");
_Static_assert(_Alignof(struct smm_runtime) >= 8,
	"SMM runtime does not preserve topology alignment");
#endif

#if CONFIG(STARLABS_STARBOOK_MTL_DMA_SMM_RECEIPT_PROVISION)
_Static_assert(offsetof(struct smm_runtime, dma_receipt_frame_base) %
	_Alignof(uintptr_t) == 0, "DMA receipt frame base is not aligned");
_Static_assert(offsetof(struct smm_runtime, dma_receipt_frame_size) %
	_Alignof(size_t) == 0, "DMA receipt frame size is not aligned");
_Static_assert(offsetof(struct smm_runtime, dma_receipt_memory) % 8 == 0,
	"DMA receipt memory authority is not aligned");
#endif

#if CONFIG(PAYLOAD_MM_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BACKING_RECEIPT)
_Static_assert(offsetof(struct smm_runtime,
	authvar_presence_lifecycle_close_backing_verifier) % 8 == 0,
	"lifecycle-close backing verifier is not aligned");
#endif

#if CONFIG(SMM_AUTHVAR_S3_STATE_SMRAM)
_Static_assert(offsetof(struct smm_runtime, authvar_s3_state_base) %
	_Alignof(uintptr_t) == 0,
	"authenticated-variable S3 state base is not aligned");
_Static_assert(offsetof(struct smm_runtime, authvar_s3_state_size) %
	_Alignof(size_t) == 0,
	"authenticated-variable S3 state size is not aligned");
#endif

#if CONFIG(SMM_AUTHVAR_PRESENCE_S3_BACKING_PROOF)
_Static_assert(offsetof(struct smm_runtime, authvar_presence_s3_backing) % 8 == 0,
	"authenticated-variable S3 backing facts are not aligned");
#endif

struct smm_module_params {
	size_t cpu;
#if CONFIG(SMM_INVOCATION_ENTRY)
	u32 initial_apic_id;
#endif
	/* A canary value that has been placed at the end of the stack.
	 * If (uintptr_t)canary != *canary then a stack overflow has occurred.
	 */
	const uintptr_t *canary;
};

#if CONFIG(SMM_INVOCATION_ENTRY)
_Static_assert(offsetof(struct smm_module_params, initial_apic_id) ==
	sizeof(size_t), "SMM entry APIC ID ABI offset changed");
#else
_Static_assert(offsetof(struct smm_module_params, canary) == sizeof(size_t),
	"disabled SMM entry ABI changed");
_Static_assert(sizeof(struct smm_module_params) == 2 * sizeof(size_t),
	"disabled SMM entry ABI size changed");
#endif

/* These parameters are used by the SMM stub code. A pointer to the params
 * is also passed to the C-base handler. */
struct smm_stub_params {
	u32 stack_size;
	u32 stack_top;
	u32 c_handler;
	u32 cr3;
	/* The apic_id_to_cpu provides a mapping from APIC id to CPU number.
	 * The CPU number is indicated by the index into the array by matching
	 * the default APIC id and value at the index. The stub loader
	 * initializes this array with a 1:1 mapping. If the APIC ids are not
	 * contiguous like the 1:1 mapping it is up to the caller of the stub
	 * loader to adjust this mapping. */
#if CONFIG(SMM_INVOCATION_ENTRY) || CONFIG(SMM_INVOCATION_TOPOLOGY)
	u32 apic_id_to_cpu[CONFIG_MAX_CPUS];
#else
	u16 apic_id_to_cpu[CONFIG_MAX_CPUS];
#endif
} __packed;

/* smm_handler_t is called with arg of smm_module_params pointer. */
typedef asmlinkage void (*smm_handler_t)(void *);

/* SMM Runtime helpers. */
#if ENV_SMM
extern struct global_nvs *gnvs;
#endif

/* Entry point for SMM modules. */
asmlinkage void smm_handler_start(void *params);

/* Retrieve SMM save state for a given CPU. WARNING: This does not take into
 * account CPUs which are configured to not save their state to RAM. */
void *smm_get_save_state(int cpu);
#if CONFIG(PAYLOAD_MM_AUTHVAR_MOR_PRIVATE_SMI)
struct payload_mm_authvar_mor_private_smi_slot *
	smm_get_payload_mm_authvar_mor_private_smi_slot(void);
#endif

/* Returns true if the region overlaps with the SMM */
bool smm_region_overlaps_handler(const struct region *r);

/* Returns true if the memory pointed to overlaps with SMM reserved memory. */
static inline bool smm_points_to_smram(const void *ptr, const size_t len)
{
	struct region r;

	if (region_create_untrusted(&r, (uintptr_t)ptr, len) != CB_SUCCESS)
		return true; /* Play it safe and pretend it overlaps if we can't tell. */

	return smm_region_overlaps_handler(&r);
}

/* SMM Module Loading API */

/* The smm_loader_params structure provides direction to the SMM loader:
 * - num_cpus - number of concurrent cpus in handler needing stack
 *                           optional for setting up relocation handler.
 * - cpu_save_state_size - the SMM save state size per cpu
 * - num_concurrent_save_states - number of concurrent cpus needing save state
 *                                space
 * - handler - optional handler to call. Only used during SMM relocation setup.
 * - runtime - this field is a result only. The SMM runtime location is filled
 *             into this field so the code doing the loading can manipulate the
 *             runtime's assumptions. e.g. updating the APIC id to CPU map to
 *             handle sparse APIC id space.
 */
struct smm_loader_params {
	size_t num_cpus;

	size_t cpu_save_state_size;
	size_t num_concurrent_save_states;

	smm_handler_t handler;
	uint32_t cr3;
};

/* All of these return 0 on success, < 0 on failure. */
int smm_setup_stack(const uintptr_t perm_smbase, const size_t perm_smram_size,
		    const unsigned int total_cpus, const size_t stack_size);
int smm_setup_relocation_handler(struct smm_loader_params *params);
int smm_load_module(uintptr_t smram_base, size_t smram_size, struct smm_loader_params *params);

u32 smm_get_cpu_smbase(unsigned int cpu_num);

/* Backup and restore default SMM region. */
void *backup_default_smm_area(void);
void restore_default_smm_area(void *smm_save_area);

/*
 * Fills in the arguments for the entire SMM region covered by chipset
 * protections. e.g. TSEG.
 */
void smm_region(uintptr_t *start, size_t *size);

static inline void aseg_region(uintptr_t *start, size_t *size)
{
	*start = SMM_BASE;
	*size = SMM_DEFAULT_SIZE; /* SMM_CODE_SEGMENT_SIZE ? */
}

enum {
	/* SMM handler area. */
	SMM_SUBREGION_HANDLER,
	/* Persistent OPAL S3 state area. */
	SMM_SUBREGION_OPAL_S3_STATE,
	/* SMM cache region. */
	SMM_SUBREGION_CACHE,
	/* Chipset specific area. */
	SMM_SUBREGION_CHIPSET,
#if CONFIG(SMM_AUTHVAR_S3_STATE_SMRAM)
	/* Persistent authenticated-variable S3 state area. */
	SMM_SUBREGION_AUTHVAR_S3_STATE,
#endif
	/* Total sub regions supported. */
	SMM_SUBREGION_NUM,
};

/* Fills in the start and size for the requested SMM subregion. Returns
 * 0 on success, < 0 on failure. */
int smm_subregion(int sub, uintptr_t *start, size_t *size);

/* Print the SMM memory layout on console. */
void smm_list_regions(void);

#define SMM_REVISION_OFFSET_FROM_TOP (0x8000 - 0x7efc)
/* Return the SMM save state revision. The revision can be fetched from the smm savestate
   which is always at the same offset downward from the top of the save state. */
uint32_t smm_revision(void);
/* Returns the PM ACPI SMI port. On Intel systems this typically not configurable (APM_CNT, 0xb2).
   On AMD systems it is sometimes configurable. */
uint16_t pm_acpi_smi_cmd_port(void);

const volatile struct smm_pci_resource_info *smm_get_pci_resource_store(void);

void smm_pci_get_stored_resources(const volatile struct smm_pci_resource_info **out_slots,
				  size_t *out_size);
/* Weak handler function to store PCI BARs. */
void smm_mainboard_pci_resource_store_init(struct smm_pci_resource_info *slots, size_t size);
/* Helper function to fill BARs from an array of device pointers. */
bool smm_pci_resource_store_fill_resources(struct smm_pci_resource_info *slots, size_t num_slots,
					   const struct device **devices, size_t num_devices);

void smm_pci_resource_store_init(struct smm_runtime *smm_runtime);

void smm_get_smmstore_com_buffer(uintptr_t *base, size_t *size);
void smm_get_payload_spi_console_buffer(uintptr_t *base, size_t *size);
#if CONFIG(Q35_SMM_CAPSULE_BROKER_BUFFERS)
bool platform_smm_dma_owned_memory(struct smm_dma_owned_memory *memory);
bool smm_get_dma_owned_memory(const struct smm_dma_owned_memory **memory);
#endif
#if CONFIG(STARLABS_STARBOOK_MTL_DMA_SMM_RECEIPT_PROVISION)
bool platform_smm_dma_receipt_frame(uintptr_t *base, size_t *size);
bool smm_get_dma_receipt_frame(uintptr_t *base, size_t *size);
bool platform_smm_dma_receipt_memory(struct smm_dma_receipt_memory *memory);
bool smm_get_dma_receipt_memory(const struct smm_dma_receipt_memory **memory);
#endif
#if CONFIG(CAPSULE_BROKER_FIXED_BUFFERS)
struct capsule_broker_buffer_reservation;
void smm_get_capsule_broker_buffers(
	struct capsule_broker_buffer_reservation *reservation);
#endif
#if CONFIG(SMM_OPAL_S3_SCRATCH_CBMEM)
void smm_get_opal_s3_scratch_buffer(uintptr_t *base, size_t *size);
#endif
#if CONFIG(SMM_OPAL_S3_STATE_SMRAM)
void smm_get_opal_s3_state_buffer(uintptr_t *base, size_t *size);
#endif
#if CONFIG(SMM_AUTHVAR_S3_STATE_SMRAM)
void smm_get_authvar_s3_state_buffer(uintptr_t *base, size_t *size);
#endif

#endif /* CPU_X86_SMM_H */
