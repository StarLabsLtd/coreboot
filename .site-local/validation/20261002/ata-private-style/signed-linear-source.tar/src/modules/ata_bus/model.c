/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#include <cdk2/ata_bus.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

static uint16_t get16(const uint8_t *value)
{
	return (uint16_t)value[0] | ((uint16_t)value[1] << 8);
}

static uint32_t get32(const uint8_t *value)
{
	return get16(value) | ((uint32_t)get16(value + 2) << 16);
}

EFI_STATUS cdk2_ata_bus_parse_identify(const UINT8 identify[512],
				       struct cdk2_ata_bus_media *media)
{
	uint16_t word49;
	uint16_t word82;
	uint16_t word83;
	uint16_t word106;
	uint16_t word209;
	uint64_t blocks;
	uint32_t block_size = 512U;
	bool lba48;

	if (identify == NULL || media == NULL)
		return EFI_INVALID_PARAMETER;
	if (identify[510] == 0xa5U) {
		uint8_t checksum = 0U;

		for (size_t byte = 0U; byte < 512U; byte++)
			checksum = (uint8_t)(checksum + identify[byte]);
		if (checksum != 0U)
			return EFI_COMPROMISED_DATA;
	}
	word49 = get16(identify + 49U * 2U);
	word82 = get16(identify + 82U * 2U);
	word83 = get16(identify + 83U * 2U);
	word106 = get16(identify + 106U * 2U);
	word209 = get16(identify + 209U * 2U);
	if ((word49 & (1U << 9)) == 0U)
		return EFI_UNSUPPORTED;
	if ((word106 & 0xc000U) == 0x4000U && (word106 & (1U << 12)) != 0U) {
		uint32_t words = get32(identify + 117U * 2U);

		if (words < 256U || words > UINT32_MAX / 2U)
			return EFI_COMPROMISED_DATA;
		block_size = words * 2U;
	}
	lba48 = (word83 & 0xc000U) == 0x4000U && (word83 & (1U << 10)) != 0U;
	blocks = lba48 ? get32(identify + 100U * 2U) |
		((uint64_t)get32(identify + 100U * 2U + 4) << 32) :
		get32(identify + 60U * 2U);
	if (blocks == 0U)
		return CDK2_EFI_NO_MEDIA;
	if ((lba48 && blocks > (UINT64_C(1) << 48)) || (!lba48 && blocks > (UINT64_C(1) << 28)))
		return EFI_COMPROMISED_DATA;
	memset(media, 0, sizeof(*media));
	media->blocks = blocks;
	media->block_size = block_size;
	media->lba48 = lba48;
	media->flush_command = (word83 & 0xc000U) == 0x4000U &&
		(word83 & (1U << 13)) != 0U ? 0xeaU :
		(word82 & (1U << 12)) != 0U ? 0xe7U : 0U;
	media->udma = (get16(identify + 53U * 2U) & (1U << 2)) != 0U &&
		      (get16(identify + 88U * 2U) & 0x7f00U) != 0U;
	media->removable = (get16(identify) & (1U << 7)) != 0U;
	media->write_caching = (get16(identify + 87U * 2U) & 0xc000U) == 0x4000U &&
			       (get16(identify + 85U * 2U) & (1U << 5)) != 0U;
	media->trusted = (get16(identify + 48U * 2U) & 0xc001U) == 0x4001U;
	media->logical_blocks_per_physical_block =
		(word106 & 0xc000U) == 0x4000U && (word106 & (1U << 13)) != 0U ?
			1U << (word106 & 0xfU) :
			1U;
	if ((word209 & 0xc000U) == 0x4000U) {
		uint32_t alignment = word209 & 0x3fffU;

		if (alignment >= media->logical_blocks_per_physical_block && alignment != 0U)
			return EFI_COMPROMISED_DATA;
		media->lowest_aligned_lba =
			alignment == 0U ? 0U :
					  media->logical_blocks_per_physical_block - alignment;
	}
	return EFI_SUCCESS;
}

static EFI_STATUS identify_device(struct cdk2_ata_pass_thru_protocol *protocol, UINT16 port,
				  UINT16 multiplier, struct cdk2_ata_bus_child *child,
				  void (*release_path)(void *, void *), void *release_context)
{
	struct cdk2_ata_command_block acb = { .command = 0xecU };
	struct cdk2_ata_status_block asb;
	struct cdk2_ata_command_packet packet = {
		.asb = &asb,
		.acb = &acb,
		.timeout = 300000000U,
		.in_data = child->identify,
		.in_length = 512U,
		.protocol = 4U,
		.length = 0xa0U,
	};
	void *path = NULL;
	EFI_STATUS status;

	for (size_t attempt = 0; attempt < 4U; attempt++) {
		packet.in_length = 512U;
		memset(&asb, 0, sizeof(asb));
		memset(child->identify, 0, sizeof(child->identify));
		status = protocol->pass_thru(protocol, port, multiplier, &packet, NULL);
		if (!EFI_ERROR(status) && packet.in_length == 512U &&
		    (asb.status & 0x21U) == 0U)
			break;
		if (!EFI_ERROR(status))
			status = EFI_DEVICE_ERROR;
	}
	if (EFI_ERROR(status))
		return status;
	if ((get16(child->identify) & (1U << 15)) != 0U)
		return EFI_UNSUPPORTED;
	status = cdk2_ata_bus_parse_identify(child->identify, &child->geometry);
	if (EFI_ERROR(status))
		return status;
	child->geometry.io_align = protocol->mode == NULL ? 0U : protocol->mode->io_align;
	status = protocol->build_device_path(protocol, port, multiplier, &path);
	if (EFI_ERROR(status) || path == NULL)
		return EFI_ERROR(status) ? status : EFI_DEVICE_ERROR;
	child->device_path_size = ((uint8_t *)path)[2] | ((size_t)((uint8_t *)path)[3] << 8);
	if (child->device_path_size > sizeof(child->device_path) ||
	    child->device_path_size < 4U) {
		release_path(release_context, path);
		return EFI_COMPROMISED_DATA;
	}
	memcpy(child->device_path, path, child->device_path_size);
	release_path(release_context, path);
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_ata_bus_add_controller_selected(struct cdk2_ata_bus *bus, void *handle,
						struct cdk2_ata_pass_thru_protocol *pass_thru,
						UINT16 selected_port,
						UINT16 selected_multiplier,
						void (*release_path)(void *, void *),
						void *release_context)
{
	struct cdk2_ata_bus staged;
	struct cdk2_ata_bus_controller *controller;
	uint16_t port = 0xffffU;
	EFI_STATUS status;

	if (bus == NULL || handle == NULL || pass_thru == NULL || release_path == NULL ||
	    pass_thru->get_next_port == NULL || pass_thru->get_next_device == NULL ||
	    pass_thru->pass_thru == NULL || pass_thru->build_device_path == NULL ||
	    pass_thru->mode == NULL ||
	    (pass_thru->mode->attributes & (CDK2_ATA_PASS_THRU_ATTRIBUTES_LOGICAL |
					    CDK2_ATA_PASS_THRU_ATTRIBUTES_NONBLOCKIO)) !=
		    (CDK2_ATA_PASS_THRU_ATTRIBUTES_LOGICAL |
		     CDK2_ATA_PASS_THRU_ATTRIBUTES_NONBLOCKIO) ||
	    (pass_thru->mode->io_align != 0U &&
	     (pass_thru->mode->io_align & (pass_thru->mode->io_align - 1U)) != 0U))
		return EFI_INVALID_PARAMETER;
	for (size_t index = 0; index < bus->controller_count; index++)
		if (bus->controllers[index].handle == handle)
			return EFI_ALREADY_STARTED;
	if (bus->controller_count == CDK2_ATA_BUS_MAX_CONTROLLERS)
		return EFI_OUT_OF_RESOURCES;
	staged = *bus;
	controller = &staged.controllers[staged.controller_count];
	memset(controller, 0, sizeof(*controller));
	controller->handle = handle;
	controller->pass_thru = pass_thru;
	controller->first_child = staged.child_count;
	while (!EFI_ERROR(status = pass_thru->get_next_port(pass_thru, &port))) {
		uint16_t multiplier = 0xffffU;

		while (!EFI_ERROR(
			status = pass_thru->get_next_device(pass_thru, port, &multiplier))) {
			struct cdk2_ata_bus_child *child;

			if (selected_port != 0xffffU &&
			    (port != selected_port || multiplier != selected_multiplier))
				continue;
			if (staged.child_count == CDK2_ATA_BUS_MAX_CHILDREN)
				return EFI_OUT_OF_RESOURCES;
			child = &staged.children[staged.child_count];
			memset(child, 0, sizeof(*child));
			child->controller = handle;
			child->port = port;
			child->multiplier = multiplier;
			child->type = CDK2_ATA_DISK;
			status = identify_device(pass_thru, port, multiplier, child,
						 release_path, release_context);
			if (status == EFI_OUT_OF_RESOURCES)
				return status;
			if (EFI_ERROR(status))
				continue;
			staged.child_count++;
			controller->child_count++;
		}
		if (status != EFI_NOT_FOUND)
			return status;
	}
	if (status != EFI_NOT_FOUND || controller->child_count == 0U)
		return status == EFI_NOT_FOUND ? EFI_NOT_FOUND : status;
	staged.controller_count++;
	*bus = staged;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_ata_bus_add_controller(struct cdk2_ata_bus *bus, void *handle,
				       struct cdk2_ata_pass_thru_protocol *pass_thru,
				       void (*release_path)(void *, void *),
				       void *release_context)
{
	return cdk2_ata_bus_add_controller_selected(bus, handle, pass_thru, 0xffffU, 0xffffU,
						    release_path, release_context);
}

EFI_STATUS cdk2_ata_bus_remove_controller(struct cdk2_ata_bus *bus, void *handle)
{
	size_t index;

	if (bus == NULL || handle == NULL)
		return EFI_INVALID_PARAMETER;
	for (index = 0; index < bus->controller_count; index++)
		if (bus->controllers[index].handle == handle)
			break;
	if (index == bus->controller_count)
		return EFI_NOT_FOUND;
	{
		size_t first = bus->controllers[index].first_child;
		size_t count = bus->controllers[index].child_count;

		memmove(&bus->children[first], &bus->children[first + count],
			(bus->child_count - first - count) * sizeof(bus->children[0]));
		bus->child_count -= count;
		memmove(&bus->controllers[index], &bus->controllers[index + 1],
			(bus->controller_count - index - 1U) * sizeof(bus->controllers[0]));
		bus->controller_count--;
		for (size_t next = index; next < bus->controller_count; next++)
			bus->controllers[next].first_child -= count;
	}
	return EFI_SUCCESS;
}
