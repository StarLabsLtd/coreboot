#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM

build_and_run() {
	name=$1
	shift
	common="-std=gnu11 -Wall -Wextra -Werror -ffunction-sections -fdata-sections -I$root/include -I$root/src/boot"
	# shellcheck disable=SC2086
	cc $common -Wconversion -Wsign-conversion "$@" -c \
		"$root/tests/system_fmp_transport_client_test.c" -o "$temporary/test.o"
	# shellcheck disable=SC2086
	cc $common -Wconversion -Wsign-conversion "$@" -c \
		"$root/src/modules/system_fmp/transport.c" -o "$temporary/transport.o"
	# These pre-existing support sources have their own strict checks.
	# shellcheck disable=SC2086
	cc $common "$@" -c "$root/src/modules/qemu_test_fmp/sha256.c" \
		-o "$temporary/sha256.o"
	# shellcheck disable=SC2086
	cc $common "$@" -c "$root/src/boot/coreboot.c" \
		-o "$temporary/coreboot.o"
	cc "$temporary/test.o" "$temporary/transport.o" \
		"$temporary/sha256.o" "$temporary/coreboot.o" \
		-Wl,--gc-sections "$@" -o "$temporary/$name"
	if test "$name" = sanitized; then
		ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
			"$temporary/$name"
	else
		"$temporary/$name"
	fi
}

build_and_run ordinary -O0
build_and_run optimized -O2
build_and_run sanitized -O1 -g -fsanitize=address,undefined \
	-fno-omit-frame-pointer

if grep -Rq 'SYSTEM_FMP_TRANSPORT' "$root/Kconfig" "$root/src"/Kconfig* 2>/dev/null; then
	echo 'ERROR: standalone SystemFmp transport switch entered production build path' >&2
	exit 1
fi
references=$(git -C "$root" grep --untracked -El \
	'cdk2_system_fmp_client_(execute|read_info)' | sort)
expected=$(printf '%s\n' \
	'include/cdk2/system_fmp_transport.h' \
	'src/boot/Makefile' \
	'src/modules/system_fmp/session.c' \
	'src/modules/system_fmp/transport.c' \
	'tests/capsule_mm_native_reset_probe.c' \
	'tests/system_fmp_future_floor_test.c' \
	'tests/system_fmp_production_closure_test.sh' \
	'tests/system_fmp_session_test.c' \
	'tests/system_fmp_transport_client_test.c')
if test "$references" != "$expected"; then
	echo 'ERROR: SystemFmp client gained an unclassified source reference' >&2
	exit 1
fi

printf '%s\n' \
	'SystemFmp client O0/O2/ASan+UBSan and source-closure tests: PASS'
