#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM

build_and_run() {
	name=$1
	shift
	cc -std=gnu11 -Wall -Wextra -Werror \
		-ffunction-sections -fdata-sections -I"$root/include" \
		-I"$root/src/boot" "$@" \
		"$root/tests/system_fmp_transport_test.c" \
		"$root/src/modules/system_fmp/transport.c" \
		"$root/src/boot/coreboot.c" -Wl,--gc-sections \
		-o "$temporary/$name"
	if test "$name" = sanitized; then
		ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
			"$temporary/$name"
	else
		"$temporary/$name"
	fi
}

build_and_run ordinary
build_and_run optimized -O2
build_and_run sanitized -O1 -g -fsanitize=address,undefined \
	-fno-omit-frame-pointer

if grep -Rq 'SYSTEM_FMP_TRANSPORT' "$root/Kconfig" "$root/src"/Kconfig* 2>/dev/null; then
	echo 'ERROR: dormant SystemFmp transport entered a production build path' >&2
	exit 1
fi
if grep -Eq 'EFI_(HANDLE|SYSTEM_TABLE)|IoWrite|outb' \
	"$root/include/cdk2/system_fmp_transport.h" \
	"$root/src/modules/system_fmp/transport.c"; then
	echo 'ERROR: parser exposes a protocol, entry point, or trigger side effect' >&2
	exit 1
fi
references=$(git -C "$root" grep --untracked -l \
	'cdk2_system_fmp_transport_from_coreboot' | sort)
expected=$(printf '%s\n' \
	'include/cdk2/system_fmp_transport.h' \
	'src/modules/dxe_core/entry.c' \
	'src/modules/system_fmp/session.c' \
	'src/modules/system_fmp/transport.c' \
	'tests/capsule_mm_native_reset_probe.c' \
	'tests/system_fmp_future_floor_test.c' \
	'tests/system_fmp_session_test.c' \
	'tests/system_fmp_transport_test.c' \
	'tests/system_fmp_transport_test.sh')
if test "$references" != "$expected"; then
	echo 'ERROR: SystemFmp endpoint importer gained an unclassified client' >&2
	exit 1
fi

printf '%s\n' \
	'SystemFmp transport parser O0/O2/ASan+UBSan and source-boundary tests: PASS'
