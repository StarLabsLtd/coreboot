#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

test "$#" -eq 2 || exit 2
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
header=$(realpath "$1")
output=$(realpath -m "$2")
capsule=${MM_FULL_CORE_CAPSULE:?signed full capsule required}
target=${MM_FULL_CORE_TARGET:?immutable full Core target required}
trust=${MM_FULL_CORE_PUBLIC_TRUST:?public trust certificate required}
tools=${CAPSULE_TOOL_ROOT:?actual coreboot capsule tool directory required}
compiler=${HOSTCC:-cc}
linker=${HOSTLD:-ld}
pe_link=${NATIVE_PE_LINK:?actual native PE linker required}
pe_audit=${NATIVE_PE_AUDIT:?actual native PE relocation audit required}
pe_marker=${NATIVE_PE_MARKER:?actual native PE relocation marker required}
readelf=${HOSTREADELF:-readelf}

grep -qx '#define CONFIG_CDK2_NATIVE_SYSTEM_FMP 1' "$header"
grep -qx '#define CONFIG_CDK2_NATIVE_QEMU_TEST_FMP 0' "$header"
grep -qx '#define CONFIG_CDK2_QEMU_ACCEPTANCE_PROFILE 0' "$header"
grep -qx '#define CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME 1' "$header"
mkdir -p "$output/include/cdk2"
cp "$header" "$output/include/cdk2/config.h"
cp "$capsule" "$output/signed_capsule.bin"
cp "$target" "$output/target-image.bin"
cp "$trust" "$output/public-trust.pem"
sha256sum "$header" "$capsule" "$target" "$trust" \
	"$root/tests/system_fmp_core_ram_stage_app.c" \
	"$root/tests/system_fmp_core_ram_stage_app.ld" \
	"$root/tests/system_fmp_core_ram_stage_app_test.sh" > "$output/inputs-before.sha256"
sha256sum "$(command -v "$compiler")" "$(command -v "$linker")" \
	"$(command -v "$readelf")" "$pe_link" "$pe_audit" "$pe_marker" \
	"$tools/validate_capsule.py" "$tools/generate_capsule.py" \
	> "$output/tools-before.sha256"
python3 "$tools/validate_capsule.py" --capsule "$output/signed_capsule.bin" \
	--guid 00112233-4455-6677-8899-aabbccddeeff --embedded-drivers 0 \
	--fw-version 0x001a000a --lsv 0x001a0009 --image "$output/target-image.bin" \
	--region COREBOOT --trusted-public-cert "$output/public-trust.pem" \
	--initiate-reset --require-fmap > "$output/capsule-validation.log" 2>&1
(cd "$output" && "$linker" -r -b binary signed_capsule.bin -o capsule.o)
"$compiler" -std=gnu11 -Wall -Wextra -Werror -O2 -ffreestanding \
	-fno-stack-protector -fno-asynchronous-unwind-tables -fshort-wchar \
	-mno-red-zone -m64 -mcmodel=small -fpie -fno-ident \
	-fcf-protection=none -maccumulate-outgoing-args \
	-I"$output/include" -I"$root/include" \
	-c "$root/tests/system_fmp_core_ram_stage_app.c" -o "$output/entry.o"
"$pe_link" "$linker" "$pe_audit" "$pe_marker" "$readelf" \
	--subsystem 10 --entry system_fmp_core_ram_stage_entry \
	--image-base 0 --section-alignment 0x1000 --file-alignment 0x1000 \
	--build-id=none --no-insert-timestamp -s --nxcompat \
	-T "$root/tests/system_fmp_core_ram_stage_app.ld" \
	-o "$output/SystemFmpCoreRamStage.efi" "$output/entry.o" "$output/capsule.o"
cmp "$header" "$output/include/cdk2/config.h"
sha256sum -c "$output/inputs-before.sha256"
sha256sum -c "$output/tools-before.sha256"
sha256sum "$output/SystemFmpCoreRamStage.efi"
printf '%s\n' 'Normal MAIN stage/cold observer compiled: no VM or install claim'
