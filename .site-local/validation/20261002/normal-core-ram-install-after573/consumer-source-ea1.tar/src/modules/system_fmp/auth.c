/* SPDX-License-Identifier: GPL-2.0-only */

#include <cdk2/system_fmp_auth.h>

/* EFI_CERT_TYPE_PKCS7_GUID in its UEFI in-memory byte order. */
enum {
	certificate_length_offset = 8,
	certificate_revision_offset = 12,
	certificate_type_offset = 14,
	certificate_guid_offset = 16,
	certificate_data_offset = 32,
};

#define WIN_CERT_REVISION_2_0 0x0200U
#define WIN_CERT_TYPE_EFI_GUID 0x0ef1U

static const uint8_t pkcs7_guid[16] = {
	0x9d, 0xd2, 0xaf, 0x4a, 0xdf, 0x68, 0xee, 0x49,
	0x8a, 0xa9, 0x34, 0x7d, 0x37, 0x56, 0x65, 0xa7,
};

static uint16_t read16(const uint8_t *data)
{
	return (uint16_t)data[0] | (uint16_t)data[1] << 8U;
}

static uint32_t read32(const uint8_t *data)
{
	return (uint32_t)read16(data) | (uint32_t)read16(data + 2U) << 16U;
}

static uint64_t read64(const uint8_t *data)
{
	return (uint64_t)read32(data) | (uint64_t)read32(data + 4U) << 32U;
}

static bool bytes_equal(const uint8_t *left, const uint8_t *right, size_t size)
{
	uint8_t difference = 0U;

	while (size-- != 0U)
		difference |= *left++ ^ *right++;
	return difference == 0U;
}

static EFI_STATUS validate_certificate_xdr(const uint8_t *xdr, size_t size)
{
	size_t offset = 0U;

	if (xdr == NULL || size == 0U)
		return EFI_INVALID_PARAMETER;
	while (offset < size) {
		uint32_t certificate_size;
		size_t padding;

		if (size - offset < sizeof(uint32_t))
			return EFI_COMPROMISED_DATA;
		certificate_size = (uint32_t)xdr[offset] << 24U |
			(uint32_t)xdr[offset + 1U] << 16U |
			(uint32_t)xdr[offset + 2U] << 8U | xdr[offset + 3U];
		offset += sizeof(uint32_t);
		if (certificate_size == 0U || certificate_size > size - offset)
			return EFI_COMPROMISED_DATA;
		offset += certificate_size;
		padding = (4U - (offset & 3U)) & 3U;
		if (padding > size - offset)
			return EFI_COMPROMISED_DATA;
		while (padding-- != 0U)
			if (xdr[offset++] != 0U)
				return EFI_COMPROMISED_DATA;
	}
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_auth_parse_untrusted(const void *image_buffer,
	size_t image_size, struct cdk2_system_fmp_untrusted_auth_view *view)
{
	const uint8_t *image = image_buffer;
	uint32_t certificate_header_size;
	size_t payload_offset;

	if (view == NULL)
		return EFI_INVALID_PARAMETER;
	*view = (struct cdk2_system_fmp_untrusted_auth_view){0};
	if (image == NULL)
		return EFI_INVALID_PARAMETER;
	if (image_size <= CDK2_FMP_AUTH_MONOTONIC_SIZE +
	    CDK2_FMP_AUTH_CERT_HEADER_SIZE)
		return EFI_COMPROMISED_DATA;
	if ((uintptr_t)image > UINTPTR_MAX - (image_size - 1U))
		return EFI_COMPROMISED_DATA;
	certificate_header_size = read32(image + certificate_length_offset);
	if (certificate_header_size <= CDK2_FMP_AUTH_CERT_HEADER_SIZE ||
	    certificate_header_size > image_size - CDK2_FMP_AUTH_MONOTONIC_SIZE)
		return EFI_COMPROMISED_DATA;
	if (read16(image + certificate_revision_offset) != WIN_CERT_REVISION_2_0 ||
	    read16(image + certificate_type_offset) != WIN_CERT_TYPE_EFI_GUID)
		return EFI_COMPROMISED_DATA;
	if (!bytes_equal(image + certificate_guid_offset, pkcs7_guid,
	    sizeof(pkcs7_guid)))
		return EFI_UNSUPPORTED;
	payload_offset = CDK2_FMP_AUTH_MONOTONIC_SIZE + certificate_header_size;
	if (payload_offset >= image_size)
		return EFI_COMPROMISED_DATA;
	*view = (struct cdk2_system_fmp_untrusted_auth_view) {
		.monotonic_count = read64(image),
		.signature = image + certificate_data_offset,
		.signature_size = certificate_header_size - CDK2_FMP_AUTH_CERT_HEADER_SIZE,
		.payload = image + payload_offset,
		.payload_size = image_size - payload_offset,
	};
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_authenticate(const void *image_buffer,
	size_t image_size, const void *certificate_xdr_buffer,
	size_t certificate_xdr_size, cdk2_system_fmp_pkcs7_verify_fn *verify,
	void *context, struct cdk2_system_fmp_auth_view *view)
{
	const uint8_t *image = image_buffer;
	const uint8_t *certificate_xdr = certificate_xdr_buffer;
	struct cdk2_system_fmp_signed_span signed_data[2];
	struct cdk2_system_fmp_untrusted_auth_view untrusted;
	struct cdk2_system_fmp_auth_view candidate;
	size_t offset;
	EFI_STATUS status;

	if (view == NULL)
		return EFI_INVALID_PARAMETER;
	*view = (struct cdk2_system_fmp_auth_view){0};
	if (image == NULL || certificate_xdr == NULL || verify == NULL)
		return EFI_INVALID_PARAMETER;
	status = cdk2_system_fmp_auth_parse_untrusted(image, image_size, &untrusted);
	if (EFI_ERROR(status))
		return status;
	status = validate_certificate_xdr(certificate_xdr, certificate_xdr_size);
	if (EFI_ERROR(status))
		return status;
	candidate = (struct cdk2_system_fmp_auth_view) {
		.monotonic_count = untrusted.monotonic_count,
		.payload = untrusted.payload,
		.payload_size = untrusted.payload_size,
	};
	signed_data[0] = (struct cdk2_system_fmp_signed_span) {
		.data = candidate.payload,
		.size = candidate.payload_size,
	};
	signed_data[1] = (struct cdk2_system_fmp_signed_span) {
		.data = image,
		.size = CDK2_FMP_AUTH_MONOTONIC_SIZE,
	};
	for (offset = 0U; offset < certificate_xdr_size;) {
		uint32_t certificate_size = (uint32_t)certificate_xdr[offset] << 24U |
			(uint32_t)certificate_xdr[offset + 1U] << 16U |
			(uint32_t)certificate_xdr[offset + 2U] << 8U |
			certificate_xdr[offset + 3U];
		size_t padding;

		offset += sizeof(uint32_t);
		if (verify(context,
		    untrusted.signature,
		    untrusted.signature_size, certificate_xdr + offset, certificate_size,
		    signed_data)) {
			*view = candidate;
			return EFI_SUCCESS;
		}
		offset += certificate_size;
		padding = (4U - (offset & 3U)) & 3U;
		offset += padding;
	}
	return EFI_SECURITY_VIOLATION;
}
