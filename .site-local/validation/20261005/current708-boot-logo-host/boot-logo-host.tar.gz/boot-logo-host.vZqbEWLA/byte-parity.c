/* SPDX-License-Identifier: GPL-2.0-only */
#define main early_splash_fixture_main
#include "/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/tests/early_splash_test.c"
#undef main

int main(void)
{
	if (early_splash_fixture_main() != 0)
		return 1;
	if (fwrite(pixels, sizeof(pixels), 1, stdout) != 1 ||
	    fwrite(bmp, sizeof(bmp), 1, stdout) != 1)
		return 1;
	return 0;
}
