deps_config := \
	kconfig/Kconfig \

/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/o2/auto.conf: $(deps_config)


$(deps_config): ;
