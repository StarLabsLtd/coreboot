/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl/draw/nxp/pxp/lv_pxp_cfg.o: \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/nxp/pxp/lv_pxp_cfg.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/nxp/pxp/lv_pxp_cfg.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/nxp/pxp/../../../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/nxp/pxp/../../../lv_conf_kconfig.h \
 /home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl-config/lv_conf.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/nxp/pxp/lv_pxp_cfg.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/nxp/pxp/../../../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/nxp/pxp/../../../lv_conf_kconfig.h:
/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl-config/lv_conf.h:
