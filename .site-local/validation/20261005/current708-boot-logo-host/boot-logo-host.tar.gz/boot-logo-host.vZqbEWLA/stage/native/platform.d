/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/platform.o: \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//src/platform/cdk2_platform_lib/cdk2_platform_lib.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/library/cdk2_platform_lib.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/library/cdk2_platform_lib.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h:
