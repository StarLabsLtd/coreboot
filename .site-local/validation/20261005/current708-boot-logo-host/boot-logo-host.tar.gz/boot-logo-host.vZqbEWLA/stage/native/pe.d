/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/pe.o: \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/pe.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pe_image_view.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/industry_standard/pe_image.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/pe.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pe_image_view.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/industry_standard/pe_image.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/pe.h:
