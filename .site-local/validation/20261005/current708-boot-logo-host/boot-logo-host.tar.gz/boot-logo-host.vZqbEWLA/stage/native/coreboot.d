/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/coreboot.o: \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/coreboot_tables.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/hob.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/boot_mode.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_checksum.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_resource.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/coreboot_tables.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/hob.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/boot_mode.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_checksum.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_resource.h:
