/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/coreboot_checksum.o: \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_checksum.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_checksum.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_checksum.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h:
