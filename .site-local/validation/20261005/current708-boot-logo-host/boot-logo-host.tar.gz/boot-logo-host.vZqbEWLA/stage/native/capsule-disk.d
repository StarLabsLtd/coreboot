/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/capsule-disk.o: \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//src/lib/capsule_disk.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/capsule_disk.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/fat_binding.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/disk_io.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/english.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/fat.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/diagnostic.h \
 /home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/include/cdk2/config.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/linear_boot.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/uart.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/capsule_disk.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/fat_binding.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/disk_io.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/english.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/fat.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/diagnostic.h:
/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/include/cdk2/config.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/linear_boot.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/uart.h:
