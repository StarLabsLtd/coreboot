/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl/draw/sdl/lv_draw_sdl.o: \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/lv_draw_sdl.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_draw_private.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_draw.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../lv_conf_kconfig.h \
 /home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl-config/lv_conf.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_style.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/lv_font.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/lv_symbol_def.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/lv_draw_buf.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_area.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_math.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_color.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_assert.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_log.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/lv_mem.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/lv_string.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_palette.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_color.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_color_op.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../stdlib/lv_string.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/lv_image_dsc.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../misc/lv_area.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_color.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_area.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_anim.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_ext_data.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_math.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_timer.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../tick/lv_tick.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../tick/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../tick/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_ll.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_text.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../stdlib/lv_sprintf.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../stdlib/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_assert.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_bidi.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_grad.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/lv_layout.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/flex/lv_flex.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/flex/../../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/flex/../../misc/lv_area.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/grid/lv_grid.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/grid/../../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/grid/../../misc/lv_area.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_style_gen.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_text.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_profiler.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_matrix.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_event.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_array.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_image_decoder.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_draw_buf.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_fs.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_area.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_os_private.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_os.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/../misc/lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_linux.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_os_none.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/lv_cache.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/../lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/lv_cache_entry.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_class.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_lru_rb.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/../lv_cache_private.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/../../lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/../../../osal/lv_os_private.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_lru_ll.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_sc_da.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/lv_cache_instance.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/lv_image_header_cache.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/../../lv_types.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/lv_image_cache.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_draw_private.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_draw.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../lv_conf_kconfig.h:
/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl-config/lv_conf.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_style.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/lv_font.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/lv_symbol_def.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/lv_draw_buf.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_area.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_math.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_color.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_assert.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_log.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/lv_mem.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/lv_string.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/../stdlib/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_palette.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_color.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../misc/lv_color_op.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../stdlib/lv_string.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/lv_image_dsc.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../draw/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../font/../misc/lv_area.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_color.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_area.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_anim.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_ext_data.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_math.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_timer.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../tick/lv_tick.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../tick/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../tick/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_ll.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_text.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../stdlib/lv_sprintf.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../stdlib/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_assert.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_bidi.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_grad.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/lv_layout.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/flex/lv_flex.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/flex/../../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/flex/../../misc/lv_area.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/grid/lv_grid.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/grid/../../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/../layouts/grid/../../misc/lv_area.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_style_gen.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_text.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_profiler.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_matrix.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_event.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_array.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_image_decoder.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../lv_draw_buf.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_fs.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/lv_area.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_os_private.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_os.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/../misc/lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_linux.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../osal/lv_os_none.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/lv_cache.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/../lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/lv_cache_entry.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_class.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_lru_rb.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/../lv_cache_private.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/../../lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/../../../osal/lv_os_private.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_lru_ll.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/class/lv_cache_sc_da.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/lv_cache_instance.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/lv_image_header_cache.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/../../lv_types.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/sdl/../../misc/cache/instance/lv_image_cache.h:
