/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/coreboot_hobs.o: \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_hobs.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pci_host_bridge.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/diagnostic.h \
 /home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/include/cdk2/config.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/linear_boot.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/uart.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/payload_handoff.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pci_configuration.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/capsule_delivery_policy.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/hob.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/hob.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/boot_mode.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/coreboot_tables.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pci_topology_handoff.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/dma_handoff.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/guid/memory_allocation_hob.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/industry_standard/mcfg.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/industry_standard/acpi.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_hobs.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_checksum.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_resource.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pci_host_bridge.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/diagnostic.h:
/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/include/cdk2/config.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/linear_boot.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/uart.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/payload_handoff.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pci_configuration.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/capsule_delivery_policy.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/hob.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/hob.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/boot_mode.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/coreboot_tables.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/pci_topology_handoff.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/dma_handoff.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/guid/memory_allocation_hob.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/industry_standard/mcfg.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/industry_standard/acpi.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_hobs.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_checksum.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/coreboot_resource.h:
