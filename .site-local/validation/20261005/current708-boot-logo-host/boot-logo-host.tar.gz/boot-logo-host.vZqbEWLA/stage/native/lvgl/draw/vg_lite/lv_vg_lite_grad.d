/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl/draw/vg_lite/lv_vg_lite_grad.o: \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/vg_lite/lv_vg_lite_grad.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/vg_lite/lv_vg_lite_grad.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/vg_lite/../../lv_conf_internal.h \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/vg_lite/../../lv_conf_kconfig.h \
 /home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl-config/lv_conf.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/vg_lite/lv_vg_lite_grad.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/vg_lite/../../lv_conf_internal.h:
/home/sean/Documents/cdk2/3rdparty/lvgl/src/draw/vg_lite/../../lv_conf_kconfig.h:
/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl-config/lv_conf.h:
