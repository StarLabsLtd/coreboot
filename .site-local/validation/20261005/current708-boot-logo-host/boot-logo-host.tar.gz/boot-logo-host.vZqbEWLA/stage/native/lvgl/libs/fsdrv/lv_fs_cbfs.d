/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl/libs/fsdrv/lv_fs_cbfs.o: \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/libs/fsdrv/lv_fs_cbfs.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
