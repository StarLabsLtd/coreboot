/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/services.o: \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/services.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/boot_mode.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/hob.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/library/cdk2_platform_lib.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/services.h \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/library/cdk2_native_services.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/uefi.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/boot_mode.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/pi/hob.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/library/cdk2_platform_lib.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675/src/boot/services.h:
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/library/cdk2_native_services.h:
