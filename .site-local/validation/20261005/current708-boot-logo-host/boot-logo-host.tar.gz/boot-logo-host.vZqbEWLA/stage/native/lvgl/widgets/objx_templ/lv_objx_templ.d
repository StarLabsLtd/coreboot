/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/native/lvgl/widgets/objx_templ/lv_objx_templ.o: \
 /home/sean/Documents/cdk2/3rdparty/lvgl/src/widgets/objx_templ/lv_objx_templ.c \
 /home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h
/home/sean/Documents/.cdk2-worktrees/roadmap-checkpoint-after675//include/cdk2/native_visibility.h:
