deps_config := \
	kconfig/Kconfig \

/home/sean/current693-fwui-qemu.PMINOC/boot-logo-host.vZqbEWLA/stage/auto.conf: $(deps_config)


$(deps_config): ;
