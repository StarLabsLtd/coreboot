/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#include <cdk2/boot_logo.h>

#include <string.h>

#define GLYPH_WIDTH 5U
#define GLYPH_HEIGHT 7U
#define GLYPH_GAP 2U
#define WORDMARK_GLYPHS 8U
#define BMP_HEADER_SIZE 54U

static const UINT8 wordmark[WORDMARK_GLYPHS][GLYPH_HEIGHT] = {
	{ 0x0f, 0x10, 0x10, 0x0e, 0x01, 0x01, 0x1e }, /* S */
	{ 0x1f, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04 }, /* T */
	{ 0x0e, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11 }, /* A */
	{ 0x1e, 0x11, 0x11, 0x1e, 0x14, 0x12, 0x11 }, /* R */
	{ 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1f }, /* L */
	{ 0x0e, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11 }, /* A */
	{ 0x1e, 0x11, 0x11, 0x1e, 0x11, 0x11, 0x1e }, /* B */
	{ 0x0f, 0x10, 0x10, 0x0e, 0x01, 0x01, 0x1e }, /* S */
};

static UINT32 channel(UINT8 value, UINT8 position, UINT8 size)
{
	UINT32 maximum = (1U << size) - 1U;

	return (((UINT32)value * maximum + 127U) / 255U) << position;
}

static UINT32 colour(const struct cdk2_boot_logo_surface *surface,
	UINT8 red, UINT8 green, UINT8 blue)
{
	return channel(red, surface->red_mask_pos, surface->red_mask_size) |
		channel(green, surface->green_mask_pos, surface->green_mask_size) |
		channel(blue, surface->blue_mask_pos, surface->blue_mask_size);
}

static BOOLEAN foreground_pixel(const struct cdk2_boot_logo_layout *layout,
	UINT32 x, UINT32 y)
{
	UINT32 glyph_stride = (GLYPH_WIDTH + GLYPH_GAP) * layout->scale;
	UINT32 glyph = x / glyph_stride;
	UINT32 column = (x % glyph_stride) / layout->scale;
	UINT32 row = y / layout->scale;

	return glyph < WORDMARK_GLYPHS && column < GLYPH_WIDTH &&
		row < GLYPH_HEIGHT &&
		(wordmark[glyph][row] & (1U << (GLYPH_WIDTH - 1U - column))) != 0U;
}

EFI_STATUS cdk2_boot_logo_layout_for_surface(const struct cdk2_boot_logo_surface *surface,
	struct cdk2_boot_logo_layout *layout)
{
	UINT32 scale;

	if (surface == NULL || layout == NULL || surface->pixels == NULL ||
	    surface->width == 0U || surface->height == 0U ||
	    surface->pixels_per_line < surface->width)
		return EFI_INVALID_PARAMETER;
	scale = surface->height / 64U;
	if (scale < 2U)
		scale = 2U;
	if (scale > 16U)
		scale = 16U;
	*layout = (struct cdk2_boot_logo_layout) {
		.width = (WORDMARK_GLYPHS * GLYPH_WIDTH +
			(WORDMARK_GLYPHS - 1U) * GLYPH_GAP) * scale,
		.height = GLYPH_HEIGHT * scale,
		.scale = scale,
	};
	if (layout->width > surface->width || layout->height > surface->height) {
		*layout = (struct cdk2_boot_logo_layout) { 0 };
		return EFI_SUCCESS;
	}
	layout->x = (surface->width - layout->width) / 2U;
	layout->y = (surface->height - layout->height) / 2U;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_boot_logo_draw(const struct cdk2_boot_logo_surface *surface,
	struct cdk2_boot_logo_layout *layout)
{
	UINT32 background, foreground;
	EFI_STATUS status;

	status = cdk2_boot_logo_layout_for_surface(surface, layout);
	if (EFI_ERROR(status) || layout->width == 0U)
		return status;
	background = colour(surface, 8U, 16U, 28U);
	foreground = colour(surface, 238U, 242U, 248U);
	for (UINT32 y = 0U; y < layout->height; y++)
		for (UINT32 x = 0U; x < layout->width; x++)
			surface->pixels[(UINTN)(layout->y + y) *
				surface->pixels_per_line + layout->x + x] =
				foreground_pixel(layout, x, y) ? foreground : background;
	return EFI_SUCCESS;
}

static void write_le16(UINT8 bytes[], UINT16 value)
{
	bytes[0] = (UINT8)value;
	bytes[1] = (UINT8)(value >> 8);
}

static void write_le32(UINT8 bytes[], UINT32 value)
{
	bytes[0] = (UINT8)value;
	bytes[1] = (UINT8)(value >> 8);
	bytes[2] = (UINT8)(value >> 16);
	bytes[3] = (UINT8)(value >> 24);
}

static EFI_STATUS initialize_bmp(UINT32 width, UINT32 height,
	void *buffer, UINTN capacity, UINTN *row_bytes, UINTN *total)
{
	UINT8 *bytes = buffer;
	UINTN image_bytes;

	if (buffer == NULL || row_bytes == NULL || total == NULL ||
	    width == 0U || height == 0U)
		return EFI_INVALID_PARAMETER;
	if (width > MAX_UINT32 / 3U)
		return EFI_BAD_BUFFER_SIZE;
	*row_bytes = ALIGN_VALUE((UINTN)width * 3U, 4U);
	if (height > (MAX_UINTN - BMP_HEADER_SIZE) / *row_bytes)
		return EFI_BAD_BUFFER_SIZE;
	image_bytes = *row_bytes * height;
	*total = BMP_HEADER_SIZE + image_bytes;
	if (*total > MAX_UINT32 || capacity < *total)
		return EFI_BUFFER_TOO_SMALL;
	memset(bytes, 0, *total);
	bytes[0] = 'B';
	bytes[1] = 'M';
	write_le32(bytes + 2U, (UINT32)*total);
	write_le32(bytes + 10U, BMP_HEADER_SIZE);
	write_le32(bytes + 14U, 40U);
	write_le32(bytes + 18U, width);
	write_le32(bytes + 22U, height);
	write_le16(bytes + 26U, 1U);
	write_le16(bytes + 28U, 24U);
	write_le32(bytes + 34U, (UINT32)image_bytes);
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_boot_logo_bmp(const struct cdk2_boot_logo_layout *layout,
	void *buffer, UINTN capacity, UINTN *size)
{
	UINT8 *bytes = buffer;
	UINTN row_bytes, total;
	EFI_STATUS status;

	if (layout == NULL || buffer == NULL || size == NULL ||
	    layout->width == 0U || layout->height == 0U)
		return EFI_INVALID_PARAMETER;
	status = initialize_bmp(layout->width, layout->height, buffer, capacity,
		&row_bytes, &total);
	if (EFI_ERROR(status))
		return status;
	for (UINT32 y = 0U; y < layout->height; y++)
		for (UINT32 x = 0U; x < layout->width; x++) {
			UINT8 *pixel = bytes + BMP_HEADER_SIZE +
				(UINTN)(layout->height - 1U - y) * row_bytes + x * 3U;

			if (foreground_pixel(layout, x, y)) {
				pixel[0] = 248U;
				pixel[1] = 242U;
				pixel[2] = 238U;
			} else {
				pixel[0] = 28U;
				pixel[1] = 16U;
				pixel[2] = 8U;
			}
		}
	*size = total;
	return EFI_SUCCESS;
}
