#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-only
"""HOST source-block sequencing tests, not USB delivery or native UI proof."""

import copy
import ast
import hashlib
import importlib.util
import json
import re
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
import uuid

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "util/qemu/bin"))
from setup_acceptance_contract import QUEUED_F2_DOWN, QUEUED_F2_UP, expected_actions, reference_status_geometry, validate_default_zero_config, validate_queued_input_snapshot
from qmp_cbmem_console import parse_table

spec = importlib.util.spec_from_file_location(
    "console_fixture", root / "tests/qmp_cbmem_console_test.py")
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)
controller = root / "util/qemu/bin/qmp-setup-acceptance.py"
source = controller.read_text()
anchor = "for _ in range(300):\n"
if source.count(anchor) != 1:
    raise RuntimeError("controller execution anchor is not unique")
block = compile(source[source.index(anchor):], str(controller), "exec")
helper_nodes = [node for node in ast.parse(source).body
                if isinstance(node, ast.FunctionDef) and
                node.name in ("wait_marker", "firmware_text", "save_console")]
if {node.name for node in helper_nodes} != {"wait_marker", "firmware_text", "save_console"} or \
        len(helper_nodes) != 3:
    raise RuntimeError("controller helper extraction is not unique")
helper_block = compile(ast.Module(body=helper_nodes, type_ignores=[]),
                       str(controller), "exec")
oracle_spec = importlib.util.spec_from_file_location(
    "zero_oracle", root / "util/qemu/bin/assert-default-zero-setup-run.py")
oracle = importlib.util.module_from_spec(oracle_spec)
oracle_spec.loader.exec_module(oracle)
config = b"""CONFIG_CDK2_BOOT_TIMEOUT=0
CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME=y
CONFIG_CDK2_NATIVE_SYSTEM_FMP=y
CONFIG_CDK2_LVGL_RENDERER=y
CONFIG_CDK2_LINEAR_SETUP_HOTKEY=y
"""


def make_run(run, mode, change_markers=None, version=0x001a0009, wait_field=0,
             result_scan=12):
    """Explicit HOST checked-table/pixel model, never native firmware output."""
    run.mkdir()
    (run / "cdk2-config.txt").write_bytes(config)
    manifest, producer, bmp, records = fixtures.logo_fixture(False)
    model = fixtures.ConsoleTest()
    model.setUp()
    markers = [
        ("SPLASH_EARLY | complete | SUCCESS", 0),
        ("INPUT_UI | begin | NOT_STARTED", 0x8000000000000013),
        ("INPUT_UI | complete | SUCCESS", 0),
        ("SetupHotkey | wait | SUCCESS", 0),
        ("SetupHotkey | result | " +
         ("SUCCESS" if mode in ("default-zero-hotkey", "default-zero-queued-hotkey") else "NOT_READY"),
         0 if mode in ("default-zero-hotkey", "default-zero-queued-hotkey") else 0x8000000000000006),
    ]
    if mode in ("default-zero-hotkey", "default-zero-queued-hotkey"):
        markers += [("SetupForm | begin | SUCCESS", 0),
                    ("SetupForm | return | ABORTED", 0x8000000000000015),
                    ("BootLogo | restore and BGRT | SUCCESS", 0)]
    markers.append(("OS_HANDOFF | begin | NOT_STARTED", 0x8000000000000013))
    if change_markers is not None:
        markers = change_markers(markers)
    body = "".join("CDK2 | " + text + " (0x" + format(status, "016x") +
                   ") | " + str(wait_field if text == "SetupHotkey | wait | SUCCESS"
                                 else result_scan if mode == "default-zero-queued-hotkey" and
                                 text == "SetupHotkey | result | SUCCESS"
                                 else 0) + " us\n"
                   for text, status in markers).encode()
    queued = None
    if mode == "default-zero-queued-hotkey":
        begin = b"CDK2 | INPUT_UI | begin | NOT_STARTED (0x8000000000000013) | 0 us\n"
        binding = b"CDK2 | module 0x03 | USB keyboard controllers | 0x0000000000000001\n"
        body = body.replace(begin, begin + binding)
        queued = body[:body.index(binding) + len(binding)]
        (run / "queued-input-console.log").write_bytes(queued)
    console = fixtures.struct.pack("<II", 4096, len(body)) + body.ljust(4096, b"\0")
    model.install(model.console_address, console)
    console_record = fixtures.record(0x31, fixtures.struct.pack(
        "<QII", model.console_address, len(console), fixtures.observer.CONSOLE_ID))
    model.install(0x300000, fixtures.table(
        [model.memory_record, console_record, fixtures.record(
            0x45, uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le +
            fixtures.struct.pack("<III", version, 0x001a0009, 8388608))] +
        [raw for tag, raw in records if tag != 1]))
    reader = fixtures.observer.ConsoleReader(model.qmp, run / "scratch")
    (run / "cbmem-live.log").write_bytes(reader.snapshot())
    (run / "cbmem-console.bin").write_bytes(reader.last_snapshot)
    (run / "cbmem-observer.json").write_text(json.dumps(reader.metadata))
    for index, raw in enumerate(reader.table_snapshots):
        (run / ("cbmem-table-" + str(index) + ".bin")).write_bytes(raw)
    (run / "coreboot-config.txt").write_bytes(producer)
    (run / "selecting-reference-manifest.json").write_text(json.dumps(manifest))
    initial = bytearray(b"\0\0\0" * (800 * 600))
    initial[30000:36000] = b"\xff\xff\xff" * 2000
    form = bytearray(b"\x10\x14\x1c" * (800 * 600))
    for first in (20000, 160000):
        form[first * 3:(first + 2000) * 3] = b"\xff\xff\xff" * 2000
    navigated = bytearray(form)
    navigated[90000:96000] = b"\0\xff\0" * 2000
    images = {"status-original": initial, "firmware-restored": initial}
    if mode in ("default-zero-hotkey", "default-zero-queued-hotkey"):
        images.update({"form-initial": form, "form-navigated": navigated})
    screens = {}
    for name, pixels in images.items():
        data = b"P6\n800 600\n255\n" + pixels
        filename = "setup-" + name + ".ppm"
        (run / filename).write_bytes(data)
        screens[name] = {"file": filename, "sha256": hashlib.sha256(data).hexdigest(),
                         "width": 800, "height": 600, "nonuniform": True}
    evidence = {
        "mode": mode, "profile": "quiet",
        "actions": expected_actions(mode, "quiet"), "screens": screens,
        "diagnostics": {
            "source": "qmp-physical-cbmem", "file": "cbmem-live.log",
            "sha256": hashlib.sha256(body).hexdigest(),
            "observer_file": "cbmem-observer.json",
            "observer_sha256": hashlib.sha256(
                (run / "cbmem-observer.json").read_bytes()).hexdigest()},
        "completion": {"os_marker": "CDK2_RUNTIME_OK",
                       "qmp_quit": {"return": {}}, "intentional": True},
    }
    if queued is not None:
        evidence["queued_input_snapshot"] = {
            "file": "queued-input-console.log",
            "sha256": hashlib.sha256(queued).hexdigest(),
        }
    (run / "qmp-setup-evidence.json").write_text(json.dumps(evidence))
    (run / "serial.log").write_text("CDK2_RUNTIME_OK\n")
    (run / "result.json").write_text(json.dumps({
        "failure": None, "observer_status": 0, "qemu_status": 0,
        "deadline_seconds": 180, "wall_seconds": 1.0}))
    inputs = {str(run / "cdk2-config.txt"): hashlib.sha256(config).hexdigest()}
    for suffix in ("before", "after"):
        (run / ("inputs-" + suffix + ".json")).write_text(json.dumps(inputs))
    return evidence


class ControllerTest(unittest.TestCase):
    def replay(self, mode, early=False, extra_form=False, reject_key=False,
               queued_snapshot=None):
        with tempfile.TemporaryDirectory(prefix="zero-controller-host.") as name:
            run = Path(name)
            manifest, producer, bmp, records = fixtures.logo_fixture(False)
            evidence = {"actions": [], "screens": {}}
            body = b"HOST modeled console"
            (run / "cbmem-live.log").write_bytes(body)
            (run / "cbmem-observer.json").write_text("{}")

            class Reader:
                metadata = {}
                table_snapshots = [fixtures.table(
                    [record for tag, record in records])]
                physical_limit = 1 << 32

                def __init__(self, *args):
                    pass

            def wait(marker):
                evidence["actions"].append({
                    "wait_serial" if marker.startswith("CDK2_")
                    else "wait_cbmem": marker})

            def key(label, keysym, down):
                if reject_key:
                    raise RuntimeError("modeled input transport failure")
                evidence["actions"].append({
                    "vnc_key": label, "state": "down" if down else "up"})

            def press(label, keysym):
                key(label, keysym, True)
                key(label, keysym, False)

            def qmp(command):
                if isinstance(command, list):
                    if reject_key:
                        raise RuntimeError("modeled input transport failure")
                    return [{"return": {}, "id": item["id"]} for item in command]
                return {"return": {}}

            def firmware_text():
                if early:
                    return "INPUT_UI | begin |"
                if extra_form:
                    return "SetupForm | begin |"
                if mode == "default-zero-queued-hotkey" and any(
                        item.get("wait_cbmem", "").startswith("module 0x03 | USB keyboard")
                        for item in evidence["actions"]):
                    return queued_snapshot if queued_snapshot is not None else (
                        "CDK2 | INPUT_UI | begin | NOT_STARTED (0x8000000000000013) | 0 us\n"
                        "CDK2 | module 0x03 | USB keyboard controllers | 0x0000000000000001\n")
                return ""

            namespace = {
                "sock_path": run, "run": run, "timeout": 1,
                "mode": mode, "profile": "quiet", "evidence": evidence,
                "expected": expected_actions(mode, "quiet"),
                "connect_vnc": lambda: evidence["actions"].append(
                    {"vnc_connected": True}),
                "ConsoleReader": Reader,
                "qmp": qmp, "QUEUED_F2_DOWN": QUEUED_F2_DOWN,
                "QUEUED_F2_UP": QUEUED_F2_UP,
                "wait_marker": wait, "save_console": lambda: body.decode(),
                "firmware_text": firmware_text,
                "validate_queued_input_snapshot": validate_queued_input_snapshot,
                "parse_table": parse_table,
                "reference_status_geometry": reference_status_geometry,
                "splash_bmp_extent": lambda *args: None,
                "manifest": manifest, "producer_config": producer,
                "bmp_input": bmp,
                "capture": lambda label: evidence["actions"].append(
                    {"capture": label}),
                "send_vnc_key": key, "send_vnc_press": press,
                "hashlib": hashlib, "json": json,
            }
            exec(block, namespace)
            return copy.deepcopy(evidence)

    def test_held_f2_before_input_and_release_after_real_marker(self):
        evidence = self.replay("default-zero-hotkey")
        actions = evidence["actions"]
        self.assertEqual(actions, expected_actions("default-zero-hotkey", "quiet"))
        self.assertLess(actions.index({"vnc_key": "f2", "state": "down"}),
                        actions.index({"wait_cbmem": "INPUT_UI | begin | NOT_STARTED"}))
        self.assertLess(actions.index({"wait_cbmem": "SetupForm | begin | SUCCESS"}),
                        actions.index({"vnc_key": "f2", "state": "up"}))
        self.assertFalse(any("delay_ms" in item for item in actions))
        self.assertEqual(sum("stop" in item for item in actions), 1)

    def test_no_key_has_zero_events_and_runtime_completion(self):
        evidence = self.replay("default-zero-no-key")
        self.assertFalse(any("vnc_key" in item for item in evidence["actions"]))
        self.assertEqual(evidence["completion"]["os_marker"], "CDK2_RUNTIME_OK")

    def test_queued_f2_after_binding_pause_before_setup(self):
        evidence = self.replay("default-zero-queued-hotkey")
        actions = evidence["actions"]
        self.assertEqual(actions, expected_actions("default-zero-queued-hotkey", "quiet"))
        self.assertEqual(sum("stop" in item for item in actions), 2)
        self.assertLess(actions.index({"queued_input_snapshot": True}),
                        next(index for index, action in enumerate(actions)
                             if action.get("qmp_pipeline") == QUEUED_F2_DOWN))
        self.assertFalse(any(action.get("vnc_key") == "f2" for action in actions))
        self.assertFalse(any("delay_ms" in item for item in actions))

    def test_queued_snapshot_missing_duplicate_count_and_late_refuse_before_input(self):
        valid = ("CDK2 | INPUT_UI | begin | NOT_STARTED (0x8000000000000013) | 0 us\n"
                 "CDK2 | module 0x03 | USB keyboard controllers | 0x0000000000000001\n")
        for changed in ("", valid.splitlines(keepends=True)[1],
                        valid + valid.splitlines(keepends=True)[1],
                        valid.replace("0000000000000001", "0000000000000002"),
                        valid.replace("NOT_STARTED", "SUCCESS"),
                        valid + "CDK2 | BOOT_POLICY | begin | NOT_STARTED\n",
                        valid + "CDK2 | SetupHotkey | wait | SUCCESS\n",
                        valid + "CDK2 | SetupForm | begin | SUCCESS\n"):
            with self.subTest(snapshot=changed), self.assertRaises(ValueError):
                # If key transport is reached, this raises RuntimeError instead.
                self.replay("default-zero-queued-hotkey", queued_snapshot=changed,
                            reject_key=True)

    def test_queued_transport_failure_is_not_delivery(self):
        with self.assertRaisesRegex(RuntimeError, "input transport failure"):
            self.replay("default-zero-queued-hotkey", reject_key=True)

    def test_late_input_barrier_refuses_before_key_submission(self):
        with self.assertRaisesRegex(SystemExit, "pause arrived after INPUT_UI"):
            self.replay("default-zero-hotkey", early=True)

    def test_unexpected_setup_in_no_key_refuses(self):
        with self.assertRaisesRegex(SystemExit, "no-key run entered setup"):
            self.replay("default-zero-no-key", extra_form=True)

    def test_transport_failure_is_not_delivery(self):
        with self.assertRaisesRegex(RuntimeError, "input transport failure"):
            self.replay("default-zero-hotkey", reject_key=True)

    def test_existing_delayed_and_fwui_transcripts_retained(self):
        for profile in ("quiet", "debug"):
            old = expected_actions("hotkey", profile)
            self.assertIn({"delay_ms": 250}, old)
            self.assertNotIn({"delay_ms": 250},
                             expected_actions("boot-to-fw-ui", profile))

    def test_default_zero_config_rejects_nonzero_test_and_duplicates(self):
        validate_default_zero_config(config)
        for changed in (config.replace(b"TIMEOUT=0", b"TIMEOUT=2"),
                        config + b"CONFIG_CDK2_QEMU_ACCEPTANCE_PROFILE=y\n",
                        config + b"CONFIG_CDK2_BOOT_TIMEOUT=0\n"):
            with self.assertRaises(ValueError):
                validate_default_zero_config(changed)

    def test_default_zero_modes_require_quiet_profile(self):
        for mode in ("default-zero-hotkey", "default-zero-no-key", "default-zero-queued-hotkey"):
            with self.assertRaisesRegex(ValueError, "normal quiet"):
                expected_actions(mode, "debug")


class SavedOracleTest(unittest.TestCase):
    def test_all_modeled_positives(self):
        with tempfile.TemporaryDirectory() as directory:
            for mode in ("default-zero-hotkey", "default-zero-no-key", "default-zero-queued-hotkey"):
                run = Path(directory) / mode
                make_run(run, mode)
                oracle.check(run, mode)

    def test_queued_saved_snapshot_binding_and_f2_metadata_required(self):
        with tempfile.TemporaryDirectory() as directory:
            for index, alteration in enumerate(("missing", "hash", "not-prefix", "late")):
                run = Path(directory) / str(index)
                evidence = make_run(run, "default-zero-queued-hotkey")
                path = run / "queued-input-console.log"
                if alteration == "missing":
                    del evidence["queued_input_snapshot"]
                elif alteration == "hash":
                    evidence["queued_input_snapshot"]["sha256"] = "0" * 64
                else:
                    data = path.read_bytes()
                    data = (b"unpublished prefix\n" + data if alteration == "not-prefix"
                            else data + b"CDK2 | SetupHotkey | wait | SUCCESS\n")
                    path.write_bytes(data)
                    evidence["queued_input_snapshot"]["sha256"] = hashlib.sha256(data).hexdigest()
                (run / "qmp-setup-evidence.json").write_text(json.dumps(evidence))
                with self.subTest(alteration=alteration), self.assertRaises(ValueError):
                    oracle.check(run, "default-zero-queued-hotkey")
            for result_scan in (0, 11, 13):
                run = Path(directory) / ("scan-" + str(result_scan))
                make_run(run, "default-zero-queued-hotkey", result_scan=result_scan)
                with self.subTest(scan=result_scan), self.assertRaisesRegex(ValueError, "actual F2"):
                    oracle.check(run, "default-zero-queued-hotkey")

    def test_input_transcript_missing_delayed_and_zero_key_events_refuse(self):
        with tempfile.TemporaryDirectory() as directory:
            for mode in ("default-zero-hotkey", "default-zero-no-key"):
                run = Path(directory) / mode
                evidence = make_run(run, mode)
                if mode == "default-zero-hotkey":
                    evidence["actions"].insert(5, {"delay_ms": 250})
                else:
                    evidence["actions"].insert(5, {"vnc_key": "f2", "state": "down"})
                (run / "qmp-setup-evidence.json").write_text(json.dumps(evidence))
                with self.assertRaisesRegex(ValueError, "action transcript"):
                    oracle.check(run, mode)

    def test_navigation_and_restoration_are_pixels_not_labels(self):
        with tempfile.TemporaryDirectory() as directory:
            for name in ("form-navigated", "firmware-restored"):
                run = Path(directory) / name
                evidence = make_run(run, "default-zero-hotkey")
                if name == "form-navigated":
                    data = (run / "setup-form-initial.ppm").read_bytes()
                else:
                    data = bytearray((run / "setup-firmware-restored.ppm").read_bytes())
                    data[-1] ^= 1
                (run / ("setup-" + name + ".ppm")).write_bytes(data)
                evidence["screens"][name]["sha256"] = hashlib.sha256(data).hexdigest()
                (run / "qmp-setup-evidence.json").write_text(json.dumps(evidence))
                with self.assertRaisesRegex(ValueError, "pixel change|restoration not exact"):
                    oracle.check(run, "default-zero-hotkey")

    def test_table_config_console_and_completion_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            for target in ("config", "table", "console", "runtime"):
                run = Path(directory) / target
                make_run(run, "default-zero-no-key")
                if target == "config":
                    (run / "cdk2-config.txt").write_bytes(config.replace(b"TIMEOUT=0", b"TIMEOUT=2"))
                elif target == "table":
                    data = bytearray((run / "cbmem-table-1.bin").read_bytes())
                    data[-1] ^= 1
                    (run / "cbmem-table-1.bin").write_bytes(data)
                elif target == "console":
                    (run / "cbmem-live.log").write_bytes(b"forged marker")
                else:
                    (run / "serial.log").write_text("CDK2_RUNTIME_OK\nCDK2_RUNTIME_OK\n")
                with self.assertRaises(ValueError):
                    oracle.check(run, "default-zero-no-key")

    def test_real_checked_console_marker_status_cardinality_and_order(self):
        changes = [
            lambda rows: [(text.replace("result | NOT_READY",
                                      "result | NOT_READY_BOGUS"), status)
                          for text, status in rows],
            lambda rows: rows + [rows[4]],
            lambda rows: [rows[1], rows[0]] + rows[2:],
            lambda rows: rows + [("SetupForm | begin | SUCCESS", 0)],
            lambda rows: [rows[0], ("junk " + rows[1][0], rows[1][1]),
                          rows[2], rows[1]] + rows[3:],
        ]
        with tempfile.TemporaryDirectory() as directory:
            for index, changed in enumerate(changes):
                run = Path(directory) / str(index)
                make_run(run, "default-zero-no-key", changed)
                with self.assertRaisesRegex(ValueError, "marker|entered setup"):
                    oracle.check(run, "default-zero-no-key")

    def test_zero_wait_field_is_configured_seconds_not_elapsed_latency(self):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory) / "wrong-wait"
            make_run(run, "default-zero-no-key", wait_field=2)
            with self.assertRaisesRegex(ValueError, "wait metadata is not zero"):
                oracle.check(run, "default-zero-no-key")

    def test_real_checked_fw_identity_not_learned_from_screens(self):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory) / "wrong-version"
            make_run(run, "default-zero-no-key", version=0x001a000a)
            with self.assertRaisesRegex(ValueError, "FW_INFO"):
                oracle.check(run, "default-zero-no-key")

    def test_recorded_wall_is_present_finite_positive_and_within_budget(self):
        with tempfile.TemporaryDirectory() as directory:
            for index, wall in enumerate((None, float("nan"), float("inf"),
                                          -1, 0, 180.01, True, "12")):
                run = Path(directory) / str(index)
                make_run(run, "default-zero-no-key")
                result = json.loads((run / "result.json").read_bytes())
                if wall is None:
                    del result["wall_seconds"]
                else:
                    result["wall_seconds"] = wall
                (run / "result.json").write_text(json.dumps(result))
                with self.assertRaisesRegex(ValueError, "did not complete"):
                    oracle.check(run, "default-zero-no-key")

    def test_runtime_is_an_exact_full_line_not_a_substring(self):
        with tempfile.TemporaryDirectory() as directory:
            for index, line in enumerate(("prefixCDK2_RUNTIME_OK\n",
                                           "CDK2_RUNTIME_OK_BOGUS\n")):
                run = Path(directory) / str(index)
                make_run(run, "default-zero-no-key")
                (run / "serial.log").write_text(line)
                with self.assertRaisesRegex(ValueError, "runtime completion"):
                    oracle.check(run, "default-zero-no-key")
            run = Path(directory) / "crlf"
            make_run(run, "default-zero-no-key")
            (run / "serial.log").write_bytes(b"CDK2_RUNTIME_OK\r\n")
            oracle.check(run, "default-zero-no-key")


class MotionTest(unittest.TestCase):
    def execute_wait(self, mode="default-zero-hotkey", persistent=False,
                     after_motion=None):
        with tempfile.TemporaryDirectory(prefix="zero-motion-host.") as name:
            run = Path(name)
            model = fixtures.ConsoleTest()
            model.setUp()
            reader = fixtures.observer.ConsoleReader(model.qmp, run / "scratch")
            sleeps = []

            class Clock:
                current = 0.0

                def monotonic(self):
                    return self.current

                def sleep(self, seconds):
                    self.current += seconds
                    sleeps.append(seconds)
                    # Motion must not publish a fabricated replacement.
                    self_test.assertEqual(reader.metadata, accepted)
                    self_test.assertEqual((run / "cbmem-live.log").read_bytes(), prior)
                    if after_motion is not None:
                        after_motion(model, reader)
                    elif not persistent:
                        body = model.body + b"HOST appended marker\n"
                        self_test.assertLessEqual(len(body), 56)
                        model.install(model.console_address, fixtures.struct.pack(
                            "<II", 56, len(body)) + body.ljust(56, b"\0"))

            self_test = self
            clock = Clock()
            namespace = {
                "mode": mode, "profile": "quiet", "run": run,
                "serial_path": run / "serial.log", "timeout": 0.01,
                "log_offsets": {"cbmem": 0, "serial": 0},
                "log_windows": {"cbmem": "", "serial": ""},
                "evidence": {"actions": []}, "cbmem_reader": reader,
                "time": clock, "hashlib": hashlib, "json": json,
                "re": re,
                "TableNotReady": fixtures.observer.TableNotReady,
                "ConsoleSnapshotMotion": fixtures.observer.ConsoleSnapshotMotion,
            }
            exec(helper_block, namespace)
            namespace["save_console"]()
            prior = (run / "cbmem-live.log").read_bytes()
            accepted = copy.deepcopy(reader.metadata)
            original_read = reader.read
            header_reads = 0

            def moving(address, size):
                nonlocal header_reads
                data = original_read(address, size)
                if address == model.console_address and size == 8:
                    header_reads += 1
                    if persistent or header_reads <= 8:
                        return fixtures.struct.pack("<II", 56, len(model.body) + 1)
                return data

            reader.read = moving
            namespace["wait_marker"]("HOST appended marker")
            return namespace["evidence"], sleeps

    def test_transient_motion_retries_then_accepts_actual_reader_snapshot(self):
        evidence, sleeps = self.execute_wait()
        self.assertEqual(sleeps, [0.005])
        self.assertEqual(evidence["actions"], [{"wait_cbmem": "HOST appended marker"}])

    def test_persistent_motion_expires_original_wait(self):
        with self.assertRaisesRegex(SystemExit, "marker did not appear"):
            self.execute_wait(persistent=True)

    def test_old_mode_motion_remains_fatal(self):
        with self.assertRaises(fixtures.observer.ConsoleSnapshotMotion):
            self.execute_wait(mode="hotkey")

    def test_semantic_corruption_and_physical_read_failure_not_retried(self):
        def corrupt_table(model, reader):
            model.memory[0x300000 + 12] ^= 1

        def fail_read(model, reader):
            reader.qmp = lambda command: {"error": {"desc": "HOST physical read failure"}}

        def rewind(model, reader):
            model.install(model.console_address,
                          fixtures.struct.pack("<II", 56, 1) + b"x".ljust(56, b"\0"))

        with self.assertRaisesRegex(ValueError, "checksum"):
            self.execute_wait(after_motion=corrupt_table)
        with self.assertRaises(fixtures.observer.PhysicalReadError):
            self.execute_wait(after_motion=fail_read)
        with self.assertRaisesRegex(SystemExit, "rewound or changed"):
            self.execute_wait(after_motion=rewind)


class QmpPipelineTest(unittest.TestCase):
    def execute(self, replies, commands=QUEUED_F2_DOWN, clock_values=None):
        nodes = [node for node in ast.parse(source).body
                 if isinstance(node, ast.FunctionDef) and node.name == "qmp"]
        self.assertEqual(len(nodes), 1)
        writes = []
        timeouts = []
        rows = [{"QMP": {}}, {"return": {}, "id": "capabilities"}] + replies
        test = self
        clock = iter(clock_values) if clock_values is not None else None

        class Socket:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                pass

            def settimeout(self, seconds):
                test.assertGreater(seconds, 0)
                test.assertLessEqual(seconds, 1)
                timeouts.append(seconds)

            def connect(self, path):
                test.assertEqual(path, "HOST socket")

            def makefile(self, *args, **kwargs):
                return self

            def sendall(self, data):
                writes.append(data)

            def readline(self):
                if len(rows) <= len(replies):
                    # All commands must already have entered one connection
                    # before the first command response is consumed.
                    test.assertEqual([json.loads(line) for line in writes[1].splitlines()],
                                     commands)
                return json.dumps(rows.pop(0)).encode() + b"\n" if rows else b""

        namespace = {"socket": SimpleNamespace(AF_UNIX=1, SOCK_STREAM=2,
                                                socket=lambda *args: Socket()),
                     "sock_path": "HOST socket", "timeout": 1,
                     "time": SimpleNamespace(monotonic=lambda: next(clock) if clock else 0),
                     "json": json}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(controller), "exec"),
             namespace)
        result = namespace["qmp"](commands)
        self.assertTrue(timeouts)
        return result

    def test_one_connection_pipeline_matches_all_ids_despite_events_and_reply_order(self):
        replies = [{"event": "RESUME"}, {"return": {}, "id": "queued-f2-down"},
                   {"return": {}, "id": "queued-cont"}]
        self.assertEqual(self.execute(replies),
                         [{"return": {}, "id": item["id"]} for item in QUEUED_F2_DOWN])
        self.assertEqual(self.execute([{"return": {}, "id": "queued-f2-up"}],
                                     QUEUED_F2_UP),
                         [{"return": {}, "id": "queued-f2-up"}])

    def test_errors_duplicates_unknown_missing_and_malformed_replies_refuse(self):
        for replies in (
                [{"error": {"desc": "VM not running"}, "id": "queued-f2-down"}],
                [{"return": {}, "id": "queued-cont"}] * 2,
                [{"return": {}, "id": "other"}],
                [{"return": {}, "id": "queued-cont"}],
                [{"return": {}}], [{"return": {}, "id": []}],
                [{"return": {}, "id": "queued-cont", "event": "RESUME"}],
                [{"return": {"unexpected": True}, "id": "queued-cont"}]):
            with self.subTest(replies=replies), self.assertRaises(ValueError):
                self.execute(replies)

    def test_duplicate_request_identity_refuses_before_socket(self):
        with self.assertRaisesRegex(ValueError, "request IDs"):
            self.execute([], [QUEUED_F2_DOWN[0], QUEUED_F2_DOWN[0]])

    def test_second_reply_cannot_extend_original_deadline(self):
        with self.assertRaisesRegex(TimeoutError, "deadline expired"):
            self.execute([{"return": {}, "id": "queued-cont"},
                          {"return": {}, "id": "queued-f2-down"}],
                         clock_values=[0, 0, 0, 0, 0, 0, 0, 2])

    def test_connect_greeting_and_capability_time_cannot_extend_next_operation(self):
        for clock_values in ([0, 0, 2], [0, 0, 0, 2], [0, 0, 0, 0, 0, 2]):
            with self.subTest(clock_values=clock_values), self.assertRaisesRegex(
                    TimeoutError, "deadline expired"):
                self.execute([{"return": {}, "id": "queued-cont"},
                              {"return": {}, "id": "queued-f2-down"}],
                             clock_values=clock_values)


class HotkeyRefusalTest(unittest.TestCase):
    def execute(self, body, marker="SetupHotkey | result | SUCCESS"):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory)
            path = run / "cbmem-live.log"
            path.write_text(body)
            actions = []
            clock = SimpleNamespace(current=0)

            def sleep(seconds):
                clock.current += seconds

            namespace = {"run": run, "serial_path": run / "serial.log",
                         "profile": "quiet", "mode": "default-zero-queued-hotkey",
                         "timeout": 0.01, "time": SimpleNamespace(
                             monotonic=lambda: clock.current, sleep=sleep),
                         "log_offsets": {"cbmem": 0}, "log_windows": {"cbmem": ""},
                         "evidence": {"actions": actions}, "re": re,
                         "ConsoleSnapshotMotion": fixtures.observer.ConsoleSnapshotMotion}
            exec(helper_block, namespace)
            namespace["firmware_text"] = lambda: body
            try:
                namespace["wait_marker"](marker)
            except SystemExit:
                self.assertEqual(actions, [])
                raise
            return actions, clock.current

    def test_complete_not_ready_and_malformed_typed_results_fail_without_waiting(self):
        row = "CDK2 | SetupHotkey | result | NOT_READY (0x8000000000000006) | 0 us\n"
        for body in (row, row.replace("0006", "0000"), row + row,
                     row.replace("NOT_READY", "NOT_READY_BOGUS")):
            with self.subTest(body=body), self.assertRaisesRegex(SystemExit, "typed hotkey"):
                self.execute(body)

    def test_substring_and_partial_lines_do_not_prove_success_or_refusal(self):
        row = "CDK2 | SetupHotkey | result | NOT_READY (0x8000000000000006) | 0 us"
        for body in (row, "prefix" + row + "\n"):
            with self.subTest(body=body), self.assertRaisesRegex(SystemExit, "did not appear"):
                self.execute(body)
        success = "CDK2 | SetupHotkey | result | SUCCESS (0x0000000000000000) | 12 us"
        for body in (success, "prefix" + success + "\n"):
            with self.subTest(body=body), self.assertRaisesRegex(SystemExit, "did not appear"):
                self.execute(body)

    def test_exact_consumed_f2_result_succeeds(self):
        actions, elapsed = self.execute(
            "CDK2 | SetupHotkey | result | SUCCESS (0x0000000000000000) | 12 us\r\n")
        self.assertEqual(elapsed, 0)
        self.assertEqual(actions, [{"wait_cbmem": "SetupHotkey | result | SUCCESS"}])


if __name__ == "__main__":
    unittest.main()
