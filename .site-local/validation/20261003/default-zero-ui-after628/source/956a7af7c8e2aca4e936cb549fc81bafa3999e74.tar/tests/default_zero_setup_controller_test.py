#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-only
"""HOST source-block sequencing tests, not USB delivery or native UI proof."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
import uuid

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "util/qemu/bin"))
from setup_acceptance_contract import expected_actions, reference_status_geometry, validate_default_zero_config
from qmp_cbmem_console import parse_table

spec = importlib.util.spec_from_file_location(
    "console_fixture", root / "tests/qmp_cbmem_console_test.py")
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)
controller = root / "util/qemu/bin/qmp-setup-acceptance.py"
source = controller.read_text()
anchor = "for _ in range(300):\n"
if source.count(anchor) != 1:
    raise RuntimeError("controller execution anchor is not unique")
block = compile(source[source.index(anchor):], str(controller), "exec")
oracle_spec = importlib.util.spec_from_file_location(
    "zero_oracle", root / "util/qemu/bin/assert-default-zero-setup-run.py")
oracle = importlib.util.module_from_spec(oracle_spec)
oracle_spec.loader.exec_module(oracle)
config = b"""CONFIG_CDK2_BOOT_TIMEOUT=0
CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME=y
CONFIG_CDK2_NATIVE_SYSTEM_FMP=y
CONFIG_CDK2_LVGL_RENDERER=y
CONFIG_CDK2_LINEAR_SETUP_HOTKEY=y
"""


def make_run(run, mode, change_markers=None, version=0x001a0009, wait_field=0):
    """Explicit HOST checked-table/pixel model, never native firmware output."""
    run.mkdir()
    (run / "cdk2-config.txt").write_bytes(config)
    manifest, producer, bmp, records = fixtures.logo_fixture(False)
    model = fixtures.ConsoleTest()
    model.setUp()
    markers = [
        ("SPLASH_EARLY | complete | SUCCESS", 0),
        ("INPUT_UI | begin | NOT_STARTED", 0x8000000000000013),
        ("INPUT_UI | complete | SUCCESS", 0),
        ("SetupHotkey | wait | SUCCESS", 0),
        ("SetupHotkey | result | " +
         ("SUCCESS" if mode == "default-zero-hotkey" else "NOT_READY"),
         0 if mode == "default-zero-hotkey" else 0x8000000000000006),
    ]
    if mode == "default-zero-hotkey":
        markers += [("SetupForm | begin | SUCCESS", 0),
                    ("SetupForm | return | ABORTED", 0x8000000000000015),
                    ("BootLogo | restore and BGRT | SUCCESS", 0)]
    markers.append(("OS_HANDOFF | begin | NOT_STARTED", 0x8000000000000013))
    if change_markers is not None:
        markers = change_markers(markers)
    body = "".join("CDK2 | " + text + " (0x" + format(status, "016x") +
                   ") | " + str(wait_field if text == "SetupHotkey | wait | SUCCESS"
                                 else 0) + " us\n"
                   for text, status in markers).encode()
    console = fixtures.struct.pack("<II", 4096, len(body)) + body.ljust(4096, b"\0")
    model.install(model.console_address, console)
    console_record = fixtures.record(0x31, fixtures.struct.pack(
        "<QII", model.console_address, len(console), fixtures.observer.CONSOLE_ID))
    model.install(0x300000, fixtures.table(
        [model.memory_record, console_record, fixtures.record(
            0x45, uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le +
            fixtures.struct.pack("<III", version, 0x001a0009, 8388608))] +
        [raw for tag, raw in records if tag != 1]))
    reader = fixtures.observer.ConsoleReader(model.qmp, run / "scratch")
    (run / "cbmem-live.log").write_bytes(reader.snapshot())
    (run / "cbmem-console.bin").write_bytes(reader.last_snapshot)
    (run / "cbmem-observer.json").write_text(json.dumps(reader.metadata))
    for index, raw in enumerate(reader.table_snapshots):
        (run / ("cbmem-table-" + str(index) + ".bin")).write_bytes(raw)
    (run / "coreboot-config.txt").write_bytes(producer)
    (run / "selecting-reference-manifest.json").write_text(json.dumps(manifest))
    initial = bytearray(b"\0\0\0" * (800 * 600))
    initial[30000:36000] = b"\xff\xff\xff" * 2000
    form = bytearray(b"\x10\x14\x1c" * (800 * 600))
    for first in (20000, 160000):
        form[first * 3:(first + 2000) * 3] = b"\xff\xff\xff" * 2000
    navigated = bytearray(form)
    navigated[90000:96000] = b"\0\xff\0" * 2000
    images = {"status-original": initial, "firmware-restored": initial}
    if mode == "default-zero-hotkey":
        images.update({"form-initial": form, "form-navigated": navigated})
    screens = {}
    for name, pixels in images.items():
        data = b"P6\n800 600\n255\n" + pixels
        filename = "setup-" + name + ".ppm"
        (run / filename).write_bytes(data)
        screens[name] = {"file": filename, "sha256": hashlib.sha256(data).hexdigest(),
                         "width": 800, "height": 600, "nonuniform": True}
    evidence = {
        "mode": mode, "profile": "quiet",
        "actions": expected_actions(mode, "quiet"), "screens": screens,
        "diagnostics": {
            "source": "qmp-physical-cbmem", "file": "cbmem-live.log",
            "sha256": hashlib.sha256(body).hexdigest(),
            "observer_file": "cbmem-observer.json",
            "observer_sha256": hashlib.sha256(
                (run / "cbmem-observer.json").read_bytes()).hexdigest()},
        "completion": {"os_marker": "CDK2_RUNTIME_OK",
                       "qmp_quit": {"return": {}}, "intentional": True},
    }
    (run / "qmp-setup-evidence.json").write_text(json.dumps(evidence))
    (run / "serial.log").write_text("CDK2_RUNTIME_OK\n")
    (run / "result.json").write_text(json.dumps({
        "failure": None, "observer_status": 0, "qemu_status": 0,
        "deadline_seconds": 180, "wall_seconds": 1.0}))
    inputs = {str(run / "cdk2-config.txt"): hashlib.sha256(config).hexdigest()}
    for suffix in ("before", "after"):
        (run / ("inputs-" + suffix + ".json")).write_text(json.dumps(inputs))
    return evidence


class ControllerTest(unittest.TestCase):
    def replay(self, mode, early=False, extra_form=False, reject_key=False):
        with tempfile.TemporaryDirectory(prefix="zero-controller-host.") as name:
            run = Path(name)
            manifest, producer, bmp, records = fixtures.logo_fixture(False)
            evidence = {"actions": [], "screens": {}}
            body = b"HOST modeled console"
            (run / "cbmem-live.log").write_bytes(body)
            (run / "cbmem-observer.json").write_text("{}")

            class Reader:
                metadata = {}
                table_snapshots = [fixtures.table(
                    [record for tag, record in records])]
                physical_limit = 1 << 32

                def __init__(self, *args):
                    pass

            def wait(marker):
                evidence["actions"].append({
                    "wait_serial" if marker.startswith("CDK2_")
                    else "wait_cbmem": marker})

            def key(label, keysym, down):
                if reject_key:
                    raise RuntimeError("modeled input transport failure")
                evidence["actions"].append({
                    "vnc_key": label, "state": "down" if down else "up"})

            def press(label, keysym):
                key(label, keysym, True)
                key(label, keysym, False)

            namespace = {
                "sock_path": run, "run": run, "timeout": 1,
                "mode": mode, "profile": "quiet", "evidence": evidence,
                "expected": expected_actions(mode, "quiet"),
                "connect_vnc": lambda: evidence["actions"].append(
                    {"vnc_connected": True}),
                "ConsoleReader": Reader,
                "qmp": lambda command: {"return": {}},
                "wait_marker": wait, "save_console": lambda: body.decode(),
                "firmware_text": lambda:
                    "INPUT_UI | begin |" if early else
                    "SetupForm | begin |" if extra_form else "",
                "parse_table": parse_table,
                "reference_status_geometry": reference_status_geometry,
                "splash_bmp_extent": lambda *args: None,
                "manifest": manifest, "producer_config": producer,
                "bmp_input": bmp,
                "capture": lambda label: evidence["actions"].append(
                    {"capture": label}),
                "send_vnc_key": key, "send_vnc_press": press,
                "hashlib": hashlib, "json": json,
            }
            exec(block, namespace)
            return copy.deepcopy(evidence)

    def test_held_f2_before_input_and_release_after_real_marker(self):
        evidence = self.replay("default-zero-hotkey")
        actions = evidence["actions"]
        self.assertEqual(actions, expected_actions("default-zero-hotkey", "quiet"))
        self.assertLess(actions.index({"vnc_key": "f2", "state": "down"}),
                        actions.index({"wait_cbmem": "INPUT_UI | begin | NOT_STARTED"}))
        self.assertLess(actions.index({"wait_cbmem": "SetupForm | begin | SUCCESS"}),
                        actions.index({"vnc_key": "f2", "state": "up"}))
        self.assertFalse(any("delay_ms" in item for item in actions))
        self.assertEqual(sum("stop" in item for item in actions), 1)

    def test_no_key_has_zero_events_and_runtime_completion(self):
        evidence = self.replay("default-zero-no-key")
        self.assertFalse(any("vnc_key" in item for item in evidence["actions"]))
        self.assertEqual(evidence["completion"]["os_marker"], "CDK2_RUNTIME_OK")

    def test_late_input_barrier_refuses_before_key_submission(self):
        with self.assertRaisesRegex(SystemExit, "pause arrived after INPUT_UI"):
            self.replay("default-zero-hotkey", early=True)

    def test_unexpected_setup_in_no_key_refuses(self):
        with self.assertRaisesRegex(SystemExit, "no-key run entered setup"):
            self.replay("default-zero-no-key", extra_form=True)

    def test_transport_failure_is_not_delivery(self):
        with self.assertRaisesRegex(RuntimeError, "input transport failure"):
            self.replay("default-zero-hotkey", reject_key=True)

    def test_existing_delayed_and_fwui_transcripts_retained(self):
        for profile in ("quiet", "debug"):
            old = expected_actions("hotkey", profile)
            self.assertIn({"delay_ms": 250}, old)
            self.assertNotIn({"delay_ms": 250},
                             expected_actions("boot-to-fw-ui", profile))

    def test_default_zero_config_rejects_nonzero_test_and_duplicates(self):
        validate_default_zero_config(config)
        for changed in (config.replace(b"TIMEOUT=0", b"TIMEOUT=2"),
                        config + b"CONFIG_CDK2_QEMU_ACCEPTANCE_PROFILE=y\n",
                        config + b"CONFIG_CDK2_BOOT_TIMEOUT=0\n"):
            with self.assertRaises(ValueError):
                validate_default_zero_config(changed)

    def test_default_zero_modes_require_quiet_profile(self):
        for mode in ("default-zero-hotkey", "default-zero-no-key"):
            with self.assertRaisesRegex(ValueError, "normal quiet"):
                expected_actions(mode, "debug")


class SavedOracleTest(unittest.TestCase):
    def test_both_modeled_positives(self):
        with tempfile.TemporaryDirectory() as directory:
            for mode in ("default-zero-hotkey", "default-zero-no-key"):
                run = Path(directory) / mode
                make_run(run, mode)
                oracle.check(run, mode)

    def test_input_transcript_missing_delayed_and_zero_key_events_refuse(self):
        with tempfile.TemporaryDirectory() as directory:
            for mode in ("default-zero-hotkey", "default-zero-no-key"):
                run = Path(directory) / mode
                evidence = make_run(run, mode)
                if mode == "default-zero-hotkey":
                    evidence["actions"].insert(5, {"delay_ms": 250})
                else:
                    evidence["actions"].insert(5, {"vnc_key": "f2", "state": "down"})
                (run / "qmp-setup-evidence.json").write_text(json.dumps(evidence))
                with self.assertRaisesRegex(ValueError, "action transcript"):
                    oracle.check(run, mode)

    def test_navigation_and_restoration_are_pixels_not_labels(self):
        with tempfile.TemporaryDirectory() as directory:
            for name in ("form-navigated", "firmware-restored"):
                run = Path(directory) / name
                evidence = make_run(run, "default-zero-hotkey")
                if name == "form-navigated":
                    data = (run / "setup-form-initial.ppm").read_bytes()
                else:
                    data = bytearray((run / "setup-firmware-restored.ppm").read_bytes())
                    data[-1] ^= 1
                (run / ("setup-" + name + ".ppm")).write_bytes(data)
                evidence["screens"][name]["sha256"] = hashlib.sha256(data).hexdigest()
                (run / "qmp-setup-evidence.json").write_text(json.dumps(evidence))
                with self.assertRaisesRegex(ValueError, "pixel change|restoration not exact"):
                    oracle.check(run, "default-zero-hotkey")

    def test_table_config_console_and_completion_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            for target in ("config", "table", "console", "runtime"):
                run = Path(directory) / target
                make_run(run, "default-zero-no-key")
                if target == "config":
                    (run / "cdk2-config.txt").write_bytes(config.replace(b"TIMEOUT=0", b"TIMEOUT=2"))
                elif target == "table":
                    data = bytearray((run / "cbmem-table-1.bin").read_bytes())
                    data[-1] ^= 1
                    (run / "cbmem-table-1.bin").write_bytes(data)
                elif target == "console":
                    (run / "cbmem-live.log").write_bytes(b"forged marker")
                else:
                    (run / "serial.log").write_text("CDK2_RUNTIME_OK\nCDK2_RUNTIME_OK\n")
                with self.assertRaises(ValueError):
                    oracle.check(run, "default-zero-no-key")

    def test_real_checked_console_marker_status_cardinality_and_order(self):
        changes = [
            lambda rows: [(text.replace("result | NOT_READY",
                                      "result | NOT_READY_BOGUS"), status)
                          for text, status in rows],
            lambda rows: rows + [rows[4]],
            lambda rows: [rows[1], rows[0]] + rows[2:],
            lambda rows: rows + [("SetupForm | begin | SUCCESS", 0)],
            lambda rows: [rows[0], ("junk " + rows[1][0], rows[1][1]),
                          rows[2], rows[1]] + rows[3:],
        ]
        with tempfile.TemporaryDirectory() as directory:
            for index, changed in enumerate(changes):
                run = Path(directory) / str(index)
                make_run(run, "default-zero-no-key", changed)
                with self.assertRaisesRegex(ValueError, "marker|entered setup"):
                    oracle.check(run, "default-zero-no-key")

    def test_zero_wait_field_is_configured_seconds_not_elapsed_latency(self):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory) / "wrong-wait"
            make_run(run, "default-zero-no-key", wait_field=2)
            with self.assertRaisesRegex(ValueError, "wait metadata is not zero"):
                oracle.check(run, "default-zero-no-key")

    def test_real_checked_fw_identity_not_learned_from_screens(self):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory) / "wrong-version"
            make_run(run, "default-zero-no-key", version=0x001a000a)
            with self.assertRaisesRegex(ValueError, "FW_INFO"):
                oracle.check(run, "default-zero-no-key")

    def test_recorded_wall_is_present_finite_positive_and_within_budget(self):
        with tempfile.TemporaryDirectory() as directory:
            for index, wall in enumerate((None, float("nan"), float("inf"),
                                          -1, 0, 180.01, True, "12")):
                run = Path(directory) / str(index)
                make_run(run, "default-zero-no-key")
                result = json.loads((run / "result.json").read_bytes())
                if wall is None:
                    del result["wall_seconds"]
                else:
                    result["wall_seconds"] = wall
                (run / "result.json").write_text(json.dumps(result))
                with self.assertRaisesRegex(ValueError, "did not complete"):
                    oracle.check(run, "default-zero-no-key")

    def test_runtime_is_an_exact_full_line_not_a_substring(self):
        with tempfile.TemporaryDirectory() as directory:
            for index, line in enumerate(("prefixCDK2_RUNTIME_OK\n",
                                           "CDK2_RUNTIME_OK_BOGUS\n")):
                run = Path(directory) / str(index)
                make_run(run, "default-zero-no-key")
                (run / "serial.log").write_text(line)
                with self.assertRaisesRegex(ValueError, "runtime completion"):
                    oracle.check(run, "default-zero-no-key")
            run = Path(directory) / "crlf"
            make_run(run, "default-zero-no-key")
            (run / "serial.log").write_bytes(b"CDK2_RUNTIME_OK\r\n")
            oracle.check(run, "default-zero-no-key")


if __name__ == "__main__":
    unittest.main()
