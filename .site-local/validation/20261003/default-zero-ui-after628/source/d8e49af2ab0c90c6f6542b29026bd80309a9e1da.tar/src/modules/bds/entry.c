/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#include <cdk2/bds.h>
#include <cdk2/bds_secure_boot.h>
#include <cdk2/bds_settings.h>
#include <cdk2/con_splitter.h>
#include <cdk2/diagnostic.h>
#include <cdk2/ec_battery_abi.h>
#include <cdk2/ftw_entry.h>
#include <cdk2/hob.h>
#include <cdk2/lvgl_renderer.h>
#include <cdk2/lvgl_ui.h>
#ifndef CDK2_BDS_UNIT_TEST
#include <cdk2/config.h>
#endif
#include <cdk2/null_memory_test.h>
#include <cdk2/terminal.h>
#include <cdk2/usb_keyboard.h>
#include <pi/hob.h>

#include <stddef.h>
#include <string.h>

#define LOAD_OPTION_ACTIVE 1U
#define LOAD_OPTION_CATEGORY_MASK 0x1f00U
#define LOAD_OPTION_CATEGORY_APP 0x0100U
#define LOCATE_ALL_HANDLES 0U
#define LOCATE_BY_PROTOCOL 2U
#define MEDIA_DEVICE_PATH 4U
#define FILE_PATH_SUBTYPE 4U
#define HARD_DRIVE_SUBTYPE 1U
#define FV_FILE_SUBTYPE 6U
#define END_DEVICE_PATH 0x7fU
#define END_ENTIRE 0xffU
#define MAX_PATH 4096U
#define VARIABLE_STORE_BYTES (512U * 1024U)
#define VARIABLE_HEADER_BYTES 60U
#define VARIABLE_NON_VOLATILE 0x00000001U
#define VARIABLE_BOOTSERVICE_ACCESS 0x00000002U
#define VARIABLE_RUNTIME_ACCESS 0x00000004U
#define VARIABLE_AUTHENTICATED_WRITE_ACCESS 0x00000010U
#define VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS 0x00000020U
#define VARIABLE_ENHANCED_AUTHENTICATED_ACCESS 0x00000080U
#define OS_INDICATIONS_ATTRIBUTES (VARIABLE_NON_VOLATILE | \
	VARIABLE_BOOTSERVICE_ACCESS | VARIABLE_RUNTIME_ACCESS)
#define OS_INDICATIONS_SUPPORTED_ATTRIBUTES (VARIABLE_BOOTSERVICE_ACCESS | \
	VARIABLE_RUNTIME_ACCESS)
#define OS_INDICATIONS_BOOT_TO_FW_UI 0x0000000000000001ULL
#define OS_INDICATIONS_FILE_CAPSULE_DELIVERY 0x0000000000000004ULL
#define SCAN_F2 0x000cU
/* One pending splitter queue plus each attached native provider queue.
 * This finite pass does not promise fairness against continuously arriving keys. */
#define SETUP_QUEUED_KEY_LIMIT (CDK2_CON_SPLITTER_MAX_INPUTS + \
	CDK2_CON_SPLITTER_MAX_INPUTS * (CDK2_USB_KEYBOARD_QUEUE > CDK2_TERMINAL_QUEUE ? \
	CDK2_USB_KEYBOARD_QUEUE : CDK2_TERMINAL_QUEUE))
#ifndef EFI_ABORTED
#define EFI_ABORTED EFIERR(21)
#endif

#ifndef CONFIG_CDK2_BOOT_TIMEOUT
#define CONFIG_CDK2_BOOT_TIMEOUT 0
#endif
#ifndef CONFIG_CDK2_CONNECT_ALL_DEVICES
#define CONFIG_CDK2_CONNECT_ALL_DEVICES 0
#endif
#ifndef CONFIG_CDK2_LINEAR_BOOT
#define CONFIG_CDK2_LINEAR_BOOT 0
#endif

typedef EFI_STATUS CDK2_MS_ABI get_variable_fn(CHAR16 *, const EFI_GUID *,
	UINT32 *, UINTN *, void *);
typedef EFI_STATUS CDK2_MS_ABI get_next_variable_fn(UINTN *, CHAR16 *, EFI_GUID *);
typedef EFI_STATUS CDK2_MS_ABI set_variable_fn(CHAR16 *, const EFI_GUID *,
	UINT32, UINTN, void *);
typedef void CDK2_MS_ABI reset_system_fn(UINT32, EFI_STATUS, UINTN, void *);
struct runtime_services {
	UINT8 before_get[72];
	get_variable_fn *get_variable;
	get_next_variable_fn *get_next_variable_name;
	set_variable_fn *set_variable;
	UINT8 to_reset[8];
	reset_system_fn *reset_system;
};
typedef EFI_STATUS CDK2_MS_ABI allocate_pool_fn(UINTN, UINTN, void **);
typedef EFI_STATUS CDK2_MS_ABI free_pool_fn(void *);
typedef void CDK2_MS_ABI event_notify_fn(void *, void *);
typedef EFI_STATUS CDK2_MS_ABI create_event_fn(UINT32, UINTN,
	event_notify_fn *, void *, void **);
typedef EFI_STATUS CDK2_MS_ABI set_timer_fn(void *, UINTN, UINT64);
typedef EFI_STATUS CDK2_MS_ABI handle_protocol_fn(void *, const EFI_GUID *,
	void **);
typedef EFI_STATUS CDK2_MS_ABI load_image_fn(BOOLEAN, void *, void *, void *,
	UINTN, void **);
typedef EFI_STATUS CDK2_MS_ABI start_image_fn(void *, UINTN *, void *);
typedef EFI_STATUS CDK2_MS_ABI unload_image_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI signal_event_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI close_event_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI create_event_ex_fn(UINT32, UINTN, void *,
	const void *, const EFI_GUID *, void **);
typedef EFI_STATUS CDK2_MS_ABI connect_fn(void *, void *, void *, BOOLEAN);
typedef EFI_STATUS CDK2_MS_ABI watchdog_fn(UINTN, UINT64, UINTN, CHAR16 *);
typedef EFI_STATUS CDK2_MS_ABI disconnect_fn(void *, void *, void *);
typedef EFI_STATUS CDK2_MS_ABI stall_fn(UINTN);
typedef EFI_STATUS CDK2_MS_ABI locate_buffer_fn(UINTN, const EFI_GUID *, void *,
	UINTN *, void ***);
typedef EFI_STATUS CDK2_MS_ABI locate_protocol_fn(const EFI_GUID *, void *, void **);
typedef EFI_STATUS CDK2_MS_ABI install_multiple_fn(void **, ...);
struct boot_services {
	UINT8 to_allocate[64];
	allocate_pool_fn *allocate_pool;
	free_pool_fn *free_pool;
	create_event_fn *create_event;
	set_timer_fn *set_timer;
	void *wait_for_event;
	signal_event_fn *signal_event;
	close_event_fn *close_event;
	UINT8 to_handle[32];
	handle_protocol_fn *handle_protocol;
	UINT8 to_load[40];
	load_image_fn *load_image;
	start_image_fn *start_image;
	UINT8 to_unload[8];
	unload_image_fn *unload_image;
	UINT8 to_stall[16];
	stall_fn *stall;
	watchdog_fn *set_watchdog_timer;
	connect_fn *connect_controller;
	disconnect_fn *disconnect_controller;
	UINT8 to_locate_buffer[32];
	locate_buffer_fn *locate_handle_buffer;
	locate_protocol_fn *locate_protocol;
	install_multiple_fn *install_multiple;
	UINT8 to_create_event_ex[32];
	create_event_ex_fn *create_event_ex;
};
struct input_key { UINT16 scan_code; CHAR16 unicode_char; };
typedef EFI_STATUS CDK2_MS_ABI read_key_fn(void *, struct input_key *);
struct simple_text_input {
	void *reset;
	read_key_fn *read_key;
	void *wait;
};
struct system_table {
	UINT8 header[40];
	void *console_in_handle;
	struct simple_text_input *console_in;
	UINT8 consoles[32];
	struct runtime_services *runtime;
	struct boot_services *boot;
	UINTN table_count;
	struct configuration_table *tables;
};
struct configuration_table { EFI_GUID guid; void *table; };
typedef char runtime_offset[
	offsetof(struct system_table, runtime) == 88 ? 1 : -1];
typedef char boot_offset[
	offsetof(struct system_table, boot) == 96 ? 1 : -1];
typedef void CDK2_MS_ABI bds_entry_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI bds_boot_next_pending_fn(BOOLEAN *);
typedef EFI_STATUS CDK2_MS_ABI bds_input_poll_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI bds_enter_setup_fn(UINTN,
	bds_input_poll_fn *, void *);
struct bds_protocol {
	bds_entry_fn *entry;
	/* CDK2 extension: use the boot manager's authoritative variable lookup,
	 * including its bounded persistent-FVB recovery path. */
	bds_boot_next_pending_fn *boot_next_pending;
	/* Synchronous setup surface for the linear boot-policy phase. */
	bds_enter_setup_fn *enter_setup;
};

typedef char get_variable_offset[offsetof(struct runtime_services,
	get_variable) == 72 ? 1 : -1];
typedef char set_variable_offset[offsetof(struct runtime_services,
	set_variable) == 88 ? 1 : -1];
typedef char reset_system_offset[offsetof(struct runtime_services,
	reset_system) == 104 ? 1 : -1];
typedef char load_offset[offsetof(struct boot_services, load_image) == 200 ? 1 : -1];
typedef char start_offset[offsetof(struct boot_services, start_image) == 208 ? 1 : -1];
typedef char unload_offset[offsetof(struct boot_services, unload_image) == 224 ? 1 : -1];
typedef char connect_offset[offsetof(struct boot_services,
	connect_controller) == 264 ? 1 : -1];
typedef char locate_buffer_offset[offsetof(struct boot_services,
	locate_handle_buffer) == 312 ? 1 : -1];
typedef char locate_protocol_offset[offsetof(struct boot_services,
	locate_protocol) == 320 ? 1 : -1];
typedef char signal_offset[offsetof(struct boot_services, signal_event) == 104 ?
	1 : -1];
typedef char close_offset[offsetof(struct boot_services, close_event) == 112 ?
	1 : -1];
typedef char create_ex_offset[offsetof(struct boot_services, create_event_ex) ==
	368 ? 1 : -1];
typedef char runtime_services_offset[offsetof(struct system_table, runtime) ==
	88 ? 1 : -1];
typedef char boot_services_offset[offsetof(struct system_table, boot) ==
	96 ? 1 : -1];

static const EFI_GUID global_guid = { 0x8be4df61, 0x93ca, 0x11d2,
	{ 0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c } };
static const EFI_GUID fvb_guid = { 0x8f644fa9, 0xe850, 0x4db1,
	{ 0x9c, 0xe2, 0x0b, 0x44, 0x69, 0x8e, 0x8d, 0xa4 } };
static const EFI_GUID authenticated_store_guid = { 0xaaf32c78, 0x947b,
	0x439a, { 0xa1, 0x80, 0x2e, 0x14, 0x4e, 0xc3, 0x77, 0x92 } };
static const EFI_GUID bds_guid = { 0x665e3ff6, 0x46cc, 0x11d4,
	{ 0x9a, 0x38, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
static const EFI_GUID path_guid = { 0x09576e91, 0x6d3f, 0x11d2,
	{ 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID simple_fs_guid = { 0x964e5b22, 0x6459, 0x11d2,
	{ 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID block_io_guid = { 0x964e5b21, 0x6459, 0x11d2,
	{ 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID hob_list_guid = { 0x7739f24c, 0x93d7, 0x11d4,
	{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
static const EFI_GUID fv2_guid = { 0x220e73b6, 0x6bdb, 0x4413,
	{ 0x84, 0x05, 0xb9, 0x74, 0xb1, 0x08, 0x61, 0x9a } };
static const EFI_GUID shell_guid = { 0x7c04a583, 0x9e3e, 0x4f1c,
	{ 0xad, 0x65, 0xe0, 0x52, 0x68, 0xd0, 0xb4, 0xd1 } };
static const EFI_GUID loaded_image_guid = { 0x5b1b31a1, 0x9562, 0x11d2,
	{ 0x8e, 0x3f, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID ready_to_boot_guid = { 0x7ce88fb3, 0x4bd7, 0x4679,
	{ 0x87, 0xa8, 0xa8, 0xd8, 0xde, 0xe5, 0x0d, 0x2b } };
static const EFI_GUID end_of_dxe_guid = { 0x02ce967a, 0xdd7e, 0x4ffc,
	{ 0x9e, 0xe7, 0x81, 0x0c, 0xf0, 0x47, 0x08, 0x80 } };
static const EFI_GUID ready_to_lock_guid = { 0x60ff8964, 0xe906, 0x41d0,
	{ 0xaf, 0xed, 0xf2, 0x41, 0xe9, 0x74, 0xe0, 0x8e } };
static const EFI_GUID memory_test_guid = { 0x309de7f1, 0x7f5e, 0x4ace,
	{ 0xb4, 0x9c, 0x53, 0x1b, 0xe5, 0xaa, 0x95, 0xef } };
static const EFI_GUID lvgl_ui_guid = { 0x87f4dfc1, 0xa2f1, 0x4c90,
	{ 0x95, 0x2d, 0x4a, 0x88, 0x1e, 0xd9, 0x52, 0x31 } };
static struct system_table *active_system;
static struct bds_protocol protocol;
static void *driver_handle;
static BOOLEAN battery_checked;
static EFI_BOOT_MODE current_boot_mode = BOOT_WITH_FULL_CONFIGURATION;

static UINT64 os_indication(UINT64 bit);

static UINTN path_size(const UINT8 *path)
{
	UINTN offset = 0;

	while (path != NULL && offset + 4 <= MAX_PATH) {
		UINTN length = path[offset + 2] | path[offset + 3] << 8;

		if (length < 4 || length > MAX_PATH - offset)
			return 0;
		offset += length;
		if (path[offset - length] == END_DEVICE_PATH &&
		    path[offset - length + 1] == END_ENTIRE)
			return offset;
	}
	return 0;
}

static BOOLEAN bytes_equal(const UINT8 *left, const UINT8 *right, UINTN size)
{
	while (size-- != 0)
		if (*left++ != *right++)
			return FALSE;
	return TRUE;
}

static void check_low_battery_once(void)
{
	struct cdk2_battery_protocol *battery = NULL;
	BOOLEAN critical = FALSE;
	EFI_STATUS status;

	if (battery_checked)
		return;
	battery_checked = TRUE;
	status = active_system->boot->locate_protocol(
		&cdk2_battery_protocol_guid, NULL, (void **)&battery);
	if (EFI_ERROR(status) || battery == NULL || battery->get_critical == NULL)
		return;
	status = battery->get_critical(&critical);
	if (!EFI_ERROR(status) && critical)
		cdk2_diag_message(CDK2_DIAG_BDS,
			"[CDK2][bds][warning] battery critically low");
}

struct setup_poll_context {
	struct cdk2_battery_protocol *battery;
	bds_input_poll_fn *input;
	void *input_context;
	UINTN ticks;
};

static void CDK2_MS_ABI poll_setup_services(void *opaque)
{
	struct setup_poll_context *context = opaque;

	if (context == NULL)
		return;
	if (context->input != NULL)
		(void)context->input(context->input_context);
	context->ticks++;
	if (context->ticks == 100U) {
		context->ticks = 0U;
		if (context->battery != NULL && context->battery->refresh != NULL)
			(void)context->battery->refresh();
	}
}

static struct cdk2_lvgl_ui_protocol *begin_setup_poll(
	struct cdk2_lvgl_ui_protocol *ui, struct setup_poll_context *context,
	bds_input_poll_fn *input,
	void *input_context, EFI_STATUS *start_status)
{
	struct cdk2_battery_protocol *battery = NULL;

	if (context == NULL || ui == NULL || start_status == NULL)
		return NULL;
	*start_status = EFI_SUCCESS;
	if (ui->set_poll == NULL) {
		*start_status = EFI_UNSUPPORTED;
		return ui;
	}
	if (EFI_ERROR(active_system->boot->locate_protocol(
		&cdk2_battery_protocol_guid, NULL, (void **)&battery)) ||
	    battery == NULL || battery->refresh == NULL)
		battery = NULL;
	*context = (struct setup_poll_context) {
		.battery = battery,
		.input = input,
		.input_context = input_context,
	};
	if (battery == NULL && input == NULL)
		return ui;
	*start_status = ui->set_poll(ui, poll_setup_services, context, 10U);
	return ui;
}

static EFI_STATUS end_setup_poll(struct cdk2_lvgl_ui_protocol *ui)
{
	if (ui == NULL)
		return EFI_SUCCESS;
	if (ui->set_poll == NULL)
		return EFI_UNSUPPORTED;
	return ui->set_poll(ui, NULL, NULL, 0U);
}

struct loaded_image_protocol {
	UINT32 revision;
	UINT32 padding;
	void *parent_handle;
	void *system_table;
	void *device_handle;
	void *file_path;
	void *reserved;
	UINT32 load_options_size;
	UINT32 options_padding;
	void *load_options;
};
static const EFI_GUID disk_io_guid = { 0xce345171, 0xba0b, 0x11d2,
	{ 0x8e, 0x4f, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b }
};
static const EFI_GUID pci_io_guid = { 0x4cf5b200, 0x68b8, 0x4ca5,
	{ 0x9e, 0xec, 0xb2, 0x3e, 0x3f, 0x50, 0x02, 0x9a }
};

static void signal_ready_to_boot(void)
{
	void *event = NULL;

	if (EFI_ERROR(active_system->boot->create_event_ex(0, 0, NULL, NULL,
		&ready_to_boot_guid, &event)))
		return;
	(void)active_system->boot->signal_event(event);
	(void)active_system->boot->close_event(event);
}

static EFI_STATUS complete_dxe(void)
{
	static UINT8 ready_marker;
	static BOOLEAN completed;
	void *event = NULL, *handle = NULL;
	EFI_STATUS status;

	if (completed)
		return EFI_SUCCESS;
	status = active_system->boot->create_event_ex(0, 0, NULL, NULL,
		&end_of_dxe_guid, &event);
	if (!EFI_ERROR(status))
		status = active_system->boot->signal_event(event);
	if (event != NULL)
		(void)active_system->boot->close_event(event);
	if (!EFI_ERROR(status))
		status = active_system->boot->install_multiple(&handle,
			&ready_to_lock_guid, &ready_marker, NULL);
	if (!EFI_ERROR(status))
		completed = TRUE;
	return status;
}

static EFI_STATUS complete_memory_test(void)
{
	struct cdk2_generic_memory_test *test = NULL;
	uint64_t tested = 0U, total = 0U;
	UINT8 soft_ecc = 0U, error = 0U;
	EFI_STATUS status = active_system->boot->locate_protocol(&memory_test_guid,
		NULL, (void **)&test);

	if (status == EFI_NOT_FOUND)
		return EFI_SUCCESS;
	if (EFI_ERROR(status) || test == NULL || test->initialize == NULL ||
	    test->perform == NULL || test->finished == NULL)
		return EFI_UNSUPPORTED;
	status = test->initialize(test, 0U, &soft_ecc);
	while (!EFI_ERROR(status))
		status = test->perform(test, &tested, &total, &error, FALSE);
	if (status == EFI_NOT_FOUND)
		status = EFI_SUCCESS;
	if (!EFI_ERROR(status) && error != 0U)
		status = EFI_DEVICE_ERROR;
	if (!EFI_ERROR(status))
		status = test->finished(test);
	return status;
}

static void connect_path(const void *path)
{
	void **handles = NULL;
	UINTN count = 0U, target_size = path_size(path);

	if (CONFIG_CDK2_CONNECT_ALL_DEVICES || target_size < 4U ||
	    EFI_ERROR(active_system->boot->locate_handle_buffer(LOCATE_BY_PROTOCOL,
	    &path_guid, NULL, &count, &handles)))
		return;
	for (UINTN index = 0U; index < count; index++) {
		const UINT8 *candidate = NULL;
		UINTN size;

		if (EFI_ERROR(active_system->boot->handle_protocol(handles[index],
		    &path_guid, (void **)&candidate)) ||
		    (size = path_size(candidate)) < 4U || size > target_size ||
		    !bytes_equal(candidate, path, size - 4U))
			continue;
		(void)active_system->boot->connect_controller(handles[index], NULL,
			NULL, TRUE);
	}
	active_system->boot->free_pool(handles);
}

static EFI_STATUS launch_path(const void *path, const void *optional_data,
	UINTN optional_data_size, BOOLEAN driver, BOOLEAN publish_ready)
{
	struct loaded_image_protocol *loaded = NULL;
	void *handle = NULL;
	UINTN exit_size = 0;
	CHAR16 *exit_data = NULL;
	EFI_STATUS status;

	connect_path(path);
#ifdef CDK2_DEBUG
	{
		UINTN bytes = path_size(path);

		cdk2_diag_value(CDK2_DIAG_BDS, "launch device-path bytes", bytes);
		/* Device paths are attacker-controlled NVRAM data.  Keep the trace
		 * useful but bounded so one bad option cannot consume the UART log. */
		if (bytes >= 4U && bytes <= MAX_PATH) {
			UINTN head = bytes > 256U ? 128U : bytes;

			cdk2_diag_bytes(CDK2_DIAG_BDS, "launch device-path head",
				path, head);
			if (bytes > 256U)
				cdk2_diag_bytes(CDK2_DIAG_BDS,
					"launch device-path tail",
					(const UINT8 *)path + bytes - 128U, 128U);
		}
		cdk2_diag_value(CDK2_DIAG_BDS, "launch optional-data bytes",
			optional_data_size);
		cdk2_diag_value(CDK2_DIAG_BDS, "launch is driver", driver);
	}
	cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1330U,
		(UINTN)path);
#endif
	status = active_system->boot->load_image(!driver, driver_handle, (void *)path,
		NULL, 0, &handle);
#ifdef CDK2_DEBUG
	cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1331U, status);
#endif
	if (!EFI_ERROR(status) && optional_data_size > MAX_UINT32)
		status = EFI_INVALID_PARAMETER;
	if (!EFI_ERROR(status) && optional_data_size != 0) {
		status = active_system->boot->handle_protocol(handle,
			&loaded_image_guid, (void **)&loaded);
		if (!EFI_ERROR(status)) {
			loaded->load_options = (void *)optional_data;
			loaded->load_options_size = (UINT32)optional_data_size;
		}
	}
	if (!EFI_ERROR(status)) {
		if (!driver && publish_ready)
			signal_ready_to_boot();
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1332U,
			(UINTN)handle);
#endif
		status = active_system->boot->start_image(handle, &exit_size, &exit_data);
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1333U, status);
#endif
	}
	if (exit_data != NULL)
		active_system->boot->free_pool(exit_data);
	if (handle != NULL && (EFI_ERROR(status) || !driver)) {
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1334U,
			(UINTN)handle);
#endif
		EFI_STATUS unload = active_system->boot->unload_image(handle);
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1335U, unload);
#endif

		if (!EFI_ERROR(status) && EFI_ERROR(unload))
			status = unload;
	}
	return status;
}

static BOOLEAN same_partition(const UINT8 *candidate, const UINT8 *short_path)
{
	if (candidate[41] != short_path[41] || candidate[40] != short_path[40])
		return FALSE;
	if (short_path[41] == 2U)
		return bytes_equal(candidate + 24U, short_path + 24U, 16U);
	if (short_path[41] == 1U)
		return bytes_equal(candidate + 24U, short_path + 24U, 4U) &&
			bytes_equal(candidate + 4U, short_path + 4U, 4U);
	return bytes_equal(candidate + 4U, short_path + 4U, 36U);
}

static UINTN hard_drive_node_offset(const UINT8 *path, UINTN path_size)
{
	UINTN offset = 0U;

	while (offset <= path_size - 4U) {
		UINTN node_size = path[offset + 2U] |
			(UINTN)path[offset + 3U] << 8U;

		if (node_size < 4U || node_size > path_size - offset)
			break;
		if (node_size == 42U && path[offset] == MEDIA_DEVICE_PATH &&
		    path[offset + 1U] == HARD_DRIVE_SUBTYPE)
			return offset;
		if (path[offset] == END_DEVICE_PATH)
			break;
		offset += node_size;
	}
	return MAX_UINTN;
}

static EFI_STATUS option_path(const struct cdk2_bds_option *option,
	BOOLEAN driver, BOOLEAN publish_ready)
{
	const UINT8 *short_path;
	void **handles = NULL;
	UINTN count = 0, index, short_offset;
	EFI_STATUS status;

	if (option->path_size < 4U)
		return launch_path(option->path, option->optional_data,
			option->optional_data_size, driver, publish_ready);
	short_offset = hard_drive_node_offset(option->path, option->path_size);
	if (short_offset == MAX_UINTN)
		return launch_path(option->path, option->optional_data,
			option->optional_data_size, driver, publish_ready);
	short_path = option->path + short_offset;
	/* Full boot paths can retain a stale PCI/NVMe prefix across firmware
	 * changes.  Try the exact path first, then recover by the partition
	 * signature just as EDK2 does for a short-form hard-drive path. */
	if (short_offset != 0U) {
		status = launch_path(option->path, option->optional_data,
			option->optional_data_size, driver, publish_ready);
		if (!EFI_ERROR(status))
			return status;
	}
	status = active_system->boot->locate_handle_buffer(LOCATE_BY_PROTOCOL,
		&path_guid, NULL, &count, &handles);
	if (EFI_ERROR(status))
		return status;
	status = EFI_NOT_FOUND;
	for (index = 0; index < count && EFI_ERROR(status); index++) {
		const UINT8 *candidate;
		UINT8 *expanded;
		UINTN candidate_size, offset = 0, total;

		if (EFI_ERROR(active_system->boot->handle_protocol(handles[index],
			&path_guid, (void **)&candidate)) ||
		    (candidate_size = path_size(candidate)) < 42U)
			continue;
		while (offset <= candidate_size - 4U) {
			UINTN node_size = candidate[offset + 2U] |
				(UINTN)candidate[offset + 3U] << 8;

			if (node_size < 4U || node_size > candidate_size - offset)
				break;
			if (node_size == 42U && candidate[offset] == MEDIA_DEVICE_PATH &&
			    candidate[offset + 1U] == HARD_DRIVE_SUBTYPE &&
			    same_partition(candidate + offset, short_path))
				break;
			offset += node_size;
		}
		if (offset > candidate_size - 42U ||
		    option->path_size - short_offset - 42U >
		    MAX_UINTN - offset - 42U)
			continue;
		total = offset + 42U + option->path_size - short_offset - 42U;
		if (EFI_ERROR(active_system->boot->allocate_pool(4, total,
			(void **)&expanded)))
			continue;
		memcpy(expanded, candidate, offset + 42U);
		memcpy(expanded + offset + 42U, short_path + 42U,
			option->path_size - short_offset - 42U);
		status = launch_path(expanded, option->optional_data,
			option->optional_data_size, driver, publish_ready);
		active_system->boot->free_pool(expanded);
	}
	active_system->boot->free_pool(handles);
	return status;
}

static UINT16 variable_read16(const UINT8 *bytes)
{
	return (UINT16)bytes[0] | (UINT16)bytes[1] << 8U;
}

static UINT32 variable_read32(const UINT8 *bytes)
{
	return variable_read16(bytes) |
		(UINT32)variable_read16(bytes + 2U) << 16U;
}

static UINTN variable_align4(UINTN value)
{
	return (value + 3U) & ~3U;
}

static BOOLEAN boot_variable_name(const CHAR16 *name)
{
	static const CHAR16 prefix[] = L"Boot";

	return name != NULL && bytes_equal((const UINT8 *)name,
		(const UINT8 *)prefix, sizeof(prefix) - sizeof(CHAR16));
}

static EFI_STATUS persistent_boot_variable(const CHAR16 *name,
	const EFI_GUID *guid, void **data, UINTN *size)
{
	void **handles = NULL;
	UINTN handle_count = 0U, name_bytes = sizeof(CHAR16), index;
	EFI_STATUS result = EFI_NOT_FOUND;

	if (!boot_variable_name(name) || !bytes_equal((const UINT8 *)guid,
	    (const UINT8 *)&global_guid, sizeof(*guid)))
		return EFI_NOT_FOUND;
	while (name[name_bytes / sizeof(CHAR16) - 1U] != 0U) {
		if (name_bytes >= 128U * sizeof(CHAR16))
			return EFI_INVALID_PARAMETER;
		name_bytes += sizeof(CHAR16);
	}
	if (EFI_ERROR(active_system->boot->locate_handle_buffer(
	    LOCATE_BY_PROTOCOL, &fvb_guid, NULL, &handle_count, &handles)))
		return EFI_NOT_FOUND;
	for (index = 0U; index < handle_count && EFI_ERROR(result); index++) {
		struct cdk2_fvb_protocol_view *fvb = NULL;
		UINT8 *image = NULL;
		UINTN total = 0U, lba = 0U, store_offset = MAX_UINTN, declared, offset;
		const UINT8 *selected = NULL;
		UINTN selected_size = 0U;

		if (EFI_ERROR(active_system->boot->handle_protocol(handles[index],
		    &fvb_guid, (void **)&fvb)) || fvb == NULL ||
		    EFI_ERROR(active_system->boot->allocate_pool(4U,
		    VARIABLE_STORE_BYTES, (void **)&image)))
			continue;
		while (total < VARIABLE_STORE_BYTES) {
			UINTN block_size, run, read_size;
			EFI_STATUS status = fvb->get_block_size(fvb, lba,
				&block_size, &run);

			if (EFI_ERROR(status) || block_size == 0U || run == 0U ||
			    block_size > VARIABLE_STORE_BYTES - total)
				break;
			read_size = block_size;
			status = fvb->read(fvb, lba++, 0U, &read_size, image + total);
			if (EFI_ERROR(status) || read_size != block_size)
				break;
			total += block_size;
		}
		if (total < 64U || variable_read32(image + 40U) != 0x4856465fU)
			goto release_image;
		/* Some retained FVB producers expose a translated header length.  The
		 * authenticated-store GUID is the on-media authority, so discover it
		 * within the bounded first block rather than trusting that translation. */
		for (offset = 0U; offset + 28U <= total && offset < 65536U;
		     offset += 4U)
			if (bytes_equal(image + offset,
			    (const UINT8 *)&authenticated_store_guid,
			    sizeof(authenticated_store_guid))) {
				store_offset = offset;
				break;
			}
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1340U, total);
		cdk2_diag_emit(store_offset == MAX_UINTN ? CDK2_DIAG_ERROR :
			CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1341U, store_offset);
#endif
		if (store_offset == MAX_UINTN)
			goto release_image;
		declared = variable_read32(image + store_offset + 16U);
		if (declared < 28U || declared > total - store_offset)
			goto release_image;
		for (offset = 28U; offset + VARIABLE_HEADER_BYTES <= declared;) {
			const UINT8 *header = image + store_offset + offset;
			UINTN record_name = variable_read32(header + 36U);
			UINTN record_data = variable_read32(header + 40U);
			UINTN occupied = variable_align4(VARIABLE_HEADER_BYTES +
				record_name + record_data);

			if (variable_read16(header) == 0xffffU)
				break;
			if (variable_read16(header) != 0x55aaU ||
			    record_name < sizeof(CHAR16) || occupied > declared - offset)
				break;
			if (record_name == name_bytes &&
			    bytes_equal(header + 44U, (const UINT8 *)guid,
				sizeof(*guid)) &&
			    bytes_equal(header + VARIABLE_HEADER_BYTES,
				(const UINT8 *)name, name_bytes)) {
				if (header[2] == 0x3fU || header[2] == 0x3eU) {
					selected = header + VARIABLE_HEADER_BYTES + record_name;
					selected_size = record_data;
				} else if (header[2] == 0x3cU) {
					selected = NULL;
					selected_size = 0U;
				}
			}
			offset += occupied;
		}
		if (selected != NULL) {
			result = active_system->boot->allocate_pool(4U, selected_size,
				data);
			if (!EFI_ERROR(result)) {
				memcpy(*data, selected, selected_size);
				*size = selected_size;
			}
		}
#ifdef CDK2_DEBUG
		cdk2_diag_emit(EFI_ERROR(result) ? CDK2_DIAG_WARN : CDK2_DIAG_DEBUG,
			CDK2_DIAG_BDS, 0x1342U,
			EFI_ERROR(result) ? result : selected_size);
#endif
release_image:
		active_system->boot->free_pool(image);
	}
	active_system->boot->free_pool(handles);
	return result;
}

static EFI_STATUS variable_guid(const CHAR16 *name, const EFI_GUID *guid,
	void **data, UINTN *size)
{
	EFI_STATUS status;

	*data = NULL;
	*size = 0;
	status = active_system->runtime->get_variable((CHAR16 *)name, guid, NULL,
		size, NULL);
	if (status == EFI_NOT_FOUND)
		return persistent_boot_variable(name, guid, data, size);
	if (status != EFI_BUFFER_TOO_SMALL || *size == 0)
		return status;
	status = active_system->boot->allocate_pool(4, *size, data);
	if (EFI_ERROR(status))
		return status;
	status = active_system->runtime->get_variable((CHAR16 *)name, guid, NULL,
		size, *data);
	if (EFI_ERROR(status)) {
		active_system->boot->free_pool(*data);
		*data = NULL;
	}
	return status;
}

static EFI_STATUS variable(const CHAR16 *name, void **data, UINTN *size)
{
	return variable_guid(name, &global_guid, data, size);
}

static BOOLEAN preserve_capsule_boot_next(void)
{
	return current_boot_mode == BOOT_ON_S4_RESUME &&
		os_indication(OS_INDICATIONS_FILE_CAPSULE_DELIVERY) != 0U;
}

static EFI_STATUS CDK2_MS_ABI bds_boot_next_pending(BOOLEAN *pending)
{
	static const CHAR16 boot_next[] = L"BootNext";
	void *data = NULL;
	UINTN size = 0U;
	EFI_STATUS status;

	if (pending == NULL)
		return EFI_INVALID_PARAMETER;
	*pending = FALSE;
	status = variable(boot_next, &data, &size);
	if (status == EFI_NOT_FOUND)
		return EFI_SUCCESS;
	if (!EFI_ERROR(status)) {
		status = size == sizeof(UINT16) ? EFI_SUCCESS : EFI_COMPROMISED_DATA;
		*pending = !EFI_ERROR(status) && !preserve_capsule_boot_next();
	}
	if (data != NULL)
		active_system->boot->free_pool(data);
	return status;
}

static EFI_STATUS publish_os_indications_support(BOOLEAN setup_capable)
{
	static CHAR16 name[] = L"OsIndicationsSupported";
	UINT64 supported = 0U;
	UINTN size = sizeof(supported);
	UINT32 attributes = 0U;
	EFI_STATUS status;

	status = active_system->runtime->get_variable(name, &global_guid,
		&attributes, &size, &supported);
	if (status != EFI_NOT_FOUND && EFI_ERROR(status))
		return status;
	if (status == EFI_SUCCESS &&
	    (size != sizeof(supported) ||
	    attributes != OS_INDICATIONS_SUPPORTED_ATTRIBUTES))
		return EFI_COMPROMISED_DATA;
	{
		UINT64 original = supported;

		if (setup_capable)
			supported |= OS_INDICATIONS_BOOT_TO_FW_UI;
		else
			supported &= ~OS_INDICATIONS_BOOT_TO_FW_UI;
		if (status == EFI_SUCCESS && supported == original)
			return EFI_SUCCESS;
	}
	return active_system->runtime->set_variable(name, &global_guid,
		OS_INDICATIONS_SUPPORTED_ATTRIBUTES, sizeof(supported), &supported);
}


static EFI_STATUS boot_option_variable(UINT16 number, void **data, UINTN *size)
{
	CHAR16 name[] = { 'B', 'o', 'o', 't', '0', '0', '0', '0', 0 };
	static const CHAR16 hex[] = { '0', '1', '2', '3', '4', '5', '6', '7',
		'8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
	UINTN index;

	for (index = 0; index < 4; index++)
		name[7 - index] = hex[(number >> (index * 4)) & 0xfU];
	return variable(name, data, size);
}

static EFI_STATUS boot_number(UINT16 number, BOOLEAN explicit)
{
	struct cdk2_bds_option option;
	void *data = NULL;
	UINTN size = 0;
	EFI_STATUS status;

	cdk2_diag_value(CDK2_DIAG_BDS, "Boot option number", number);
	cdk2_diag_value(CDK2_DIAG_BDS, "Boot option explicit", explicit);
	status = boot_option_variable(number, &data, &size);
	if (!EFI_ERROR(status))
		status = cdk2_bds_parse_option(data, size, &option);
	if (!EFI_ERROR(status) && (explicit ||
	    ((option.attributes & LOAD_OPTION_ACTIVE) != 0U &&
	    (option.attributes & LOAD_OPTION_CATEGORY_MASK) !=
	    LOAD_OPTION_CATEGORY_APP)))
		(void)active_system->runtime->set_variable(
			(CHAR16[]){ 'B', 'o', 'o', 't', 'C', 'u', 'r', 'r', 'e', 'n', 't', 0 },
			&global_guid, 6U, sizeof(number), &number);
	if (!EFI_ERROR(status) && (explicit ||
	    ((option.attributes & LOAD_OPTION_ACTIVE) != 0U &&
	    (option.attributes & LOAD_OPTION_CATEGORY_MASK) !=
	    LOAD_OPTION_CATEGORY_APP)))
		status = option_path(&option, FALSE, TRUE);
	else if (!EFI_ERROR(status))
		status = EFI_NOT_FOUND;
	(void)active_system->runtime->set_variable(
		(CHAR16[]){ 'B', 'o', 'o', 't', 'C', 'u', 'r', 'r', 'e', 'n', 't', 0 },
		&global_guid, 0, 0, NULL);
	if (data != NULL)
		active_system->boot->free_pool(data);
	if (explicit)
		cdk2_diag_emit(CDK2_DIAG_WARN, CDK2_DIAG_BDS,
			CDK2_EVENT_BDS_BOOTNEXT_FAILED, status);
	return status;
}

static BOOLEAN force_reconnect;

static void process_sysprep_order(void)
{
	static const CHAR16 order_name[] = L"SysPrepOrder";
	static const CHAR16 hex[] = L"0123456789ABCDEF";
	void *order = NULL;
	UINTN size = 0U;

	if (EFI_ERROR(variable(order_name, &order, &size)) || (size & 1U) != 0U)
		goto done;
	for (UINTN item = 0U; item < size / sizeof(UINT16); item++) {
		CHAR16 name[] = L"SysPrep0000";
		struct cdk2_bds_option option;
		void *data = NULL;
		UINTN option_size = 0U;
		UINT16 number = ((UINT16 *)order)[item];

		for (UINTN digit = 0U; digit < 4U; digit++)
			name[10U - digit] = hex[(number >> (digit * 4U)) & 0xfU];
		if (!EFI_ERROR(variable(name, &data, &option_size)) &&
		    !EFI_ERROR(cdk2_bds_parse_option(data, option_size, &option)) &&
		    (option.attributes & LOAD_OPTION_ACTIVE) != 0U)
			(void)option_path(&option, FALSE, FALSE);
		if (data != NULL)
			active_system->boot->free_pool(data);
	}
done:
	if (order != NULL)
		active_system->boot->free_pool(order);
}

static EFI_STATUS driver_number(UINT16 number)
{
	CHAR16 name[] = { 'D', 'r', 'i', 'v', 'e', 'r', '0', '0', '0', '0', 0 };
	static const CHAR16 hex[] = { '0', '1', '2', '3', '4', '5', '6', '7',
		'8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
	struct cdk2_bds_option option;
	void *data = NULL;
	UINTN size = 0, index;
	EFI_STATUS status;

	for (index = 0; index < 4U; index++)
		name[9U - index] = hex[(number >> (index * 4U)) & 0xfU];
	status = variable(name, &data, &size);
	if (!EFI_ERROR(status))
		status = cdk2_bds_parse_option(data, size, &option);
	if (!EFI_ERROR(status) && (option.attributes & LOAD_OPTION_ACTIVE) != 0U) {
		status = option_path(&option, TRUE, TRUE);
		if (!EFI_ERROR(status) && (option.attributes & 2U) != 0U)
			force_reconnect = TRUE;
	} else if (!EFI_ERROR(status))
		status = EFI_NOT_FOUND;
	if (data != NULL)
		active_system->boot->free_pool(data);
	return status;
}

static void process_driver_order(void)
{
	static const CHAR16 driver_order[] = { 'D', 'r', 'i', 'v', 'e', 'r',
		'O', 'r', 'd', 'e', 'r', 0 };
	void *data = NULL;
	static BOOLEAN processed;
	UINTN size = 0, index;

	if (processed || EFI_ERROR(variable(driver_order, &data, &size)))
		return;
	processed = TRUE;
	if ((size & 1U) == 0U)
		for (index = 0U; index < size / sizeof(UINT16); index++)
			(void)driver_number(((UINT16 *)data)[index]);
	active_system->boot->free_pool(data);
}

static EFI_STATUS browse_setup(struct cdk2_lvgl_ui_protocol *ui)
{
#if CONFIG_CDK2_NATIVE_LVGL_SETUP
	struct cdk2_runtime_services_view native_runtime = { 0 };

	if (ui == NULL || ui->show_form == NULL || active_system == NULL ||
	    active_system->runtime == NULL ||
	    active_system->runtime->get_variable == NULL ||
	    active_system->runtime->set_variable == NULL)
		return EFI_UNSUPPORTED;
	native_runtime.get_variable = (void *)active_system->runtime->get_variable;
	native_runtime.set_variable = (void *)active_system->runtime->set_variable;
#if CONFIG_CDK2_SECURE_BOOT_CONFIG
	{
		struct cdk2_boot_services_view native_boot = { 0 };

		native_boot.allocate_pool = (void *)active_system->boot->allocate_pool;
		native_boot.free_pool = (void *)active_system->boot->free_pool;
		return cdk2_secure_boot_setup_root(ui, &native_runtime, &native_boot,
			cdk2_bds_browse_settings);
	}
#else
	return cdk2_bds_browse_settings(ui, &native_runtime);
#endif
#else
	(void)ui;
	return EFI_UNSUPPORTED;
#endif
}

static BOOLEAN native_setup_surface_available(const struct cdk2_lvgl_ui_protocol *ui)
{
#if CONFIG_CDK2_NATIVE_LVGL_SETUP
	return ui != NULL && ui->show_menu != NULL && ui->show_form != NULL &&
		active_system != NULL && active_system->runtime != NULL &&
		active_system->runtime->get_variable != NULL &&
		active_system->runtime->set_variable != NULL;
#else
	(void)ui;
	return FALSE;
#endif
}

static BOOLEAN native_setup_available(void)
{
#if CONFIG_CDK2_NATIVE_LVGL_SETUP
	struct cdk2_lvgl_ui_protocol *ui = NULL;
	EFI_STATUS status;

	if (active_system == NULL || active_system->boot == NULL ||
	    active_system->boot->locate_protocol == NULL ||
	    active_system->runtime == NULL)
		return FALSE;
	status = active_system->boot->locate_protocol(&lvgl_ui_guid, NULL,
		(void **)&ui);
	if (EFI_ERROR(status) || ui == NULL)
		return FALSE;
	return native_setup_surface_available(ui);
#else
	return FALSE;
#endif
}

static EFI_STATUS consume_os_indication(UINT64 bit);

static EFI_STATUS graphical_boot_order(const UINT16 *order, UINTN count,
	UINTN *resume_index, BOOLEAN consume_fw_ui, BOOLEAN *menu_presented,
	BOOLEAN *request_consumed)
{
	static const CHAR16 title[] = { 'B', 'o', 'o', 't', ' ', 'M', 'e', 'n', 'u', 0 };
	static const CHAR16 setup_label[] = {
		'F', 'i', 'r', 'm', 'w', 'a', 'r', 'e', ' ', 'S', 'e', 't', 'u', 'p', 0
	};
	static const CHAR16 next_label[] = {
		'N', 'e', 'x', 't', ' ', 'P', 'a', 'g', 'e', 0
	};
	struct cdk2_lvgl_menu_item items[CDK2_LVGL_MENU_MAX_ITEMS];
	void *option_data[CDK2_LVGL_MENU_MAX_ITEMS] = { 0 };
	UINT16 option_numbers[CDK2_LVGL_MENU_MAX_ITEMS] = { 0 };
	UINTN option_indexes[CDK2_LVGL_MENU_MAX_ITEMS] = { 0 };
	struct cdk2_lvgl_ui_protocol *ui;
	struct cdk2_bds_option option;
	UINTN item_count, index, page_start = 0U, selection, size;
	BOOLEAN setup_item, has_next;
	EFI_STATUS status;

	if (resume_index != NULL)
		*resume_index = 0U;
	if (menu_presented != NULL)
		*menu_presented = FALSE;
	if (request_consumed != NULL)
		*request_consumed = FALSE;

	status = active_system->boot->locate_protocol(&lvgl_ui_guid, NULL,
		(void **)&ui);
	if (EFI_ERROR(status) || ui == NULL || ui->show_menu == NULL)
		return EFI_UNSUPPORTED;
	do {
		BOOLEAN advance_page = FALSE;

		item_count = 0U;
		selection = MAX_UINTN;
		if (consume_fw_ui && !native_setup_surface_available(ui))
			return EFI_UNSUPPORTED;
		setup_item = native_setup_surface_available(ui);
		for (index = page_start; index < count && item_count <
		    ARRAY_SIZE(items) - (setup_item ? 1U : 0U) - 1U; index++) {
			size = 0;
			status = boot_option_variable(order[index],
				&option_data[item_count], &size);
			if (EFI_ERROR(status) || EFI_ERROR(cdk2_bds_parse_option(
				option_data[item_count], size, &option)) ||
			    (option.attributes & LOAD_OPTION_ACTIVE) == 0) {
				if (option_data[item_count] != NULL)
					active_system->boot->free_pool(option_data[item_count]);
				option_data[item_count] = NULL;
				continue;
			}
			items[item_count].label = option.description;
			items[item_count].disabled = FALSE;
			option_numbers[item_count] = order[index];
			option_indexes[item_count] = index;
			item_count++;
		}
		has_next = index < count;
		if (has_next) {
			items[item_count].label = next_label;
			items[item_count].disabled = FALSE;
		}
		if (setup_item) {
			items[item_count + has_next].label = setup_label;
			items[item_count + has_next].disabled = FALSE;
		}
		status = item_count == 0U && !has_next && !setup_item ? EFI_NOT_FOUND :
			ui->show_menu(ui, title, items,
				item_count + has_next + setup_item, &selection);
		if (!EFI_ERROR(status)) {
			if (menu_presented != NULL)
				*menu_presented = TRUE;
			if (consume_fw_ui) {
				status = consume_os_indication(OS_INDICATIONS_BOOT_TO_FW_UI);
				if (!EFI_ERROR(status))
					consume_fw_ui = FALSE;
				if (!consume_fw_ui && request_consumed != NULL)
					*request_consumed = TRUE;
			}
		}
		if (!EFI_ERROR(status) && selection < item_count) {
			status = boot_number(option_numbers[selection], TRUE);
			if (resume_index != NULL)
				*resume_index = option_indexes[selection] + 1U;
			status = EFI_ABORTED;
		} else if (!EFI_ERROR(status) && has_next && selection == item_count) {
			page_start = index;
			advance_page = TRUE;
		} else if (!EFI_ERROR(status) && setup_item &&
		    selection == item_count + has_next) {
			struct setup_poll_context poll_context;
			EFI_STATUS poll_start_status;
			struct cdk2_lvgl_ui_protocol *poll_ui =
				begin_setup_poll(ui, &poll_context, NULL, NULL,
					&poll_start_status);

			if (EFI_ERROR(poll_start_status))
				status = poll_start_status;
			else
				status = browse_setup(ui);
			{
				EFI_STATUS poll_status = end_setup_poll(poll_ui);
				if ((status == EFI_SUCCESS || status == EFI_ABORTED) &&
				    EFI_ERROR(poll_status))
					status = poll_status;
			}
		} else if (!EFI_ERROR(status)) {
			status = EFI_NOT_FOUND;
		}
		for (index = 0; index < item_count; index++) {
			active_system->boot->free_pool(option_data[index]);
			option_data[index] = NULL;
		}
		if (!advance_page)
			break;
	} while (TRUE);
	return status;
}

static void connect_all(void)
{
	void **handles = NULL;
	UINTN count = 0, index;
	UINTN search = LOCATE_ALL_HANDLES;
	const EFI_GUID *protocol = NULL;

	if (!CONFIG_CDK2_CONNECT_ALL_DEVICES)
		return;

	if (EFI_ERROR(active_system->boot->locate_handle_buffer(
		search, protocol, NULL, &count, &handles)))
		return;
	for (index = 0; index < count; index++) {
		EFI_STATUS connect_status =
			active_system->boot->connect_controller(handles[index],
				NULL, NULL, TRUE);

		cdk2_diag_value(CDK2_DIAG_BDS, "connect-all handle",
			(UINTN)handles[index]);
		cdk2_diag_emit(EFI_ERROR(connect_status) ? CDK2_DIAG_DEBUG :
			CDK2_DIAG_INFO, CDK2_DIAG_BDS, 0x1336U,
			connect_status);
	}
	active_system->boot->free_pool(handles);
}

struct block_media_view {
	UINT32 media_id;
	BOOLEAN removable_media;
};
struct block_io_view { UINT64 revision; struct block_media_view *media; };

static EFI_STATUS make_file_path(void *handle, const CHAR16 *file,
	UINT8 **path_out, UINTN *size_out)
{
	const UINT8 *parent;
	UINT8 *path;
	UINTN parent_size, chars = 0, node_size, total, index;
	EFI_STATUS status;

	status = active_system->boot->handle_protocol(handle, &path_guid,
		(void **)&parent);
	if (EFI_ERROR(status) || (parent_size = path_size(parent)) < 4)
		return EFI_NOT_FOUND;
	while (file[chars] != 0)
		chars++;
	node_size = 4 + (chars + 1) * sizeof(CHAR16);
	if (node_size > MAX_UINT16 || parent_size - 4 > MAX_UINTN - node_size - 4)
		return EFI_OUT_OF_RESOURCES;
	total = parent_size - 4 + node_size + 4;
	status = active_system->boot->allocate_pool(4, total, (void **)&path);
	if (EFI_ERROR(status))
		return status;
	memcpy(path, parent, parent_size - 4);
	index = parent_size - 4;
	path[index] = MEDIA_DEVICE_PATH;
	path[index + 1] = FILE_PATH_SUBTYPE;
	path[index + 2] = (UINT8)node_size;
	path[index + 3] = (UINT8)(node_size >> 8);
	memcpy(path + index + 4, file, (chars + 1) * sizeof(CHAR16));
	index += node_size;
	path[index] = END_DEVICE_PATH;
	path[index + 1] = END_ENTIRE;
	path[index + 2] = 4;
	path[index + 3] = 0;
	*path_out = path;
	*size_out = total;
	return EFI_SUCCESS;
}

static EFI_STATUS append_file_path(void *handle, const CHAR16 *file)
{
	UINT8 *path = NULL;
	UINTN size;
	EFI_STATUS status = make_file_path(handle, file, &path, &size);

#ifdef CDK2_DEBUG
	cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1336U,
		EFI_ERROR(status) ? status : size);
#endif
	(void)size;
	if (EFI_ERROR(status))
		return status;
	status = launch_path(path, NULL, 0, FALSE, TRUE);
	active_system->boot->free_pool(path);
	return status;
}

static EFI_STATUS removable_fallback(void)
{
	static const CHAR16 fallback[] = { '\\', 'E', 'F', 'I', '\\', 'B', 'O',
		'O', 'T', '\\', 'B', 'O', 'O', 'T', 'X', '6', '4', '.', 'E', 'F',
		'I', 0 };
	void **handles = NULL;
	UINTN count = 0, index;
	EFI_STATUS status;

	status = active_system->boot->locate_handle_buffer(LOCATE_BY_PROTOCOL,
		&simple_fs_guid, NULL, &count, &handles);
	if (EFI_ERROR(status))
		return status;
	status = EFI_NOT_FOUND;
	for (index = 0; index < count && EFI_ERROR(status); index++) {
		struct block_io_view *block;

		if (EFI_ERROR(active_system->boot->handle_protocol(handles[index],
			&block_io_guid, (void **)&block)) || block == NULL ||
		    block->media == NULL || !block->media->removable_media)
			continue;
		status = append_file_path(handles[index], fallback);
	}
	active_system->boot->free_pool(handles);
	return status;
}

static EFI_STATUS fixed_fallback(void)
{
	static const CHAR16 fallback[] = { '\\', 'E', 'F', 'I', '\\', 'B', 'O',
		'O', 'T', '\\', 'B', 'O', 'O', 'T', 'X', '6', '4', '.', 'E', 'F',
		'I', 0 };
	void **handles = NULL;
	UINTN count = 0, index;
	EFI_STATUS status;

	status = active_system->boot->locate_handle_buffer(LOCATE_BY_PROTOCOL,
		&simple_fs_guid, NULL, &count, &handles);
#ifdef CDK2_DEBUG
	cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1337U,
		EFI_ERROR(status) ? status : count);
#endif
	if (EFI_ERROR(status))
		return status;
	status = EFI_NOT_FOUND;
	for (index = 0; index < count && EFI_ERROR(status); index++) {
		struct block_io_view *block;
		EFI_STATUS block_status;

#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1338U, index);
#endif
		block_status = active_system->boot->handle_protocol(handles[index],
			&block_io_guid, (void **)&block);
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x1339U,
			EFI_ERROR(block_status) ? block_status :
			(block != NULL && block->media != NULL ?
			 block->media->removable_media : MAX_UINT64));
#endif
		if (EFI_ERROR(block_status) || block == NULL ||
		    block->media == NULL || block->media->removable_media)
			continue;
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x133aU, index);
#endif
		status = append_file_path(handles[index], fallback);
#ifdef CDK2_DEBUG
		cdk2_diag_emit(CDK2_DIAG_DEBUG, CDK2_DIAG_BDS, 0x133bU, status);
#endif
	}
	active_system->boot->free_pool(handles);
	return status;
}

static EFI_STATUS shell_fallback(void)
{
	void **handles = NULL;
	const UINT8 *parent;
	UINT8 *path;
	UINTN count = 0, index, parent_size, total;
	EFI_STATUS status;

	status = active_system->boot->locate_handle_buffer(LOCATE_BY_PROTOCOL,
		&fv2_guid, NULL, &count, &handles);
	if (EFI_ERROR(status))
		return status;
	status = EFI_NOT_FOUND;
	for (index = 0; index < count && EFI_ERROR(status); index++) {
		if (EFI_ERROR(active_system->boot->handle_protocol(handles[index],
			&path_guid, (void **)&parent)) ||
		    (parent_size = path_size(parent)) < 4)
			continue;
		total = parent_size - 4 + 20 + 4;
		if (EFI_ERROR(active_system->boot->allocate_pool(4, total,
			(void **)&path)))
			continue;
		memcpy(path, parent, parent_size - 4);
		path[parent_size - 4] = MEDIA_DEVICE_PATH;
		path[parent_size - 3] = FV_FILE_SUBTYPE;
		path[parent_size - 2] = 20;
		path[parent_size - 1] = 0;
		memcpy(path + parent_size, &shell_guid, sizeof(shell_guid));
		path[parent_size + 16] = END_DEVICE_PATH;
		path[parent_size + 17] = END_ENTIRE;
		path[parent_size + 18] = 4;
		path[parent_size + 19] = 0;
		status = launch_path(path, NULL, 0, FALSE, TRUE);
		active_system->boot->free_pool(path);
		/* Any returned shell attempt failed to transfer control permanently. */
		status = EFI_NOT_FOUND;
	}
	active_system->boot->free_pool(handles);
	return status;
}

#if CONFIG_CDK2_SETUP_UI
static EFI_STATUS wait_for_setup_polled(UINTN seconds,
	bds_input_poll_fn *poll_input,
	void *poll_context, BOOLEAN *requested)
{
	struct input_key key;
	UINTN tick, ticks;

	if (requested == NULL || seconds > MAX_UINTN / 10U)
		return EFI_INVALID_PARAMETER;
	*requested = FALSE;
	if (seconds == 0U) {
		EFI_STATUS status;

		status = poll_input == NULL ? EFI_SUCCESS : poll_input(poll_context);
		if (EFI_ERROR(status))
			return status;
		if (active_system->console_in == NULL ||
		    active_system->console_in->read_key == NULL)
			return EFI_SUCCESS;
		for (size_t index = 0; index < SETUP_QUEUED_KEY_LIMIT; index++) {
			status = active_system->console_in->read_key(
				active_system->console_in, &key);
			if (EFI_ERROR(status))
				break;
			if (key.scan_code == SCAN_F2) {
				*requested = TRUE;
				break;
			}
		}
		return EFI_SUCCESS;
	}
	ticks = seconds * 10U;
	for (tick = 0; tick < ticks; tick++) {
		EFI_STATUS status;

		status = poll_input == NULL ? EFI_SUCCESS : poll_input(poll_context);
		if (EFI_ERROR(status))
			return status;
		if (active_system->console_in != NULL &&
		    active_system->console_in->read_key != NULL &&
		    !EFI_ERROR(active_system->console_in->read_key(
			active_system->console_in, &key))) {
			if (key.scan_code == SCAN_F2) {
				*requested = TRUE;
				return EFI_SUCCESS;
			}
		}
		if (EFI_ERROR(active_system->boot->stall(100000U)))
			return EFI_DEVICE_ERROR;
	}
	return EFI_SUCCESS;
}

static BOOLEAN wait_for_setup(UINTN seconds)
{
	BOOLEAN requested = FALSE;

	return wait_for_setup_polled(seconds, NULL, NULL, &requested) ==
		EFI_SUCCESS && requested;
}
#endif

static void drain_console_input(void)
{
	struct input_key key;

	if (active_system == NULL || active_system->console_in == NULL ||
	    active_system->console_in->read_key == NULL)
		return;
	while (!EFI_ERROR(active_system->console_in->read_key(
		active_system->console_in, &key)))
		;
}

EFI_STATUS CDK2_MS_ABI cdk2_bds_enter_setup(UINTN timeout_seconds,
	bds_input_poll_fn *poll_input, void *poll_context)
{
#if CONFIG_CDK2_SETUP_UI && CONFIG_CDK2_NATIVE_LVGL_SETUP
	struct cdk2_lvgl_ui_protocol *ui = NULL;
	struct cdk2_lvgl_ui_protocol *poll_ui;
	struct setup_poll_context setup_poll;
	BOOLEAN firmware_request, requested;
	EFI_STATUS status, poll_start_status;

	if (active_system == NULL || active_system->boot == NULL ||
	    active_system->boot->locate_protocol == NULL)
		return EFI_NOT_READY;
	status = active_system->boot->locate_protocol(&lvgl_ui_guid, NULL,
		(void **)&ui);
	if (EFI_ERROR(status) || !native_setup_surface_available(ui))
		status = EFI_UNSUPPORTED;
	cdk2_diag_phase("SetupForm", "available", status, 0U);
	if (EFI_ERROR(status))
		return status;
	status = publish_os_indications_support(TRUE);
	cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_WARN : CDK2_DIAG_INFO,
		CDK2_DIAG_BDS, CDK2_EVENT_BDS_OS_INDICATIONS_RESULT, status);
	if (EFI_ERROR(status))
		return status;
	firmware_request = os_indication(OS_INDICATIONS_BOOT_TO_FW_UI) != 0U;
	requested = firmware_request;
	status = EFI_SUCCESS;
	if (!requested) {
		cdk2_diag_phase("SetupHotkey", "wait", EFI_SUCCESS, timeout_seconds);
		status = wait_for_setup_polled(timeout_seconds, poll_input, poll_context,
			&requested);
		if (EFI_ERROR(status))
			return status;
	}
	if (!requested) {
		cdk2_diag_phase("SetupHotkey", "result", EFI_NOT_READY, 0U);
		return EFI_NOT_READY;
	}
	cdk2_diag_phase("SetupHotkey", "result", EFI_SUCCESS,
		firmware_request ? 0U : SCAN_F2);
	cdk2_diag_phase("SetupForm", "begin", EFI_SUCCESS, 0U);
	if (firmware_request)
		drain_console_input();
	poll_ui = begin_setup_poll(ui, &setup_poll, poll_input, poll_context,
		&poll_start_status);
	if (EFI_ERROR(poll_start_status))
		status = poll_start_status;
	else
		status = browse_setup(ui);
	{
		EFI_STATUS poll_status = end_setup_poll(poll_ui);
		if ((status == EFI_SUCCESS || status == EFI_ABORTED) &&
		    EFI_ERROR(poll_status))
			status = poll_status;
	}
	if (firmware_request && (status == EFI_SUCCESS || status == EFI_ABORTED)) {
		EFI_STATUS consume_status =
			consume_os_indication(OS_INDICATIONS_BOOT_TO_FW_UI);

		if (EFI_ERROR(consume_status))
			status = consume_status;
	}
	cdk2_diag_phase("SetupForm", "return", status, 0U);
	return status == EFI_ABORTED ? EFI_SUCCESS : status;
#else
	(void)timeout_seconds;
	(void)poll_input;
	(void)poll_context;
	return EFI_UNSUPPORTED;
#endif
}

static UINT64 os_indication(UINT64 bit)
{
	static CHAR16 indications_name[] = L"OsIndications";
	void *data = NULL;
	UINTN size = 0U;
	UINT64 value = 0U;
	BOOLEAN requested = FALSE;

	if (!EFI_ERROR(variable(indications_name, &data, &size)) &&
	    size == sizeof(value)) {
		value = *(UINT64 *)data;
		if ((value & bit) != 0U)
			requested = TRUE;
	}
	if (data != NULL)
		active_system->boot->free_pool(data);
	return requested ? bit : 0U;
}

static EFI_STATUS consume_os_indication(UINT64 bit)
{
	static CHAR16 name[] = L"OsIndications";
	void *data = NULL;
	UINTN size = 0U;
	UINT64 value;
	EFI_STATUS status;

	status = variable(name, &data, &size);
	if (EFI_ERROR(status))
		return status;
	if (size != sizeof(value)) {
		active_system->boot->free_pool(data);
		return EFI_COMPROMISED_DATA;
	}
	value = *(UINT64 *)data;
	active_system->boot->free_pool(data);
	if ((value & bit) == 0U)
		return EFI_SUCCESS;
	value &= ~bit;
	return active_system->runtime->set_variable(name, &global_guid,
		OS_INDICATIONS_ATTRIBUTES, sizeof(value), &value);
}

static void diagnose_storage_handles(const EFI_GUID *protocol, UINT32 event)
{
	void **handles = NULL;
	UINTN count = 0U;
	EFI_STATUS status;

	status = active_system->boot->locate_handle_buffer(LOCATE_BY_PROTOCOL,
		protocol, NULL, &count, &handles);
	cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_WARN : CDK2_DIAG_INFO,
		CDK2_DIAG_BDS, event, EFI_ERROR(status) ? status : count);
	if (handles != NULL)
		active_system->boot->free_pool(handles);
}

EFI_STATUS cdk2_bds_boot_once(void)
{
#ifdef CDK2_DEBUG
	cdk2_diag_message(CDK2_DIAG_BDS, "[CDK2][bds][info] boot selection begin");
#endif
	static const CHAR16 boot_next[] = { 'B', 'o', 'o', 't', 'N', 'e', 'x', 't', 0 };
	static const CHAR16 boot_order[] = { 'B', 'o', 'o', 't', 'O', 'r', 'd', 'e', 'r', 0 };
	void *data = NULL;
	UINTN size = 0, index = MAX_UINTN, boot_order_start = 0U;
	EFI_STATUS status, boot_status = EFI_NOT_FOUND, boot_order_status;
	BOOLEAN fw_ui_requested, menu_requested;
	BOOLEAN preserve_boot_next;
	BOOLEAN setup_capable, menu_presented = FALSE, request_consumed = FALSE;
	BOOLEAN boot_next_attempted = FALSE;

	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_BOOT_BEGIN, EFI_SUCCESS);

	setup_capable = native_setup_available();
	status = publish_os_indications_support(setup_capable);
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_OS_INDICATIONS_RESULT, status);
	status = active_system->boot->set_watchdog_timer(0, 0, 0, NULL);
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_WATCHDOG_RESULT, status);
	status = complete_memory_test();
	if (EFI_ERROR(status))
		return status;
	status = complete_dxe();
	if (EFI_ERROR(status))
		return status;
	preserve_boot_next = preserve_capsule_boot_next();
	check_low_battery_once();
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_CONNECT_ALL_BEGIN, EFI_SUCCESS);
	if (!CONFIG_CDK2_LINEAR_BOOT)
		connect_all();
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_CONNECT_ALL_END, EFI_SUCCESS);
	diagnose_storage_handles(&pci_io_guid, CDK2_EVENT_BDS_PCI_IO_HANDLES);
	diagnose_storage_handles(&block_io_guid, CDK2_EVENT_BDS_BLOCK_IO_HANDLES);
	diagnose_storage_handles(&disk_io_guid, CDK2_EVENT_BDS_DISK_IO_HANDLES);
	diagnose_storage_handles(&simple_fs_guid, CDK2_EVENT_BDS_SIMPLE_FS_HANDLES);
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_DRIVER_ORDER_BEGIN, EFI_SUCCESS);
	process_driver_order();
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_DRIVER_ORDER_END, EFI_SUCCESS);
	if (force_reconnect) {
		force_reconnect = FALSE;
		connect_all();
	}
	process_sysprep_order();
	fw_ui_requested = os_indication(OS_INDICATIONS_BOOT_TO_FW_UI) != 0U;
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_FW_UI_RESULT,
		fw_ui_requested ? EFI_SUCCESS : EFI_NOT_READY);
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_SETUP_WAIT_BEGIN, EFI_SUCCESS);
	menu_requested = fw_ui_requested && setup_capable;
#if CONFIG_CDK2_SETUP_UI
	menu_requested = menu_requested || (setup_capable &&
		wait_for_setup(CONFIG_CDK2_BOOT_TIMEOUT));
#endif
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_SETUP_WAIT_RESULT,
		menu_requested ? EFI_SUCCESS : EFI_NOT_READY);
	if (!menu_requested && !preserve_boot_next) {
		status = variable(boot_next, &data, &size);
		if (!EFI_ERROR(status) && size == sizeof(UINT16)) {
			status = active_system->runtime->set_variable((CHAR16 *)boot_next,
				&global_guid, 0, 0, NULL);
			if (!EFI_ERROR(status))
				boot_next_attempted = TRUE;
			if (!EFI_ERROR(status))
				status = boot_number(*(UINT16 *)data, TRUE);
		} else if (!EFI_ERROR(status))
			status = EFI_COMPROMISED_DATA;
		if (EFI_ERROR(status) && !boot_next_attempted && status != EFI_NOT_FOUND)
			cdk2_diag_emit(CDK2_DIAG_WARN, CDK2_DIAG_BDS,
				CDK2_EVENT_BDS_BOOTNEXT_FAILED, status);
		if (data != NULL)
			active_system->boot->free_pool(data);
	}
	/* A started image that returns did not boot the machine.  Continue with
	 * BootOrder rather than retrying the same returning image forever. */
	data = NULL;
	status = variable(boot_order, &data, &size);
	boot_order_status = status;
	if (menu_requested) {
		EFI_STATUS menu_status;

		if (fw_ui_requested)
			drain_console_input();
		menu_status = graphical_boot_order(
			!EFI_ERROR(status) && (size & 1U) == 0U ? data : NULL,
			!EFI_ERROR(status) && (size & 1U) == 0U ?
				size / sizeof(UINT16) : 0U, &boot_order_start,
			fw_ui_requested, &menu_presented, &request_consumed);

		if (fw_ui_requested &&
		    ((menu_presented && !request_consumed) ||
		     menu_status == EFI_UNSUPPORTED)) {
			if (data != NULL)
				active_system->boot->free_pool(data);
			return menu_status;
		}

		if (!EFI_ERROR(menu_status)) {
			cdk2_diag_emit(CDK2_DIAG_WARN, CDK2_DIAG_BDS,
				CDK2_EVENT_BDS_MENU_RETURN, menu_status);
			if (data != NULL)
				active_system->boot->free_pool(data);
			return EFI_SUCCESS;
		}
	}
	if (!EFI_ERROR(status) && (size & 1U) == 0)
		for (index = boot_order_start; index < size / sizeof(UINT16); index++)
			boot_status = boot_number(((UINT16 *)data)[index], FALSE);
	else if (!EFI_ERROR(status))
		status = EFI_COMPROMISED_DATA;
	if (data != NULL)
		active_system->boot->free_pool(data);
	cdk2_diag_emit(CDK2_DIAG_WARN, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_BOOTORDER_FAILED,
		EFI_ERROR(status) ? status : boot_status);
	status = removable_fallback();
	if (!EFI_ERROR(status)) {
		cdk2_diag_emit(CDK2_DIAG_WARN, CDK2_DIAG_BDS,
			CDK2_EVENT_BDS_REMOVABLE_RETURN, status);
	} else
		cdk2_diag_emit(CDK2_DIAG_WARN, CDK2_DIAG_BDS,
			CDK2_EVENT_BDS_REMOVABLE_FAILED, status);
	/* Refresh the standard fixed-media fallback when no persisted BootOrder is
	 * visible, as EDK2 does after enumerating boot devices.  An unsupported
	 * variable service needs the same recovery route. */
	if (boot_order_status == EFI_NOT_FOUND ||
	    boot_order_status == EFI_UNSUPPORTED) {
		status = fixed_fallback();
		cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_WARN : CDK2_DIAG_INFO,
			CDK2_DIAG_BDS, CDK2_EVENT_BDS_FIXED_FALLBACK_RESULT, status);
		if (!EFI_ERROR(status)) {
			cdk2_diag_emit(CDK2_DIAG_WARN, CDK2_DIAG_BDS,
				CDK2_EVENT_BDS_FIXED_RETURN, status);
			return EFI_SUCCESS;
		}
	}
	status = shell_fallback();
	if (EFI_ERROR(status)) {
#ifdef CDK2_DEBUG
		cdk2_diag_message(CDK2_DIAG_BDS, "[CDK2][bds][error] fallback exhausted");
#endif
		cdk2_diag_emit(CDK2_DIAG_ERROR, CDK2_DIAG_BDS,
			CDK2_EVENT_BDS_SHELL_FAILED, status);
	}
	cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_ERROR : CDK2_DIAG_WARN,
		CDK2_DIAG_BDS, CDK2_EVENT_BDS_FINAL_RETURN, status);
	return status;
}

static void CDK2_MS_ABI bds_entry(void *ignored)
{
	(void)ignored;
	/* The BDS architectural protocol must never return to DXE Core.  A failed
	 * pass reconnects devices and retries so newly inserted recovery media can
	 * become bootable without resetting the machine. */
	for (;;) {
		EFI_STATUS status = cdk2_bds_boot_once();

		cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_ERROR : CDK2_DIAG_WARN,
			CDK2_DIAG_BDS, CDK2_EVENT_BDS_BOOT_PASS_RETURN, status);
#ifdef CDK2_DEBUG
		/* The debug policy is a single complete pass.  Freeze without dispatching
		 * timer callbacks or reconnecting devices, preserving the final ledger. */
		for (;;)
			__asm__ __volatile__("" ::: "memory");
#else
		/* Any returned pass failed to transfer control permanently.  Rate-limit
		 * both error and nominal returns so a returning image cannot turn BDS
		 * into a tight reconnect loop. */
		(void)active_system->boot->stall(1000000U);
#endif
	}
}

EFI_STATUS CDK2_MS_ABI cdk2_bds_entry(void *image, void *system_table)
{
	struct system_table *table = system_table;
	EFI_STATUS status;

	if (image == NULL || table == NULL || table->boot == NULL ||
	    table->runtime == NULL || table->runtime->get_variable == NULL ||
	    table->runtime->set_variable == NULL ||
#if CONFIG_CDK2_CAPSULE
	    table->runtime->get_next_variable_name == NULL ||
#endif
	    table->boot->allocate_pool == NULL || table->boot->free_pool == NULL ||
	    table->boot->handle_protocol == NULL ||
	    table->boot->signal_event == NULL || table->boot->close_event == NULL ||
	    table->boot->create_event_ex == NULL ||
	    table->boot->load_image == NULL || table->boot->start_image == NULL ||
	    table->boot->unload_image == NULL ||
	    table->boot->set_watchdog_timer == NULL ||
	    table->boot->stall == NULL ||
	    table->boot->connect_controller == NULL ||
	    table->boot->locate_handle_buffer == NULL ||
	    table->boot->locate_protocol == NULL ||
	    table->boot->install_multiple == NULL)
		return EFI_INVALID_PARAMETER;
	if (table->table_count != 0U && table->tables == NULL)
		return EFI_INVALID_PARAMETER;
	active_system = table;
	current_boot_mode = BOOT_WITH_FULL_CONFIGURATION;
	for (UINTN index = 0U; index < table->table_count; index++) {
		if (bytes_equal((const UINT8 *)&table->tables[index].guid,
		    (const UINT8 *)&hob_list_guid, sizeof(hob_list_guid))) {
			EFI_HOB_HANDOFF_INFO_TABLE *handoff =
				table->tables[index].table;

			if (EFI_ERROR(cdk2_hob_list_validate(handoff)))
				return EFI_COMPROMISED_DATA;
			current_boot_mode = handoff->boot_mode;
			(void)cdk2_diag_configure_hob(handoff);
			break;
		}
	}
	cdk2_diag_emit(CDK2_DIAG_INFO, CDK2_DIAG_BDS,
		CDK2_EVENT_BDS_DRIVER_ENTRY, EFI_SUCCESS);
#if CONFIG_CDK2_SECURE_BOOT
	{
		struct cdk2_runtime_services_view secure_runtime = { 0 };
		struct cdk2_boot_services_view secure_boot = { 0 };
		EFI_STATUS secure_status;

		secure_runtime.set_variable = (void *)table->runtime->set_variable;
		secure_boot.allocate_pool = (void *)table->boot->allocate_pool;
		secure_boot.free_pool = (void *)table->boot->free_pool;
		secure_status = cdk2_secure_boot_publish_defaults(&secure_runtime,
			&secure_boot);
		if (EFI_ERROR(secure_status))
			cdk2_diag_message_status(CDK2_DIAG_BDS,
				"Secure Boot defaults", secure_status);
	}
#endif
	driver_handle = image;
	protocol.entry = bds_entry;
	protocol.boot_next_pending = bds_boot_next_pending;
	protocol.enter_setup = cdk2_bds_enter_setup;
	status = active_system->boot->install_multiple(&driver_handle, &bds_guid, &protocol,
		NULL);
	cdk2_diag_emit(EFI_ERROR(status) ? CDK2_DIAG_ERROR : CDK2_DIAG_INFO,
		CDK2_DIAG_BDS, CDK2_EVENT_BDS_PROTOCOL_READY, status);
	if (!EFI_ERROR(status)) {
		EFI_STATUS support_status = publish_os_indications_support(
			native_setup_available());

		cdk2_diag_emit(EFI_ERROR(support_status) ? CDK2_DIAG_WARN :
			CDK2_DIAG_INFO, CDK2_DIAG_BDS,
			CDK2_EVENT_BDS_OS_INDICATIONS_RESULT, support_status);
	}
	return status;
}
