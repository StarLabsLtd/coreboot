/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#include <cdk2/diagnostic.h>
#include <cdk2/config.h>
#include <cdk2/hob.h>
#include <pi/hob.h>

const EFI_GUID cdk2_diag_handoff_guid = { 0xb8632d8e, 0x4f85, 0x4b9f,
	{ 0x91, 0x67, 0x86, 0xd7, 0xe5, 0x72, 0x93, 0xa1 } };

enum {
	diagnostic_owner_is_aligned =
		1 / !!((OFFSET_OF(struct cdk2_diag_handoff, emission_owner) & 7U) == 0U),
	diagnostic_handoff_is_aligned =
		1 / !!((sizeof(struct cdk2_diag_handoff) & 7U) == 0U),
};

static struct cdk2_diag_config active;
static void configure_active(const struct cdk2_diag_config *config,
	BOOLEAN preserve_cbmem);
static UINT64 emitting_owner;
static BOOLEAN emission_acquired;
static UINT64 acquired_owner;
static struct cdk2_diag_handoff local_handoff;
static BOOLEAN physical_sinks_retired;
static UINT8 spi_console_record[256];
static UINTN spi_console_record_bytes;
static UINT32 spi_console_local_remaining;
static BOOLEAN spi_console_record_enabled;
static BOOLEAN spi_console_record_critical;
static BOOLEAN spi_console_record_suppressed;
static const char *level_name(enum cdk2_diag_level level);

uint64_t cdk2_diag_now(void)
{
	return active.clock == NULL ? 0U : active.clock(active.clock_context);
}

#if CONFIG_CDK2_SPI_CONSOLE
#define CDK2_DIAG_SPI_CONSOLE_ENABLED 1
#else
#define CDK2_DIAG_SPI_CONSOLE_ENABLED 0
#endif

#define SPI_CONSOLE_SIGNATURE 0x434c5053U
#define SPI_CONSOLE_VERSION 1U
#define SPI_CONSOLE_PENDING 0U
#define SPI_CONSOLE_SUCCESS 1U
/* coreboot bounds this payload's per-boot SPI writes independently of the
 * flash region size. Leave room for terminal phases and failures; UART and
 * CBMEM continue to receive every record when ordinary SPI detail is skipped. */
#define CDK2_DIAG_SPI_CONSOLE_RESERVE (8U * 1024U)

struct spi_console_request {
	UINT32 signature;
	UINT16 version;
	UINT16 header_size;
	UINT16 length;
	UINT16 flags;
	volatile UINT32 status;
	UINT8 data[];
} __packed;

_Static_assert(sizeof(struct spi_console_request) == 16U,
	"SPI-console request ABI size changed");
_Static_assert(OFFSET_OF(struct spi_console_request, status) == 12U,
	"SPI-console request status offset changed");

#if defined(CDK2_DIAG_UNIT_TEST)
static UINT32 spi_console_test_status = SPI_CONSOLE_SUCCESS;
static void (*release_test_hook)(void *context);
static void *release_test_context;

void cdk2_diag_test_spi_status(UINT32 status)
{
	spi_console_test_status = status;
}
#endif

static BOOLEAN direct_serial_allowed(BOOLEAN debug, BOOLEAN cbmem_configured)
{
	return debug || !cbmem_configured;
}

static EFI_STATUS cbmem_console_validate(const struct cdk2_cbmem_console *console,
	UINTN total_bytes)
{
	UINT32 cursor;
	UINT32 size;

	if (console == NULL || ((UINTN)console & (sizeof(UINT32) - 1U)) != 0U ||
	    total_bytes <= sizeof(*console) ||
	    total_bytes > sizeof(*console) + CDK2_CBMEM_CONSOLE_MAX_SIZE)
		return EFI_INVALID_PARAMETER;

	size = __atomic_load_n(&console->size, __ATOMIC_ACQUIRE);
	cursor = __atomic_load_n(&console->cursor, __ATOMIC_ACQUIRE);
	if (size == 0U || size > CDK2_CBMEM_CONSOLE_CURSOR_MASK ||
	    size != total_bytes - sizeof(*console) ||
	    (cursor & CDK2_CBMEM_CONSOLE_CURSOR_MASK) > size)
		return EFI_COMPROMISED_DATA;

	return EFI_SUCCESS;
}

static UINTN cbmem_console_write(struct cdk2_cbmem_console *console,
	UINTN total_bytes, const void *buffer, UINTN count)
{
	const UINT8 *bytes = buffer;
	UINT32 cursor;
	UINT32 flags;
	UINT32 next;
	UINT32 position;
	UINT32 size;
	UINTN written;

	if (buffer == NULL || count == 0U ||
	    EFI_ERROR(cbmem_console_validate(console, total_bytes)))
		return 0U;

	size = __atomic_load_n(&console->size, __ATOMIC_RELAXED);
	for (written = 0U; written < count; written++) {
		cursor = __atomic_load_n(&console->cursor, __ATOMIC_ACQUIRE);
		position = cursor & CDK2_CBMEM_CONSOLE_CURSOR_MASK;
		if (position > size)
			return written;

		flags = cursor & ~CDK2_CBMEM_CONSOLE_CURSOR_MASK;
		/* coreboot permits cursor == size until the following byte.  That
		 * byte starts the wrapped generation at offset zero. */
		if (position == size) {
			position = 0U;
			flags |= CDK2_CBMEM_CONSOLE_OVERFLOW;
		}
		next = flags | (position + 1U);

		/* Match coreboot's byte-then-cursor publication order. begin_emit()
		 * serializes each diagnostic record and suppresses recursive writers. */
		__atomic_store_n(&console->body[position], bytes[written], __ATOMIC_RELEASE);
		__atomic_store_n(&console->cursor, next, __ATOMIC_RELEASE);
	}

	return written;
}

static UINT64 x86_owner_token(UINT32 topology_ebx, UINT32 topology_ecx,
	UINT32 topology_edx, BOOLEAN amd_extended, UINT32 amd_eax,
	UINT32 legacy_ebx)
{
	if ((topology_ebx & 0xffffU) != 0U &&
	    ((topology_ecx >> 8) & 0xffU) != 0U)
		return (UINT64)topology_edx + 1U;
	if (amd_extended)
		return (UINT64)amd_eax + 1U;
	return ((UINT64)(legacy_ebx >> 24) & 0xffU) + 1U;
}

static UINT64 default_owner(void)
{
#if defined(__x86_64__)
	UINT32 eax;
	UINT32 ebx;
	UINT32 ecx;
	UINT32 edx;
	UINT32 leaf;
	UINT32 maximum;
	UINT32 extended_maximum;

	__asm__ volatile ("cpuid" : "=a"(maximum), "=b"(ebx), "=c"(ecx),
		"=d"(edx) : "a"(0U), "c"(0U));
	leaf = maximum >= 0x1fU ? 0x1fU : 0x0bU;
	if (maximum >= leaf) {
		__asm__ volatile ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx),
			"=d"(edx) : "a"(leaf), "c"(0U));
		if ((ebx & 0xffffU) != 0U && ((ecx >> 8) & 0xffU) != 0U)
			return x86_owner_token(ebx, ecx, edx, FALSE, 0U, 0U);
	}
	if (leaf != 0x0bU && maximum >= 0x0bU) {
		__asm__ volatile ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx),
			"=d"(edx) : "a"(0x0bU), "c"(0U));
		if ((ebx & 0xffffU) != 0U && ((ecx >> 8) & 0xffU) != 0U)
			return x86_owner_token(ebx, ecx, edx, FALSE, 0U, 0U);
	}
	__asm__ volatile ("cpuid" : "=a"(extended_maximum), "=b"(ebx),
		"=c"(ecx), "=d"(edx) : "a"(0x80000000U), "c"(0U));
	if (extended_maximum >= 0x8000001eU) {
		__asm__ volatile ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx),
			"=d"(edx) : "a"(0x8000001eU), "c"(0U));
		return x86_owner_token(0U, 0U, 0U, TRUE, eax, 0U);
	}
	__asm__ volatile ("cpuid" : "=a"(eax), "=b"(ebx), "=c"(ecx),
		"=d"(edx) : "a"(1U), "c"(0U));
	return x86_owner_token(0U, 0U, 0U, FALSE, 0U, ebx);
#else
	/* Native CDK2 currently enters diagnostics on one execution context on
	 * non-x86 targets. Platforms adding concurrent callers must supply owner. */
	return 1U;
#endif
}

static UINT64 current_owner(void)
{
	UINT64 owner = active.owner == NULL ?
		default_owner() : active.owner(active.owner_context);

	return owner == 0U ? 1U : owner;
}

static BOOLEAN begin_emit(BOOLEAN critical)
{
	UINT64 owner = current_owner();
	UINT64 expected;
	volatile UINT64 *shared_owner = active.emission_owner == NULL ?
		&emitting_owner : active.emission_owner;

	for (;;) {
		expected = __atomic_load_n(shared_owner, __ATOMIC_ACQUIRE);
		if (expected == owner)
			return FALSE;
		expected = 0U;
		if (__atomic_compare_exchange_n(shared_owner, &expected, owner,
						FALSE, __ATOMIC_ACQUIRE, __ATOMIC_RELAXED)) {
			emission_acquired = TRUE;
			acquired_owner = owner;
			spi_console_record_critical = critical;
			spi_console_record_suppressed = FALSE;
			spi_console_record_enabled = TRUE;
#if CDK2_DIAG_SPI_CONSOLE_ENABLED
			if (!critical && active.spi_console_remaining != NULL &&
			    __atomic_load_n(active.spi_console_remaining,
				    __ATOMIC_ACQUIRE) <= CDK2_DIAG_SPI_CONSOLE_RESERVE) {
				spi_console_record_enabled = FALSE;
				spi_console_record_suppressed = TRUE;
			}
#endif
			return TRUE;
		}
#if defined(__x86_64__)
		__asm__ volatile ("pause");
#endif
	}
}

static BOOLEAN spi_console_flush(void)
{
#if CDK2_DIAG_SPI_CONSOLE_ENABLED
	struct spi_console_request *request = active.spi_console_buffer;
	volatile UINT32 *remaining = active.spi_console_remaining;
	UINT32 budget;

	if (spi_console_record_bytes == 0U)
		return TRUE;
	if (spi_console_record_suppressed) {
		spi_console_record_bytes = 0U;
		return TRUE;
	}
	if (remaining == NULL)
		return FALSE;
	budget = __atomic_load_n(remaining, __ATOMIC_ACQUIRE);
	if (!spi_console_record_critical &&
	    (budget <= CDK2_DIAG_SPI_CONSOLE_RESERVE ||
	     spi_console_record_bytes > budget - CDK2_DIAG_SPI_CONSOLE_RESERVE)) {
		spi_console_record_bytes = 0U;
		spi_console_record_enabled = FALSE;
		spi_console_record_suppressed = TRUE;
		return TRUE;
	}
	if (request == NULL || spi_console_record_bytes > active.spi_console_max_chunk ||
	    spi_console_record_bytes > budget ||
	    sizeof(*request) + spi_console_record_bytes >
		active.spi_console_buffer_bytes)
		return FALSE;

	request->signature = SPI_CONSOLE_SIGNATURE;
	request->version = SPI_CONSOLE_VERSION;
	request->header_size = sizeof(*request);
	request->length = (UINT16)spi_console_record_bytes;
	request->flags = 0U;
	request->status = SPI_CONSOLE_PENDING;
	for (UINTN index = 0U; index < spi_console_record_bytes; index++)
		request->data[index] = spi_console_record[index];
	__atomic_thread_fence(__ATOMIC_RELEASE);
#if defined(CDK2_DIAG_UNIT_TEST)
	request->status = spi_console_test_status;
#elif defined(__x86_64__)
	__asm__ volatile ("outb %0, %w1" : : "a"(active.spi_console_apm_cmd),
		"Nd"((UINT16)0xb2U) : "memory");
#else
	return FALSE;
#endif
	__atomic_thread_fence(__ATOMIC_ACQUIRE);
	if (request->status != SPI_CONSOLE_SUCCESS)
		return FALSE;
	__atomic_store_n(remaining, budget - spi_console_record_bytes, __ATOMIC_RELEASE);
	spi_console_record_bytes = 0U;
	return TRUE;
#else
	return FALSE;
#endif
}

static size_t diagnostic_text_length(const char *text)
{
	size_t length = 0U;

	while (text != NULL && text[length] != '\0')
		length++;
	return length;
}

static size_t diagnostic_length_add(size_t length, size_t addition)
{
	return addition > MAX_UINTN - length ? MAX_UINTN : length + addition;
}

static size_t diagnostic_decimal_length(uint64_t value)
{
	size_t length = 1U;

	while (value >= 10U && length < sizeof(uint64_t) * 8U) {
		value /= 10U;
		length++;
	}
	return length;
}

static void spi_console_prepare_record(size_t length)
{
#if CDK2_DIAG_SPI_CONSOLE_ENABLED
	UINT32 budget;

	if (!spi_console_record_enabled || spi_console_record_suppressed)
		return;
	if (active.spi_console_buffer == NULL || active.spi_console_remaining == NULL)
		return;
	budget = __atomic_load_n(active.spi_console_remaining, __ATOMIC_ACQUIRE);
	if (length > budget)
		goto suppress;
	if (!spi_console_record_critical && (budget <= CDK2_DIAG_SPI_CONSOLE_RESERVE ||
	    length > budget - CDK2_DIAG_SPI_CONSOLE_RESERVE))
		goto suppress;
	return;

suppress:
	spi_console_record_enabled = FALSE;
	spi_console_record_suppressed = TRUE;
#else
	(void)length;
#endif
}

static size_t diagnostic_record_length(enum cdk2_diag_level level)
{
	size_t length = 1U;

	length = diagnostic_length_add(length, diagnostic_text_length(level_name(level)));
	length = diagnostic_length_add(length, sizeof("] CDK2:m=") - 1U);
	length = diagnostic_length_add(length, 2U);
	length = diagnostic_length_add(length, sizeof(":e=") - 1U);
	length = diagnostic_length_add(length, 4U);
	length = diagnostic_length_add(length, sizeof(":status=") - 1U);
	length = diagnostic_length_add(length, sizeof(EFI_STATUS) * 2U);
	return diagnostic_length_add(length, 1U);
}

static void end_emit(void)
{
	UINT64 owner;
	volatile UINT64 *shared_owner = active.emission_owner == NULL ?
		&emitting_owner : active.emission_owner;

	if (!emission_acquired)
		return;
	if (!spi_console_flush()) {
		active.spi_console_buffer = NULL;
		spi_console_record_bytes = 0U;
	}
	spi_console_record_enabled = FALSE;
	spi_console_record_critical = FALSE;
	spi_console_record_suppressed = FALSE;
	owner = acquired_owner;
	emission_acquired = FALSE;
	acquired_owner = 0U;
	(void)__atomic_compare_exchange_n(shared_owner, &owner, 0U, FALSE,
		__ATOMIC_RELEASE, __ATOMIC_RELAXED);
#if defined(CDK2_DIAG_UNIT_TEST)
	if (release_test_hook != NULL) {
		void (*hook)(void *context) = release_test_hook;
		void *context = release_test_context;

		release_test_hook = NULL;
		release_test_context = NULL;
		hook(context);
	}
#endif
}

#if defined(CDK2_DIAG_UNIT_TEST)
EFI_STATUS cdk2_diag_test_cbmem_validate(
	const struct cdk2_cbmem_console *console, UINTN total_bytes)
{
	return cbmem_console_validate(console, total_bytes);
}

UINTN cdk2_diag_test_cbmem_write(struct cdk2_cbmem_console *console,
	UINTN total_bytes, const void *buffer, UINTN count)
{
	return cbmem_console_write(console, total_bytes, buffer, count);
}

BOOLEAN cdk2_diag_test_acquire_owner(volatile UINT64 *shared_owner, UINT64 owner)
{
	UINT64 expected = 0U;

	if (shared_owner == NULL || owner == 0U ||
	    __atomic_load_n(shared_owner, __ATOMIC_ACQUIRE) == owner)
		return FALSE;
	return __atomic_compare_exchange_n(shared_owner, &expected, owner, FALSE,
		__ATOMIC_ACQUIRE, __ATOMIC_RELAXED);
}

void cdk2_diag_test_release_owner(volatile UINT64 *shared_owner, UINT64 owner)
{
	if (shared_owner != NULL && owner != 0U)
		(void)__atomic_compare_exchange_n(shared_owner, &owner, 0U, FALSE,
			__ATOMIC_RELEASE, __ATOMIC_RELAXED);
}

void cdk2_diag_test_set_release_hook(void (*hook)(void *context), void *context)
{
	release_test_hook = hook;
	release_test_context = context;
}

void cdk2_diag_test_set_putc(cdk2_diag_putc_fn putc, void *context)
{
	active.putc = putc;
	active.putc_context = context;
}

BOOLEAN cdk2_diag_test_direct_serial_allowed(BOOLEAN debug,
	BOOLEAN cbmem_configured)
{
	return direct_serial_allowed(debug, cbmem_configured);
}

UINT64 cdk2_diag_test_x86_owner_token(UINT32 topology_ebx,
	UINT32 topology_ecx, UINT32 topology_edx, BOOLEAN amd_extended,
	UINT32 amd_eax, UINT32 legacy_ebx)
{
	return x86_owner_token(topology_ebx, topology_ecx, topology_edx,
		amd_extended, amd_eax, legacy_ebx);
}
#endif

static BOOLEAN bytes_equal(const void *left, const void *right, UINTN size)
{
	const UINT8 *a = left;
	const UINT8 *b = right;

	while (size-- != 0U)
		if (*a++ != *b++)
			return FALSE;
	return TRUE;
}

static void bytes_copy(void *destination, const void *source, UINTN size)
{
	UINT8 *to = destination;
	const UINT8 *from = source;

	while (size-- != 0U)
		*to++ = *from++;
}

struct diagnostic_configuration_table {
	EFI_GUID guid;
	void *table;
};

struct diagnostic_system_table {
	UINT8 prefix[104];
	UINTN table_count;
	struct diagnostic_configuration_table *tables;
};

static const EFI_GUID hob_list_guid = { 0x7739f24c, 0x93d7, 0x11d4,
	{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };

EFI_STATUS cdk2_diag_configure_system_table(void *system_table)
{
	struct diagnostic_system_table *system = system_table;

	if (system == NULL || (system->table_count != 0U && system->tables == NULL))
		return EFI_INVALID_PARAMETER;
	for (UINTN index = 0U; index < system->table_count; index++)
		if (bytes_equal(&system->tables[index].guid, &hob_list_guid,
		    sizeof(hob_list_guid)))
			return cdk2_diag_configure_hob(system->tables[index].table);
	return EFI_NOT_FOUND;
}

static UINT8 mmio_read(const struct cdk2_diag_handoff *handoff, UINTN reg)
{
	UINTN address = (UINTN)handoff->register_base + reg * handoff->register_stride;

	if (handoff->register_width == 4U)
		return *(volatile uint32_t *)address;
	if (handoff->register_width == 2U)
		return *(volatile uint16_t *)address;
	return *(volatile UINT8 *)address;
}

static void mmio_write(const struct cdk2_diag_handoff *handoff, UINT8 value)
{
	UINTN address = (UINTN)handoff->register_base;

	if (handoff->register_width == 4U)
		*(volatile uint32_t *)address = value;
	else if (handoff->register_width == 2U)
		*(volatile uint16_t *)address = value;
	else
		*(volatile UINT8 *)address = value;
}

static void handoff_putc(char character, void *context)
{
	const struct cdk2_diag_handoff *handoff = context;
	UINTN timeout = 100000U;
	UINT8 ready;

	if (handoff->serial_type == CDK2_DIAG_SERIAL_PIO) {
#if defined(__x86_64__)
		UINT16 base = (UINT16)handoff->register_base;

		do {
			__asm__ volatile ("inb %w1, %0" : "=a"(ready) :
				"Nd"((UINT16)(base + 5U * handoff->register_stride)));
			if ((ready & 0x20U) != 0U)
				break;
		} while (timeout-- != 0U);
		if ((ready & 0x20U) != 0U)
			__asm__ volatile ("outb %0, %w1" : : "a"((UINT8)character),
				"Nd"(base));
#endif
		return;
	}
	do {
		ready = mmio_read(handoff, 5U);
		if ((ready & 0x20U) != 0U)
			break;
	} while (timeout-- != 0U);
	if ((ready & 0x20U) != 0U)
		mmio_write(handoff, (UINT8)character);
}

static uint64_t handoff_clock(void *context)
{
	UINT32 low, high;

	(void)context;
#if defined(__x86_64__)
	__asm__ volatile ("rdtsc" : "=a"(low), "=d"(high));
	return (UINT64)low | ((UINT64)high << 32);
#else
	return 0U;
#endif
}

EFI_STATUS cdk2_diag_configure_hob(void *hob_list)
{
	EFI_HOB_HANDOFF_INFO_TABLE *handoff = hob_list;
	EFI_HOB_GENERIC_HEADER *hob;
	UINTN end;

	if (EFI_ERROR(cdk2_hob_list_validate(handoff)))
		return EFI_COMPROMISED_DATA;
	hob = (void *)handoff;
	end = handoff->efi_end_of_hob_list;
	while ((UINTN)hob < end) {
		EFI_HOB_GUID_TYPE *guid;
		struct cdk2_diag_config config = {0};
		struct cdk2_diag_handoff candidate;

		if (hob->hob_length < sizeof(*hob) || (hob->hob_length & 7U) != 0U ||
		    hob->hob_length > end - (UINTN)hob)
			return EFI_COMPROMISED_DATA;
		if (hob->hob_type != EFI_HOB_TYPE_GUID_EXTENSION ||
		    hob->hob_length < sizeof(*guid)) {
			hob = (void *)((UINT8 *)hob + hob->hob_length);
			continue;
		}
		guid = (void *)hob;
		if (!bytes_equal(&guid->name, &cdk2_diag_handoff_guid,
		    sizeof(guid->name))) {
			hob = (void *)((UINT8 *)hob + hob->hob_length);
			continue;
		}
		if (hob->hob_length != sizeof(*guid) + sizeof(local_handoff))
			return EFI_COMPROMISED_DATA;
		bytes_copy(&candidate, guid + 1, sizeof(candidate));
		if (candidate.revision != CDK2_DIAG_HANDOFF_REVISION ||
		    candidate.length != sizeof(candidate) || candidate.reserved != 0U ||
		    candidate.spi_console_reserved[0] != 0U ||
		    candidate.spi_console_reserved[1] != 0U ||
		    candidate.spi_console_reserved[2] != 0U ||
		    !cdk2_uart_registers_valid(candidate.serial_type, candidate.register_base,
			candidate.register_width, candidate.register_stride, 5U) ||
		    (candidate.timestamp_base == 0U) != (candidate.timestamp_bytes == 0U))
			return EFI_COMPROMISED_DATA;
		/* A rejected primary tuple must not replace the context of a live sink. */
		local_handoff = candidate;
		/* The GUID HOB remains writable for the lifetime of DXE.  Every image
		 * points at this naturally aligned owner instead of its private data. */
		config.emission_owner = (volatile UINT64 *)((UINT8 *)(guid + 1) +
			OFFSET_OF(struct cdk2_diag_handoff, emission_owner));
		if (local_handoff.serial_type != CDK2_DIAG_SERIAL_NONE) {
			config.putc = handoff_putc;
			config.putc_context = &local_handoff;
			config.putc_provenance = CDK2_DIAG_SINK_SERIAL;
		}
		if (local_handoff.timestamp_base != 0U) {
			config.timestamps = (void *)(UINTN)local_handoff.timestamp_base;
			config.timestamp_bytes = local_handoff.timestamp_bytes;
			config.clock = handoff_clock;
			if (config.timestamp_bytes >= sizeof(*config.timestamps))
				config.clock_hz =
					(UINT64)config.timestamps->tick_freq_mhz * 1000000U;
		}
		/* A corrupt optional CBMEM sink must not take down a valid serial
		 * sink.  Install serial first, then report the bad secondary sink. */
		if ((local_handoff.cbmem_console_base == 0U) !=
		     (local_handoff.cbmem_console_bytes == 0U) ||
		    (local_handoff.cbmem_console_base != 0U &&
		     (local_handoff.cbmem_console_base > MAX_UINTN ||
		      (local_handoff.cbmem_console_base & (sizeof(UINT32) - 1U)) != 0U ||
		      local_handoff.cbmem_console_bytes <=
			      sizeof(struct cdk2_cbmem_console) ||
		      local_handoff.cbmem_console_bytes >
			      sizeof(struct cdk2_cbmem_console) +
			      CDK2_CBMEM_CONSOLE_MAX_SIZE ||
		      local_handoff.cbmem_console_base > MAX_UINTN -
			      local_handoff.cbmem_console_bytes))) {
			configure_active(&config, FALSE);
			return EFI_COMPROMISED_DATA;
		}
		if (local_handoff.cbmem_console_base != 0U) {
			config.cbmem_console =
				(void *)(UINTN)local_handoff.cbmem_console_base;
			config.cbmem_console_bytes = local_handoff.cbmem_console_bytes;
			if (EFI_ERROR(cbmem_console_validate(config.cbmem_console,
			    config.cbmem_console_bytes))) {
				config.cbmem_console = NULL;
				config.cbmem_console_bytes = 0U;
				configure_active(&config, FALSE);
				return EFI_COMPROMISED_DATA;
			}
		}
#if CDK2_DIAG_SPI_CONSOLE_ENABLED
		if ((local_handoff.spi_console_buffer == 0U) !=
		     (local_handoff.spi_console_buffer_bytes == 0U) ||
		    (local_handoff.spi_console_buffer == 0U &&
		     (local_handoff.spi_console_max_chunk != 0U ||
		      local_handoff.spi_console_boot_limit != 0U ||
		      local_handoff.spi_console_apm_cmd != 0U)) ||
		    (local_handoff.spi_console_buffer != 0U &&
		     (local_handoff.cbmem_console_base == 0U ||
		      local_handoff.spi_console_buffer > MAX_UINTN ||
		      (local_handoff.spi_console_buffer & 3U) != 0U ||
		      local_handoff.spi_console_buffer_bytes <
			  sizeof(struct spi_console_request) ||
		      local_handoff.spi_console_max_chunk == 0U ||
		      local_handoff.spi_console_max_chunk > sizeof(spi_console_record) ||
		      local_handoff.spi_console_max_chunk >
			  local_handoff.spi_console_buffer_bytes -
			  sizeof(struct spi_console_request) ||
			      local_handoff.spi_console_boot_limit <
			  local_handoff.spi_console_max_chunk ||
		      local_handoff.spi_console_remaining >
			  local_handoff.spi_console_boot_limit ||
			      local_handoff.spi_console_apm_cmd != 0xe8U ||
		      local_handoff.spi_console_buffer > MAX_UINTN -
			  local_handoff.spi_console_buffer_bytes + 1U))) {
			/* SPI is optional. Keep every validated primary sink live. */
			cdk2_diag_configure(&config);
			return EFI_COMPROMISED_DATA;
		}
		if (local_handoff.spi_console_buffer != 0U) {
			config.spi_console_buffer =
				(void *)(UINTN)local_handoff.spi_console_buffer;
			config.spi_console_buffer_bytes =
				local_handoff.spi_console_buffer_bytes;
			config.spi_console_max_chunk =
				local_handoff.spi_console_max_chunk;
			config.spi_console_boot_limit =
				local_handoff.spi_console_boot_limit;
			config.spi_console_apm_cmd = local_handoff.spi_console_apm_cmd;
			config.spi_console_remaining =
				(volatile UINT32 *)((UINT8 *)(guid + 1) +
				OFFSET_OF(struct cdk2_diag_handoff, spi_console_remaining));
		}
#endif
		cdk2_diag_configure(&config);
		return EFI_SUCCESS;
	}
	return EFI_NOT_FOUND;
}

static void write_char(char character)
{
	BOOLEAN cbmem_written = FALSE;
	if (!physical_sinks_retired && active.putc != NULL &&
	    (active.putc_provenance !=
	    CDK2_DIAG_SINK_SERIAL ||
	    direct_serial_allowed(CONFIG_CDK2_BUILD_DEBUG,
		active.cbmem_console != NULL)))
		active.putc(character, active.putc_context);
	if (active.cbmem_console != NULL)
		cbmem_written = cbmem_console_write(active.cbmem_console,
			active.cbmem_console_bytes, &character, 1U) == 1U;
	if (cbmem_written && active.spi_console_buffer != NULL &&
	    spi_console_record_enabled) {
		if (spi_console_record_bytes == active.spi_console_max_chunk &&
		    !spi_console_flush()) {
			active.spi_console_buffer = NULL;
			spi_console_record_bytes = 0U;
			return;
		}
		spi_console_record[spi_console_record_bytes++] = (UINT8)character;
	}
}

static void write_text(const char *text)
{
	while (*text != '\0')
		write_char(*text++);
}

static void write_hex(uint64_t value, size_t digits)
{
	static const char hex[] = "0123456789abcdef";

	while (digits != 0U) {
		digits--;
		write_char(hex[(value >> (digits * 4U)) & 0xfU]);
	}
}

static void write_decimal(uint64_t value)
{
	char digits[20];
	size_t count = 0U;

	do {
		digits[count++] = (char)('0' + value % 10U);
		value /= 10U;
	} while (value != 0U && count < sizeof(digits));
	while (count != 0U)
		write_char(digits[--count]);
}

static const char *status_name(EFI_STATUS status)
{
	switch (status) {
	case EFI_SUCCESS: return "SUCCESS";
	case EFI_INVALID_PARAMETER: return "INVALID_PARAMETER";
	case EFI_UNSUPPORTED: return "UNSUPPORTED";
	case EFI_BAD_BUFFER_SIZE: return "BAD_BUFFER_SIZE";
	case EFI_BUFFER_TOO_SMALL: return "BUFFER_TOO_SMALL";
	case EFI_NOT_READY: return "NOT_READY";
	case EFI_DEVICE_ERROR: return "DEVICE_ERROR";
	case EFI_OUT_OF_RESOURCES: return "OUT_OF_RESOURCES";
	case EFI_VOLUME_FULL: return "VOLUME_FULL";
	case EFI_NOT_FOUND: return "NOT_FOUND";
	case EFI_ACCESS_DENIED: return "ACCESS_DENIED";
	case EFI_TIMEOUT: return "TIMEOUT";
	case EFI_ABORTED: return "ABORTED";
	case EFI_NOT_STARTED: return "NOT_STARTED";
	case EFI_ALREADY_STARTED: return "ALREADY_STARTED";
	case EFI_SECURITY_VIOLATION: return "SECURITY_VIOLATION";
	case EFI_CRC_ERROR: return "CRC_ERROR";
	case EFI_COMPROMISED_DATA: return "COMPROMISED_DATA";
	default: return "EFI_ERROR";
	}
}

static const char *level_name(enum cdk2_diag_level level)
{
	switch (level) {
	case CDK2_DIAG_DEBUG: return "DEBUG";
	case CDK2_DIAG_INFO: return "INFO";
	case CDK2_DIAG_WARN: return "WARN";
	case CDK2_DIAG_ERROR: return "ERROR";
	default: return "INVALID";
	}
}

static uint64_t diagnostic_elapsed_microseconds(uint64_t elapsed_ticks)
{
	uint64_t elapsed_us = 0U;

	if (active.clock_hz != 0U) {
		uint64_t whole = elapsed_ticks / active.clock_hz;
		uint64_t remainder = elapsed_ticks % active.clock_hz;

		if (whole > MAX_UINT64 / 1000000U)
			return MAX_UINT64;
		elapsed_us = whole * 1000000U;
		if (remainder <= MAX_UINT64 / 1000000U)
			elapsed_us += (remainder * 1000000U) / active.clock_hz;
	}
	return elapsed_us;
}

static size_t diagnostic_phase_length(const char *phase,
	const char *operation, EFI_STATUS status, uint64_t elapsed_ticks)
{
	size_t length = sizeof("CDK2 | ") - 1U;

	length = diagnostic_length_add(length, diagnostic_text_length(phase));
	length = diagnostic_length_add(length, sizeof(" | ") - 1U);
	length = diagnostic_length_add(length, diagnostic_text_length(operation));
	length = diagnostic_length_add(length, sizeof(" | ") - 1U);
	length = diagnostic_length_add(length, diagnostic_text_length(status_name(status)));
	length = diagnostic_length_add(length, sizeof(" (0x") - 1U);
	length = diagnostic_length_add(length, sizeof(EFI_STATUS) * 2U);
	length = diagnostic_length_add(length, sizeof(") | ") - 1U);
	length = diagnostic_length_add(length,
		diagnostic_decimal_length(diagnostic_elapsed_microseconds(elapsed_ticks)));
	return diagnostic_length_add(length, sizeof(" us\n") - 1U);
}

static void append_timestamp_at(UINT32 event, UINT64 now)
{
	struct cdk2_diag_timestamp_table *table = active.timestamps;
	UINTN header = sizeof(*table), capacity;
	UINT32 index;

	if (table == NULL || active.timestamp_bytes < header)
		return;
	capacity = (active.timestamp_bytes - header) / sizeof(table->entries[0]);
	if (table->max_entries > capacity || table->num_entries > table->max_entries)
		return;
	if (table->num_entries == table->max_entries) {
		/* Keep loss visible even when the table is already full.  Reusing the
		 * final slot preserves the bounded coreboot layout and avoids changing
		 * num_entries, which older cbmem readers use as the extent. */
		if (table->max_entries != 0U &&
		    table->entries[table->max_entries - 1U].entry_id !=
			CDK2_EVENT_TIME_OVERFLOW) {
			UINT32 last = table->max_entries - 1U;
			table->entries[last].entry_id = CDK2_EVENT_TIME_OVERFLOW;
			if (now >= table->base_time) {
				UINT64 delta = now - table->base_time;
				table->entries[last].entry_stamp = delta > INT64_MAX ?
					INT64_MAX : (INT64)delta;
			} else {
				UINT64 delta = table->base_time - now;
				table->entries[last].entry_stamp =
					delta >= (UINT64)INT64_MAX + 1U ? INT64_MIN :
					-(INT64)delta;
			}
		}
		return;
	}
	index = table->num_entries;
	table->entries[index].entry_id = event;
	if (now >= table->base_time) {
		UINT64 delta = now - table->base_time;

		table->entries[index].entry_stamp = delta > INT64_MAX ?
			INT64_MAX : (INT64)delta;
	} else {
		UINT64 delta = table->base_time - now;

		if (delta >= (UINT64)INT64_MAX + 1U)
			table->entries[index].entry_stamp = INT64_MIN;
		else
			table->entries[index].entry_stamp = -(INT64)delta;
	}
	/* Publish the count last so readers never observe a partial entry. */
	table->num_entries = index + 1U;
}

static void append_timestamp(UINT32 event)
{
	if (active.clock != NULL)
		append_timestamp_at(event, active.clock(active.clock_context));
}

#if defined(__x86_64__)
static uint64_t diagnostic_default_timestamp_clock(void *context)
{
	UINT32 low, high;

	(void)context;
	__asm__ volatile ("rdtsc" : "=a"(low), "=d"(high));
	return (UINT64)low | ((UINT64)high << 32);
}
#endif

static void configure_active(const struct cdk2_diag_config *config,
	BOOLEAN preserve_cbmem)
{
	struct cdk2_diag_config previous = active;
	struct cdk2_diag_config next = config == NULL ? (struct cdk2_diag_config){0} : *config;

	if (emission_acquired)
		return;
	/* Module entry points may present a reduced system-table view.  Keep the
	 * coreboot-owned sinks once established instead of silently dropping the
	 * timing stream on that later pass. */
	if (next.timestamps == NULL) {
		next.timestamps = previous.timestamps;
		next.timestamp_bytes = previous.timestamp_bytes;
	}
	/* A handoff may repeat the table address while omitting its clock
	 * callback.  Keep the complete timing source, not just the buffer. */
	if (next.clock == NULL) {
		next.clock = previous.clock;
		next.clock_context = previous.clock_context;
		next.clock_hz = previous.clock_hz;
	}
#if defined(__x86_64__)
	if (next.timestamps != NULL && next.clock_hz == 0U &&
	    next.timestamp_bytes >= sizeof(*next.timestamps) &&
	    next.timestamps->tick_freq_mhz != 0U)
		next.clock_hz = (UINT64)next.timestamps->tick_freq_mhz * 1000000U;
#endif
#if defined(__x86_64__)
	/* A valid coreboot TIME table must remain measurable even if a later
	 * module handoff omits the platform clock callback. */
	if (next.timestamps != NULL && next.clock == NULL)
		next.clock = diagnostic_default_timestamp_clock;
#endif
	if (preserve_cbmem && next.cbmem_console == NULL) {
		next.cbmem_console = previous.cbmem_console;
		next.cbmem_console_bytes = previous.cbmem_console_bytes;
	}
	active = next;
	spi_console_record_bytes = 0U;
	spi_console_record_enabled = FALSE;
	spi_console_record_critical = FALSE;
	spi_console_record_suppressed = FALSE;
	if (active.spi_console_remaining == NULL) {
		spi_console_local_remaining = active.spi_console_boot_limit;
		active.spi_console_remaining = &spi_console_local_remaining;
	}
	physical_sinks_retired = FALSE;
	emission_acquired = FALSE;
	acquired_owner = 0U;
	if (active.cbmem_console != NULL &&
	    EFI_ERROR(cbmem_console_validate(active.cbmem_console,
		active.cbmem_console_bytes))) {
		active.cbmem_console = NULL;
		active.cbmem_console_bytes = 0U;
	}
	__atomic_store_n(&emitting_owner, 0U, __ATOMIC_RELEASE);
}

void cdk2_diag_configure(const struct cdk2_diag_config *config)
{
	configure_active(config, TRUE);
}

void cdk2_diag_runtime_transition(void)
{
	physical_sinks_retired = TRUE;
	end_emit();
	active = (struct cdk2_diag_config){0};
}

static void emit_record(enum cdk2_diag_level level, enum cdk2_diag_module module,
	uint32_t event, EFI_STATUS status, BOOLEAN timestamp)
{
	/* Runtime services may remain callable after SetVirtualAddressMap, but
	 * their physical diagnostic sinks are no longer valid. */
	if (physical_sinks_retired)
		return;
	if (!begin_emit(level >= CDK2_DIAG_ERROR))
		return;
	if (timestamp)
		append_timestamp(event);
	spi_console_prepare_record(diagnostic_record_length(level));
	write_char('[');
	write_text(level_name(level));
	write_text("] CDK2:m=");
	write_hex(module, 2U);
	write_text(":e=");
	write_hex(event, 4U);
	write_text(":status=");
	write_hex(status, sizeof(status) * 2U);
	write_char('\n');
	end_emit();
}

void cdk2_diag_emit(enum cdk2_diag_level level, enum cdk2_diag_module module,
	uint32_t event, EFI_STATUS status)
{
	emit_record(level, module, event, status, TRUE);
}

void cdk2_diag_emit_console(enum cdk2_diag_level level,
	enum cdk2_diag_module module, uint32_t event, EFI_STATUS status)
{
	emit_record(level, module, event, status, FALSE);
}

void cdk2_diag_emit_compact(enum cdk2_diag_module module, uint32_t event,
	EFI_STATUS status)
{
	cdk2_diag_emit(CDK2_DIAG_INFO, module, event, status);
}

void cdk2_diag_message(enum cdk2_diag_module module, const char *message)
{
	cdk2_diag_message_status(module, message, EFI_SUCCESS);
}

void cdk2_diag_message_status(enum cdk2_diag_module module,
	const char *message, EFI_STATUS status)
{
	enum cdk2_diag_level level = CDK2_DIAG_DEBUG;
	uint32_t hash = 2166136261U;
	const char *cursor;

	if (message == NULL)
		return;
	for (cursor = message; *cursor != '\0'; cursor++) {
		hash ^= (uint8_t)*cursor;
		hash *= 16777619U;
		if (cursor[0] == '[' && cursor[1] != '\0' && cursor[2] != '\0' &&
		    cursor[1] == 'e' && cursor[2] == 'r')
			level = CDK2_DIAG_ERROR;
		else if (cursor[0] == '[' && cursor[1] != '\0' &&
			 cursor[2] != '\0' && cursor[1] == 'w' && cursor[2] == 'a')
			level = CDK2_DIAG_WARN;
		else if (cursor[0] == '[' && cursor[1] != '\0' &&
			 cursor[2] != '\0' && cursor[1] == 'i' && cursor[2] == 'n')
			level = CDK2_DIAG_INFO;
	}
	/* The release profile retains structured phase and error records in CBMEM.
	 * Free-form DEBUG() traffic is neither human-readable here (only its stable
	 * hash is stored) nor free: the EFI loader can emit it thousands of times.
	 * CDK2_DEBUG remains the A/B profile that retains every upstream message. */
#if !CONFIG_CDK2_BUILD_DEBUG
	if (level == CDK2_DIAG_DEBUG)
		return;
#endif
	/* Message hashes identify console records only. They are not stable timing
	 * boundaries, so keeping them out of CBMEM TIME makes every timestamp
	 * independently meaningful to cbmem and to automated comparisons. */
	emit_record(level, module, 0x2000U | (hash & 0x0fffU), status, FALSE);
}

static void value_prefix(enum cdk2_diag_module module, const char *label)
{
	write_text("CDK2 | module 0x");
	write_hex(module, 2U);
	write_text(" | ");
	write_text(label);
	write_text(" | ");
}

void cdk2_diag_value(enum cdk2_diag_module module, const char *label,
	uint64_t value)
{
	if (label == NULL || !begin_emit(FALSE))
		return;
	{
		size_t length = sizeof("CDK2 | module 0x") - 1U;

		length = diagnostic_length_add(length, 2U);
		length = diagnostic_length_add(length, sizeof(" | ") - 1U);
		length = diagnostic_length_add(length, diagnostic_text_length(label));
		length = diagnostic_length_add(length, sizeof(" | ") - 1U);
		length = diagnostic_length_add(length, sizeof("0x") - 1U);
		length = diagnostic_length_add(length, sizeof(value) * 2U);
		spi_console_prepare_record(diagnostic_length_add(length, 1U));
	}
	value_prefix(module, label);
	write_text("0x");
	write_hex(value, sizeof(value) * 2U);
	write_char('\n');
	end_emit();
}

void cdk2_diag_bytes(enum cdk2_diag_module module, const char *label,
	const void *bytes, size_t count)
{
	const uint8_t *value = bytes;
	size_t index;

	if (label == NULL || (bytes == NULL && count != 0U) || !begin_emit(FALSE))
		return;
	{
		size_t length = sizeof("CDK2 | module 0x") - 1U;

		length = diagnostic_length_add(length, 2U);
		length = diagnostic_length_add(length, sizeof(" | ") - 1U);
		length = diagnostic_length_add(length, diagnostic_text_length(label));
		length = diagnostic_length_add(length, sizeof(" | ") - 1U);
		length = count > (MAX_UINTN - length - 1U) / 2U ? MAX_UINTN :
			length + count * 2U + 1U;
		spi_console_prepare_record(length);
	}
	value_prefix(module, label);
	for (index = 0U; index < count; index++)
		write_hex(value[index], 2U);
	write_char('\n');
	end_emit();
}

static void emit_phase_locked(uint32_t event, uint64_t event_ticks,
	BOOLEAN supplied_ticks, const char *phase,
	const char *operation, EFI_STATUS status, uint64_t elapsed_ticks)
{
	uint64_t elapsed_us = diagnostic_elapsed_microseconds(elapsed_ticks);
	if (event != 0U) {
		if (supplied_ticks)
			append_timestamp_at(event, event_ticks);
		else
			append_timestamp(event);
	}
	write_text("CDK2 | ");
	write_text(phase);
	write_text(" | ");
	write_text(operation);
	write_text(" | ");
	write_text(status_name(status));
	write_text(" (0x");
	write_hex(status, sizeof(status) * 2U);
	write_char(')');
	write_text(" | ");
	write_decimal(elapsed_us);
	write_text(" us\n");
}

void cdk2_diag_phase_event(uint32_t event, const char *phase,
	const char *operation, EFI_STATUS status, uint64_t elapsed_ticks)
{
	if (phase == NULL || operation == NULL ||
	    !begin_emit(event != 0U || EFI_ERROR(status)))
		return;
	spi_console_prepare_record(diagnostic_phase_length(phase, operation, status,
		elapsed_ticks));
	emit_phase_locked(event, 0U, FALSE, phase, operation, status,
		elapsed_ticks);
	end_emit();
}

void cdk2_diag_phase_event_at(uint32_t event, uint64_t event_ticks,
	const char *phase, const char *operation, EFI_STATUS status,
	uint64_t elapsed_ticks)
{
	if (phase == NULL || operation == NULL ||
	    !begin_emit(event != 0U || EFI_ERROR(status)))
		return;
	spi_console_prepare_record(diagnostic_phase_length(phase, operation, status,
		elapsed_ticks));
	emit_phase_locked(event, event_ticks, TRUE, phase, operation, status,
		elapsed_ticks);
	end_emit();
}

BOOLEAN cdk2_diag_optional_phase_pair_at(uint32_t begin_event, uint32_t end_event,
	uint64_t begin_ticks, uint64_t end_ticks, const char *phase,
	uint64_t elapsed_ticks, EFI_STATUS status)
{
	struct cdk2_diag_timestamp_table *table;
	UINTN capacity;

	if (phase == NULL || !begin_emit(TRUE))
		return FALSE;
	table = active.timestamps;
	if (table == NULL || active.timestamp_bytes < sizeof(*table)) {
		end_emit();
		return FALSE;
	}
	capacity = (active.timestamp_bytes - sizeof(*table)) /
		sizeof(table->entries[0]);
	if (table->max_entries > capacity || table->max_entries < 65U ||
	    table->num_entries > table->max_entries ||
	    table->max_entries - table->num_entries < 3U) {
		end_emit();
		return FALSE;
	}
	spi_console_prepare_record(diagnostic_length_add(
			diagnostic_phase_length(phase, "BEGIN", EFI_SUCCESS, 0U),
			diagnostic_phase_length(phase, "END", status, elapsed_ticks)));
	emit_phase_locked(begin_event, begin_ticks, TRUE, phase, "BEGIN",
		EFI_SUCCESS, 0U);
	emit_phase_locked(end_event, end_ticks, TRUE, phase, "END", status,
		elapsed_ticks);
	end_emit();
	return TRUE;
}

void cdk2_diag_phase(const char *phase, const char *operation,
	EFI_STATUS status, uint64_t elapsed_ticks)
{
	cdk2_diag_phase_event(0U, phase, operation, status, elapsed_ticks);
}
