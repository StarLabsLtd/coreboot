#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

test "$#" -eq 2 || exit 2
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
header=$(realpath "$1")
output=$(realpath -m "$2")
capsule=${MM_FULL_CORE_CAPSULE:?signed full capsule required}
target=${MM_FULL_CORE_TARGET:?immutable full Core target required}
trust=${MM_FULL_CORE_PUBLIC_TRUST:?public trust certificate required}
tools=${CAPSULE_TOOL_ROOT:?actual coreboot capsule tool directory required}
compiler=${HOSTCC:-cc}
linker=${HOSTLD:-ld}
pe_link=${NATIVE_PE_LINK:?actual native PE linker required}
pe_audit=${NATIVE_PE_AUDIT:?actual native PE relocation audit required}
pe_marker=${NATIVE_PE_MARKER:?actual native PE relocation marker required}
readelf=${HOSTREADELF:-readelf}
attempt=${MM_FULL_CORE_ATTEMPT:-0x001a000a}
target_running=${MM_FULL_CORE_TARGET_RUNNING:-0x001a000a}
prior_running=${MM_FULL_CORE_PRIOR_RUNNING:-0x001a0009}
prior_history=${MM_FULL_CORE_PRIOR_HISTORY:-0}
refusal=${MM_FULL_CORE_REFUSAL:-}
certified=${MM_FULL_CORE_CERTIFIED_REFUSAL:-}
if test -n "$certified"; then
	test -z "$refusal" || exit 2
	case "$certified" in wrong-signer|signed-byte) ;; *) exit 2 ;; esac
	refusal=$certified
fi
reference=${MM_FULL_CORE_REFERENCE_CAPSULE:-}
signer=${MM_FULL_CORE_SIGNER_CERT:-}
python3 - "$attempt" "$target_running" "$prior_running" "$prior_history" "$refusal" <<-'PY'
	import re
	import sys
	values = []
	for text in sys.argv[1:5]:
	    if not re.fullmatch(r'(?:0[xX][0-9a-fA-F]{1,8}|0|[1-9][0-9]{0,9})', text):
	        raise SystemExit('invalid fixture numeric constant')
	    value = int(text, 16 if text.lower().startswith('0x') else 10)
	    if value > 0xffffffff:
	        raise SystemExit('fixture numeric constant overflow')
	    values.append(value)
	attempt, target, running, history = values
	refusal = sys.argv[5]
	if refusal:
	    expected = 0x001a0008 if refusal == 'below-floor' else 0x001a000a
	    if refusal not in ('wrong-signer', 'signed-byte', 'below-floor') or \
	            (attempt, target, running, history) != (expected, 0x001a000a, 0x001a0009, 0):
	        raise SystemExit('invalid finite refusal fixture constants')
	elif running < 0x001a0009 or target < 0x001a0009 or target == running or \
	        attempt <= running or attempt <= history:
	    raise SystemExit('fixture running/history/attempt relation invalid')
PY

grep -qx '#define CONFIG_CDK2_NATIVE_SYSTEM_FMP 1' "$header"
grep -qx '#define CONFIG_CDK2_NATIVE_QEMU_TEST_FMP 0' "$header"
grep -qx '#define CONFIG_CDK2_QEMU_ACCEPTANCE_PROFILE 0' "$header"
grep -qx '#define CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME 1' "$header"
mkdir -p "$output/include/cdk2"
cp "$header" "$output/include/cdk2/config.h"
cp "$capsule" "$output/signed_capsule.bin"
cp "$target" "$output/target-image.bin"
cp "$trust" "$output/public-trust.pem"
sha256sum "$header" "$capsule" "$target" "$trust" \
	"$root/tests/system_fmp_core_ram_stage_app.c" \
	"$root/tests/system_fmp_core_ram_stage_app.ld" \
	"$root/tests/system_fmp_core_ram_stage_app_test.sh" \
	"$root/tests/system_fmp_core_ram_refusal.py" > "$output/inputs-before.sha256"
sha256sum "$(command -v "$compiler")" "$(command -v "$linker")" \
	"$(command -v "$readelf")" "$pe_link" "$pe_audit" "$pe_marker" \
	"$tools/validate_capsule.py" "$tools/generate_capsule.py" \
	> "$output/tools-before.sha256"
if test -n "$refusal"; then
	sha256sum "$reference" >> "$output/inputs-before.sha256"
	set -- --tools "$tools" --capsule "$output/signed_capsule.bin" \
		--target "$output/target-image.bin" --trust "$output/public-trust.pem" \
		--reference "$reference" --case "$refusal" --attempt "$attempt"
	if test -n "$signer"; then
		sha256sum "$signer" >> "$output/inputs-before.sha256"
		set -- "$@" --signer "$signer"
	fi
	python3 "$root/tests/system_fmp_core_ram_refusal.py" "$@" \
		> "$output/capsule-validation.log" 2>&1
else
	python3 "$tools/validate_capsule.py" --capsule "$output/signed_capsule.bin" \
		--guid 00112233-4455-6677-8899-aabbccddeeff --embedded-drivers 0 \
		--fw-version "$attempt" --lsv 0x001a0009 --image "$output/target-image.bin" \
		--region COREBOOT --trusted-public-cert "$output/public-trust.pem" \
		--initiate-reset --require-fmap > "$output/capsule-validation.log" 2>&1
fi
(cd "$output" && "$linker" -r -b binary signed_capsule.bin -o capsule.o)
"$compiler" -std=gnu11 -Wall -Wextra -Werror -O2 -ffreestanding \
	-fno-stack-protector -fno-asynchronous-unwind-tables -fshort-wchar \
	-mno-red-zone -m64 -mcmodel=small -fpie -fno-ident \
	-fcf-protection=none -maccumulate-outgoing-args \
	-DCDK2_CORE_RAM_ATTEMPT="$attempt" \
	-DCDK2_CORE_RAM_TARGET_RUNNING="$target_running" \
	-DCDK2_CORE_RAM_PRIOR_RUNNING="$prior_running" \
	-DCDK2_CORE_RAM_PRIOR_HISTORY="$prior_history" \
	${certified:+-DCDK2_CORE_RAM_CERTIFIED_REFUSAL} \
	-I"$output/include" -I"$root/include" \
	-c "$root/tests/system_fmp_core_ram_stage_app.c" -o "$output/entry.o"
set --
if test -n "$certified"; then
	for source in src/lib/coreboot_hob.c src/boot/coreboot.c \
		src/boot/coreboot_checksum.c src/boot/coreboot_resource.c src/modules/dxe_core/string.c; do
		sha256sum "$root/$source" >> "$output/inputs-before.sha256"
		object="$output/$(basename "$source" .c).o"
		"$compiler" -std=gnu11 -Wall -Wextra -Werror -O2 -ffreestanding \
			-fno-builtin -fno-stack-protector -fno-asynchronous-unwind-tables \
			-fshort-wchar -mno-red-zone -m64 -mcmodel=small -fpie -fno-ident \
			-fcf-protection=none -maccumulate-outgoing-args \
			-I"$output/include" -I"$root/include" -c "$root/$source" -o "$object"
		set -- "$@" "$object"
	done
fi
"$pe_link" "$linker" "$pe_audit" "$pe_marker" "$readelf" \
	--subsystem 10 --entry system_fmp_core_ram_stage_entry \
	--image-base 0 --section-alignment 0x1000 --file-alignment 0x1000 \
	--build-id=none --no-insert-timestamp -s --nxcompat \
	-T "$root/tests/system_fmp_core_ram_stage_app.ld" \
	-o "$output/SystemFmpCoreRamStage.efi" "$output/entry.o" "$output/capsule.o" "$@"
cmp "$header" "$output/include/cdk2/config.h"
sha256sum -c "$output/inputs-before.sha256"
sha256sum -c "$output/tools-before.sha256"
sha256sum "$output/SystemFmpCoreRamStage.efi"
printf '%s\n' 'Normal MAIN stage/cold observer compiled: no VM or install claim'
