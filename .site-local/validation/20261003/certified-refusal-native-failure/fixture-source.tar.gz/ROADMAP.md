# CDK2 coreboot-native roadmap

## Current work (2026-10-03)

This checkpoint supersedes older WIP statuses below, not the full release gates.
The ready linear chains reach CDK2 PR592 and coreboot PR387. Detailed bounded
receipts and preserved failures are recorded in the ready linear CDK2 PR
chain and coreboot's
`agent/validation-evidence-20261001` branch. Earlier percentage estimates are
not an audited whole-project completion measure.

PR561 imports the complete authenticated RAM handoff, seals the imported
endpoint and handoff, and delegates verification of the original signed bytes
to the actual MM authority. Its untrusted framing parser is explicitly not an
authentication result. Legacy frontend CMS verification and the production
StarLabs certificate remain unchanged. Independent focused authentication,
session, transport, real-CMS HOST route and production-symbol-closure tests pass;
these modeled-transport tests do not prove the normal native capsule writer.

The subsequent reviewed linear slices share one system-table definition
(PR562), use native private provider types and remove its one-use wrapper
(PR563), remove three duplicate/thin helpers without changing ordering
(PR564), convert the handoff reader and its decoded native model (PR565--566),
and convert private transport and entry bookkeeping (PR567--568). Actual UEFI
callbacks, loaded-image wire fields, GUIDs and protocol types remain explicit.
PR566 preserves all model offsets, alignment, the complete 584-byte imported
representation including padding, and its production digest under real P0/P1
generated configurations; all 18 consuming-object comparisons pass. PR567's
O2 objects are equal, but bool normalization changes O0 and Os objects. The
reviewed Os text grows by seven bytes; this is not a performance improvement
or universal object-parity claim. Focused joined-parent gates pass, not a new
complete final-tree regression.

PR570 converts the decoded transport model without bool normalization: all
eight storage flags remain uint8_t and preserve all 256 byte values. All 30
consuming-object comparisons and full endpoint/INFO representations pass in
the tested P0/P1 configurations; INFO response generation remains modeled.

PR583 removes the unused deadline API. PR584/586 convert coherent native
diagnostic API/formatter groups without changing actual timestamp, CBMEM or
HOB wire representations. PR587 deletes the uncalled executable-FV discovery
implementation and its object/header dependencies; variable-store FV/FVB
formats and codecs are untouched. PR589 removes only three unused configuration
controls: late-link policy, CPUID CPU timer and maximum logical processors.
Genuine default/protected resolution differs only in those removed symbols;
48 representative whole native objects, both stage/coreboot/inventory profiles
and existing profile/linear tests pass. The resolved configuration hashes
legitimately change. Earlier missing-BearSSL profile builds and an incorrect
PE proof source path remain classified harness failures, not firmware failures.

PR591 removes only the unused standalone compact diagnostic emitter; the live
compact entry remains in diagnostic.c. PR592 removes the actual fixed-COM1
fallback, validates the complete logger UART register span, preserves an active
context when mandatory replacement data is rejected, and honors imported
16/32-bit MMIO widths. Quiet and genuinely resolved debug/serial-selected
stage/coreboot/CBMEM/entry gates pass. HOST tests actually exercise HOB MMIO
width/stride and rejected-context preservation; the native serial callbacks
are compiled, not claimed hardware-executed. Independent runtime tests cover
configured callback and CBMEM retirement. Earlier incomplete/suppressed logging
fixture failures remain separate from the corrected passes. The finite peer-
reviewed evidence packet is published on the coreboot evidence branch at
`8c77029a8b5`, under `20261003/owned-cleanup-client-uart-after592`.

SerialIO's separate register-6 tuple, optional producer export, and bounded HOB
scanner closure is being implemented and reviewed; PR592 does not close it.
The certified refusal lifecycle (provider/Runtime/Core ownership proof, CLOSE
and exact request retirement) is also under final test review, not released
native acceptance. A separately reviewed continuation fixture is preserved in
signed branch `agent/normal-refusal-continuation-after592` at `3853a0b8f4`.
Its 32 HOST runner checks and real EFI parser/link closure pass, but it has not
yet run the new guest continuation class. Historical PR580 refusal results
remain HOST termination at a failed phase, not successful continuation. No new
hardware or complete final-tree regression result is claimed here.

PR571 adds a genuine normal production SystemFmp/Core RAM fixture with the
test FMP driver disabled. Both initial and target firmware contain the actual
full Core payload before signing. A normally loaded MAIN diagnostic stages
through installed QueryCapsule/UpdateCapsule services; the next warm boot
processes the real capsule HOB before PCI/storage, then cold-boots the unchanged
target into ordinary MAIN. No component observer or post-write substitution
qualifies. Its first native run rejected the provider's own request GUID as
overlapping the session owner and exhausted the unchanged 180-second budget.
That failed receipt is preserved. PR573 copies that GUID outside the owner
without weakening the guard and adds a real provider/session/CMS HOST join.

The first fixed normal three-boot run at signed ea1b13a747 returns 0:
171.507 seconds in QEMU within the same 180-second limit, 174.77 seconds for
the whole invocation. Actual retained signed bytes, warm processing before
PCI, cold running/history version 0x001a000a with floor 0x001a0009, target COREBOOT bytes,
excluded probe/gap and unchanged disk all pass. Independent immutable-input
and saved-acceptance reviews pass. A fresh independent boot replay returns 0
in 149.281 seconds of QEMU and 152.43 seconds for the whole invocation. It
uses private media and its own compiled MAIN fixture, but explicitly clones
the same full Core build and inventory; it is not an independent Core rebuild.
CLOSE-before-success-reset ordering is source-backed inference, not an observed
marker. The normal original-content restore also passes: author QEMU
147.514 seconds / whole invocation 150.28 seconds, and a fresh independent
replay 147.671 / 150.86 seconds. Each starts from its own successful newer
image, restores the pre-signed full Core image with compiled running version
0x001a0009 under admitted attempt/history 0x001a000b, and preserves floor
0x001a0009, the excluded probe/gap and disk. Both produce the same final media
hash. The independent replay again clones the actual ea1 Core and inventory;
it is not an independent Core rebuild. PR576/578 retain the earlier observer
failure and narrowly handle moving console snapshots only during an observed
reset's bounded pre-acceptance publication period.

Three normal RAM refusal cases at PR580 pass the author run and independent
saved-outcome review: wrong signer, one signed-byte CMS corruption, and a
genuinely signed below-floor image. The first two retain generic
EFI_DEVICE_ERROR; the third returns EFI_UNSUPPORTED from the source-owned
checked FMP VERSION_TOO_LOW/ImageUpdatable policy before MM. Its genuine
signature is a HOST capsule-tool fixture proof, not native MM signature
verification in that third case. Each proves the actual
retained candidate, exact warm failure, unchanged firmware outside SMMSTORE,
unchanged disk, canonical zero FmpState and clean FTW through the real codecs.
Completion is deliberate HOST termination after validated refusal, not guest
success, OS continuation or retirement of the rejected request. Fresh
independent negative boots, rejected-request consumption/result/continuation,
DISK delivery, interruption/power-loss recovery and hardware remain separate
gates. In particular, current Core retires CapsuleUpdateData only after a
successful apply; no generic execution error may be reclassified as a safe
pre-mutation refusal.

Full default and protected review-profile-check/check/native-stage runs at
signed PR569 return 0 in 49:45.77 and 51:09.25 respectively; both generated
configurations retain their before-run hashes. These are historical HOST/build
regressions, not final PR573 whole-suite results or firmware boot times.
PR572 compiles the unchanged checkpatch filter once per selected invocation
instead of once per file. Direct-wrapper/driver diagnostics and statuses match
in its focused regression. The complete earlier lint gate still fails; the
optimized sweep of the original PR570 inventory also returns checker status 1.
Neither the speedup nor these receipts close final lint or project sign-off.

PR387 distinguishes a clean CHECK signature rejection from other execution
failures through the real authentication/transaction/broker chain. Changed
input, owner/current control, resources, checkpoints, media or completion
failures do not qualify; SET remains generic. PR588 classifies only the matching
CHECK reply after complete existing reply/digest validation, rejects that result
on SET, and clears the classification on shared buffer cleanup failure.
Session's public EFI_DEVICE_ERROR behavior remains unchanged. Focused source
and HOST proofs do not establish native refused-request retirement, OS
continuation or a completed producer/consumer recovery lifecycle.

The combined quiet QEMU three-boot suite passes actual F2 navigation,
OS-requested setup, restored LVGL splash text, logo/BGRT restoration, Linux
completion and the full protected-store oracle. The minimal owned LVGL config
preserves all 343 historical effective macros. Local checker grammar changes
are bound to their unchanged upstream preimage. These are bounded QEMU/HOST
results, not hardware or complete-project sign-off.

The latest quiet three-boot run at signed `ff4792d423` returns 0 in
1m46.58s for the whole test sequence, not one firmware boot. Independent
saved-evidence checks also return 0 for F2 navigation, OS-requested setup,
splash restoration and the protected-store transition. The actual QEMU
profile selects `CDK2_NATIVE_QEMU_TEST_FMP`; this does not prove the native
production SystemFmp writer. The native payload ELF is the unchanged signed
PR544 build, not a newly built PR548 ELF. Screenshots were visually inspected.
The earlier PR547 aggregate failure remains recorded: its store oracle
omitted the actual cold-provider zero-valued FmpState record. PR548 derives
that expected record from the real producer config rather than injecting it.

Native authenticated capsule CHECK and CLOSE have passed, including a
correct-version signed-payload corruption refusal. Native SET at PR385 still
exceeded the unchanged 90-second gate after SET_BEGIN; that failed receipt
remains preserved.
Late bounded debugger samples hit delay, root inventory and DMA table scans.
Source inspection finds 24 unconditional xHCI 1ms reset waits per 4KiB
block, approximately 49 seconds across this image before other work. These
samples do not establish an exact time breakdown. First differing flash
bytes are not a progress measure because erased padding may already match.
PR386 supplies reviewed, exclusive-E8-generation-scoped retirement: the
first mutation cancels controllers, while subsequent admissions repeat the
physical controller, inventory, translation-table and target-exclusion
proofs. Any drift poisons the held scope; it does not re-retire a rearmed
controller or cache a grant across SMIs. Fresh selected and unselected
coreboot builds and real metadata/CLOSE boots pass separately.

The first authenticated native Q35 CHECK/SET and genuine cold-reset history
run at this producer returns 0 in 88.19s for the whole invocation, within the
unchanged 90-second QEMU limit. Actual CHECK leaves media/state unchanged;
SET readback, CLOSE-before-reset, cold-running identity and history pass.
The full firmware route and immutable probe route match their pristine
targets. The whole ROM intentionally differs because durable SMMSTORE state
changes. This is the actual early-RAM component at frozen CDK2 `d3745376a4`,
not a production SystemFmp fullgraph or hardware claim. Restoration from a
byte-identical owned copy of the successfully updated image also returns 0
in 87.65s: actual prior history, unchanged CHECK, exact original-content
route/probe readback, CLOSE-before-reset and cold running/history pass.
The cold restored image runs version `0x001a0009` while retaining successful
attempt `0x001a000b` and floor `0x001a0009`; history is not seeded or erased.
Independent install and owned-copy restoration also return 0. Their whole
invocation times are 88.48s and 94.91s respectively; the latter includes
configuration, compilation and HOST readback. Both actual QEMU invocations
retain the declared 90-second deadline and exit with the required status.
The final whole-image hashes match the author's corresponding results.
The signed finite install/restore packet preserves all four raw runs.
No per-boot timing or controlled performance comparison is inferred.

The full default regression at `dc2b0c60f2` returns 0 after changed-source
recompilation in its prior build directory. The selected VariableRuntime
aggregate at `61f382de12` also returns 0, with the modeled legacy entry isolated
from the genuine protected entry tests. The protected quiet whole regression
at that revision returned 2 because two manual Core recipes omitted the real
direct-image table implementation. PR535 fixes those two link closures; their
focused tests and lint gates pass. The full protected regression at
`74e4fa5122` returned 2: a manual bridge scratch test inherited the caller's
generated-header path and replaced its protected header with the default
profile. PR538 isolates that scratch environment and registers the actual
RAM-window Core gate; its focused tests preserve the caller's hashes. A wider
scratch-caller replay then found inherited build-directory leakage and obsolete
configuration/diagnostic fixtures. PR541 fixes those test-only callers and
resolved fixtures; its seven-caller integration and strict lint gates pass.
Neither contaminated run is a protected-profile pass. A separately started
quiet native run was stopped with SIGTERM when shared artifacts were found
at risk; it is not a pass, irrespective of the unit's result label. Final
whole-regression reruns must fingerprint the actual config and header before
and after testing in independently owned artifact directories.

Both full regressions now return 0 at clean signed CDK2 `522c0a2a7c`:
protected in 21m26.188s and default in 25m28.655s. Both actual config/header
fingerprints remain unchanged. These were changed-source rebuilds in reused,
independently owned artifact directories, not fresh builds. The additive
`full-protected-after541` and `full-default-after541` evidence packets preserve
the raw results separately from earlier failures. Future source changes still
need their appropriate regression gates.

Both full regressions also return 0 at signed PR549 `8b5025c733`: default
in 49m18.70s and protected quiet in 50m39.72s. Actual configuration and
generated-header fingerprints remain unchanged. These concurrent complete
HOST/build runs reused independently owned artifact directories; they are
not firmware boot timings, fresh builds, or whole-regression passes for
newer patches. Their raw logs are signed and pushed in coreboot's
`full-regression-after549` evidence packet.

The complete QEMU harness selftest at signed PR552 `e77ac7cd5c` returns 0
in 4m58.67s, using the genuine producer cbfstool. Its finite signed evidence
packet preserves the earlier PR549 failure and explicitly modeled UI/boot
fixtures. This is a HOST/harness result, not a fresh native payload boot.
PR553 registers the existing software-hash gate and obtains real transitive
compiler dependencies through the existing build helper. PR554/556 clean
the six authored hash adapters and fix reproduced standalone/repeated
inclusion failures without changing the four imported hash C files.
Vectors, strict sanitizer checks and 15 consuming compiler-object
comparisons pass. PR555 teaches checkpatch the actual public capsule HOB
typedef without changing its wire ABI or relaxing spacing rejection.
PR557 refreshes the stale RAM-submit source hash from genuine deterministic
fixture generation; the complete generated disk bytes remain identical.

The separate protected-variable seven-VM suite returns 0 at isolated signed
PR557 `ab2cb8fc96` with the genuine PR386 Q35 producer. Enrolled and ordinary
boot, EBS/nonidentity virtual-address transitions, Auth2 newer/replay/rogue
cases, real Security2 child decisions and cold signed/unsigned/rogue MAIN
outcomes pass. The caller configuration/header, 1570 tracked-source inputs,
448 pinned BearSSL inputs and producer/donor/codec fingerprints remain
unchanged. Its 110.51s whole-suite duration is not a firmware boot timing.
This profile still selects QEMU_TEST_FMP: it proves the protected admission
and variable-runtime regression, not production SystemFmp writing, a complete
EFI-loader matrix, hardware behavior or whole-project completion.

PR542 removes only the two runtime metadata caps that rejected a durable
rollback floor above the still-running image version before reset. Compiled
endpoint baselines, exact running identity and minimum-floor checks remain.
Real session/CMS/payload/board HOST gates refuse a trusted below-floor image
and rogue signer, permit at-floor delegation, and reject four exact restored
cap mutants. Transport execution in that fixture is explicitly modeled, not
a native firmware-write claim. Author and independent replays pass.

The finite owned-file style sweep covers 879 owned files and 14 exact imported
files. Remaining checker findings are classified public FAT ABI tail layouts,
literal operation labels and one userspace ENOSYS/errno check, not permission
to change public UEFI structures.
Fresh release-review agreement remains a separate gate. A fresh aggregate
`make lint review-profile-check` at PR548 returns 2: the stable native-boundary,
type, naming and other stable lint checks pass, but the checkpatch test fails.
The review-profile checks pass. Owned-source and imported-source findings
are being audited; the finite sweep is not a clean aggregate-lint claim.
PR558 preserves the exact whole-tree failure and a fresh 17-file audit at
PR556: 761 errors and 26 warnings remain in that finite scope, predominantly
unchanged imported vboot C. The authored adapters have no errors and one
preserved macro-grammar warning; public FAT tails, literal diagnostic labels
and userspace errno recommendations remain explicitly classified. No lint
rule, exclusion, exception ledger or imported source was changed to hide
these findings. The raw receipts are recoverable from the committed finite
archive in `migration/checkpatch-audit-20261002`.

Capsule media now supports paired transaction acquisition/release on every
exit. The Q35 drain and physical DMA table scanner are reviewed primitives,
not current device-ownership or writer-admission proof. Real held-transfer QEMU
tests distinguish BME clearing from NVMe/AHCI draining and xHCI cancellation.
All six root held-I/O cases pass on the shipped QEMU, with exact helper hashes
and bounded no-late-write observations archived in the evidence branch. Two
actual cold coreboot QEMU boots now exercise retirement and the owned-table
scan before table construction; this is not SMM writer admission. The current
DMA wrapper now requires the actual held E8 owner and irreversible early RAM
window before and after cancellation; metadata and CLOSE do not use it.
The default-off Q35 capsule provider and its real private bootstrap completion
publication are source-reviewed. Its first enabled link attempt exposed missing
existing `memchr` SMM composition; adding the existing coreboot implementation
to that stage fixes the link without another parser. The corrected incremental
enabled build returns 0. Fresh ON/OFF closure and genuine endpoint publication
now pass for the scoped Q35 producer; production fullgraph and other platform
writer admission remain separate gates.
The physical write policy, coherent broker/writer conversion and sealed QEMU
pflash transport are reviewed and published. They preserve genuine SMMSTORE
without inventing raw journals for the authenticated-variable owner. The
irreversible RAM window and its CDK2 consumer are also published. Earlier
HOST-only component results did not establish firmware installation; the
native early-RAM result above is a separately observed bounded proof. The E8
receiver and actual provider are joined for that exact Q35 component, not
for every platform or delivery lifecycle. Metadata
and CLOSE must not reset devices; mutation can retire controllers only in the
genuinely held early RAM window. Disk delivery still needs an independently
validated live-controller lifecycle.

Remaining work:

- Preserve the passing default/protected whole regressions and obtain fresh
  reviewers' agreement after the remaining source changes. HOST linkage and
  scratch isolation defects were fixed without disabling production policy.
- Extend the selected-Q35 typed MM writer/DMA and normal authenticated
  newer-image/original-content-restore proofs to the final profile and supported
  hardware. Prove rejected-request retirement/result/continuation and exact
  interruption recovery without treating transport or ownership failures as
  ordinary capsule refusal.
- Validate board selection and hardware execution of the existing Intel/AMD
  early-DMA producers, allocation provenance, invalidation/drain and exclusion;
  do not infer hardware proof from the selected-Q35 emulator results.
- Validate the final hardware tuple: cold/warm boot, timings, complete EDK2/CDK2
  Linux A/B, UI/firmware-setup entry, capsules, peripherals and power behavior.
- Finish directory/artifact consolidation without losing source or receipts.
  Four inactive dirty review copies have signed, pushed recovery snapshots and
  are consolidated under `Documents/.cdk2-recovery-worktrees-20261002`.
  Three additional inactive clean style worktrees have been retired without
  force after source/bundle verification and fresh reader checks. Their signed
  refs, complete history, source archives and original build artifacts remain
  recoverable; this does not claim whole-host cleanup is complete.
  Four further inactive clean worktrees have been retired without force after
  the same checks. Two initialized-vendor copies were explicitly deferred.
  Four completed PR554--558 style/audit worktrees are also retired non-force
  after all readers released them. Their exact source archives and verified
  complete signed-history bundle are recoverable under
  `/home/sean/retired-style-wave553-558.q2teOr`; no external build or receipt
  was removed.
  The completed provider-session and provider-byte-storage source worktrees
  were also retired non-force after signed-ref, complete-bundle and exact-source
  checks. Recovery is recorded in
  `/home/sean/retired-provider-sources.QDpbwA/README.md`; actual Core/config/tool
  donors and raw receipts were not removed. Historical before-input source
  paths are not claims that those retired worktrees remain live inputs.

Preserve public UEFI ABI/wire types where required; use coreboot-style private
types and naming elsewhere. Discover platform resources from actual coreboot
handoff data rather than per-board payload build arguments. No new features are
added to this scope.

The target is a small, readable UEFI payload whose control flow and ownership
are suitable for review alongside coreboot. Booting Linux is necessary but is
not sufficient: the implementation must be deterministic, linear, and free of
unnecessary EDK2 infrastructure.

Work and commits stay linear. Each mechanism is implemented, reviewed, tested,
and committed before a dependent conversion or deletion begins. The product
priority is also explicit:

1. preserve the earliest possible coreboot-drawn splash;
2. complete the capsule and authenticated-variable architecture, because its
   ownership decisions determine the order of the remaining migration; and
3. complete direct packaging, portability, UI, DMA, style, and release gates
   without parallel alternative production paths.

## Post-audit continuation (2026-09-22)

The source has advanced beyond the older audited pair below. The published,
ready-for-review CDK2 chain now reaches
[PR 347](https://github.com/StarLabsLtd/cdk2/pull/347) at
`c56c1a5d7e1b9cdbee97ec3b40ab6a049de44424`, based on the linear feature and
documentation chain through PRs 314--319 and 322--347.
The published, ready-for-review coreboot chain now reaches
[PR 138](https://github.com/StarLabsLtd/coreboot/pull/138) at
`26e9a61322b1f10d467d6fc171f2494de81c6935`, based linearly on PRs 101--138.
Both heads were open, ready for review, and non-draft when this ledger was
updated; that status is not a merge or release claim.

The dormant authenticated-variable consumer is published as ready PR 349 at
`06345635ff87f1239b2ce973fbe20b375e89531e`, stacked on PR 348. It
consumes the canonical frozen 64-byte endpoint and 144-byte message ABI,
requires a unique validated coreboot-table record, reserves the physical
mailbox as runtime data, and keeps a
private-scratch, fail-closed client outside production selection. O0/O2
ASan/UBSan authvar transport tests, the native coreboot regression test,
repository lints, and exact layout parity against coreboot
`30752e84cfcc1deedf04cb40f744b2c6f905f446` pass. It publishes no endpoint,
replaces no variable runtime, and remains separate from SystemFmp; production
policy, composition, cutover, QEMU, and hardware gates remain open.

- PR 314 makes the stable native lint boundaries executable and reviewed.
- PR 315 hardens the native PE loader and direct-image linkage.
- PR 316 removes the legacy HII BDS dispatch edges, adopts physical native
  USB keyboard input, polls the exact staged XHCI controller during setup,
  and transfers periodic polling plus interrupts only at the external-loader
  boundary. Timer cleanup retains ownership across failure and is retryable.
- PR 316 also drives real QEMU setup through a USB keyboard with i8042
  disabled and makes interrupted QEMU ownership and teardown race-free.
- PR 317 reseals all four retained-relocation ledgers against the final
  default, setup, QEMU, and secure-QEMU firmware volumes. Every positive
  evidence oracle and hostile mutation suite passes; executable, parent FFS,
  report, site, and count columns are unchanged.
- PR 318 mirrors the coreboot revision-2 capsule transport and adds a dormant,
  typed READ_INFO client. It binds immutable identity to the coreboot handoff,
  accepts only bounded monotonic rollback-floor increases, and has no
  production caller, SMI route, writer, persistence, SPI access, or platform
  selection.
- [PR 323](https://github.com/StarLabsLtd/cdk2/pull/323)
  (`5da1f67c00ad565c4a436789b3f83c6ef695f704`) adds a bounded native-LVGL
  splash status strip. It keeps coreboot as the logo owner, restores the exact
  touched rectangle before BGRT publication or loader handoff, keeps normal
  release boots quiet, and makes error text best effort. It does not supply
  exact-head visual or hardware evidence.
- [PR 324](https://github.com/StarLabsLtd/cdk2/pull/324)
  (`26f94f79a1ec21a60fae416dff492f55a5c89f67`) composes the native
  authentication, MSS1 payload, board-binding, durable-state, and typed
  coreboot-transport gates behind one source-neutral SystemFmp session. The
  session is dormant: it has no production caller or selection, publishes no
  FMP/ESRT instance, performs no reset, and does not retire the retained
  SystemFmp/FV path.
- PRs 325--329 reconcile the implementation ledger, harden native variable
  scanning, make the native security stub unconditional in linear profiles,
  select native SystemFmp, and retire PCD from strict linear production.
- PRs 330--333 close strict direct-image composition and provenance, dispatch
  linked images without FV discovery, preserve durable capsule rejection
  across warm reset, and produce the selected strict payload without an FV,
  FFS, DEPEX, or PCD packaging dependency.
- [PR 334](https://github.com/StarLabsLtd/cdk2/pull/334) binds the complete
  ordinary, setup, and Secure Boot QEMU acceptance matrix to exact loader,
  timing, storage-recovery, and teardown contracts.
- [PR 335](https://github.com/StarLabsLtd/cdk2/pull/335) gives ConSplitter
  exclusive strict-setup input ownership and proves both physical F2 entry and
  the two-boot `BootToFwUI` request path.
- [PR 336](https://github.com/StarLabsLtd/cdk2/pull/336) removes the remaining
  build-time SystemFmp identity inputs from strict profiles and requires the
  bounded coreboot runtime identity instead.
- [PR 337](https://github.com/StarLabsLtd/cdk2/pull/337) consumes coreboot's
  backend-neutral revision-2 DMA contract, restricts every admitted requester
  to its immutable arena, and quiesces and scrubs those arenas before loader
  handoff.
- [PR 338](https://github.com/StarLabsLtd/cdk2/pull/338) validates complete
  pre-EBS NVMe and XHCI spans against those arenas and uses an unlisted EDU
  requester as the default-deny fault oracle.
- [PR 339](https://github.com/StarLabsLtd/cdk2/pull/339) and
  [PR 340](https://github.com/StarLabsLtd/cdk2/pull/340) define and harden the
  pointer-free authenticated-variable service ABI without adding a caller,
  endpoint, storage backend, writer, journal, or payload-owned SMM code.
- [PR 341](https://github.com/StarLabsLtd/cdk2/pull/341) replaces strict PCI
  configuration-space rediscovery with the bounded, generation-bound topology
  and resource handoff produced by coreboot. It retains read-only live identity
  checks and removes the obsolete scan-era hierarchy harness.
- [PR 345](https://github.com/StarLabsLtd/cdk2/pull/345)
  (`a785835b39b3c9e3ef8347d9c908d2eabb2694b9`) validates the fixed-width
  authenticated-variable response status/result matrix, including bounded and
  scrubbed GET/NEXT results, QUERY accounting, hostile statuses, and legal
  zero-GUID keys. It remains a consumer-side ABI validator: it adds no caller,
  endpoint, store authority, persistence, writer, journal, or payload-owned
  SMM code.
- [PR 347](https://github.com/StarLabsLtd/cdk2/pull/347)
  (`c56c1a5d7e1b9cdbee97ec3b40ab6a049de44424`) removes runtime-reachable
  FV2 scanning, FFS parsing and DEPEX dispatch from strict DxeCore while
  retaining the separate non-strict compatibility route and external
  filesystem/device-path `LoadImage()` support. Artifact and mutation oracles
  prove fresh strict PE/map closure; profile-sensitive tests separately prove
  correct strict-to-compatibility same-directory rebuilding.
- [coreboot PR 126](https://github.com/StarLabsLtd/coreboot/pull/126) defines
  the backend-neutral arena contract;
  [PR 127](https://github.com/StarLabsLtd/coreboot/pull/127) supplies the real
  Q35 NVMe/XHCI producer and EDU denial oracle; and
  [PR 128](https://github.com/StarLabsLtd/coreboot/pull/128) inventories the
  exact Meteor Lake requesters without claiming a production VT-d backend.
- [coreboot PRs 129--131](https://github.com/StarLabsLtd/coreboot/pull/131)
  complete the reviewed Intel/AMD DMA continuation and linear test repairs;
  [PR 132](https://github.com/StarLabsLtd/coreboot/pull/132) defines the
  dormant authenticated-variable service ABI; and
  [PR 133](https://github.com/StarLabsLtd/coreboot/pull/133) adds its bounded,
  default-off, read-only EDK2-layout store scanner.
- [coreboot PR 135](https://github.com/StarLabsLtd/coreboot/pull/135)
  (`a209e79028cf2dbb989ac5e3aed5bba7d8dbb91c`) adds the read-only EDK2
  26.09 FV/FTW recovery decoder and compiles both authvar decoders in the Q35
  proof configuration. Its strict host suites and full proof-enabled Q35 build
  pass. PRs 133 and 135 deliberately add no flash write, variable-service
  endpoint, table publication, or CDK2 caller.
- [coreboot PR 136](https://github.com/StarLabsLtd/coreboot/pull/136)
  (`04ef2065455491344b1c3eabf396c239b8673353`) supplies the matching
  fixed-width response status/result matrix and hostile coreboot-side ABI
  validation. It publishes no endpoint and dispatches no operation.
- [coreboot PR 137](https://github.com/StarLabsLtd/coreboot/pull/137)
  (`2afa66dd89a2cc888ef3b884d1032d25992db189`) adds pure, read-only
  GET, NEXT, and QUERY semantics derived from pinned EDK2 26.09 for the
  persistent common-store subset, plus a deterministic append-or-reclaim space
  planner. This is not end-to-end parity: volatile, HOB, and hardware-error
  classes are excluded, and the canonical zero-size wire cursor differs from
  EDK2's public NEXT input. The planner describes copies and placement only: it
  does not mutate media, execute FTW, authenticate an update, publish a service,
  or provide a CDK2 caller.
- [coreboot PR 138](https://github.com/StarLabsLtd/coreboot/pull/138)
  (`26e9a61322b1f10d467d6fc171f2494de81c6935`) adds the sealed SMMSTORE-
  relative media port. It binds callbacks and copied context to the installed
  SMRAM authority, serializes sessions, verifies NOR program/erase by sync and
  exact readback, and poisons ambiguous mutation. It remains a dormant Q35
  compile proof with no record writer, FTW executor, endpoint, backend producer,
  SMI route, table publication, or production selection.

The exact PR 335 payload is
`6b1c50391b28142ab91f891dbe46fe5e7ef2a300e56755d10f7eb33a4cbcd5d2`;
its paired ROM is
`60a5c9fcd223deea7a6c4fd0253e287c4aeee810b8e7e7eaec5fc8ae8266a32b`.
Its UI evidence remains under `../cdk2-validation/pr335-final-157f71d07c/`.
F2 setup, OS-requested setup, Linux handoff, hostile evidence tests, and the
broad QEMU harness passed at that revision.

The exact PR 338 DMA pair uses
`../cdk2-validation/dma-qemu-real-requesters/rev2-final-dma.rom`, SHA-256
`d9977cb099fba478dc0a530f1e5a48d3835aedb90b34ab5dcd67a0ba73d86e90`.
Independently reviewed evidence is under `rev2-final-nvme-2/` and
`rev2-final-usb-2/` in the same directory. Both lanes pass complete-span
requester validation, the unlisted EDU denial, requester quiescence, Linux DMAR
takeover, EFI runtime variable exercise, and clean S5. These are exact Q35
mechanism and integration results, not production Intel/AMD backends, a repeat
of every PR 335 UI lane at PR 338, or hardware sign-off.

### Historical whole-project gap inventory (superseded)

The continuation closes the selected strict outer-packaging, setup, and Q35
DMA mechanism gates, but it does not close the entire coreboot-native brief.
The following ten-gate inventory records the earlier migration state. Its
missing capsule/authenticated-variable backend, runtime capsule-policy and
external-packaging claims are superseded by the current checkpoint and updated
sections below; it is not a current missing-mechanism list. Unclosed validation,
compatibility, TPM, UI and hardware gates still apply:

1. **Execution and direct packaging:** the selected strict payload and DxeCore
   now have no FV carrier, FV2 scanner, FFS parser or DEPEX dispatcher. Finish
   typed phase inputs/outputs and add CDK2 to coreboot's payload menu/build
   rules without restoring a second package owner. Non-strict compatibility
   remains a separate profile.
2. **Runtime platform facts and portability:** PR 341 completed authoritative
   coreboot PCI topology consumption for the strict import path; non-strict
   compatibility retains enumeration. Strict owned-device configuration and
   quiescence still use bounded PCI config access in addition to immutable
   topology identity/resource consistency checks.
   Reset and S5 facts already come from coreboot-published ACPI/FADT data. The
   concrete audited build-time residual identified here is capsule delivery
   capability and size policy; the broader production-input audit remains open.
   EC/battery values are non-strict compatibility debt, power-button data is a
   future capability, and CPU vendor only selects payload-owned-SMM/test
   fixtures. Replace applicable residuals with typed runtime handoffs, then
   prove one payload across Intel and AMD.
3. **Native UI and splash:** complete LVGL ownership of setup, Secure Boot,
   accessibility, boot selection, product strings, and one-shot splash/error
   text while preserving coreboot as the earliest and only logo owner.
4. **Capsules:** compose and publish the protected broker, flash planner,
   endpoint, FMP/ESRT identity and persisted reset/result handling; then retire
   transitional SystemFmp FFS/internal-FV routes and prove both update
   directions plus hostile/interrupted cases.
5. **Authenticated variables:** implement the small coreboot Payload MM
   library as the sole authority inside coreboot-controlled SMM, expose only the typed
   DMA-protected CDK2 runtime/VariablePolicy proxy, retire raw payload SMMSTORE
   and FVB/FTW mutation, and make SMM_BWP non-bypassable in production. The
   published work now supplies the dormant ABI, fixed response matrix, bounded
   read-only variable scanner, read-only FV/FTW recovery decoder, read-only
   GET/NEXT/QUERY semantics, deterministic reclaim planning, and a sealed,
   verified media port. The
   authenticated update policy, AUTH2 parser and crypto, key hierarchy,
   crash-consistent journal/executor and append/reclaim writer, protected
   endpoint and table producer, DMA-protected CDK2 runtime/VariablePolicy
   proxy, raw-SMMSTORE/FVB/FTW deletion, no-bypass production composition,
   differential QEMU tests, and hardware evidence remain. This is not yet an
   authenticated-variable backend.
6. **TPM measured boot:** close firmware issue 454 with exact PCR 4/5 and
   separator ordering, supported-bank, Linux event-log, `systemd-pcrlock`, and
   single-ACPI-owner evidence. coreboot PR 134 and CDK2 PR 342 now provide
   independently reviewed, exact-head Q35 ownership and four-bank evidence:
   the strict-direct ROM reaches Linux and powers off with status zero, exposes
   one `MSFT0101:00`, and passes the PCR 4/5 replay oracle. `systemd-pcrlock` is
   absent from the current Linux fixture and remains an explicit nonclaim.
7. **DMA:** the revision-2 exact-BDF handoff, pre-mapped arenas, default-deny
   policy, and real NVMe/XHCI Q35 acceptance are complete. Add production Intel
   Meteor Lake and AMD Cezanne producers, enumerate every owned controller,
   complete portability review, and capture hardware evidence.
8. **Runtime and asynchronous ownership:** prove loader/runtime-service paths,
   USB deadlines, hotkeys and teardown with explicit owners for every remaining
   event, interrupt and DMA-capable device.
9. **Style and deletion:** finish source-wide coreboot naming, integer types,
   includes, ABI-boundary isolation, dead-code removal, provenance and
   size/complexity/performance ratchets without adding single-use helper noise.
10. **Validation and release:** capture exact-head QEMU acceptance after each
   serial slice, then complete Linux, UI/hotkey, capsule, timing, log,
   failure-path and recovery validation, EDK2/CDK2 A/B, and capsule round trips
   on the designated hardware.

The exact `aede328` implementation payload was rebuilt with the Q35 setup
profile and passed the machine-checked F2, Down, Escape, LVGL setup
transition, splash restoration, Linux runtime, and acceptance-harness
teardown lane. The resulting ROM is
`fde1f1aa2c01c7cc173df9799eff4f5ed2a685e57da08d4d8541afb831bf03c6`.
Evidence is under `../cdk2-validation/qemu/pr315-final-aede*`. PR 317 closes
the inherited retained-relocation evidence gate for its exact successor
volumes. The PR 318 transport/parser and client suites pass at O0, O2, and
under ASan/UBSan, including hostile response, reentry, cache, scrub, and close
paths. PR 323 and PR 324 add reviewed source and hostile host-test coverage,
but production capsule composition, final exact-head QEMU, and hardware
sign-off remain open.

## Status at the audited heads

This roadmap was reconciled on 2026-09-19 against this exact pair:

- CDK2 `d048700e333c3a68b388eeb4c10a46c9ffb37809` (PR 298); and
- coreboot `4dff00b51e4a5870134d810db34c862411942474`
  (PR 86).

The acceptance ledger contains 106 gates. At this pair, 33 are accepted and
73 remain open: **31.1% complete**. The count is deliberately conservative.
A reviewed prerequisite, a passing host test, or a boot of an earlier image
does not close a broader production or exact-head gate.
This percentage is a frozen historical measurement of that audited pair; no
current completion percentage is claimed for the continuation heads.

- `[x]` means the implementation is present at that exact source revision. It
  does not imply that the exact revision has passed QEMU or hardware sign-off.
- `[ ]` means either implementation remains or the required evidence has not
  been captured for that exact revision.
- Host tests, an older QEMU run, or an older hardware boot cannot substitute
  for a named exact-head QEMU or hardware result.

Earlier notes that say "only hardware remains", "testing only", or give a
higher completion percentage are historical snapshots and are superseded by
this ledger. Source, packaging, selection, security, and QEMU gates remain in
addition to hardware validation. Preserve those notes as historical evidence;
do not use them as current completion claims.

Fresh exact-pair QEMU boot, UI, capsule, and failure-path evidence is not yet
complete. Fresh exact-pair hardware evidence is also not recorded.

### Accepted CDK2 slices since the previous roadmap audit

These slices are reviewed and tested at their exact commits. Their non-claims
are part of the evidence: none closes a broader gate unless every remaining
subgate is also satisfied.

- **PR 292** (`b5dff4d8de8fdb62c1234884fdaf4bd448e7cae6`): the dead
  LVGL IFR parser is removed and the production LVGL image is byte-identical.
  This does not provide native setup or splash text.
- **PR 293** (`388566459935190b4835b48911df227e1b69b247`): keyboard
  layout no longer consumes HII; native and sanitizer tests pass. This does
  not remove the HII database or make setup native.
- **PR 294** (`ef14641d2accae45fa24028572d5f80ef02120b2`): the graphics
  console renders its source-owned font directly. This does not validate the
  native LVGL setup path.
- **PR 295** (`fd45285858249073216f6905da5f19802e76269a`): six HII
  protocol families and their producer are absent, and the pre-existing
  VFR/UNI absence is enforced. It did not remove VFR/UNI files. HII-dependent
  third-party applications are unsupported, and setup remains open.
- **PR 296** (`1075b6747da35a22568233552e87ba6882b705ab`): the linear PCI
  host bridge consumes the coreboot resource HOB rather than dynamic PCD.
  Nonlinear PCD scan compatibility and other production PCDs remain.
- **PR 297** (`b41d2fa598cbda97744722c89c16a18c8357fb80`): GRUB,
  shim-to-GRUB, and systemd-boot reach a probe in QEMU. The evidence is
  Secure-Boot-off and is not final exact-head validation.
- **PR 298** (`d048700e333c3a68b388eeb4c10a46c9ffb37809`): linear
  SecurityStub DEPEX no longer consumes PCD, and Q35 boots Linux. The retained
  PE, FV/FFS packaging, and production PCD package remain.

### Dormant coreboot capsule slices

coreboot PRs 81--86 form one reviewed, dependency-ordered dormant chain. They
prove protected mechanisms, not a usable capsule endpoint.

- **PR 81** (`28bc24720981de10dc462d87269919471b35c23d`) seals the
  authentication callback and checkpoint-bound approval. It adds no provider,
  executor, transport, backend, endpoint, or selection.
- **PR 82** (`30a1f0b2aeea124c4065f8e670b308357836620e`) adds a bounded
  SMM CMS/X.509 verifier and proves Q35 fits in the TSEG budget. It adds no
  policy/provider or production selection.
- **PR 83** (`89d37467fbf98785f69b502e01a0361365a28303`) adds the
  board-bound MSS1, rollback, dependency, and trust policy owner. It adds no
  executor, transport, backend, endpoint, or selection.
- **PR 84** (`17fc59ecd5884af05d69173b04d75fb91d242c2e`) adds the
  synchronous protected CHECK/SET transaction executor. It adds no transport,
  backend, endpoint, producer, or selection.
- **PR 85** (`6d4f39bd9fb1cd2da4c244a2670f1cc0225705ab`) separates the
  authenticated envelope from the sealed raw-ROM span. It adds no transport,
  table, SMI endpoint, backend, or selection.
- **PR 86** (`4dff00b51e4a5870134d810db34c862411942474`) adds the fixed,
  pointer-free request/intent/result transport. It adds no SMI entry, table
  producer, backend, endpoint publication, or selection.

The published linear continuation in coreboot PRs 102--111 adds proof and
prerequisite slices without composing a production capsule service:

- **PR 102** (`a0d26cf24b36bc0a5861df1f4d5dc81f96d29df6`) extends the
  coreboot/CDK2 ABI validator across the revision-2 handoff, endpoint,
  transport, intent, and result. It changes validation only and installs no
  producer, endpoint, SMI route, backend, or platform selection.
- **PR 103** (`077f851965d89008761c4a6a96e28f5cb9016b2c`) makes the
  legacy capsule driver, full-flash SMMSTORE modifier, and direct writable
  boot-device route unavailable when the typed contract is selected. This is
  build-time route exclusion, not runtime isolation or production broker
  composition.
- **PR 104** (`268ce668ec21781500b3f1c8537e751b7e5cf092`) adds the
  dormant, default-off, one-shot TPM anchor grant. It performs no TPM
  mutation and supplies no authorization provider, route, or endpoint.
- **PR 105** (`9a68d30a35f2e0c6555fb37cabc5dd518c600e23`) adds the
  dormant, reset-safe owner-journal PREPARED sidecar and reconciliation path.
  It adds no TPM call from SMM, route, endpoint, raw-flash path, or selection.
- **PR 106** (`18d0be9efe409f86105eedd3820dd8640e43d108`) adds the
  hidden, default-off pre-OS anchor-transition coordinator contract. It has no
  production authorization provider, prepared-state reader, route, or
  endpoint.
- **PR 107** (`825c5b76fc0a64479de03c3687126701afe70113`) adds
  default-off Q35 fixed communication and staging buffers. It proves their
  allocation and lifetime ownership and provides separate SMM-owned scratch;
  it publishes no endpoint and makes no DMA-protection claim.
- **PR 108** (`ec6fdd76dddeab79cd1d235d5a5038e7e5d8b54b`) wires the
  existing default-off early-DMA policy into Meteor Lake FSP-M and restores
  PMR protection after memory initialization. It is a prerequisite, not a DMA
  handoff, capsule-range proof, or production guarantee.
- **PR 109** (`a99c5dc2d8ef30e04cda8dd1db4fbb98baf2ac05`) adds the
  default-off, one-shot PREPARED-state reader with exact media, layout,
  identity, and anchor binding. It adds no write path, TPM policy provider,
  route, or publication.
- **PR 110** (`fd64c79979d938f81032c74c93ae195c45053905`) revises the
  dormant transition authorization ABI to bind separate `NV_Write` and
  `NV_WriteLock` operations and authoritative readback. It still has no
  concrete TPM policy provider, platform selection, route, or endpoint.
- **PR 111** (`aaecc1c9138d2f890a5cc5bb2519b8557a54fecd`) adds a
  default-off Q35 exact-range DMA proof for the fixed capsule buffers. Its
  real denied and positive-control traffic is specific to QEMU EDU; it
  installs no broker, SMI route, endpoint, or production DMA guarantee.
- **PR 112** (`aaf61ea86c8ae1f4a522c23364bd02f0846cf083`) adds
  caller-owned TPM2 transports for bounded NV reads, policy sessions and
  transient objects. It preserves the legacy global wire path and stack
  footprint, adds empty-password `AUTHREAD`, and carries the scoped transport
  through mandatory cleanup.
- **PR 113** (`51d5ae6f2dd0face557826ed5a2573664ac2222b`) adds the
  default-off capsule anchor policy provider. It verifies the exact NV public
  area, derives the fixed policy and command hashes, executes distinct signed
  write and write-lock transcripts, seals hostile inputs and attempt state,
  and distinguishes delivered TPM errors from malformed replies or transport
  loss. No platform selects it or supplies its authorization and protected
  storage callbacks.
- **[PR 114](https://github.com/StarLabsLtd/coreboot/pull/114)**
  (`1f2954bc200c4f3f5f6caf692880b9a9d7d8012f`) adds the default-off,
  exclusive pre-OS TPM2 FIFO lifecycle owner. It takes the exact legacy FIFO
  route once, rejects later global access, rechecks locality before command
  readiness, and quiesces/releases locality before payload handoff. It adds no
  authorization material, capsule provider, SMI route, endpoint, or platform
  selection.
- **[PR 115](https://github.com/StarLabsLtd/coreboot/pull/115)**
  (`7f9166b93ef051424a484659b015d8732f1e5132`) extends the durable PREPARED
  journal with signed transition-authorization material and a capsule receipt,
  then validates and independently rereads both through a one-shot pre-OS
  reader. Its version-2 composite candidate anchor binds the exact manifest,
  predecessor anchor, generation, transaction, and complete-capsule receipt
  prefix while excluding the authorization bytes that would make the format
  self-referential. It rejects revision-1 receipts, ambiguous divergent
  duplicates, and ordinary journal commits after an authorized transition,
  and preserves the composite sidecar through recovery and garbage collection.
  The amended head passed independent final review and its O0/O2, strict,
  ASan, UBSan, interruption, transcript, and checkpatch suites. It adds no
  pre-OS composition, protected flash
  planner/backend, SMM grant installation, broker, SMI endpoint, production
  selection, or CDK2 caller.

Where these slices have selectable firmware paths, those paths remain dormant
and default-off. A concrete TPM authorization provider, an exclusive pre-OS
FIFO owner, and durable authorization storage now exist, but there is still no
pre-OS composition, protected flash planner, protected SMM grant installation,
production broker, or endpoint. Published PR 115 now uses a version-2
authorized composite candidate digest over
`domain || manifest || current || generation || transaction || receipt_prefix`,
excluding the authorization and `auth_digest` fields to avoid self-reference.
Supplying that authorization requires a two-round or otherwise separate
authorization flow; an embedded-auth MSS1 cannot authorize itself. Prove that
flow and its reset/resume behavior before selecting the chain. The Q35 DMA
result now covers real NVMe and XHCI requesters with EDU as the unlisted denial
oracle; production Intel and AMD DMA integration and all corresponding hardware
validation remain open.

The capsule production gate is split by mechanism and validation scope:

1. resolve and prove the durable signing and reset/resume model;
2. compose the pre-OS TPM authorization path;
3. the protected planner/backend, immutable-region policy, broker, DMA gate
   and readiness-gated endpoint are implemented and exercised on selected Q35;
4. normal source-owned SystemFmp update/restore and durable state/reset are
   proven in that emulator scope; safe rejected-request continuation remains open;
5. strict direct composition omits transitional SystemFmp FFS/internal FV,
   while compatibility-carrier retirement remains separate; and
6. complete final exact-pair, enrolled-policy, interruption, round-trip and
   hardware validation. None of the selected-Q35 results closes items 1 or 2.

### Current open-work snapshot

The following are source or validation work, not hardware-only cleanup:

- native LVGL Secure Boot controls, accessibility, product strings, boot
  policy, and exact visual/hardware proof. HII, VFR, UNI, and IFR are absent;
  native LVGL setup and QEMU USB input exist, and PR 323 supplies the source
  status overlay;
- final artifact/profile closure, not a retained executable-FV discovery,
  dynamic-PCD or payload-owned-SMM family. Commit
  `d2998fe1e3ac8bf32930bb5b2c5d9f5c10a2a469` retired those families; current
  source/config inventory has no PcdDxe/database/extractor or dynamic-PCD
  production path. PR587 removes the unused `src/boot/fv.c` discovery object
  and recipes rather than retaining an uncalled compatibility parser. FV/FVB
  variable-store formats and codecs are distinct from executable FV/FFS packaging;
- capsule validation beyond the implemented selected-Q35 endpoint, protected
  backend, shared selection and normal update/restore: safe refusal lifecycle,
  interruption/recovery, DISK ownership and supported hardware;
- platform selection and an authorization/protected-storage route connecting
  the TPM policy provider to the dormant grant, PREPARED journal/reader, and
  transition contracts;
- board selection, profile builds and hardware proof for the existing Intel
  and AMD early-DMA producers. StarBook MTL has revision-4 controller inventory
  in `payload_resource_handoff.c`; Cezanne has DMA handoff/binding/guard/policy
  code, but its default mainboard selector returns NONE and requires an exact
  board override. Code availability is not selected-board or hardware proof;
- complete versioned coreboot-table coverage for every platform fact;
- authenticated-variable final-profile/hardware/differential and interrupted
  recovery validation. Selected-Q35 AUTH2 policy, SMM endpoint/media/writer,
  FTW/store codecs and runtime proxy already exist and have bounded tests;
- owned-code style conversion, narrow `EFI_*`/`CHAR16` boundaries, dead-code
  deletion, and size/complexity ratchets; and
- final exact-pair QEMU, UI, loader, failure-injection, performance, A/B,
  capsule, and hardware evidence.

The requested authorship/review structure is also not yet evidenced as a
complete ledger. Before sign-off, record eight subsystem implementation
owners and eight independent opposing reviews, with exact commit, reviewer,
findings, resolution commit, and rerun evidence for every lane. Existing
individual exact-commit reviews count only where that mapping is recorded.

Work that does not change the capsule trust boundary can proceed in parallel:
authenticated-variable threat modelling, coreboot-table inventory, Intel/AMD
DMA ownership mapping, direct-image/FV cutover harnesses, event/async
inventory, grouping the open EDK2 delta, style/dead-code review, and QEMU
automation. Production capsule work must retain the serial order above. After
that chain, finish authenticated variables and disable raw SMMSTORE; then
finish Secure Boot UI, coreboot-table coverage, DMA, direct-image selection and
residual helper/dead-code disposition, event linearization, style/deletion,
both missing review ledgers, and final QEMU plus hardware evidence.

### PR 219 reconstruction ledger

PR 219 remains open at
`31f23abede9d9319990238933e9b9d407afbb701`. Its reconstruction is a release
gate, not historical context. Every change in that exact source must have one
ledger row classified as:

1. implemented by a named, reviewed, dependency-ordered linear successor;
2. intentionally rejected with a recorded reason and opposing review; or
3. still open with an owner, dependency, and acceptance evidence.

The current ledger status is **open**: an exhaustive row-by-row mapping has
not been recorded at the audited pair.

The ledger must preserve splash-first ordering. Capsule ownership and trust
boundary decisions control every dependent conversion or deletion. A later PR
number, similar feature name, or passing aggregate build is not proof that a
PR 219 change has been reconstructed.

- [ ] Pin the validated EDK2 26.09 reference revision, audit every later EDK2
  change that affects a retained UEFI ABI or required behavior, and backport
  the applicable fixes without reintroducing its build or dispatcher model.

The EDK2 26.09 delta inventory frozen at CDK2
`67cfe2d45f1cbf5b99ff39855fb1e9593b89efda` had 262 entries: 133 irrelevant,
41 implemented, one explicitly backported, 79 open, and eight validation gaps.
These are historical counts, not PR 324 status. Reconcile every row against PR
324 before assigning current counts or grouping the remaining implementation
and evidence work; the inventory is not itself acceptance evidence.

## 1. Preserve the known-good hardware baseline and timings

- [ ] Record one tracked tuple containing the exact coreboot, CDK2,
  configuration, ROM, and capsule hashes for the first CDK2 build known to
  boot Fedora on `lite_adl`; component hashes alone are not that evidence.
- [ ] Preserve its complete UART and CBMEM logs as durable test artifacts.
- [ ] Record cold-boot timings for every named phase and Linux login readiness.
- [x] Append coreboot-compatible events for the linear phases and module
  boundaries to the coreboot CBMEM TIME table, preserve the sink across reduced
  system-table handoffs, and use the same event IDs in diagnostics.
- [x] Host-test seeded coreboot TIME tables for monotonic timestamps, bounded
  capacity, and retention through module reconfiguration.
- [x] Provide quiet release diagnostics and keep boot-bounded debug routing
  separate from the linear control flow.
- [ ] Capture exact-head QEMU and hardware proof that `cbmem -t` exposes every
  expected event and that UART and CBMEM agree after injected failures.
- [ ] Measure debug and quiet builds to prove serial output is not dominating
  production boot time.

The two persistent-console deliverables are distinct:

- **CBMEM console:** source lineage is recorded at
  `f26b70cb9f1367ceb25190ba2777631ee42c69fe`; the current bounded coreboot
  handoff, ring writer, configuration, and host tests remain in the audited
  source. Exact-pair QEMU and hardware `cbmem -c` readback, injected-failure
  agreement, and implementation-to-opposing-review mapping remain open.
- **SPI console:** the source and host-test evidence is
  `9c3b9526f3a5a6a223edf5b25a878af24a93206d`, followed by the boot-global,
  SMM-safe lifetime fix at
  `bf36761feb2beb69e513167d9f94badf728bdbc1` and terminal-evidence budget at
  `7083044ab620660e675f69ff2d84b39c05338b23`. Exact-pair QEMU and hardware
  SPI readback, failure behavior, and implementation-to-opposing-review
  mapping remain open.

Acceptance: the baseline can be rebuilt byte-for-byte or its differences are
accounted for, and a regression can be localized to a named phase.

## 2. Capture an EDK2/CDK2 Linux A/B reference

Collect the same data from the same `lite_adl` unit after a cold boot with EDK2
and CDK2. Store raw output and a normalized diff; do not compare selectively.

- [ ] Firmware: complete UART, `cbmem -c`, `cbmem -t`, SMBIOS, ACPI tables,
  EFI memory map, EFI variables, ESRT, and firmware-update device metadata.
- [ ] Linux: `dmesg`, `lspci -nnvvxxxx`, `lsusb -v`, `lsblk`, `findmnt`,
  `/proc/iomem`, `/proc/ioports`, `/proc/interrupts`, IOMMU groups, loaded
  modules, network devices, input devices, power supplies, and backlight.
- [ ] ACPI: raw tables plus decoded `acpidump`/`iasl` output.
- [ ] Graphics: framebuffer/GOP handoff, display mode, backlight, and bootsplash
  continuity.
- [ ] Power: battery status, charging state, suspend/resume, reboot, and poweroff.
- [ ] Classify every difference as intentional, harmless, or a defect with an
  owner and follow-up test.

Acceptance: CDK2 exposes all hardware and firmware interfaces required by
Linux, or each remaining difference has a documented fix.

## 3. Keep one early splash owner

- [x] Adopt the framebuffer and validated splash metadata produced by coreboot
  instead of drawing a second normal-boot logo.
- [x] Retain the coreboot BMP for zero-copy BGRT publication and restore only
  the changed splash rectangle after setup or another UI owner dirties it.
- [x] Bounds-check the framebuffer, image rectangle, BMP allocation, and CBMEM
  record before adopting them; fall back to the native early renderer only when
  no valid coreboot splash record exists.
- [x] Restore concise, one-shot phase and error text through the native LVGL
  path without HII, periodic redraws, or a full-frame clear. PR 323 provides
  the source implementation; exact-head visual and hardware proof remains
  separate below.
- [ ] Visually verify exact-head QEMU framebuffer continuity, setup return,
  BGRT contents, quiet-profile suppression, and the error overlay.
- [ ] Confirm the same behavior and earliest-logo timing on hardware.

Acceptance: coreboot draws the first and only logo; CDK2 adopts it without a
visible clear or redraw and can add useful native status text when configured.

## 4. Make capsules reliable in both directions

The selected architecture keeps coreboot SMM as the sole resident
authenticated-variable authority and flash writer. CDK2 is a thin UEFI runtime
and VariablePolicy proxy over a fixed, pointer-free, revisioned coreboot-table
mailbox; it has no authoritative variable cache, FVB, FTW, PI MM dispatcher, or
parallel store owner. The typed mailbox supplies only `GET`, `NEXT`, `SET`, and
`QUERY`, plus irreversible `READY_TO_BOOT` and `ENTER_RUNTIME` restriction
transitions. SMM copies each request once into SMRAM, uses generation and
request-ID validation with a non-waiting lock and SMI rendezvous, writes bounded
response bytes and the echoed header/status, then publishes `completion` last.

Preserve the EDK2 authenticated-store format and the pinned 26.09 external
semantics: `EFI_VARIABLE_AUTHENTICATION_2` time-based signatures with SHA-256,
SHA-384, and SHA-512; PK/KEK/db/dbx/dbt/certdb hierarchy; append and delete.
Counter-based authentication remains unsupported. Do not grant unconditional
physical presence. Derive flash geometry from FMAP, keep authenticated-variable
and FMP journals in separate domains, suppress `CB_TAG_SMMSTOREV2` raw write
and clear operations, and route coreboot's internal option writes through the
same sole authority. DMA protection is a prerequisite for exposing the
mailbox.

- [x] Threat-model variable reads, writes, enumeration, garbage collection,
  Secure Boot key updates, rollback, physical-presence policy, and SPI access.
- [x] Document the small typed coreboot-SMM/CDK2 trust boundary and validate
  its pointer-free ABI shape. Do not import an EDK2 PI MM/SMM dispatcher or
  parallel driver model.
- [x] Implement the bounded read-only authenticated-variable store scanner and
  exercise its record-layout and visibility rules with an independent fixture
  derived from pinned EDK2 26.09 sources. Full recovery execution and
  interoperability remain open.
- [x] Implement the read-only EDK2-compatible FV/FTW geometry and recovery
  decoder using the pinned 26.09 state-first FTW queue layout. Retained CDK2
  `ftw_pi.h` is not a compatibility oracle and remains scheduled for removal
  with the payload-owned FTW path.
- [x] Implement pure GET, NEXT, and QUERY semantics plus deterministic
  append-or-reclaim planning over a successfully scanned store. The planner
  records copy order, transition promotion, and destination placement; it does
  not write media or execute recovery.
- [x] Validate the exact fixed-width request/response status and result matrix
  independently in coreboot and CDK2, including buffer bounds, scrubbed output,
  QUERY limits, hostile statuses, and legal zero-GUID keys.
- [x] Add the sealed SMMSTORE-relative media port inside the installed SMRAM
  authority. Serialize sessions, bind cache validity to backend generation,
  enforce NOR program/erase rules, and require sync plus exact readback before
  accepting mutation. PR 138 is a dormant Q35 compile proof with no backend
  producer or endpoint.
- [x] Implement the append/reclaim record and state writer against the sealed
  media port. Final EDK2 visibility/transition differential and interrupted
  recovery validation remain open rather than a missing-writer claim.
- [ ] Complete FTW journal/executor validation with reset injection at every
  erase/program boundary and verified recovery after power loss; existing
  codecs and execution tests do not establish that complete matrix.
- [x] Implement selected-Q35 AUTH2 parsing, SHA-256/384/512 verification and
  authenticated update policy. `payload_mm_authvar_authority.c` binds the
  parsed request, existing record, timestamp and verification result; this is
  an implemented authority, not only a read-only decoder.
- [ ] Complete the exact-profile PK/KEK/db/dbx/dbt/certdb hierarchy, append,
  delete, rollback, timestamp, Secure Boot mode and physical-presence behavior
  audit and differential/hardware evidence. Counter-based authentication
  remains unsupported; the implemented subset does not close every clause.
- [x] Implement the DMA-protected mailbox, table validators, SMM authority,
  dispatch/locking/lifecycle path and thin CDK2 runtime/VariablePolicy proxy
  for the selected-Q35 composition.
- [ ] Audit every remaining compatibility profile for generic SMMSTORE
  mutation or retained EDK2 FVB/FTW bypass; selected typed authority alone does
  not prove all profile exclusions.
- [x] Keep capsule writes separate from variable writes and restrict them to a
  validated, authenticated, board-matched BIOS/update-region operation.
- [ ] Reconcile capsule flash ownership with Gerrit 91652 and preserve all
  immutable flash regions.
- [ ] Reuse outer coreboot Kconfig symbols for SMM write protection, the typed
  authenticated-variable authority, capsule support, SPI ownership, Secure
  Boot, and platform capabilities.
- [ ] Reconcile `migration/edk2-26.09-delta-audit.*`, the legacy-boundary
  disposition/resweep, and related SystemFmp migration documentation so
  `Payload MM` consistently means the authority hosted by coreboot-controlled
  SMM, never payload-owned PI MM or a second variable-store owner.
- [x] Implement one capsule-profile Firmware Management Protocol instance and
  one corresponding ESRT entry in the capsule-enabled source path.
- [ ] Prove that the final exact-head capsule profile publishes exactly that
  FMP/ESRT pair, while capsule-disabled profiles publish neither.
- [x] Demonstrate EDK2 to CDK2 using the in-memory `lite_adl` capsule path on an
  earlier known build.
- [ ] Repeat EDK2 to CDK2 with the final exact-head candidate.
- [x] Update CDK2 to a newer CDK2 build through the normal production RAM path
  on selected Q35, and restore original full Core content at a later admitted
  version. This is not the final hardware/EDK2 round trip.
- [ ] Roll CDK2 back to the preserved EDK2 image with
  `fwupdtool install-blob coreboot.cap <device-id>`.
- [ ] Verify Linux and fwupd report matching device ID, version, minimum
  version, flags, and capsule GUID under EDK2 and CDK2.
- [ ] Validate authentication, bounds, BIOS-region targeting, reset, persisted
  status, and negative cases including corrupt, wrong-board, wrong-GUID,
  truncated, and interrupted updates.
- [ ] Differential-test GET/NEXT/SET/QUERY, enumeration, quota, recovery, key
  hierarchy, lifecycle restriction, and power-loss behavior against pinned
  EDK2 26.09; then capture exact-head QEMU and designated-hardware evidence.

Acceptance: EDK2 -> CDK2 -> CDK2 -> EDK2 succeeds without a programmer, the
authenticated variable boundary has no raw bypass, and negative cases fail
safely with persisted diagnostics.

Continue from the implemented selected-Q35 authenticated-variable authority,
writer, AUTH2/crypto, endpoint/mailbox and proxy toward full policy/differential,
interrupted-recovery and hardware validation. Audit remaining optional raw
SMMSTORE/FVB/FTW profiles separately; their existence does not mean the selected
protected authority is absent, and store-format FV codecs are not executable
FV carriers.

## 5. Remove HII and make setup native LVGL

- [ ] Replace HII forms, strings, images, fonts, configuration routing, keyword
  protocols, VFR, and `.uni` packages with small native data structures.
- [ ] Bind LVGL controls directly to typed settings and UEFI variables.
- [x] Remove `CDK2_NATIVE_HII_DATABASE`, HII protocol publication, HII package
  generation, and VFR/UNI/IFR production inputs. Native replacement coverage
  remains a separate gate; dynamic-PCD families are already retired.
- [ ] Retain LVGL as the only firmware UI and input presentation layer.
- [ ] Preserve setup functionality, accessibility, Secure Boot controls, boot
  selection, splash text, and all required product strings.

The HII gate is split as follows at the audited pair:

- **accepted:** the test-only IFR parser is deleted (PR 292);
- **accepted:** USB keyboard layout ownership is typed and HII-free (PR 293);
- **accepted:** GraphicsConsole owns its fixed font without HII (PR 294);
- **accepted:** the HII database, six protocol families, and production build
  edges are removed, while pre-existing VFR/UNI absence is enforced (PR 295);
  and
- **open:** native LVGL ownership of typed settings, Secure Boot controls, boot
  selection, accessibility, and product strings, plus exact-head UI and
  external-loader evidence. PR 323 supplies the splash/status source slice but
  does not close those visual or integration gates.

The accepted deletion slices do not make the section accepted: the product UI
that replaces the old setup behavior is still incomplete or unproved.

Acceptance: the production image and native source contain no HII database,
form-browser, VFR, `.uni`, or HII configuration-routing dependency.

## 6. Keep asynchronous activity explicitly owned

- [x] Remove `ASYNC_ENABLE` as a firmware phase and delete the generic async
  service abstraction.
- [x] Keep interrupts disabled during deterministic discovery and initialization.
- [x] Leave interrupts and the local APIC timer disabled at `StartImage`; no
  current linear loader has a proven interrupt-driven requirement.
- [x] Replace the battery timer event with a one-second timestamp check owned by
  the setup loop.
- [x] Read battery state once during normal boot for the critical-battery
  warning; refresh it only while setup is open.
- [x] Bound XHCI polling and quiesce it at the valid memory-map handoff instead
  of allowing an unrelated callback to run between phases.
- [x] Bound optional USB media discovery to two seconds by default, preserve
  media found before expiry, and keep that deadline separate from the boot-menu
  timeout.
- [ ] Prove the exact-head USB deadline, no-device path, and media-found-before-
  expiry behavior in QEMU and on hardware.
- [ ] Give keyboard, mouse, storage completion, and every remaining event an
  explicit polling-loop or teardown owner.
- [ ] Validate GRUB, shim, systemd-boot UI, loader timeout, and setup hotkeys
  with the APIC timer and IF inert.
- [ ] Stop remaining events, quiesce input/USB, and establish the documented
  interrupt state before `ExitBootServices` and OS handoff.

Acceptance: no driver can run an unrelated callback between linear phases, and
every remaining interrupt or event has one explicit lifetime owner.

## 7. Make the execution model genuinely linear

- [x] Make the production payload start one source-owned strict linear phase
  sequence and reject fallback to nonlinear DXE startup.
- [x] Prevent public dispatch from advancing strict linear boot and remove
  obsolete deferred initial-provider startup.
- [x] Load internal images through owned immutable transactions rather than
  mutable global discovery inputs.
- [x] Omit unused strict-linear providers and remove dormant EBC and private
  startup adapters from the production closure.
- [ ] Replace the remaining internal protocol discovery with explicit typed
  phase inputs and outputs.
- [ ] Give PCI, storage, filesystems, display, input, capsules, and boot policy
  complete ownership and teardown boundaries.
- [ ] Remove protocol notifications and redispatch wherever the ordered plan
  already supplies the dependency.
- [ ] Retire the remaining compatibility configuration surface, including
  `CONFIG_CDK2_LINEAR_BOOT`, once direct packaging no longer needs to
  distinguish legacy profiles.
- [ ] Keep only UEFI protocols consumed by an OS loader or external UEFI
  application, and keep helpers only when they have multiple meaningful users.

Acceptance: a trace contains one begin/end pair per phase in declared order;
internal operation does not depend on dispatcher scheduling or protocol-notify
side effects.

## 8. Reuse coreboot ownership and runtime facts

- [x] Treat coreboot as the sole pre-payload MTRR writer; CDK2 validates the
  effective MTRR/PAT state and contains no general MTRR programming fallback.
- [x] Consume the validated revision-4 coreboot PCI resource and topology
  handoff for strict ordering and assigned-resource ownership instead of
  assigning the same resources again.
- [x] Remove PciBus's exhaustive `cdk2_pci_enumerate()` topology discovery from
  the strict import path. Keep bounded snapshot identity/resource checks and
  owned-device configuration/quiescence access; non-strict compatibility still
  retains enumeration.
- [x] Publish coreboot's validated SMBIOS entries directly and remove the
  redundant strict-linear SMBIOS producer.
- [x] Implement the TPM event-log import/separation work associated with
  StarLabsLtd/firmware issue 454, including typed coreboot TPM/ACPI handoff and
  native TCG2 service tests.
- [ ] Validate issue 454 end-to-end in exact-head QEMU and hardware: the
  selected boot application/boot option in PCR 4, its selected GPT in PCR 5,
  separator ordering, TPM present/absent, supported banks, Linux event-log
  parsing, `systemd-pcrlock` replay, and no duplicate TPM2 ACPI ownership.
- [ ] Define one versioned, bounds-checked coreboot-table contract for every
  remaining production platform fact: UART, display, TPM, flash/update map,
  capsule delivery modes and limits, typed SMM-service policy, PCI ownership,
  and DMA/IOMMU state. Add EC/battery or power-button records only when those
  capabilities become part of the strict portable profile.
- [ ] Audit every production input and remove board-specific PCDs, numeric
  Kconfig addresses, fixed MMIO/serial/flash defaults, and embedded FMP paths.
- [ ] Reuse coreboot Kconfig symbols and defaults directly. Maintain a table
  classifying each residual CDK2 symbol as a coreboot alias, derived build fact,
  runtime discovery result, or justified CDK2-only policy.
- [ ] Compare bus-master and device ownership with depthcharge and leave
  devices disabled unless CDK2 explicitly owns them.

The coreboot-table gate remains open until every strict production input has a
typed, versioned, bounds-checked runtime source. PR 341 closes strict PCI
topology discovery, and reset/S5 already consume coreboot-published ACPI/FADT
facts. Numeric EC/battery Kconfig inputs are excluded from the strict runtime;
the power-button item is future scope. `CDK2_CPU_VENDOR_INTEL` remains a
Kconfig/fixture prerequisite, but the audited production source has no consumer
or remaining payload-owned-SMM family. The concrete audited build-time residual
previously identified here, capsule delivery policy, now has a typed runtime
source. `include/cdk2/capsule_delivery_policy.h` validates the unique versioned
record; `src/boot/coreboot_hobs.c` imports the coreboot delivery record into a
GUID HOB, and `src/modules/capsule_runtime/entry.c` derives allowed transports
and populate/nonpopulate limits from it. DxeCore's RAM gate consumes the same
policy. Build selection still determines which generic transports/controllers
are compiled; DISK delivery requires its own live-controller ownership proof.
This closes neither every profile's portability nor the broader platform-input,
Kconfig and ownership audits above.

The next bounded source/configuration questions are distinct. The advertised
`CDK2_CAPSULE_EMBED_FMP_DXE` generator has no implementation, but its select
still changes the real embedded-driver admission policy; it is not a harmless
no-op deletion. The HPET timer choice has no corresponding driver and disables
the existing LAPIC selection. Actual LAPIC frequency already comes from the
validated coreboot timer record, so another table is not needed. The live
diagnostic implementation can still probe fixed COM1 when serial is selected
without a validated sink, including an invalid-handoff error path; validated
PIO/MMIO serial import already exists, and quiet serial-disabled profiles do
not take that fallback. Separately, `src/lib/diagnostic_event.c` is an
unreferenced duplicate compact emitter, not another live production UART path.
Separate closures need actual policy/profile/timer admission and absent-UART
no-port-write tests; their audit does not close every board's ownership contract.

Acceptance: one payload binary can serve Intel GLK/ADL/MTL and AMD Cezanne when
coreboot supplies their differing validated runtime records and board-specific
capsule metadata.

## 9. Replace retained-FV packaging with one direct payload

- [x] Own native compilation, configuration, link layout, image inventory, and
  provenance metadata in Make/Kconfig without EDK2 BaseTools or INF dispatch.
- [x] Generate bounded direct-image metadata and fail closed when an external
  retained binary is relabelled as source-built.
- [x] Make the strict runtime consume the direct image table and start DxeCore and the
  ordered modules from the source-linked payload.
  - [x] Publish a bounded revisioned direct-image GUID HOB and compile an
    independently validated, transactional direct-driver seeder into DxeCore.
  - [x] Select that seeder after retained-FV comparison and exact QEMU
    equivalence tests pass.
- [x] Remove the internal retained FV, FFS repacker, and DEPEX scheduler from
  the selected strict production artifact. Strict DxeCore also omits the public
  FV2 scanner, FFS parser and DEPEX dispatcher; external filesystem/device-path
  `LoadImage()` remains. Non-strict compatibility remains separate.
- [x] Implement SystemFmp from owned source and retire its retained production
  binary and board-private PE/FFS build arguments.
  - [x] Replace the retained authentication-envelope parser and signature-input
    assembly with an unselected native gate: bounded EFI/PKCS7 fields, retained
    XDR trust iteration, and exact payload-then-monotonic signed spans. Host
    OpenSSL evidence covers signed success, wrong signer, mutation and every
    truncation; production selection remains open.
  - [x] Add the unselected native PKCS7/X509 callback with a pinned minimal
    BearSSL source closure. It preserves partial-chain, disabled-time and binary
    detached-signature policy, supports RSA-2048/SHA-256, and fails closed on
    unsupported algorithms without an EFI crypto service or release test key.
  - [x] Add an unselected source-owned MSS1 payload gate with bounded optional
    dependency framing and postfix evaluation, exact raw-image extent, outer
    image-type/index routing, resolved lowest-version admission, and EDK2 26.09
    check/set results for well-formed inputs. Documented fail-closed bounds
    harden dependency operands and oversized headers. Device checking, saved
    dependency state, and every production update side effect remain open.
  - [x] Add an unselected bounded durable-state model with the exact FmpState
    wire layout, typed legacy migration, monotonic LSV semantics and a durable
    unsuccessful checkpoint before writer admission. coreboot-SMM variable
    authority and production integration remain open.
  - [x] Add an unselected transaction coordinator that independently
    authenticates CHECK and SET, composes MSS1, board and durable-state gates,
    and makes the typed broker reachable only after the failure checkpoint.
    Provider publication, real board/store/broker ports and reset remain open.
  - [x] Compose those gates behind PR 324's dormant, source-neutral SystemFmp
    session, snapshotting trust, dependency and board inputs before the typed
    coreboot transaction.
  - [x] Add the exact singleton FMP provider and source-owned StarLabs public
    trust policy, select it for the capsule profile, require runtime
    `FW_INFO`/capsule-handoff/exact broker capabilities, and remove retained
    SystemFmp and its build arguments from production. QEMU acceptance selects
    only QemuTestFmp; the test digest remains historical evidence only.
  - [ ] Publish the protected coreboot broker on real platforms, prove
    persisted result/reset behavior and exact FMP/ESRT profile pairs, then
    validate signed positive and hostile capsule paths in QEMU and hardware.
  - [x] Retire transitional source FFS, DEPEX metadata, production dynamic-PCD
    families and internal-FV production carriers through the direct-dispatch
    cutover. Residual helper/object cleanup and every profile's final artifact
    inventory remain separate checks.
- [x] Add the native CDK2 payload to coreboot's payload build/package flow.
  `payloads/external/Makefile.mk` invokes the verified pinned `coreboot-stage`
  contract, requires strict direct configuration and uses normal CBFS payload
  packaging. Both outer coreboot and nested CDK2 configurations are included;
  `Documentation/payloads/cdk2.md` documents that existing integration. Final
  exact-pair/profile and hardware acceptance remain separate from packaging.
- [x] Make strict build tests reject FV/FFS/DEPEX/PCD/INF/VFR/UNI production
  composition and any board-private CDK2 artifact path.
- [x] Boot the exact no-FV artifact through QEMU before preparing a hardware
  candidate. PR 338 supplies strict-direct Q35 Linux and clean-S5 evidence; it
  is not hardware acceptance.

Historical dynamic-PCD retirement subgates (the family is now retired):

1. remove the linear PCI host bridge dependency (accepted by PR 296);
2. remove the linear SecurityStub DEPEX dependency (accepted by PR 298);
3. enumerate every strict-linear production PCD consumer and replace it with a
   typed phase input, coreboot table, derived build fact, or owned policy
   (complete for non-Secure-Boot coreboot ownership);
4. force PCD off, omit `PcdDxe`, database extraction, package and dispatch in
   that profile, with direct and retained-route executable closure (complete);
5. retire the remaining consumers and delete the compatibility implementation
   (implemented by `d2998fe1e3ac8bf32930bb5b2c5d9f5c10a2a469`); keep artifact
   checks rejecting obsolete PCD identities.

No dynamic-PCD compatibility family remains in the audited source/config
inventory. The selected strict artifact omits executable internal FV, FFS,
DEPEX and FV2 dispatch. PR587 removes the unused `src/boot/fv.c` implementation
and object recipes; it does not delete variable-storage protocols.
Optional native SMMSTORE FVB/FTW profiles and authenticated-variable FV codecs
refer to variable storage, not a payload executable carrier. SystemFmp uses
the published selected-Q35 protected endpoint; other board composition and
final artifact/hardware acceptance remain open.

Acceptance: coreboot packages one native payload ELF; CDK2 does not construct
or scan an internal EDK2 firmware volume to run its own phases.

## 10. Complete early DMA protection

- [x] Define and host-test the dormant, versioned coreboot DMA-handoff ABI and
  bounds-checked CDK2 parser. The audited head does not enable or enforce it.
- [x] Import the outer coreboot Kconfig selection atomically and add ABI and
  configuration parity oracles so coreboot and CDK2 cannot silently differ.
- [x] Implement the exact Q35 coreboot IOMMU producer and retain translation
  before any CDK2 phase can enable a PCI bus master.
- [ ] Enroll every CDK2-owned DMA controller with explicit bounded mappings and
  no identity-DMA fallback.
- [x] Fail closed on missing, duplicate, malformed, stale, or contradictory DMA
  contracts while leaving bus mastering disabled.
- [x] Validate the exact Q35 producer and consumer under QEMU with protected
  NVMe and USB Linux boots, unlisted EDU denial, and Linux IOMMU takeover.
- [ ] Implement and validate Intel Meteor Lake and AMD Cezanne producers on
  hardware with active translation and interrupt remapping. ABI portability
  review is in progress.

The parser/parity contract, Meteor Lake prerequisite wiring, and Q35 real
NVMe/XHCI plus hostile EDU proof exist. They do not supply a complete Intel or
AMD producer, enroll every production-owned controller, prove the production
capsule mailbox, or provide hardware evidence.

Acceptance: no unprotected DMA-capable device is published or enabled before a
complete trusted handoff establishes its ownership and translations.

## 11. Finish boundary-aware coreboot style

- [x] Document the native/UEFI ABI boundary and add lint ratchets for owned leaf
  code while preserving exact protocol and wire layouts.
- [ ] Convert owned implementation internals to coreboot naming, include order,
  standard integer types, bounded arithmetic, and meaningful long names.
- [ ] Keep `EFI_*`, `CHAR16`, Microsoft ABI annotations, and other UEFI types
  only at actual protocol, wire-format, or external application boundaries;
  translate once into native models.
- [ ] Split large orchestration and policy files into small subsystem interfaces
  without replacing clear code with single-use helpers.
- [ ] Remove unused modules, duplicated policy, generated EDK2 metadata, and
  migration scaffolding as their final consumers disappear.
- [ ] Maintain SPDX/license provenance and isolate immutable imported or
  byte-pinned compatibility code rather than cosmetically rewriting it.
- [ ] Ratchet source lines, image size, phase count, protocol count, event
  count, and boot time; require cleanup patches not to regress them without
  rationale.

At this head, `CHAR16` appears in 106 files and `EFI_*` in 402 files under
`src/` and `include/cdk2/`. These counts are an inventory, not evidence that
every use is wrong: classify actual UEFI ABI and wire boundaries before
translating native internals, and do not blindly rewrite imported or boundary
code.

Acceptance: owned production code follows coreboot conventions while UEFI ABI
types remain explicit and reviewable at the narrow boundaries that require
them.

## 12. Exact-head validation and release gate

- [ ] Pass the complete native test, lint, checkpatch, direct-image, PE/ELF,
  MTRR ownership, sanitizer, and hardened-harness suite at the final exact SHA.
- [ ] Boot that SHA in QEMU to a test OS and exercise normal boot, setup,
  hotkeys, loader interruption, UI navigation, capsule paths, and injected
  failures.
- [ ] Verify exact-head QEMU UART/CBMEM agreement, complete named timings,
  splash/BGRT continuity, TPM event logs, and quiet/release output.
- [ ] Boot `lite_adl` to Linux after cold boot, warm reboot, and power loss;
  validate setup, hotkeys, runtime services, loaders, suspend/resume, reboot,
  poweroff, `OsIndications`, `systemctl reboot --firmware-setup`, and
  Linux-visible hardware.
- [ ] Complete the EDK2/CDK2 A/B capture and capsule round trip on the final
  candidate.
- [ ] Validate release and debug configurations and archive the exact config,
  coreboot/CDK2 hashes, ROM/capsule hashes, UART, CBMEM, QEMU, and Linux logs.
- [ ] Complete the PR 219 reconstruction ledger and keep every successor
  reviewable and linear: mechanism, conversion, deletion, then tests and
  documentation. Preserve splash-first and capsule-controlled ordering; no
  commit may depend on a later fix to boot.

PR 297 supplies useful loader compatibility evidence, but only with Secure
Boot disabled. Its three subgates are deliberately separate:

1. **accepted slice:** direct GRUB, shim-to-signed-GRUB, and systemd-boot reach
   the source-owned probe through real `LoadImage`/`StartImage` in QEMU;
2. **open:** repeat the loader matrix with production Secure Boot policy,
   authenticated variables, key enrollment, allow/deny, and rollback cases;
   and
3. **open:** repeat it at the final exact pair, then on supported hardware with
   setup hotkeys, timeout interruption, runtime services, and OS handoff.

Final sign-off also requires the eight-author/eight-opposing-review ledger
described in the current open-work snapshot. Review activity without an exact
commit-to-review-to-resolution mapping is not sufficient evidence.

## Definition of done

CDK2 boots Linux promptly on supported hardware; capsules work in both
directions; EDK2/CDK2 Linux-visible hardware is equivalent; setup and splash
text are native LVGL without HII; internal packaging has no FV/FFS/DEPEX/PCD
dependency; initialization is deterministic and sequential; asynchronous and
DMA work has explicit ownership; all platform facts come from validated
coreboot contracts; and the remaining code is small and clear enough to review
as coreboot code.
