#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$#" -gt 1 ] || { echo "usage: $0 CONFIG_HEADER ACTUAL_DXE_HOST_SOURCES..." >&2; exit 2; }
configuration=$(CDPATH= cd -- "$(dirname -- "$1")/.." && pwd)
shift
for source in "$@"; do
	case "$source" in
	*.c) [ -f "$source" ] ;;
	*) echo "DXE host source must be an actual C translation unit: $source" >&2; exit 2 ;;
	esac
done
temporary=$(mktemp -d)
if [ "${KEEP_SPLASH_STATUS_TMP:-0}" = 1 ]; then
	echo "Splash HOST artifacts: $temporary"
else
	trap 'rm -rf "$temporary"' EXIT HUP INT TERM
fi
ulimit -c 0
compiler=${HOSTCC:-cc}
compiler_path=$(command -v -- "$compiler")
# The same compile flags apply to support objects and the changed fixture.
# Link-only options and the mutated entry selector are supplied by the caller.
compile_source()
{
	set -- -std=c11 -O"$optimization" -Wall -Wextra -Werror \
		-fshort-wchar -ffunction-sections -fdata-sections \
		-fsanitize=address,undefined -fno-sanitize-recover=all -fno-pie \
		-DCDK2_HOST_TEST -DCDK2_SPLASH_TEST_DEBUG="$debug" \
		-I"$configuration" -I"$root/include" -I"$root/src/modules/dxe_core" \
		-I"$root/src/lib/tcg_hash/vendor/linux/include" "$@"
	printf '%s\0' "$compiler" "$@" >> "$temporary/argv-$debug-$optimization"
	printf '\0' >> "$temporary/argv-$debug-$optimization"
	"$compiler" "$@"
}
sed '/static EFI_STATUS show_linear_status(/,/^}/s/CDK2_LINEAR_STATE_SPLASH_VISIBLE/CDK2_LINEAR_STATE_COREBOOT_SPLASH/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/coreboot-only.c"
sed 's/if (!begin \&\& EFI_ERROR(status))/if (EFI_ERROR(status))/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/begin-error.c"
sed '/static EFI_STATUS capture_boot_graphics_region(/,/^}/s/if (snapshot->pixels != NULL)/if (snapshot->pixels != NULL \&\& false)/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/reseal.c"
sed '/static struct boot_logo_publication publish_boot_logo(/,/^}/s/status = restore_boot_graphics_region(\&surface, \&context->status_snapshot);/status = EFI_SUCCESS;/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/dirty-bgrt.c"
perl -0pe 's/else if \(begin && phase == CDK2_LINEAR_BOOT_POLICY\)/else if (CONFIG_CDK2_BUILD_DEBUG \&\& begin \&\& phase == CDK2_LINEAR_BOOT_POLICY)/g == 1 or die "Selecting branch changed\n"' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/debug-only.c"
sed 's/CONFIG_CDK2_BUILD_DEBUG \&\& begin \&\& phase/begin \&\& phase/' \
	"$temporary/debug-only.c" > "$temporary/debug-only-reversed.c"
cmp "$root/src/modules/dxe_core/entry.c" "$temporary/debug-only-reversed.c"
perl -0pe 's/owner->load_generation != output->generation/false/g == 1 or die "status owner generation changed\n"' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/owner-generation.c"
perl -0pe 's/owner == NULL \|\| false \|\|/owner == NULL || owner->load_generation != output->generation ||/g == 1 or die "generation inverse changed\n"' \
	"$temporary/owner-generation.c" > "$temporary/owner-generation-reversed.c"
cmp "$root/src/modules/dxe_core/entry.c" "$temporary/owner-generation-reversed.c"
perl -0pe 's/output->interface->show_status != output->show_status/false/g == 1 or die "status callback identity changed\n"' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/callback-identity.c"
perl -0pe 's/\|\|\n\t    false/||\n\t    output->interface->show_status != output->show_status/g == 1 or die "callback inverse changed\n"' \
	"$temporary/callback-identity.c" > "$temporary/callback-identity-reversed.c"
cmp "$root/src/modules/dxe_core/entry.c" "$temporary/callback-identity-reversed.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/coreboot-only.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/begin-error.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/reseal.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/dirty-bgrt.c"
for debug in 0 1; do
	for optimization in 0 2; do
		objects="$temporary/support-$debug-$optimization"
		mkdir "$objects"
		# Snapshot the actual complete dependency closure before compiling.
		# All mutants alter expressions only, not include/config selection.
		compile_source -M -MT cdk2-splash-dependencies \
			"$root/tests/splash_status_report_test.c" "$@" > "$objects/dependencies.make"
		perl -MText::ParseWords=shellwords -0777 -ne '
			s/\\\n/ /g;
			for (split /\n/) {
				s/^cdk2-splash-dependencies: // or next;
				s/\$\$/\$/g;
				print join("\n", shellwords($_)), "\n";
			}' "$objects/dependencies.make" | sort -u > "$objects/dependencies.txt"
		[ -s "$objects/dependencies.txt" ]
		xargs -d '\n' sha256sum < "$objects/dependencies.txt" > "$objects/inputs.sha256"
		sha256sum "$compiler_path" "$0" "$configuration/cdk2/config.h" "$@" \
			>> "$objects/inputs.sha256"
		index=0
		for source in "$@"; do
			index=$((index + 1))
			object=$(printf '%s/support-%04u.o' "$objects" "$index")
			compile_source -c "$source" -o "$object"
		done
		for mode in original coreboot-only begin-error reseal dirty-bgrt debug-only owner-generation callback-identity; do
			case "$mode" in
			reseal|dirty-bgrt)
				[ "$debug:$optimization" = 1:2 ] || continue ;;
			debug-only)
				[ "$debug:$optimization" = 0:2 ] || continue ;;
			owner-generation|callback-identity)
				[ "$debug" = 1 ] || continue ;;
			esac
			entry="$root/src/modules/dxe_core/entry.c"
			if [ "$mode" != original ]; then entry="$temporary/$mode.c"; fi
			compile_source -no-pie -Wl,--gc-sections -DCDK2_SPLASH_ENTRY_SOURCE="\"$entry\"" \
				"$root/tests/splash_status_report_test.c" "$objects"/*.o \
				-o "$temporary/report"
			if [ "$mode" = original ]; then
				ASAN_OPTIONS=abort_on_error=1:detect_leaks=1 \
					UBSAN_OPTIONS=halt_on_error=1 "$temporary/report"
				continue
			fi
			status=0
			ASAN_OPTIONS=abort_on_error=1:detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 \
				"$temporary/report" > "$temporary/mutant.log" 2>&1 || status=$?
			[ "$status" -eq 134 ] || { cat "$temporary/mutant.log"; exit 1; }
			! grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' \
				"$temporary/mutant.log"
			case "$mode" in
			coreboot-only) oracle='show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_SUCCESS' ;;
			begin-error|debug-only)
				oracle='status_calls == 1 && received.message == CDK2_LVGL_STATUS_SELECTING_BOOT' ;;
			reseal) oracle='allocations == saved_allocations' ;;
			dirty-bgrt) oracle='BGRT excludes transient status' ;;
			owner-generation) oracle='captured UI generation refusal' ;;
			callback-identity) oracle='captured UI callback refusal' ;;
			esac
			grep -Fq "$oracle" "$temporary/mutant.log"
		done
		sha256sum -c "$objects/inputs.sha256" > "$objects/inputs-after.log"
		sha256sum "$temporary/argv-$debug-$optimization"
	done
done
echo 'Splash owner/begin-sentinel/snapshot lifetime coupled source mutants: PASS'
