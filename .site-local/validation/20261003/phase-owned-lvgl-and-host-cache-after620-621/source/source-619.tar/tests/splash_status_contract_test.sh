#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

if [ "$#" -ne 3 ]; then
	echo "usage: $0 DXE_ENTRY LVGL_DRIVER LVGL_HEADER" >&2
	exit 2
fi

entry=$1
driver=$2
header=$3
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM

awk '
	/static EFI_STATUS CDK2_MS_ABI show_status\(/ { inside = 1 }
	inside { print }
	inside && /^}/ { exit }
' "$driver" >"$temporary/show-status"
grep -q 'lv_display_create(status_line->width, status_line->height)' \
	"$temporary/show-status"
grep -q 'LV_DISPLAY_RENDER_MODE_PARTIAL' "$temporary/show-status"
grep -q 'menu.origin_x = status_line->x' "$temporary/show-status"
grep -q 'menu.origin_y = status_line->y' "$temporary/show-status"
! grep -q 'advance_periodic_poll\|CDK2_BLT_VIDEO_FILL\|status_line->text' \
	"$temporary/show-status"

grep -q 'CDK2_LVGL_STATUS_MESSAGE_COUNT' "$header"
! awk '/struct cdk2_lvgl_status {/,/^};/' "$header" | grep -q 'CHAR8 \*'
grep -q '_Static_assert(sizeof(struct cdk2_lvgl_ui_protocol)' "$driver"
grep -q 'struct cdk2_lvgl_status_protocol' "$header"
grep -q 'lvgl_status_protocol_guid' "$entry"
! grep -q 'display_status = show_linear_status' "$entry"

awk '
	/static void dxe_linear_report\(/ { inside = 1 }
	inside { print }
	inside && /^}/ { exit }
' "$entry" >"$temporary/report"
grep -q '#if CONFIG_CDK2_LVGL_RENDERER' "$temporary/report"
grep -Fq 'if (!begin && EFI_ERROR(status))' "$temporary/report"
! grep -q 'CONFIG_CDK2_BUILD_DEBUG' "$temporary/report"
awk '
	/message = CDK2_LVGL_STATUS_BOOT_FAILED;/ { error = NR; errors++ }
	/CDK2_LVGL_STATUS_SELECTING_BOOT/ { selecting = NR; selections++ }
	/CDK2_LVGL_STATUS_STARTING_OS/ { starting = NR; starts++ }
	/CDK2_LVGL_STATUS_PREPARING/ { preparing = NR; preparations++ }
	END { exit errors == 1 && selections == 1 && starts == 1 && preparations == 1 &&
		error < selecting && selecting < starting && starting < preparing ? 0 : 1 }
' "$temporary/report" || {
	echo "on-screen splash status policy is not exact" >&2
	exit 1
}

awk '
	/static EFI_STATUS show_linear_status\(/ { inside = 1 }
	inside { print }
	inside && /^}/ { exit }
' "$entry" >"$temporary/status-region"
grep -q 'CDK2_LINEAR_STATE_SPLASH_VISIBLE' "$temporary/status-region"
grep -q 'cdk2_boot_logo_layout_for_surface' "$temporary/status-region"
! grep -q 'cdk2_boot_logo_draw' "$temporary/status-region"
awk '
	/boot_graphics_region_valid\(&surface, &layout\)/ { bound = NR }
	/capture_boot_graphics_region\(&surface, &status_rectangle/ { capture = NR }
	/status = status_ui->show_status/ { callback = NR }
	END { exit bound && capture && callback && bound < capture &&
		capture < callback ? 0 : 1 }
' "$temporary/status-region" || {
	echo "splash region must be bounded before capture/publication" >&2
	exit 1
}

awk '
	/static uint64_t handoff_operating_system\(/ { inside = 1 }
	inside { print }
	inside && /^}/ { exit }
' "$entry" >"$temporary/handoff"
awk '
	/publish_boot_logo\(context\)/ { restore = NR }
	/status = activate_loader_services\(context\)/ { activate = NR }
	/status = start\(image/ { start = NR }
	/prepare_bds_display\(context\)/ { prepare = NR }
	/show_linear_status\(context,/ { failed = NR }
	/CDK2_LVGL_STATUS_BOOT_FAILED/ && failed { message = NR }
	/bds->entry\(bds\)/ { failover = NR }
	END { exit restore && activate && start && prepare && failed && message &&
		failover && restore < activate && activate < start &&
		start < prepare && prepare < failed && failed <= message &&
		message < failover ? 0 : 1 }
' "$temporary/handoff" || {
	echo "splash restore/error-failover order is not exact" >&2
	exit 1
}
grep -q 'fatal_display_failure = EFI_ERROR(publication.display)' \
	"$temporary/handoff"
grep -q 'if (EFI_ERROR(status) && !fatal_display_failure)' \
	"$temporary/handoff"

awk '
	/static struct boot_logo_publication publish_boot_logo\(/ { inside = 1 }
	inside { print }
	inside && /^}/ { exit }
' "$entry" >"$temporary/publish"
grep -q 'restore_boot_graphics_region(&surface, &context->splash_snapshot)' "$temporary/publish"
grep -q 'release_boot_graphics_snapshots(context)' "$temporary/publish"
awk '
	/status = restore_boot_graphics_region\(&surface, &context->status_snapshot\)/ { restore = NR }
	/status = cdk2_boot_logo_draw\(/ { draw = NR }
	/status = cdk2_boot_logo_bmp\(/ { bmp = NR }
	/acpi->install\(/ { bgrt = NR }
	END { exit restore && draw && bmp && bgrt && restore < draw &&
		draw < bmp && bmp < bgrt ? 0 : 1 }
' "$temporary/publish"
awk '
	/static uint64_t select_boot_policy\(/ { inside = 1 }
	inside { print }
	inside && /^}/ { exit }
' "$entry" >"$temporary/setup"
grep -q 'status = enter_linear_setup(' "$temporary/setup"
! grep -q 'restore_boot_graphics_region\|restore_status_background' "$temporary/setup"

awk '
	/^EFI_STATUS CDK2_MS_ABI cdk2_dxe_core_entry\(/ { inside = 1 }
	inside { print }
	inside && /^}/ { exit }
' "$entry" >"$temporary/entry"
awk '
	/status = cdk2_linear_run\(/ { run = NR }
	/status = finish_loader_services\(&services/ { finish = NR }
	/cleanup = release_boot_graphics_snapshots\(&services\)/ { cleanup = NR }
	/if \(status != EFI_SUCCESS\)/ { terminal = NR }
	END { exit run && finish && cleanup && terminal && run < finish &&
		finish < cleanup && cleanup < terminal ? 0 : 1 }
' "$temporary/entry"

echo "splash status ownership contract: PASS"
