/* SPDX-License-Identifier: GPL-2.0-only */

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cdk2/config.h>
#undef CONFIG_CDK2_BUILD_DEBUG
#define CONFIG_CDK2_BUILD_DEBUG CDK2_SPLASH_TEST_DEBUG
#undef CONFIG_CDK2_LVGL_RENDERER
#define CONFIG_CDK2_LVGL_RENDERER 1

#ifndef CDK2_SPLASH_ENTRY_SOURCE
#define CDK2_SPLASH_ENTRY_SOURCE "../src/modules/dxe_core/entry.c"
#endif
#include CDK2_SPLASH_ENTRY_SOURCE

#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME
/* HOST IRQ state only; this fixture exercises display ownership, not admission. */
static bool interrupts_enabled = true;

bool cdk2_dxe_policy_interrupts_get(void)
{
	return interrupts_enabled;
}

void cdk2_dxe_policy_interrupts_set(bool enabled)
{
	interrupts_enabled = enabled;
}
#endif

static uint32_t pixels[800U * 480U];
static uint32_t pristine[ARRAY_SIZE(pixels)];
static uint32_t status_calls, allocations;
static uint32_t releases, bgrt_calls;
static EFI_STATUS allocation_status = EFI_SUCCESS;
static EFI_STATUS callback_status = EFI_SUCCESS;
static EFI_STATUS release_status = EFI_SUCCESS;
static struct cdk2_lvgl_status received;
static uint64_t published_bmp;

static EFI_STATUS CDK2_MS_ABI record_status(struct cdk2_lvgl_status_protocol *protocol,
	const struct cdk2_lvgl_status *line)
{
	assert(protocol != NULL);
	received = *line;
	status_calls++;
	for (uint32_t row = 0; row < line->height; row++)
		for (uint32_t x = 0; x < line->width; x++)
			pixels[(line->y + row) * 800U + line->x + x] =
				0x00ee1111U + line->message;
	return callback_status;
}

static EFI_STATUS CDK2_MS_ABI allocate_snapshot(uint32_t type, UINTN bytes, void **out)
{
	(void)type;
	allocations++;
	if (EFI_ERROR(allocation_status)) {
		*out = NULL;
		return allocation_status;
	}
	*out = malloc(bytes);
	return *out == NULL ? EFI_OUT_OF_RESOURCES : EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI free_snapshot(void *pixels_to_release)
{
	releases++;
	free(pixels_to_release);
	return release_status;
}

static uint64_t input_phase_complete(void *context)
{
	assert(context != NULL);
	return EFI_SUCCESS;
}

static uint64_t policy_phase_failure(void *context)
{
	assert(context != NULL);
	return EFI_SECURITY_VIOLATION;
}

static EFI_STATUS CDK2_MS_ABI install_bgrt(struct acpi_table_protocol *protocol,
	const void *data, UINTN bytes, UINTN *key)
{
	const struct boot_graphics_resource_table *table = data;

	assert(protocol != NULL && bytes == sizeof(*table));
	assert(table->header.signature == SIGNATURE_32('B', 'G', 'R', 'T'));
	assert(table->status == 1 && table->image_address != 0);
	assert(!memcmp(pristine, pixels, sizeof(pixels)) && "BGRT excludes transient status");
	bgrt_calls++;
	published_bmp = table->image_address;
	*key = 1;
	return EFI_SUCCESS;
}

static struct acpi_table_protocol acpi = { .install = install_bgrt };

static EFI_STATUS CDK2_MS_ABI locate_acpi(const EFI_GUID *guid, void *registration, void **out)
{
	(void)registration;
	assert(!memcmp(guid, &acpi_table_protocol_guid, sizeof(*guid)));
	*out = &acpi;
	return EFI_SUCCESS;
}

struct graphics_fixture {
	EFI_HOB_HANDOFF_INFO_TABLE handoff;
	EFI_HOB_GUID_TYPE guid;
	EFI_PEI_GRAPHICS_INFO_HOB graphics;
	EFI_HOB_GENERIC_HEADER end;
};

static void verify_owner(bool coreboot_logo)
{
	struct graphics_fixture hobs = {0};
	struct cdk2_linear_state state = {0};
	struct dxe_services_context context = { .handoff = &hobs.handoff,
		.linear_state = &state };
	struct cdk2_lvgl_status_protocol protocol = {
		.revision = CDK2_LVGL_STATUS_PROTOCOL_REVISION,
		.size = sizeof(protocol), .show_status = record_status,
	};
	struct cdk2_boot_logo_surface surface;
	struct cdk2_boot_logo_layout logo;
	struct boot_logo_publication publication;
	void *handle = NULL;
	void *bmp = NULL;
	UINTN bmp_size = 0;
	uint32_t before, saved_allocations;

	memset(&core, 0, sizeof(core));
	assert(cdk2_dxe_database_initialize(&core.database) == EFI_SUCCESS);
	assert(cdk2_dxe_install(&core.database, &handle, &lvgl_status_protocol_guid,
		&protocol) == EFI_SUCCESS);
	core.boot_services.allocate_pool = (void *)allocate_snapshot;
	core.boot_services.free_pool = (void *)free_snapshot;
	core.boot_services.locate_protocol = (void *)locate_acpi;
	hobs.handoff.header.hob_type = EFI_HOB_TYPE_HANDOFF;
	hobs.handoff.header.hob_length = sizeof(hobs.handoff);
	hobs.handoff.efi_end_of_hob_list = (UINTN)&hobs.end;
	hobs.guid.header.hob_type = EFI_HOB_TYPE_GUID_EXTENSION;
	hobs.guid.header.hob_length = sizeof(hobs.guid) + sizeof(hobs.graphics);
	hobs.guid.name = graphics_hob_guid;
	hobs.graphics.frame_buffer_base = (UINTN)pixels;
	hobs.graphics.graphics_mode.horizontal_resolution = 800;
	hobs.graphics.graphics_mode.vertical_resolution = 480;
	hobs.graphics.graphics_mode.pixels_per_scan_line = 800;
	hobs.graphics.graphics_mode.pixel_format = pixel_blue_green_red_reserved8_bit_per_color;
	hobs.end.hob_type = EFI_HOB_TYPE_END_OF_HOB_LIST;
	hobs.end.hob_length = sizeof(hobs.end);
	state.flags = CDK2_LINEAR_STATE_SPLASH_VISIBLE;
	state.splash_framebuffer = (UINTN)pixels;
	state.splash_x_resolution = 800;
	state.splash_y_resolution = 480;
	state.splash_bytes_per_line = 800U * sizeof(uint32_t);
	if (coreboot_logo) {
		state.flags |= CDK2_LINEAR_STATE_COREBOOT_SPLASH;
		state.splash_image_offset_x = 100;
		state.splash_image_offset_y = 80;
		state.splash_image_width = 240;
		state.splash_image_height = 80;
	}
	for (size_t index = 0; index < ARRAY_SIZE(pixels); index++)
		pixels[index] = 0x0008101c;
	assert(boot_logo_surface(&hobs.graphics, &surface) == EFI_SUCCESS);
	if (coreboot_logo) {
		logo = (struct cdk2_boot_logo_layout) { .x = 100, .y = 80,
			.width = 240, .height = 80, .scale = 4 };
		bmp = malloc(54U + 240U * 80U * 3U);
		assert(bmp != NULL && cdk2_boot_logo_bmp(&logo, bmp,
			54U + 240U * 80U * 3U, &bmp_size) == EFI_SUCCESS);
		state.splash_bmp_address = (UINTN)bmp;
		state.splash_bmp_size = bmp_size;
		for (uint32_t y = 0; y < logo.height; y++)
			for (uint32_t x = 0; x < logo.width; x++) {
				const uint8_t *pixel = (uint8_t *)bmp + 54U +
					(logo.height - y - 1U) * logo.width * 3U + x * 3U;

				pixels[(logo.y + y) * 800U + logo.x + x] = pixel[0] |
					((uint32_t)pixel[1] << 8) | ((uint32_t)pixel[2] << 16);
			}
	} else {
		assert(cdk2_boot_logo_draw(&surface, &logo) == EFI_SUCCESS);
	}
	memcpy(pristine, pixels, sizeof(pixels));
	status_calls = 0;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_SUCCESS);
	assert(status_calls == 1 && received.message == CDK2_LVGL_STATUS_PREPARING);
	assert(received.width != 0 && received.height != 0 && received.height <= 48);
	assert(received.x < 800 && received.width <= 800 - received.x);
	assert(received.y < 480 && received.height <= 480 - received.y);
	for (size_t index = 0; index < ARRAY_SIZE(pixels); index++) {
		size_t x = index % 800U, y = index / 800U;

		if (x < received.x || x >= received.x + received.width ||
		    y < received.y || y >= received.y + received.height)
			assert(pixels[index] == pristine[index]);
	}
	assert(context.status_snapshot.pixels != NULL);
	saved_allocations = allocations;
	if (coreboot_logo) {
		assert(received.x == 100 && received.y == 168 && received.width == 240 &&
			received.height == 48);
		assert(context.splash_snapshot.pixels != NULL);
	} else {
		assert(state.splash_image_width == 0 && state.splash_image_height == 0 &&
			state.splash_image_offset_x == 0 && state.splash_image_offset_y == 0);
		assert(context.splash_snapshot.pixels == NULL);
		assert(received.y == logo.y + logo.height + 8);
	}
	/* Polling must retain status; later draws never reseal rendered UI pixels. */
	assert(memcmp(pristine, pixels, sizeof(pixels)) != 0);
	pixels[received.y * 800U + received.x] = 0x00887766;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_SUCCESS);
	assert(allocations == saved_allocations);
	assert(memcmp(pristine, pixels, sizeof(pixels)) != 0);
	assert(restore_boot_graphics_region(&context.status_snapshot.framebuffer,
		&context.status_snapshot) == EFI_SUCCESS);
	context.status_snapshot.size--;
	before = status_calls;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_COMPROMISED_DATA);
	assert(status_calls == before && !memcmp(pristine, pixels, sizeof(pixels)));
	context.status_snapshot.size++;
	status_calls = 0;
	dxe_linear_report(CDK2_LINEAR_BOOT_POLICY, "policy", EFI_NOT_STARTED, 0,
		TRUE, TRUE, &context);
	assert(status_calls == 1 && received.message == CDK2_LVGL_STATUS_SELECTING_BOOT);
	status_calls = 0;
	dxe_linear_report(CDK2_LINEAR_INPUT_UI, "input", EFI_SUCCESS, 0,
		TRUE, FALSE, &context);
	assert(status_calls == 1 && received.message == CDK2_LVGL_STATUS_PREPARING);
	status_calls = 0;
	dxe_linear_report(CDK2_LINEAR_OS_HANDOFF, "handoff", EFI_NOT_STARTED, 0,
		TRUE, TRUE, &context);
	assert(status_calls == 1 && received.message == CDK2_LVGL_STATUS_STARTING_OS);
	status_calls = 0;
	dxe_linear_report(CDK2_LINEAR_BLOCK_DISCOVERY, "block", EFI_SUCCESS, 0,
		TRUE, FALSE, &context);
	assert(status_calls == 0);
	status_calls = 0;
	dxe_linear_report(CDK2_LINEAR_BOOT_POLICY, "policy", EFI_DEVICE_ERROR, 0,
		TRUE, FALSE, &context);
	assert(status_calls == 1 && received.message == CDK2_LVGL_STATUS_BOOT_FAILED);
	callback_status = EFI_DEVICE_ERROR;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_DEVICE_ERROR);
	assert(!memcmp(pristine, pixels, sizeof(pixels)));
	callback_status = EFI_SUCCESS;
	before = status_calls;
	state.flags &= ~CDK2_LINEAR_STATE_SPLASH_VISIBLE;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_UNSUPPORTED);
	state.flags |= CDK2_LINEAR_STATE_SPLASH_VISIBLE;
	protocol.revision++;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_NOT_FOUND);
	protocol.revision--;
	hobs.graphics.frame_buffer_base++;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_COMPROMISED_DATA);
	hobs.graphics.frame_buffer_base--;
	hobs.graphics.graphics_mode.pixel_format = pixel_red_green_blue_reserved8_bit_per_color;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_COMPROMISED_DATA);
	{
		struct cdk2_boot_logo_surface changed = context.status_snapshot.framebuffer;

		changed.red_mask_pos = 0;
		assert(restore_boot_graphics_region(&changed, &context.status_snapshot) ==
			EFI_COMPROMISED_DATA);
	}
	assert(!memcmp(pristine, pixels, sizeof(pixels)));
	hobs.graphics.graphics_mode.pixel_format = pixel_blue_green_red_reserved8_bit_per_color;
	state.splash_framebuffer = UINTPTR_MAX - 15U;
	hobs.graphics.frame_buffer_base = state.splash_framebuffer;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_COMPROMISED_DATA);
	state.splash_framebuffer = (UINTN)pixels;
	hobs.graphics.frame_buffer_base = state.splash_framebuffer;
	if (coreboot_logo) {
		state.splash_image_width = UINT32_MAX;
		assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) ==
			EFI_COMPROMISED_DATA);
		state.splash_image_width = 240;
		state.splash_image_offset_y = 380;
		assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_UNSUPPORTED);
		{
			struct dxe_services_context empty = { .handoff = &hobs.handoff,
				.linear_state = &state };

			assert(show_linear_status(&empty, CDK2_LVGL_STATUS_PREPARING) == EFI_UNSUPPORTED);
			assert(empty.status_snapshot.pixels == NULL && empty.splash_snapshot.pixels == NULL);
		}
		state.splash_image_offset_y = 80;
		assert(boot_logo_surface(&hobs.graphics, &surface) == EFI_SUCCESS);
		pixels[80U * 800U + 100U] ^= 1;
		assert(restore_boot_graphics_region(&surface, &context.splash_snapshot) == EFI_SUCCESS);
		assert(!memcmp(pristine, pixels, sizeof(pixels)));
	} else {
		state.splash_y_resolution = 124;
		hobs.graphics.graphics_mode.vertical_resolution = 124;
		assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) ==
			EFI_UNSUPPORTED);
		{
			struct dxe_services_context empty = { .handoff = &hobs.handoff,
				.linear_state = &state };

			assert(show_linear_status(&empty, CDK2_LVGL_STATUS_PREPARING) == EFI_UNSUPPORTED);
			assert(empty.status_snapshot.pixels == NULL && empty.splash_snapshot.pixels == NULL);
		}
		state.splash_y_resolution = 480;
		hobs.graphics.graphics_mode.vertical_resolution = 480;
	}
	assert(status_calls == before);
	assert(allocations == saved_allocations);
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_SUCCESS);
	publication = publish_boot_logo(&context);
	assert(publication.display == EFI_SUCCESS && publication.bgrt == EFI_SUCCESS &&
		publication.snapshot == EFI_SUCCESS);
	assert(!memcmp(pristine, pixels, sizeof(pixels)));
	assert(context.splash_snapshot.pixels == NULL && context.status_snapshot.pixels == NULL);
	/* The installed CDK2 BMP remains owned by ACPI, not the transient snapshots. */
	free((void *)(uintptr_t)published_bmp);
	before = status_calls;
	allocation_status = EFI_OUT_OF_RESOURCES;
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_OUT_OF_RESOURCES);
	allocation_status = EFI_SUCCESS;
	assert(status_calls == before && context.status_snapshot.pixels == NULL &&
		context.splash_snapshot.pixels == NULL && !memcmp(pristine, pixels, sizeof(pixels)));
	assert(show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_SUCCESS);
	hobs.graphics.frame_buffer_base++;
	publication = publish_boot_logo(&context);
	assert(publication.display == EFI_COMPROMISED_DATA &&
		context.status_snapshot.pixels == NULL && context.splash_snapshot.pixels == NULL);
	hobs.graphics.frame_buffer_base--;
	/*
	 * The real runner/report and pool owner close a required-phase failure.
	 * Earlier entry initialization and these two phase bodies are modeled.
	 */
	{
		const struct cdk2_linear_phase phases[] = {
			{ CDK2_LINEAR_INPUT_UI, "INPUT_UI", input_phase_complete, TRUE },
			{ CDK2_LINEAR_BOOT_POLICY, "BOOT_POLICY", policy_phase_failure, TRUE },
		};
		const struct cdk2_linear_plan plan = { .phases = phases,
			.count = ARRAY_SIZE(phases), .clock = dxe_linear_clock,
			.report = dxe_linear_report, .context = &context };
		size_t completed;
		EFI_STATUS status;

		state.revision = CDK2_LINEAR_STATE_REVISION;
		state.length = sizeof(state);
		state.next_phase = CDK2_LINEAR_INPUT_UI;
		state.completed_mask = (1U << CDK2_LINEAR_INPUT_UI) - 1U;
		state.flags |= CDK2_LINEAR_CAPSULE_RESULT_NONE << CDK2_LINEAR_STATE_CAPSULE_SHIFT;
		status = cdk2_linear_run(&plan, &state, &completed);
		assert(status == EFI_SECURITY_VIOLATION && completed == 1);
		assert(context.status_snapshot.pixels != NULL);
		assert(received.message == CDK2_LVGL_STATUS_BOOT_FAILED);
		before = releases;
		release_status = EFI_DEVICE_ERROR;
		assert(release_boot_graphics_snapshots(&context) == EFI_DEVICE_ERROR);
		release_status = EFI_SUCCESS;
		assert(releases == before + (coreboot_logo ? 2U : 1U));
		assert(context.status_snapshot.pixels == NULL && context.splash_snapshot.pixels == NULL);
		assert(pixels[received.y * 800U + received.x] ==
			0x00ee1111U + CDK2_LVGL_STATUS_BOOT_FAILED);
		assert(status == EFI_SECURITY_VIOLATION);
	}
	assert(releases != 0);
}

int main(void)
{
	verify_owner(false);
	verify_owner(true);
	assert(bgrt_calls == 2);
	puts("Actual DXE splash callbacks: both logo owners, begin/completion and quiet release: PASS");
	return 0;
}
