#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
[ "$#" -gt 1 ] || { echo "usage: $0 CONFIG_HEADER ACTUAL_DXE_HOST_SOURCES..." >&2; exit 2; }
configuration=$(CDPATH= cd -- "$(dirname -- "$1")/.." && pwd)
shift
for source in "$@"; do
	case "$source" in
	*.c) [ -f "$source" ] ;;
	*) echo "DXE host source must be an actual C translation unit: $source" >&2; exit 2 ;;
	esac
done
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM
ulimit -c 0
sed '/static EFI_STATUS show_linear_status(/,/^}/s/CDK2_LINEAR_STATE_SPLASH_VISIBLE/CDK2_LINEAR_STATE_COREBOOT_SPLASH/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/coreboot-only.c"
sed 's/if (!begin \&\& EFI_ERROR(status))/if (EFI_ERROR(status))/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/begin-error.c"
sed '/static EFI_STATUS capture_boot_graphics_region(/,/^}/s/if (snapshot->pixels != NULL)/if (snapshot->pixels != NULL \&\& false)/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/reseal.c"
sed '/static struct boot_logo_publication publish_boot_logo(/,/^}/s/status = restore_boot_graphics_region(\&surface, \&context->status_snapshot);/status = EFI_SUCCESS;/' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/dirty-bgrt.c"
perl -0pe 's/else if \(begin && phase == CDK2_LINEAR_BOOT_POLICY\)/else if (CONFIG_CDK2_BUILD_DEBUG \&\& begin \&\& phase == CDK2_LINEAR_BOOT_POLICY)/g == 1 or die "Selecting branch changed\n"' \
	"$root/src/modules/dxe_core/entry.c" > "$temporary/debug-only.c"
sed 's/CONFIG_CDK2_BUILD_DEBUG \&\& begin \&\& phase/begin \&\& phase/' \
	"$temporary/debug-only.c" > "$temporary/debug-only-reversed.c"
cmp "$root/src/modules/dxe_core/entry.c" "$temporary/debug-only-reversed.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/coreboot-only.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/begin-error.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/reseal.c"
! cmp -s "$root/src/modules/dxe_core/entry.c" "$temporary/dirty-bgrt.c"
for debug in 0 1; do
	for optimization in 0 2; do
		for mode in original coreboot-only begin-error reseal dirty-bgrt debug-only; do
			case "$mode" in
			reseal|dirty-bgrt)
				[ "$debug:$optimization" = 1:2 ] || continue ;;
			debug-only)
				[ "$debug:$optimization" = 0:2 ] || continue ;;
			esac
			entry="$root/src/modules/dxe_core/entry.c"
			if [ "$mode" != original ]; then entry="$temporary/$mode.c"; fi
			"${HOSTCC:-cc}" -std=c11 -O"$optimization" -Wall -Wextra -Werror \
				-fshort-wchar -ffunction-sections -fdata-sections \
				-fsanitize=address,undefined -fno-sanitize-recover=all \
				-fno-pie -no-pie -Wl,--gc-sections -DCDK2_HOST_TEST \
				-DCDK2_SPLASH_TEST_DEBUG="$debug" -DCDK2_SPLASH_ENTRY_SOURCE="\"$entry\"" \
				-I"$configuration" -I"$root/include" -I"$root/src/modules/dxe_core" \
				-I"$root/src/lib/tcg_hash/vendor/linux/include" \
				"$root/tests/splash_status_report_test.c" "$@" \
				-o "$temporary/report"
			if [ "$mode" = original ]; then
				ASAN_OPTIONS=abort_on_error=1:detect_leaks=1 \
					UBSAN_OPTIONS=halt_on_error=1 "$temporary/report"
				continue
			fi
			status=0
			ASAN_OPTIONS=abort_on_error=1:detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 \
				"$temporary/report" > "$temporary/mutant.log" 2>&1 || status=$?
			[ "$status" -eq 134 ] || { cat "$temporary/mutant.log"; exit 1; }
			! grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' \
				"$temporary/mutant.log"
			case "$mode" in
			coreboot-only) oracle='show_linear_status(&context, CDK2_LVGL_STATUS_PREPARING) == EFI_SUCCESS' ;;
			begin-error|debug-only)
				oracle='status_calls == 1 && received.message == CDK2_LVGL_STATUS_SELECTING_BOOT' ;;
			reseal) oracle='allocations == saved_allocations' ;;
			dirty-bgrt) oracle='BGRT excludes transient status' ;;
			esac
			grep -Fq "$oracle" "$temporary/mutant.log"
		done
	done
done
echo 'Splash owner/begin-sentinel/snapshot lifetime coupled source mutants: PASS'
