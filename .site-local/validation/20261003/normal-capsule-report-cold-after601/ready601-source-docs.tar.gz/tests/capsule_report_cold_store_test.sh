#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

test "$#" -eq 2 || exit 2
: "${COREBOOT_TREE:?actual producer codec source required}"
: "${CBFSTOOL:?matching actual producer cbfstool required}"
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
mkdir -p "$2"
output=$(mktemp -d "$2/cold-report-store.XXXXXX")
compiler=${HOSTCC:-cc}
sources=
for implementation in fv store record store_semantics writer default_store ftw; do
	sources="$sources $COREBOOT_TREE/src/lib/payload_mm_authvar_$implementation.c"
done
sources="$sources $COREBOOT_TREE/src/lib/uuid.c $COREBOOT_TREE/src/lib/hexstrtobin.c"
# shellcheck disable=SC2086
sha256sum "$1" "$CBFSTOOL" "$0" "$root/tests/capsule_report_cold_store.c" \
	"$root/tests/system_fmp_core_ram_refusal_store.c" "$root/include/cdk2/capsule_report.h" \
	"$(command -v "$compiler")" $sources > "$output/inputs-before.sha256"
"$CBFSTOOL" "$1" read -r SMMSTORE -f "$output/store.bin" > "$output/extract.log" 2>&1
"$CBFSTOOL" "$1" extract -n config -f "$output/producer.config" > "$output/config.log" 2>&1
grep -qx 'CONFIG_Q35_SMM_CAPSULE_BROKER=y' "$output/producer.config"
grep -qx 'CONFIG_PAYLOAD_MM_FMP_OWNER_AUTHVAR_BOOT=y' "$output/producer.config"
test "$(grep -c '^CONFIG_DRIVERS_EFI_MAIN_FW_GUID=' "$output/producer.config")" -eq 1
guid=$(sed -n 's/^CONFIG_DRIVERS_EFI_MAIN_FW_GUID="\(.*\)"$/\1/p' "$output/producer.config")
# Same genuine HOST aliases as the existing producer codec oracle; no grant defines.
# shellcheck disable=SC2086
"$compiler" -std=gnu11 -Wall -Wextra -Werror -g -O2 -fshort-wchar \
	-fno-builtin -fno-pie -no-pie -fsanitize=address,undefined \
	-fno-sanitize-recover=all -DENV_TEST=1 \
	-Du8=uint8_t -Du16=uint16_t -Du32=uint32_t -Du64=uint64_t \
	-Ds32=int32_t -Ds64=int64_t \
	-include "$COREBOOT_TREE/src/commonlib/bsd/include/commonlib/bsd/compiler.h" \
	-I"$root/include" -I"$COREBOOT_TREE/src/commonlib/include" \
	-I"$COREBOOT_TREE/src/commonlib/bsd/include" -idirafter "$COREBOOT_TREE/src/include" \
	"$root/tests/capsule_report_cold_store.c" $sources -o "$output/check" \
	> "$output/build.log" 2>&1
ASAN_OPTIONS=abort_on_error=1:detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 \
	"$output/check" "$output/store.bin" "$guid" > "$output/report-last.bin"
sha256sum -c "$output/inputs-before.sha256" > "$output/inputs-check.log"
# Only these public standard-report records are emitted, never whole store/media.
cat "$output/report-last.bin"
