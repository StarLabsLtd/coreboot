#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

test "$#" -eq 3 || exit 2
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
header=$(realpath "$1")
capsule=$(realpath "$2")
output=$(realpath -m "$3")
compiler=${HOSTCC:-cc}
linker=${HOSTLD:-ld}
readelf=${HOSTREADELF:-readelf}
: "${NATIVE_PE_LINK:?actual native PE linker required}"
: "${NATIVE_PE_AUDIT:?actual native PE relocation audit required}"
: "${NATIVE_PE_MARKER:?actual native PE relocation marker required}"
test ! -e "$output"
mkdir -p "$output/include/cdk2"
cp "$header" "$output/include/cdk2/config.h"
for setting in NATIVE_SYSTEM_FMP PROTECTED_VARIABLE_RUNTIME; do
	grep -qx "#define CONFIG_CDK2_$setting 1" "$header"
done
grep -qx '#define CONFIG_CDK2_NATIVE_QEMU_TEST_FMP 0' "$header"
grep -qx '#define CONFIG_CDK2_QEMU_ACCEPTANCE_PROFILE 0' "$header"
sha256sum "$header" "$capsule" "$0" "$root/tests/capsule_report_cold_app.c" \
	"$root/tests/capsule_report_cold_app.ld" "$root/include/cdk2/capsule_report.h" \
	"$(command -v "$compiler")" "$(command -v "$linker")" "$(command -v "$readelf")" \
	"$NATIVE_PE_LINK" "$NATIVE_PE_AUDIT" "$NATIVE_PE_MARKER" \
	> "$output/inputs-before.sha256"
# The expected CapsuleGuid is copied from the actual prior request, not its report.
python3 - "$capsule" <<-'PY'
	import struct
	import sys
	from pathlib import Path
	data = Path(sys.argv[1]).read_bytes()
	if len(data) < 28 or struct.unpack_from('<III', data, 16) != (28, 0x50000, len(data)):
	    raise SystemExit('expected actual PERSIST/INITIATE_RESET prior capsule')
PY
dd if="$capsule" of="$output/capsule_guid.bin" bs=16 count=1 status=none
(cd "$output" && "$linker" -r -b binary capsule_guid.bin -o capsule-guid.o)
set --
for source in tests/capsule_report_cold_app.c src/lib/coreboot_hob.c \
	src/boot/coreboot.c src/boot/coreboot_checksum.c src/boot/coreboot_resource.c \
	src/modules/dxe_core/string.c; do
	sha256sum "$root/$source" >> "$output/inputs-before.sha256"
	object="$output/$(basename "$source" .c).o"
	"$compiler" -std=gnu11 -Wall -Wextra -Werror -O2 -ffreestanding \
		-fno-builtin -fno-stack-protector -fno-asynchronous-unwind-tables \
		-fshort-wchar -mno-red-zone -m64 -mcmodel=small -fpie -fno-ident \
		-fcf-protection=none -maccumulate-outgoing-args \
		-I"$output/include" -I"$root/include" -c "$root/$source" -o "$object"
	set -- "$@" "$object"
done
"$NATIVE_PE_LINK" "$linker" "$NATIVE_PE_AUDIT" "$NATIVE_PE_MARKER" "$readelf" \
	--subsystem 10 --entry capsule_report_cold_entry --image-base 0 \
	--section-alignment 0x1000 --file-alignment 0x1000 --build-id=none \
	--no-insert-timestamp -s --nxcompat -T "$root/tests/capsule_report_cold_app.ld" \
	-o "$output/CapsuleReportCold.efi" "$@" "$output/capsule-guid.o"
cmp "$header" "$output/include/cdk2/config.h"
sha256sum -c "$output/inputs-before.sha256"
sha256sum "$output/CapsuleReportCold.efi"
printf '%s\n' 'Ordinary cold MAIN report observer compiled: no native persistence claim'
