/* SPDX-License-Identifier: GPL-2.0-only */
/* Actual producer decoders; a persistence comparison, never guest admission. */
#include <cdk2/capsule_report.h>
#define main cdk2_refusal_store_main
#include "system_fmp_core_ram_refusal_store.c"
#undef main

int main(int argc, char **argv)
{
	static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
	static const uint16_t report_name[] = {
		'C', 'a', 'p', 's', 'u', 'l', 'e', '0', '0', '0', '0', 0 };
	static const uint16_t last_name[] = {
		'C', 'a', 'p', 's', 'u', 'l', 'e', 'L', 'a', 's', 't', 0 };
	static const uint16_t last_value[] = {
		'C', 'a', 'p', 's', 'u', 'l', 'e', '0', '0', '0', '0' };
	struct payload_mm_authvar_fv_geometry geometry;
	struct payload_mm_authvar_store_entry entries[ENTRY_CAPACITY];
	struct payload_mm_authvar_store_index index = {
		.entries = entries, .entry_capacity = ARRAY_SIZE(entries),
	};
	const struct payload_mm_authvar_store_limits limits = {
		.maximum_store_size = REGION_SIZE, .maximum_name_size = 4096,
		.maximum_data_size = REGION_SIZE, .maximum_records = ENTRY_CAPACITY,
	};
	const struct payload_mm_authvar_store_entry *report, *last;
	const void *report_bytes, *last_bytes;
	uint8_t firmware_guid[UUID_LEN];
	FILE *input;
	bool complete;

	if (argc != 3 || parse_uuid(firmware_guid, argv[2]) != 0)
		return 2;
	input = fopen(argv[1], "rb");
	if (input == NULL)
		return 2;
	complete = fread(media, 1, sizeof(media), input) == sizeof(media) &&
		fgetc(input) == EOF && !ferror(input);
	if (fclose(input) != 0 || !complete)
		return 2;
	if (!matches(media, firmware_guid, NULL, NULL) ||
	    !payload_mm_authvar_fv_geometry(&geometry, REGION_SIZE, 4096) ||
	    payload_mm_authvar_store_scan(&index, media + PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE,
		geometry.variable_size - PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE, &limits) != CB_SUCCESS ||
	    index.dirty_tail_offset != 0)
		return 1;
	report = payload_mm_authvar_store_find(&index, (const void *)&report_guid,
		report_name, sizeof(report_name));
	last = payload_mm_authvar_store_find(&index, (const void *)&report_guid,
		last_name, sizeof(last_name));
	if (report == NULL || last == NULL || report->attributes != 7 || last->attributes != 7 ||
	    report->data_size != CDK2_CAPSULE_REPORT_FMP_SIZE || last->data_size != sizeof(last_value))
		return 1;
	report_bytes = payload_mm_authvar_store_data(&index, report);
	last_bytes = payload_mm_authvar_store_data(&index, last);
	if (report_bytes == NULL || last_bytes == NULL ||
	    memcmp(last_bytes, last_value, sizeof(last_value)))
		return 1;
	if (fwrite(report_bytes, 1, report->data_size, stdout) != report->data_size ||
	    fwrite(last_bytes, 1, last->data_size, stdout) != last->data_size || fflush(stdout))
		return 2;
	return 0;
}
