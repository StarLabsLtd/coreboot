/* SPDX-License-Identifier: GPL-2.0-only */
/* Ordinary cold MAIN observer: no capsule submission or provider authority. */
#include <cdk2/capsule_report.h>
#include <cdk2/capsule_runtime_entry.h>
#include <cdk2/coreboot_hob.h>
#include <cdk2/esrt.h>
#include <cdk2/system_fmp_provider.h>
#include "../src/boot/coreboot.h"
#include <stdint.h>
#include <string.h>

extern const uint8_t _binary_capsule_guid_bin_start[];

typedef EFI_STATUS CDK2_MS_ABI locate_fn(const EFI_GUID *, void *, void **);
typedef EFI_STATUS CDK2_MS_ABI get_fn(CHAR16 *, const EFI_GUID *, UINT32 *, UINTN *, void *);
typedef EFI_STATUS CDK2_MS_ABI set_fn(CHAR16 *, const EFI_GUID *, UINT32, UINTN, void *);

static void marker(const char *text)
{
	while (*text != '\0') {
		__asm__ volatile("outb %0, %1" : : "a"((uint8_t)*text), "Nd"((uint16_t)0x3f8));
		text++;
	}
}

static void fail(void)
{
	marker("CDK2_CAPSULE_REPORT_COLD_MAIN_FAIL\r\n");
	__asm__ volatile("outl %0, %1" : : "a"(2U), "Nd"((uint16_t)0xf4));
	for (;;)
		__asm__ volatile("cli; hlt");
}

EFI_STATUS CDK2_MS_ABI capsule_report_cold_entry(void *image,
	struct cdk2_system_table_view *system)
{
	static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
	static const EFI_GUID global_guid = { 0x8be4df61, 0x93ca, 0x11d2,
		{ 0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c } };
	static const EFI_GUID fmp_guid = { 0x86c77a67, 0x0b97, 0x4633,
		{ 0xa1, 0x87, 0x49, 0x10, 0x4d, 0x06, 0x85, 0xc7 } };
	static const EFI_GUID hob_guid = { 0x7739f24c, 0x93d7, 0x11d4,
		{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
	static const EFI_GUID capsule_variable_guid = { 0x711c703f, 0xc285, 0x4b10,
		{ 0xa3, 0xb0, 0x36, 0xec, 0xbd, 0x3c, 0x8b, 0xe2 } };
	struct configuration_table { EFI_GUID guid; void *table; };
	struct cdk2_fmp_descriptor descriptor;
	struct cdk2_fmp_protocol *fmp = NULL;
	struct cdk2_coreboot_handoff handoff;
	const struct configuration_table *tables;
	const void *hobs = NULL, *record = NULL;
	locate_fn *locate;
	get_fn *get;
	set_fn *set;
	CHAR16 maximum[11], last[12] = { 0 };
	uint8_t report[CDK2_CAPSULE_REPORT_FMP_SIZE], setup = 0, secure = 1, count = 0;
	uint32_t state[5], total, reserved;
	UINT32 attributes = 0, descriptor_version = 0, package_version = 0;
	UINTN size, descriptor_size = 0;
	CHAR16 *package_name = NULL;
	uint64_t request, failure;

	(void)image;
	marker("CDK2_CAPSULE_REPORT_COLD_MAIN_ENTRY\r\n");
	if (system == NULL || system->boot == NULL || system->runtime == NULL)
		fail();
	locate = system->boot->locate_protocol;
	get = system->runtime->get_variable;
	set = system->runtime->set_variable;
	if (locate == NULL || get == NULL || set == NULL)
		fail();
	size = 1;
	if (get(L"SetupMode", &global_guid, &attributes, &size, &setup) != EFI_SUCCESS ||
	    size != 1 || setup != 1)
		fail();
	size = 1;
	if (get(L"SecureBoot", &global_guid, &attributes, &size, &secure) != EFI_SUCCESS ||
	    size != 1 || secure != 0)
		fail();
	if (locate(&fmp_guid, NULL, (void **)&fmp) != EFI_SUCCESS || fmp == NULL ||
	    fmp->get_image_info == NULL)
		fail();
	size = sizeof(descriptor);
	if (fmp->get_image_info(fmp, &size, &descriptor, &descriptor_version, &count,
	    &descriptor_size, &package_version, &package_name) != EFI_SUCCESS ||
	    size != sizeof(descriptor) || count != 1 || descriptor_size != sizeof(descriptor) ||
	    descriptor.image_index == 0 || descriptor.version != 0x001a0009 ||
	    descriptor.lowest_supported_version != 0x001a0009 ||
	    descriptor.last_attempt_version != 0 || descriptor.last_attempt_status != 0 ||
	    descriptor.size != 8388608 ||
	    !(descriptor.attributes_setting & CDK2_SYSTEM_FMP_AUTHENTICATION_REQUIRED))
		fail();
	size = sizeof(state);
	if (get(L"FmpState", &descriptor.image_type_id, &attributes, &size, state) != EFI_SUCCESS ||
	    attributes != 3 || size != sizeof(state))
		fail();
	for (size_t index = 0; index < 5; index++)
		if (state[index] != 0)
			fail();
	tables = system->configuration_table;
	if (tables == NULL || system->table_entries > 256 ||
	    (uintptr_t)tables % _Alignof(*tables) ||
	    (uintptr_t)tables > UINTPTR_MAX - system->table_entries * sizeof(*tables))
		fail();
	for (size_t index = 0; index < system->table_entries; index++) {
		if (memcmp(&tables[index].guid, &hob_guid, sizeof(hob_guid)))
			continue;
		if (hobs != NULL || tables[index].table == NULL)
			fail();
		hobs = tables[index].table;
	}
	if (EFI_ERROR(cdk2_coreboot_handoff_from_hobs(hobs, &handoff)) ||
	    cdk2_coreboot_find_unique_record(&handoff, CB_TAG_CAPSULE,
		 sizeof(struct cb_range), &record) != EFI_NOT_FOUND)
		fail();
	size = sizeof(request);
	if (get(L"CapsuleUpdateData", &capsule_variable_guid, &attributes, &size, &request) !=
	    EFI_NOT_FOUND)
		fail();
	size = sizeof(maximum);
	if (get(L"CapsuleMax", &report_guid, &attributes, &size, maximum) != EFI_SUCCESS ||
	    attributes != 6 || size != sizeof(maximum) || memcmp(maximum, L"Capsuleffff", 22) ||
	    set(L"CapsuleMax", &report_guid, 6, 22, maximum) != EFI_WRITE_PROTECTED)
		fail();
	size = 22;
	if (get(L"CapsuleLast", &report_guid, &attributes, &size, last) != EFI_SUCCESS ||
	    attributes != 7 || size != 22 || memcmp(last, L"Capsule0000", 22) ||
	    set(L"CapsuleLast", &report_guid, 7, 22, last) != EFI_WRITE_PROTECTED)
		fail();
	size = sizeof(report);
	if (get(last, &report_guid, &attributes, &size, report) != EFI_SUCCESS ||
	    attributes != 7 || size != sizeof(report))
		fail();
	memcpy(&total, report, sizeof(total));
	memcpy(&reserved, report + 4, sizeof(reserved));
	memcpy(&failure, report + 40, sizeof(failure));
	if (total != sizeof(report) || reserved != 0 ||
	    memcmp(report + 8, _binary_capsule_guid_bin_start, 16) ||
	    failure != EFI_DEVICE_ERROR || report[48] != 1 || report[49] != 0 ||
	    report[50] != 0 || report[51] != descriptor.image_index ||
	    memcmp(report + 52, &descriptor.image_type_id, 16) ||
	    memcmp(report + 68, "\0\0\0\0", 4))
		fail();
	marker("CDK2_CAPSULE_REPORT_COLD_PERSISTED_LOCKED_MAIN_PASS\r\n");
	__asm__ volatile("outl %0, %1" : : "a"(1U), "Nd"((uint16_t)0xf4));
	for (;;)
		__asm__ volatile("cli; hlt");
}
