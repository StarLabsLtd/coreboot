# SPDX-License-Identifier: GPL-2.0-only
"""MODELED cold observation boundaries; no firmware or persisted report claim."""

import ast
import json
import tempfile
import unittest
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import capsule_report_cold_native_test as runner
from system_fmp_core_ram_runner_test import table


class ColdReportTest(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        (self.directory / "cbmem-observer.json").write_text(json.dumps({"tables": [{}]}))
        self.table_path = self.directory / "cbmem-table-0.bin"
        self.table_path.write_bytes(table(0x001A0009, False))
        self.guid = uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le
        self.body = (b"CDK2 | CAPSULE_RAM | begin\n"
                     b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n"
                     b"CDK2 | PCI_ROOTS | begin\n")
        self.uart = (b"CDK2_CAPSULE_REPORT_COLD_MAIN_ENTRY\n"
                     b"CDK2_CAPSULE_REPORT_COLD_PERSISTED_LOCKED_MAIN_PASS\n")

    def check(self, events=()):
        with patch.object(runner, "validate_saved_console", return_value=self.body):
            runner.check_cold_boot(self.directory, self.guid, self.uart, events)

    def test_normal_cold(self):
        self.check()

    def test_no_reset(self):
        with self.assertRaisesRegex(ValueError, "must not reset"):
            self.check([{"event": "RESET", "data": {"guest": True}}])

    def test_marker_cardinality(self):
        for uart in (b"", self.uart * 2, self.uart + b"CDK2_CAPSULE_REPORT_COLD_MAIN_FAIL"):
            with self.subTest(uart=uart):
                with patch.object(runner, "validate_saved_console", return_value=self.body):
                    with self.assertRaisesRegex(ValueError, "marker cardinality"):
                        runner.check_cold_boot(self.directory, self.guid, uart, [])

    def test_retained_capsule_is_not_cold(self):
        self.table_path.write_bytes(table(0x001A0009, True))
        with self.assertRaisesRegex(ValueError, "capsule handoff"):
            self.check()

    def test_wrong_firmware_or_guid(self):
        self.table_path.write_bytes(table(0x001A000A, False))
        with self.assertRaisesRegex(ValueError, "firmware identity"):
            self.check()
        self.table_path.write_bytes(table(0x001A0009, False))
        self.guid = bytes(16)
        with self.assertRaisesRegex(ValueError, "firmware identity"):
            self.check()

    def test_phase_failure_or_order(self):
        good = self.body
        for body in (b"", good.replace(b"complete | SUCCESS", b"failed | DEVICE_ERROR"),
                     good.replace(b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n", b""),
                     good + b"CDK2 | PLATFORM_TABLES | failed | COMPROMISED_DATA\n"):
            self.body = body
            with self.assertRaisesRegex(ValueError, "RAM completion"):
                self.check()

    def test_actual_terminal_budget_guard(self):
        source = Path(runner.__file__).read_text()
        guards = [node for node in ast.walk(ast.parse(source)) if isinstance(node, ast.If) and
                  "cold persistence requires actual guest exit3" in ast.get_source_segment(source, node)]
        self.assertEqual(len(guards), 1)
        code = compile(ast.Module(body=[guards[0]], type_ignores=[]), runner.__file__, "exec")
        for status, now, qmp in ((3, 179, object()), (3, 181, object()),
                                 (None, 179, object()), (2, 179, object()), (3, 179, None)):
            scope = {"process": SimpleNamespace(poll=lambda: status),
                     "time": SimpleNamespace(monotonic=lambda: now), "deadline": 180, "qmp": qmp}
            if status == 3 and now <= 180 and qmp is not None:
                exec(code, scope)
            else:
                with self.assertRaisesRegex(ValueError, "exit3 within 180"):
                    exec(code, scope)


if __name__ == "__main__":
    unittest.main()
