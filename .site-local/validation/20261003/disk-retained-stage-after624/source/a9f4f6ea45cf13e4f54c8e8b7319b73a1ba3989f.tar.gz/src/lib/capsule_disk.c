/* SPDX-License-Identifier: GPL-2.0-only */

#include <cdk2/capsule_disk.h>

#include <cdk2/english.h>

#include <stddef.h>
#include <string.h>

struct loaded_file {
	struct cdk2_capsule_disk_file file;
	CHAR16 *owned_name;
	UINTN index;
	void *data;
	BOOLEAN valid;
	BOOLEAN malformed;
	BOOLEAN deletable;
	BOOLEAN reset_requested;
};

struct capsule_disk_transaction {
	UINT64 magic;
	struct cdk2_capsule_disk_result *owner;
	struct cdk2_capsule_list *capsules;
	const void *source_identity;
	struct cdk2_capsule_image *images;
	UINTN capsule_count;
	UINTN source;
	UINTN file_count;
	struct loaded_file *files;
	EFI_STATUS processing_status;
};

#define CDK2_CAPSULE_DISK_TRANSACTION_MAGIC 0x43444b325452584eULL

#define CDK2_CAPSULE_DISK_BATCH_FILES 32U
#define CDK2_CAPSULE_DISK_PREFLIGHT_FILES 32U
#define CDK2_CAPSULE_DISK_METADATA_FILES \
	(CDK2_CAPSULE_DISK_BATCH_FILES + CDK2_CAPSULE_DISK_PREFLIGHT_FILES)
#define CDK2_CAPSULE_DISK_NAME_CHARS 256U

static const EFI_GUID fmp_capsule_guid = { 0x6dcbd5ed, 0xe82d, 0x4c44,
	{ 0xbd, 0xa1, 0x71, 0x94, 0x19, 0x9a, 0xd9, 0x2a } };

static void copy_bytes(void *destination, const void *source, UINTN size)
{
	UINT8 *to = destination;
	const UINT8 *from = source;

	while (size-- != 0U)
		*to++ = *from++;
}

static BOOLEAN guid_zero(const EFI_GUID *guid)
{
	const UINT8 *bytes = (const void *)guid;
	UINTN index;

	for (index = 0U; index < sizeof(*guid); index++)
		if (bytes[index] != 0U)
			return FALSE;
	return TRUE;
}

static BOOLEAN guid_equal(const EFI_GUID *left, const EFI_GUID *right)
{
	const UINT8 *left_bytes = (const void *)left;
	const UINT8 *right_bytes = (const void *)right;
	UINTN index;

	for (index = 0U; index < sizeof(*left); index++)
		if (left_bytes[index] != right_bytes[index])
			return FALSE;
	return TRUE;
}

static BOOLEAN regular_file(UINT64 attributes)
{
	return (attributes & ~CDK2_CAPSULE_FILE_VALID_ATTRIBUTES) == 0U &&
		(attributes & CDK2_CAPSULE_FILE_DIRECTORY_ATTRIBUTE) == 0U;
}

static INTN compare_names(const CHAR16 *left, const CHAR16 *right)
{
	const CHAR16 *raw_left = left;
	const CHAR16 *raw_right = right;

	while (*left != 0U) {
		CHAR16 a = cdk2_english_fold(*left);
		CHAR16 b = cdk2_english_fold(*right);

		if (a != b)
			return (INTN)a - (INTN)b;
		left++;
		right++;
	}
	if (*right != 0U)
		return -(INTN)*right;
	/* Preserve a total order for names with equivalent folded spelling. */
	while (*raw_left != 0U && *raw_left == *raw_right) {
		raw_left++;
		raw_right++;
	}
	return (INTN)*raw_left - (INTN)*raw_right;
}

static INTN compare_file_order(const CHAR16 *left_name, UINTN left_index,
			       const CHAR16 *right_name, UINTN right_index,
			       UINTN *work)
{
	INTN order = compare_names(left_name, right_name);

	if (*work != MAX_UINTN)
		(*work)++;

	if (order != 0 || left_index == right_index)
		return order;
	return left_index < right_index ? -1 : 1;
}

static INTN compare_loaded(const struct loaded_file *left,
			   const struct loaded_file *right, UINTN *work)
{
	return compare_file_order(left->file.name, left->index, right->file.name,
		right->index, work);
}

static void sort_files(struct loaded_file *files, UINTN count, UINTN *work)
{
	UINTN index;

	for (index = 1U; index < count; index++) {
		struct loaded_file value = files[index];
		UINTN position = index;

		while (position != 0U && compare_file_order(value.file.name,
							    value.index,
							    files[position - 1U].file.name,
							    files[position - 1U].index,
							    work) < 0) {
			files[position] = files[position - 1U];
			position--;
		}
		files[position] = value;
	}
}

static void heap_up(struct loaded_file *files, UINTN position, UINTN *work)
{
	while (position != 0U) {
		UINTN parent = (position - 1U) / 2U;
		struct loaded_file swap;
		INTN order;

		order = compare_loaded(&files[parent], &files[position], work);
		if (order >= 0)
			break;
		swap = files[parent];
		files[parent] = files[position];
		files[position] = swap;
		position = parent;
	}
}

static void heap_down(struct loaded_file *files, UINTN count, UINTN *work)
{
	UINTN position = 0U;

	for (;;) {
		UINTN child = position * 2U + 1U;
		struct loaded_file swap;
		INTN order;

		if (child >= count)
			break;
		if (child + 1U < count &&
		    compare_loaded(&files[child], &files[child + 1U], work) < 0)
			child++;
		order = compare_loaded(&files[position], &files[child], work);
		if (order >= 0)
			break;
		swap = files[position];
		files[position] = files[child];
		files[child] = swap;
		position = child;
	}
}

static void report(const struct cdk2_capsule_disk_ops *ops,
	enum cdk2_capsule_disk_event event, UINTN source, UINTN file,
	UINT64 value, EFI_STATUS status)
{
	if (ops->report != NULL)
		ops->report(event, source, file, value, status, ops->context);
}

static EFI_STATUS prefer_failure(EFI_STATUS status, EFI_STATUS candidate)
{
	if (candidate != EFI_SUCCESS &&
	    (status == EFI_SUCCESS || (!EFI_ERROR(status) && EFI_ERROR(candidate))))
		return candidate;
	return status;
}

static BOOLEAN structural_valid(const void *data, UINTN size)
{
	const struct cdk2_capsule_header *header = data;

	if (data == NULL || size < sizeof(*header) || size > MAX_UINT32 ||
	    header->header_size < sizeof(*header) || header->header_size > size ||
	    header->image_size != size || guid_zero(&header->guid) ||
	    (header->flags & ~CDK2_CAPSULE_ALLOWED_FLAGS) != 0U ||
	    ((header->flags & CDK2_CAPSULE_POPULATE_SYSTEM_TABLE) != 0U &&
	     (header->flags & CDK2_CAPSULE_PERSIST_ACROSS_RESET) == 0U) ||
	    ((header->flags & CDK2_CAPSULE_INITIATE_RESET) != 0U &&
	     (header->flags & CDK2_CAPSULE_PERSIST_ACROSS_RESET) == 0U))
		return FALSE;
	return TRUE;
}

static BOOLEAN definitive_validation_failure(EFI_STATUS status)
{
	return status == EFI_INVALID_PARAMETER || status == EFI_UNSUPPORTED ||
		status == EFI_SECURITY_VIOLATION ||
		status == EFI_COMPROMISED_DATA;
}

static EFI_STATUS validate_name(const struct cdk2_capsule_disk_file *file,
				UINTN *characters)
{
	UINTN index;

	if (file->name == NULL || file->name_bytes < sizeof(CHAR16) ||
	    file->name_bytes % sizeof(CHAR16) != 0U ||
	    file->name_bytes / sizeof(CHAR16) > CDK2_CAPSULE_DISK_NAME_CHARS)
		return EFI_COMPROMISED_DATA;
	for (index = 0U; index < file->name_bytes / sizeof(CHAR16); index++)
		if (file->name[index] == 0U)
			break;
	if (index == file->name_bytes / sizeof(CHAR16))
		return EFI_COMPROMISED_DATA;
	if (characters != NULL)
		*characters = index;
	return EFI_SUCCESS;
}

static EFI_STATUS copy_name(const struct cdk2_capsule_disk_ops *ops,
			    const struct cdk2_capsule_disk_file *file,
			    CHAR16 **name)
{
	CHAR16 *copy;
	UINTN index;
	EFI_STATUS status;

	*name = NULL;
	status = validate_name(file, &index);
	if (EFI_ERROR(status))
		return status;
	if (index > (MAX_UINTN / sizeof(CHAR16)) - 1U)
		return EFI_OUT_OF_RESOURCES;
	copy = ops->alloc((index + 1U) * sizeof(*copy), ops->context);
	if (copy == NULL)
		return EFI_OUT_OF_RESOURCES;
	copy_bytes(copy, file->name, (index + 1U) * sizeof(*copy));
	*name = copy;
	return EFI_SUCCESS;
}

static EFI_STATUS copy_metadata(const struct cdk2_capsule_disk_ops *ops,
				const struct cdk2_capsule_disk_file *file,
				UINTN index, struct loaded_file *loaded)
{
	EFI_STATUS status;

	*loaded = (struct loaded_file){0};
	status = copy_name(ops, file, &loaded->owned_name);
	if (EFI_ERROR(status))
		return status;
	loaded->file.name = loaded->owned_name;
	loaded->file.name_bytes = file->name_bytes;
	loaded->file.size = file->size;
	loaded->file.attributes = file->attributes;
	loaded->index = index;
	return EFI_SUCCESS;
}

static void free_loaded(const struct cdk2_capsule_disk_ops *ops,
	struct loaded_file *files, UINTN count, BOOLEAN keep_valid)
{
	UINTN index;

	if (files == NULL)
		return;
	for (index = 0U; index < count; index++) {
		if (files[index].data != NULL && !(keep_valid && files[index].valid))
			ops->free(files[index].data, ops->context);
		if (files[index].owned_name != NULL)
			ops->free(files[index].owned_name, ops->context);
	}
	ops->free(files, ops->context);
}

static void discard_transaction(const struct cdk2_capsule_disk_ops *ops,
	struct capsule_disk_transaction *transaction)
{
	UINTN index;

	if (transaction == NULL)
		return;
	for (index = 0U; index < transaction->file_count; index++)
		if (transaction->files[index].owned_name != NULL)
			ops->free(transaction->files[index].owned_name, ops->context);
	ops->free(transaction->files, ops->context);
	ops->free(transaction, ops->context);
}

static EFI_STATUS load_source(const struct cdk2_capsule_disk_ops *ops,
	UINTN source, struct loaded_file **loaded, UINTN *loaded_count,
	UINTN *valid_count, BOOLEAN qualify_deferred, BOOLEAN *deferred_valid,
	EFI_STATUS *io_status, UINTN *metadata_work)
{
	struct cdk2_capsule_disk_file file;
	struct loaded_file *files;
	EFI_STATUS status;
	UINTN candidates = 0U;
	UINTN capacity = CDK2_CAPSULE_DISK_METADATA_FILES;
	UINTN batch_count;
	UINTN index;
	UINTN maximum_size = ops->max_populate_size > ops->max_nonpopulate_size ?
		ops->max_populate_size : ops->max_nonpopulate_size;
	UINTN allocated_size = 0U;
	BOOLEAN aggregate_limited = FALSE;
	BOOLEAN metadata_limited = FALSE;

	*loaded = NULL;
	*loaded_count = 0U;
	*valid_count = 0U;
	*deferred_valid = FALSE;
	*io_status = EFI_SUCCESS;
	files = ops->alloc(capacity * sizeof(*files), ops->context);
	if (files == NULL)
		return EFI_OUT_OF_RESOURCES;
	for (index = 0U; index < capacity; index++)
		files[index] = (struct loaded_file){0};
	for (index = 0U;; index++) {
		struct loaded_file replacement;

		status = ops->file(source, index, &file, ops->context);
		if (status == EFI_NOT_FOUND)
			break;
		if (status != EFI_SUCCESS) {
			if (candidates == 0U) {
				free_loaded(ops, files, candidates, FALSE);
				return status;
			}
			*io_status = status;
			break;
		}
		if (file.name == NULL || file.name_bytes < sizeof(CHAR16)) {
			free_loaded(ops, files, candidates, FALSE);
			return EFI_COMPROMISED_DATA;
		}
		if (!regular_file(file.attributes))
			continue;
		status = validate_name(&file, NULL);
		if (EFI_ERROR(status)) {
			free_loaded(ops, files, candidates, FALSE);
			return status;
		}
		if (candidates < capacity) {
			status = copy_metadata(ops, &file, index, &files[candidates]);
			if (EFI_ERROR(status)) {
				free_loaded(ops, files, candidates, FALSE);
				return status;
			}
			heap_up(files, candidates, metadata_work);
			candidates++;
			continue;
		}
		metadata_limited = TRUE;
		if (compare_file_order(file.name, index, files[0].file.name,
				       files[0].index, metadata_work) >= 0)
			continue;
		ops->free(files[0].owned_name, ops->context);
		files[0].owned_name = NULL;
		status = copy_metadata(ops, &file, index, &replacement);
		if (EFI_ERROR(status)) {
			free_loaded(ops, files, candidates, FALSE);
			return status;
		}
		files[0] = replacement;
		heap_down(files, candidates, metadata_work);
	}
	if (candidates == 0U) {
		free_loaded(ops, files, candidates, FALSE);
		return EFI_NOT_FOUND;
	}
	sort_files(files, candidates, metadata_work);
	batch_count = candidates < CDK2_CAPSULE_DISK_BATCH_FILES ? candidates :
		CDK2_CAPSULE_DISK_BATCH_FILES;
	for (index = 0U; index < batch_count; index++) {
		const struct cdk2_capsule_header *header;

		if (files[index].file.size == 0U ||
		    files[index].file.size > MAX_UINT32 ||
		    files[index].file.size > MAX_UINTN ||
		    files[index].file.size > maximum_size) {
			files[index].malformed = TRUE;
			files[index].deletable = TRUE;
			report(ops, CDK2_CAPSULE_DISK_MALFORMED, source,
				files[index].index, files[index].file.size,
				EFI_COMPROMISED_DATA);
			continue;
		}
		if ((UINTN)files[index].file.size > maximum_size - allocated_size) {
			if (!EFI_ERROR(*io_status))
				*io_status = EFI_OUT_OF_RESOURCES;
			aggregate_limited = TRUE;
			break;
		}
		files[index].data = ops->alloc((UINTN)files[index].file.size,
			ops->context);
		if (files[index].data == NULL) {
			if (!EFI_ERROR(*io_status))
				*io_status = EFI_OUT_OF_RESOURCES;
			break;
		}
		allocated_size += (UINTN)files[index].file.size;
		status = ops->read(source, files[index].index, files[index].data,
			(UINTN)files[index].file.size, ops->context);
		if (EFI_ERROR(status)) {
			report(ops, CDK2_CAPSULE_DISK_IO_ERROR, source,
				files[index].index, files[index].file.size, status);
			ops->free(files[index].data, ops->context);
			files[index].data = NULL;
			allocated_size -= (UINTN)files[index].file.size;
			if (!EFI_ERROR(*io_status))
				*io_status = status;
			break;
		}
		if (!structural_valid(files[index].data,
		    (UINTN)files[index].file.size)) {
			ops->free(files[index].data, ops->context);
			files[index].data = NULL;
			allocated_size -= (UINTN)files[index].file.size;
			files[index].malformed = TRUE;
			files[index].deletable = TRUE;
			report(ops, CDK2_CAPSULE_DISK_MALFORMED, source,
				files[index].index, files[index].file.size,
				EFI_COMPROMISED_DATA);
			continue;
		}
		header = files[index].data;
		{
			UINTN limit = (header->flags &
				CDK2_CAPSULE_POPULATE_SYSTEM_TABLE) != 0U ?
				ops->max_populate_size : ops->max_nonpopulate_size;

			if (files[index].file.size > limit) {
				ops->free(files[index].data, ops->context);
				files[index].data = NULL;
				allocated_size -= (UINTN)files[index].file.size;
				files[index].malformed = TRUE;
				files[index].deletable = TRUE;
				report(ops, CDK2_CAPSULE_DISK_MALFORMED, source,
					files[index].index, files[index].file.size,
					EFI_INVALID_PARAMETER);
				continue;
			}
		}
		if ((header->flags & CDK2_CAPSULE_POPULATE_SYSTEM_TABLE) != 0U &&
		    guid_equal(&header->guid, &fmp_capsule_guid))
			status = EFI_INVALID_PARAMETER;
		else if ((header->flags & CDK2_CAPSULE_POPULATE_SYSTEM_TABLE) != 0U)
			status = EFI_SUCCESS;
		else
			status = ops->validate_fmp(files[index].data,
				(UINTN)files[index].file.size, ops->context);
		if (EFI_ERROR(status)) {
			if (definitive_validation_failure(status)) {
				ops->free(files[index].data, ops->context);
				files[index].data = NULL;
				allocated_size -= (UINTN)files[index].file.size;
				files[index].malformed = TRUE;
				files[index].deletable = TRUE;
				report(ops, CDK2_CAPSULE_DISK_MALFORMED, source,
					files[index].index, files[index].file.size,
					status);
			} else {
				ops->free(files[index].data, ops->context);
				files[index].data = NULL;
				report(ops, CDK2_CAPSULE_DISK_IO_ERROR, source,
					files[index].index, files[index].file.size,
					status);
				if (!EFI_ERROR(*io_status))
					*io_status = status;
				break;
			}
			continue;
		}
		files[index].valid = TRUE;
		files[index].reset_requested = (header->flags &
			CDK2_CAPSULE_INITIATE_RESET) != 0U;
		(*valid_count)++;
		report(ops, CDK2_CAPSULE_DISK_FILE, source, files[index].index,
			files[index].file.size, EFI_SUCCESS);
	}
	if (qualify_deferred && *valid_count == 0U && !EFI_ERROR(*io_status)) {
		UINTN preflight_bytes = 0U;
		UINTN preflight_files = 0U;

		for (index = batch_count; index < candidates; index++) {
			const struct cdk2_capsule_header *header;
			UINTN limit;

			if (files[index].file.size == 0U ||
			    files[index].file.size > MAX_UINT32 ||
			    files[index].file.size > MAX_UINTN ||
			    files[index].file.size > maximum_size)
				continue;
			if (preflight_files == CDK2_CAPSULE_DISK_PREFLIGHT_FILES ||
			    (UINTN)files[index].file.size > maximum_size - preflight_bytes) {
				*io_status = EFI_OUT_OF_RESOURCES;
				break;
			}
			preflight_files++;
			preflight_bytes += (UINTN)files[index].file.size;
			files[index].data = ops->alloc((UINTN)files[index].file.size,
				ops->context);
			if (files[index].data == NULL) {
				*io_status = EFI_OUT_OF_RESOURCES;
				break;
			}
			status = ops->read(source, files[index].index, files[index].data,
				(UINTN)files[index].file.size, ops->context);
			if (EFI_ERROR(status)) {
				ops->free(files[index].data, ops->context);
				files[index].data = NULL;
				*io_status = status;
				break;
			}
			if (!structural_valid(files[index].data,
			    (UINTN)files[index].file.size)) {
				ops->free(files[index].data, ops->context);
				files[index].data = NULL;
				continue;
			}
			header = files[index].data;
			limit = (header->flags & CDK2_CAPSULE_POPULATE_SYSTEM_TABLE) != 0U ?
				ops->max_populate_size : ops->max_nonpopulate_size;
			if (files[index].file.size > limit ||
			    ((header->flags & CDK2_CAPSULE_POPULATE_SYSTEM_TABLE) != 0U &&
			     guid_equal(&header->guid, &fmp_capsule_guid)))
				status = EFI_INVALID_PARAMETER;
			else if ((header->flags &
			    CDK2_CAPSULE_POPULATE_SYSTEM_TABLE) != 0U)
				status = EFI_SUCCESS;
			else
				status = ops->validate_fmp(files[index].data,
					(UINTN)files[index].file.size, ops->context);
			ops->free(files[index].data, ops->context);
			files[index].data = NULL;
			if (EFI_ERROR(status) &&
			    !definitive_validation_failure(status)) {
				*io_status = status;
				break;
			}
			if (!EFI_ERROR(status)) {
				*deferred_valid = TRUE;
				break;
			}
		}
		if (!*deferred_valid && metadata_limited && !EFI_ERROR(*io_status))
			*io_status = EFI_OUT_OF_RESOURCES;
	}
	for (index = batch_count; index < candidates; index++) {
		ops->free(files[index].owned_name, ops->context);
		files[index].owned_name = NULL;
	}
	/* The loaded prefix is independently valid and can be applied now. Do not
	 * leave it on disk merely because a later sibling exceeds this batch's
	 * aggregate allocation bound; successful completion deletes the prefix,
	 * letting the next scan advance to that sibling. */
	if (aggregate_limited && *valid_count != 0U &&
	    *io_status == EFI_OUT_OF_RESOURCES)
		*io_status = EFI_SUCCESS;
	*loaded = files;
	*loaded_count = batch_count;
	return EFI_SUCCESS;
}

static EFI_STATUS cleanup_definitive(const struct cdk2_capsule_disk_ops *ops,
	UINTN source, struct loaded_file *files, UINTN count,
	struct cdk2_capsule_disk_result *result)
{
	EFI_STATUS first_error = EFI_SUCCESS;
	UINTN index;

	for (index = 0U; index < count; index++) {
		EFI_STATUS status;

		if (!files[index].deletable)
			continue;
		status = files[index].data != NULL ?
			ops->remove(source, files[index].file.name, files[index].data,
				(UINTN)files[index].file.size, ops->context) :
			ops->remove_unread(source, files[index].file.name,
				files[index].file.size, files[index].file.attributes,
				ops->context);
		if (status != EFI_SUCCESS) {
			result->cleanup_failed = TRUE;
			result->cleanup_failures++;
			report(ops, CDK2_CAPSULE_DISK_DELETE_ERROR, source,
				files[index].index, 0U, status);
			if (first_error == EFI_SUCCESS ||
			    (!EFI_ERROR(first_error) && EFI_ERROR(status)))
				first_error = status;
		} else {
			result->deleted++;
		}
	}
	return first_error;
}

static EFI_STATUS append_valid(const struct cdk2_capsule_disk_ops *ops,
	struct cdk2_capsule_list *capsules, struct loaded_file *files,
	UINTN count, UINTN valid_count)
{
	struct cdk2_capsule_image *images;
	UINTN total;
	UINTN index;
	UINTN output;

	if (valid_count == 0U)
		return EFI_NOT_FOUND;
	if (capsules->count > MAX_UINTN - valid_count ||
	    capsules->count + valid_count > MAX_UINTN / sizeof(*images))
		return EFI_OUT_OF_RESOURCES;
	total = capsules->count + valid_count;
	images = ops->alloc(total * sizeof(*images), ops->context);
	if (images == NULL)
		return EFI_OUT_OF_RESOURCES;
	if (capsules->count != 0U)
		copy_bytes(images, capsules->images,
			capsules->count * sizeof(*images));
	output = capsules->count;
	for (index = 0U; index < count; index++) {
		const struct cdk2_capsule_header *header;

		if (!files[index].valid)
			continue;
		header = files[index].data;
		images[output++] = (struct cdk2_capsule_image){
			.data = files[index].data,
			.size = (UINTN)files[index].file.size,
			.guid = header->guid,
			.flags = header->flags,
		};
	}
	capsules->images = images;
	capsules->count = total;
	return EFI_SUCCESS;
}

static EFI_STATUS scan_failure(struct cdk2_capsule_disk_result *result,
	EFI_STATUS status)
{
	result->scan_status = status;
	return status;
}

EFI_STATUS cdk2_capsule_disk_scan(const struct cdk2_capsule_disk_ops *ops,
	struct cdk2_capsule_list *capsules,
	struct cdk2_capsule_disk_result *result)
{
	struct cdk2_capsule_disk_source source;
	struct loaded_file *selected = NULL;
	struct capsule_disk_transaction *transaction = NULL;
	UINTN selected_count = 0U;
	UINTN selected_valid = 0U;
	EFI_STATUS selected_io = EFI_SUCCESS;
	BOOLEAN selected_preferred = FALSE;
	UINTN selected_source = MAX_UINTN;
	UINTN fallback_sources = 0U;
	EFI_STATUS fallback_error = EFI_SUCCESS;
	EFI_STATUS fallback_cleanup = EFI_SUCCESS;
	EFI_STATUS scan_status;
	UINTN index;
	EFI_STATUS status;

	if (ops == NULL || capsules == NULL || result == NULL ||
	    ops->source == NULL || ops->file == NULL || ops->read == NULL ||
	    ops->remove == NULL || ops->remove_unread == NULL ||
	    ops->validate_fmp == NULL ||
	    ops->process_fmp == NULL ||
	    ops->alloc == NULL || ops->free == NULL ||
	    ops->source_identity == NULL ||
	    ops->max_nonpopulate_size == 0U || ops->max_populate_size == 0U ||
	    (capsules->count != 0U && capsules->images == NULL)) {
		if (result != NULL)
			result->scan_status = EFI_INVALID_PARAMETER;
		return EFI_INVALID_PARAMETER;
	}
	*result = (struct cdk2_capsule_disk_result){ .source = MAX_UINTN };
	/* Preferred ESPs are authoritative whenever they contain regular files. */
	for (index = 0U; index < ops->source_count; index++) {
		struct loaded_file *files;
		UINTN count;
		UINTN valid;
		BOOLEAN deferred_valid;
		EFI_STATUS io_status;

		status = ops->source(index, &source, ops->context);
		if (EFI_ERROR(status)) {
			free_loaded(ops, selected, selected_count, FALSE);
			return scan_failure(result, status);
		}
		if (!source.preferred || !source.esp)
			continue;
		status = load_source(ops, source.id, &files, &count, &valid,
			FALSE, &deferred_valid,
			&io_status, &result->metadata_work);
		if (status == EFI_NOT_FOUND)
			continue;
		if (EFI_ERROR(status)) {
			free_loaded(ops, selected, selected_count, FALSE);
			return scan_failure(result, status);
		}
		if (selected != NULL) {
			free_loaded(ops, files, count, FALSE);
			free_loaded(ops, selected, selected_count, FALSE);
			return scan_failure(result, EFI_SECURITY_VIOLATION);
		}
		selected = files;
		selected_count = count;
		selected_valid = valid;
		selected_io = io_status;
		selected_source = source.id;
		selected_preferred = TRUE;
	}
	/* A fallback qualifies only when it contains a valid capsule. */
	if (selected == NULL) {
		for (index = 0U; index < ops->source_count; index++) {
			struct loaded_file *files;
			UINTN count;
			UINTN valid;
			BOOLEAN deferred_valid;
			EFI_STATUS io_status;

			status = ops->source(index, &source, ops->context);
			if (EFI_ERROR(status)) {
				free_loaded(ops, selected, selected_count, FALSE);
				return scan_failure(result, status);
			}
			if (source.preferred || !source.esp)
				continue;
			status = load_source(ops, source.id, &files, &count, &valid,
				TRUE, &deferred_valid,
				&io_status, &result->metadata_work);
			if (status == EFI_NOT_FOUND)
				continue;
			if (EFI_ERROR(status)) {
				free_loaded(ops, selected, selected_count, FALSE);
				return scan_failure(result, status);
			}
			if (valid == 0U && !deferred_valid) {
				EFI_STATUS cleanup_status;

				/* A bounded preflight can establish malformed entries before
				 * it runs out of budget. Remove only those definitive entries
				 * so the next boot advances past the same prefix. */
				cleanup_status = cleanup_definitive(ops, source.id, files, count, result);
				if (EFI_ERROR(io_status) && !EFI_ERROR(fallback_error))
					fallback_error = io_status;
				if (cleanup_status != EFI_SUCCESS &&
				    (fallback_cleanup == EFI_SUCCESS ||
				     (!EFI_ERROR(fallback_cleanup) && EFI_ERROR(cleanup_status))))
					fallback_cleanup = cleanup_status;
				free_loaded(ops, files, count, FALSE);
				continue;
			}
			fallback_sources++;
			if (fallback_sources > 1U) {
				free_loaded(ops, files, count, FALSE);
				free_loaded(ops, selected, selected_count, FALSE);
				return scan_failure(result, EFI_SECURITY_VIOLATION);
			}
			selected = files;
			selected_count = count;
			selected_valid = valid;
			selected_io = io_status;
			selected_source = source.id;
		}
	}
	if (selected == NULL)
		return scan_failure(result,
			fallback_error != EFI_SUCCESS ? fallback_error :
			fallback_cleanup != EFI_SUCCESS ? fallback_cleanup : EFI_NOT_FOUND);
	if (EFI_ERROR(fallback_error)) {
		free_loaded(ops, selected, selected_count, FALSE);
		return scan_failure(result, fallback_error);
	}
	if (fallback_cleanup != EFI_SUCCESS &&
	    (selected_io == EFI_SUCCESS ||
	     (!EFI_ERROR(selected_io) && EFI_ERROR(fallback_cleanup))))
		selected_io = fallback_cleanup;
	result->source = selected_source;
	result->candidates = selected_count;
	for (index = 0U; index < selected_count; index++)
		if (selected[index].malformed)
			result->malformed++;
	result->used_preferred = selected_preferred;
	report(ops, CDK2_CAPSULE_DISK_SOURCE, selected_source, MAX_UINTN,
		selected_count, EFI_SUCCESS);
	scan_status = EFI_NOT_FOUND;
	if (selected_valid != 0U) {
		transaction = ops->alloc(sizeof(*transaction), ops->context);
		if (transaction == NULL) {
			free_loaded(ops, selected, selected_count, FALSE);
			return scan_failure(result, EFI_OUT_OF_RESOURCES);
		}
		*transaction = (struct capsule_disk_transaction){
			.magic = CDK2_CAPSULE_DISK_TRANSACTION_MAGIC,
			.owner = result,
			.capsules = capsules,
			.source_identity = ops->source_identity,
			.images = capsules->images,
			.capsule_count = capsules->count + selected_valid,
			.source = selected_source,
			.file_count = selected_count,
			.files = selected,
		};
		scan_status = append_valid(ops, capsules, selected, selected_count,
			selected_valid);
		if (EFI_ERROR(scan_status)) {
			ops->free(transaction, ops->context);
			free_loaded(ops, selected, selected_count, FALSE);
			return scan_failure(result, scan_status);
		}
		result->loaded = selected_valid;
	}
	for (index = 0U; index < selected_count; index++) {
		EFI_STATUS remove_status;

		if (!selected[index].deletable)
			continue;
		remove_status = selected[index].data != NULL ?
			ops->remove(selected_source, selected[index].file.name,
				selected[index].data, (UINTN)selected[index].file.size,
				ops->context) :
			ops->remove_unread(selected_source, selected[index].file.name,
				selected[index].file.size, selected[index].file.attributes,
				ops->context);
		if (remove_status != EFI_SUCCESS) {
			result->cleanup_failed = TRUE;
			result->cleanup_failures++;
			report(ops, CDK2_CAPSULE_DISK_DELETE_ERROR, selected_source,
				selected[index].index, 0U, remove_status);
			if (selected_io == EFI_SUCCESS ||
			    (!EFI_ERROR(selected_io) && EFI_ERROR(remove_status)))
				selected_io = remove_status;
		} else {
			result->deleted++;
		}
		if (!selected[index].valid && selected[index].data != NULL) {
			ops->free(selected[index].data, ops->context);
			selected[index].data = NULL;
		}
	}
	if (selected_valid != 0U) {
		EFI_STATUS finish_status = EFI_SUCCESS;

		if (ops->finish != NULL)
			finish_status = ops->finish(ops->context);
		if (finish_status == EFI_SUCCESS) {
			EFI_STATUS process_status = ops->process_fmp(
				&capsules->images[capsules->count - selected_valid],
				selected_valid, ops->context);

			result->processing_attempted = TRUE;
			result->processing_status = process_status;
			if (process_status != EFI_SUCCESS) {
				report(ops, CDK2_CAPSULE_DISK_IO_ERROR, selected_source,
					MAX_UINTN, selected_valid, process_status);
			}
			transaction->processing_status = process_status;
		} else {
			selected_io = prefer_failure(selected_io, finish_status);
			transaction->processing_status = finish_status;
		}
		/* Retain valid names with the images until the consumer confirms
		 * successful application through cdk2_capsule_disk_complete(). */
		for (index = 0U; index < selected_count; index++) {
			if (selected[index].valid)
				continue;
			if (selected[index].owned_name != NULL) {
				ops->free(selected[index].owned_name, ops->context);
				selected[index].owned_name = NULL;
			}
		}
		transaction->images = capsules->images;
		transaction->capsule_count = capsules->count;
		result->transaction = transaction;
		transaction = NULL;
	} else {
		free_loaded(ops, selected, selected_count, FALSE);
	}
	result->scan_status = prefer_failure(selected_io, scan_status);
	status = prefer_failure(result->scan_status,
		result->processing_attempted ? result->processing_status : EFI_SUCCESS);
	report(ops, CDK2_CAPSULE_DISK_COMPLETE, selected_source, MAX_UINTN,
		result->loaded, status);
	return status;
}

EFI_STATUS cdk2_capsule_disk_complete(const struct cdk2_capsule_disk_ops *ops,
	struct cdk2_capsule_list *capsules,
	struct cdk2_capsule_disk_result *result)
{
	struct capsule_disk_transaction *transaction;
	struct loaded_file *files;
	EFI_STATUS first_error = EFI_SUCCESS;
	BOOLEAN reset_required = FALSE;
	UINTN index;

	if (result != NULL)
		result->completion_status = EFI_INVALID_PARAMETER;
	if (ops == NULL || capsules == NULL || result == NULL ||
		ops->remove == NULL || ops->free == NULL || ops->source_identity == NULL ||
		result->transaction == NULL)
		return EFI_INVALID_PARAMETER;
	transaction = result->transaction;
	if (transaction->magic != CDK2_CAPSULE_DISK_TRANSACTION_MAGIC ||
		transaction->owner != result || transaction->capsules != capsules ||
		transaction->source_identity != ops->source_identity ||
		transaction->images != capsules->images ||
		transaction->capsule_count != capsules->count)
		return EFI_INVALID_PARAMETER;
	result->completion_status = EFI_SUCCESS;
	files = transaction->files;
	if (transaction->processing_status != EFI_SUCCESS) {
		EFI_STATUS processing_status = transaction->processing_status;

		discard_transaction(ops, transaction);
		result->transaction = NULL;
		result->reset_required = FALSE;
		return processing_status;
	}
	for (index = 0U; index < transaction->file_count; index++) {
		EFI_STATUS status;

		if (!files[index].valid)
			continue;
		status = ops->remove(transaction->source, files[index].file.name,
			files[index].data, (UINTN)files[index].file.size, ops->context);
		if (status != EFI_SUCCESS) {
			result->cleanup_failed = TRUE;
			result->cleanup_failures++;
			report(ops, CDK2_CAPSULE_DISK_DELETE_ERROR, transaction->source,
				files[index].index, 0U, status);
			if (first_error == EFI_SUCCESS ||
			    (!EFI_ERROR(first_error) && EFI_ERROR(status)))
				first_error = status;
			continue;
		}
		result->deleted++;
		if (files[index].reset_requested)
			reset_required = TRUE;
	}
	result->reset_required = reset_required && first_error == EFI_SUCCESS &&
		!result->cleanup_failed;
	result->completion_status = first_error;
	discard_transaction(ops, transaction);
	result->transaction = NULL;
	return first_error;
}

struct esp_file_info {
	UINT64 size, file_size, physical_size;
	UINT8 times[48];
	UINT64 attribute;
	CHAR16 name[];
};

#define ESP_MAX_FILES 32U
#define ESP_MAX_NAME 128U
struct esp_scan_context {
	struct cdk2_fat_file_protocol *root, *directory;
	struct {
		CHAR16 name[ESP_MAX_NAME];
		UINTN name_bytes;
		UINT64 size, attributes;
	} files[ESP_MAX_FILES];
	UINTN count;
	void *caller_context;
	cdk2_capsule_disk_validate_fn *validate;
	cdk2_capsule_disk_process_fn *process;
	UINTN max_nonpopulate_size, max_populate_size;
	cdk2_capsule_disk_alloc_fn allocate;
	cdk2_capsule_disk_free_fn release;
	cdk2_capsule_disk_report_fn report;
};

static EFI_STATUS esp_source(UINTN index, struct cdk2_capsule_disk_source *source,
	void *opaque)
{
	(void)opaque;
	if (index != 0U || source == NULL)
		return EFI_NOT_FOUND;
	*source = (struct cdk2_capsule_disk_source){ .id = 0U, .preferred = TRUE,
		.esp = TRUE };
	return EFI_SUCCESS;
}

static EFI_STATUS esp_file(UINTN source, UINTN index,
	struct cdk2_capsule_disk_file *file, void *opaque)
{
	struct esp_scan_context *context = opaque;

	if (source != 0U || context == NULL || file == NULL || index >= context->count)
		return EFI_NOT_FOUND;
	*file = (struct cdk2_capsule_disk_file){ .name = context->files[index].name,
		.name_bytes = context->files[index].name_bytes,
		.size = context->files[index].size,
		.attributes = context->files[index].attributes };
	return EFI_SUCCESS;
}

static EFI_STATUS esp_open(struct esp_scan_context *context, const CHAR16 *name,
	UINT64 mode, struct cdk2_fat_file_protocol **file)
{
	if (context == NULL || name == NULL || file == NULL ||
	    context->directory == NULL || context->directory->open == NULL)
		return EFI_INVALID_PARAMETER;
	return context->directory->open(context->directory, file,
		(CHAR16 *)name, mode, 0U);
}

static EFI_STATUS esp_read(UINTN source, UINTN index, void *buffer, UINTN size,
	void *opaque)
{
	struct esp_scan_context *context = opaque;
	struct cdk2_fat_file_protocol *file = NULL;
	UINTN read_size = size;
	EFI_STATUS status;

	if (source != 0U || context == NULL || index >= context->count ||
	    buffer == NULL)
		return EFI_INVALID_PARAMETER;
	status = esp_open(context, context->files[index].name, 1U, &file);
	if (!EFI_ERROR(status) && (file == NULL || file->read == NULL ||
	    file->close == NULL))
		status = EFI_COMPROMISED_DATA;
	if (!EFI_ERROR(status))
		status = file->read(file, &read_size, buffer);
	if (!EFI_ERROR(status) && read_size != size)
		status = EFI_DEVICE_ERROR;
	if (file != NULL && file->close != NULL) {
		EFI_STATUS close_status = file->close(file);

		if (!EFI_ERROR(status) && EFI_ERROR(close_status))
			status = close_status;
	}
	return status;
}

static EFI_STATUS esp_remove(UINTN source, const CHAR16 *name,
	const void *expected, UINTN size, void *opaque)
{
	struct esp_scan_context *context = opaque;
	struct cdk2_fat_file_protocol *file = NULL;
	UINT8 actual[512];
	EFI_STATUS status;
	UINTN offset = 0U;

	if (source != 0U || name == NULL || (expected == NULL && size != 0U))
		return EFI_INVALID_PARAMETER;
	status = esp_open(context, name, 3U, &file);
	if (EFI_ERROR(status))
		return status;
	if (file == NULL || file->delete == NULL || file->read == NULL) {
		if (file != NULL && file->close != NULL)
			(void)file->close(file);
		return EFI_UNSUPPORTED;
	}
	while (status == EFI_SUCCESS && offset < size) {
		UINTN requested = size - offset > sizeof(actual) ? sizeof(actual) :
			size - offset;
		UINTN read_size = requested;

		status = file->read(file, &read_size, actual);
		if (status == EFI_SUCCESS &&
		    (read_size == 0U || read_size > requested ||
		     memcmp(actual, (const UINT8 *)expected + offset, read_size) != 0))
			status = EFI_COMPROMISED_DATA;
		offset += status == EFI_SUCCESS ? read_size : 0U;
	}
	if (status == EFI_SUCCESS) {
		UINT8 extra;
		UINTN read_size = 1U;

		status = file->read(file, &read_size, &extra);
		if (status == EFI_SUCCESS && read_size != 0U)
			status = EFI_COMPROMISED_DATA;
	}
	if (status == EFI_SUCCESS)
		return file->delete(file);
	if (file->close != NULL)
		status = prefer_failure(status, file->close(file));
	return status;
}

static EFI_STATUS esp_remove_unread(UINTN source, const CHAR16 *name,
	UINT64 size, UINT64 attributes, void *opaque)
{
	static const EFI_GUID file_info_guid = { 0x09576e92, 0x6d3f, 0x11d2,
		{ 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
	struct esp_scan_context *context = opaque;
	struct cdk2_fat_file_protocol *file = NULL;
	UINT8 buffer[512];
	struct esp_file_info *info = (void *)buffer;
	UINTN info_size = sizeof(buffer);
	EFI_STATUS status;

	if (source != 0U || name == NULL)
		return EFI_INVALID_PARAMETER;
	status = esp_open(context, name, 3U, &file);
	if (status == EFI_SUCCESS && (file == NULL || file->delete == NULL ||
	    file->get_info == NULL || file->close == NULL))
		status = EFI_UNSUPPORTED;
	if (status == EFI_SUCCESS)
		status = file->get_info(file, (EFI_GUID *)&file_info_guid,
			&info_size, buffer);
	if (status == EFI_SUCCESS && (info_size < offsetof(struct esp_file_info, name) ||
	    info->file_size != size || info->attribute != attributes))
		status = EFI_COMPROMISED_DATA;
	if (status == EFI_SUCCESS)
		return file->delete(file);
	if (file != NULL && file->close != NULL)
		status = prefer_failure(status, file->close(file));
	return status;
}

static EFI_STATUS esp_validate(const void *image, UINTN size, void *opaque)
{
	struct esp_scan_context *context = opaque;

	return context->validate(image, size, context->caller_context);
}

static EFI_STATUS esp_process(const struct cdk2_capsule_image *images,
	UINTN count, void *opaque)
{
	struct esp_scan_context *context = opaque;

	return context->process(images, count, context->caller_context);
}

static void *esp_alloc(UINTN size, void *opaque)
{
	struct esp_scan_context *context = opaque;

	return context->allocate(size, context->caller_context);
}

static void esp_free(void *buffer, void *opaque)
{
	struct esp_scan_context *context = opaque;

	context->release(buffer, context->caller_context);
}

static void esp_report(enum cdk2_capsule_disk_event event, UINTN source,
	UINTN file, UINT64 value, EFI_STATUS status, void *opaque)
{
	struct esp_scan_context *context = opaque;

	if (context->report != NULL)
		context->report(event, source, file, value, status,
			context->caller_context);
}

static EFI_STATUS esp_finish(void *opaque)
{
	struct esp_scan_context *context = opaque;
	EFI_STATUS status = EFI_SUCCESS;

	if (context == NULL)
		return EFI_INVALID_PARAMETER;
	if (context->directory != NULL && context->directory->close != NULL)
		status = prefer_failure(status,
			context->directory->close(context->directory));
	context->directory = NULL;
	if (context->root != NULL && context->root->close != NULL)
		status = prefer_failure(status, context->root->close(context->root));
	context->root = NULL;
	return status;
}

EFI_STATUS cdk2_capsule_disk_scan_esp(
	struct cdk2_fat_simple_fs_protocol *filesystem,
	UINTN max_nonpopulate_size, UINTN max_populate_size,
	cdk2_capsule_disk_validate_fn *validate_fmp,
	cdk2_capsule_disk_process_fn *process_fmp,
	cdk2_capsule_disk_alloc_fn alloc, cdk2_capsule_disk_free_fn free,
	cdk2_capsule_disk_report_fn report_fn, void *caller_context,
	struct cdk2_capsule_list *capsules, struct cdk2_capsule_disk_result *result)
{
	struct esp_scan_context context = { .caller_context = caller_context,
		.validate = validate_fmp, .process = process_fmp,
		.max_nonpopulate_size = max_nonpopulate_size,
		.max_populate_size = max_populate_size,
		.allocate = alloc, .release = free, .report = report_fn };
	UINT8 info_buffer[4096];
	BOOLEAN scanned = FALSE;
	EFI_STATUS finish_status;
	EFI_STATUS status;

	if (filesystem == NULL || filesystem->open_volume == NULL ||
	    max_nonpopulate_size == 0U || max_populate_size == 0U ||
	    validate_fmp == NULL || process_fmp == NULL || alloc == NULL ||
	    free == NULL || capsules == NULL || result == NULL) {
		if (result != NULL)
			result->scan_status = EFI_INVALID_PARAMETER;
		return EFI_INVALID_PARAMETER;
	}
	*result = (struct cdk2_capsule_disk_result){ .source = MAX_UINTN };
	status = filesystem->open_volume(filesystem, &context.root);
	if (EFI_ERROR(status) || context.root == NULL || context.root->open == NULL ||
	    context.root->close == NULL) {
		result->scan_status = EFI_ERROR(status) ? status : EFI_COMPROMISED_DATA;
		return result->scan_status;
	}
	status = context.root->open(context.root, &context.directory,
		(CHAR16 *)CDK2_CAPSULE_FILE_DIRECTORY, 1U, 0U);
	if (status == EFI_NOT_FOUND)
		goto out;
	if (EFI_ERROR(status) || context.directory == NULL ||
	    context.directory->read == NULL || context.directory->close == NULL) {
		status = EFI_ERROR(status) ? status : EFI_COMPROMISED_DATA;
		goto out;
	}
	for (;;) {
		struct esp_file_info *info = (void *)info_buffer;
		UINTN bytes = sizeof(info_buffer), name_limit, name;

		status = context.directory->read(context.directory, &bytes, info_buffer);
		if (EFI_ERROR(status) || bytes == 0U)
			break;
		if (bytes < offsetof(struct esp_file_info, name) + sizeof(CHAR16) ||
		    info->size > bytes) {
			status = EFI_COMPROMISED_DATA;
			break;
		}
		name_limit = (bytes - offsetof(struct esp_file_info, name)) /
			sizeof(CHAR16);
		for (name = 0U; name < name_limit && info->name[name] != 0U; name++)
			;
		if (name == name_limit || name >= ESP_MAX_NAME) {
			status = EFI_COMPROMISED_DATA;
			break;
		}
		if ((info->attribute & CDK2_CAPSULE_FILE_DIRECTORY_ATTRIBUTE) != 0U)
			continue;
		if (context.count == ESP_MAX_FILES) {
			status = EFI_COMPROMISED_DATA;
			break;
		}
		for (UINTN character = 0U; character <= name; character++)
			context.files[context.count].name[character] = info->name[character];
		context.files[context.count].name_bytes =
			(name + 1U) * sizeof(CHAR16);
		context.files[context.count].size = info->file_size;
		context.files[context.count].attributes = info->attribute;
		context.count++;
	}
	if (!EFI_ERROR(status)) {
		const struct cdk2_capsule_disk_ops ops = { .source_count = 1U,
			.max_nonpopulate_size = context.max_nonpopulate_size,
			.max_populate_size = context.max_populate_size,
			.source = esp_source, .file = esp_file, .read = esp_read,
			.remove = esp_remove, .remove_unread = esp_remove_unread,
			.validate_fmp = esp_validate,
			.process_fmp = esp_process, .alloc = esp_alloc, .free = esp_free,
			.finish = esp_finish, .report = esp_report, .context = &context,
			.source_identity = filesystem };

		status = cdk2_capsule_disk_scan(&ops, capsules, result);
		scanned = TRUE;
	}
out:
	finish_status = esp_finish(&context);
	if (scanned)
		result->scan_status = prefer_failure(result->scan_status, finish_status);
	else
		result->scan_status = prefer_failure(status, finish_status);
	status = prefer_failure(status, finish_status);
	return status;
}

EFI_STATUS cdk2_capsule_disk_complete_esp(
	struct cdk2_fat_simple_fs_protocol *filesystem,
	cdk2_capsule_disk_alloc_fn alloc, cdk2_capsule_disk_free_fn free,
	cdk2_capsule_disk_report_fn report_fn, void *caller_context,
	struct cdk2_capsule_list *capsules,
	struct cdk2_capsule_disk_result *result)
{
	struct esp_scan_context context = { .caller_context = caller_context,
		.allocate = alloc, .release = free, .report = report_fn };
	struct cdk2_capsule_disk_ops ops = { .remove = esp_remove,
		.free = esp_free, .report = esp_report, .context = &context,
		.source_identity = filesystem };
	EFI_STATUS status;
	EFI_STATUS completion;
	EFI_STATUS backend_status = EFI_SUCCESS;
	BOOLEAN completion_started;
	struct capsule_disk_transaction *transaction;

	if (result != NULL)
		result->completion_status = EFI_INVALID_PARAMETER;
	if (filesystem == NULL || filesystem->open_volume == NULL || alloc == NULL ||
	    free == NULL || capsules == NULL || result == NULL ||
	    result->transaction == NULL)
		return EFI_INVALID_PARAMETER;
	transaction = result->transaction;
	if (transaction->magic != CDK2_CAPSULE_DISK_TRANSACTION_MAGIC ||
	    transaction->owner != result || transaction->capsules != capsules ||
	    transaction->source_identity != filesystem)
		return EFI_INVALID_PARAMETER;
	result->completion_status = EFI_SUCCESS;
	status = transaction->processing_status;
	completion_started = status == EFI_SUCCESS;
	if (status == EFI_SUCCESS) {
		status = filesystem->open_volume(filesystem, &context.root);
		backend_status = status;
	}
	if (status == EFI_SUCCESS && (context.root == NULL ||
	    context.root->open == NULL || context.root->close == NULL)) {
		status = EFI_COMPROMISED_DATA;
		backend_status = status;
	}
	if (status == EFI_SUCCESS)
		status = context.root->open(context.root, &context.directory,
			(CHAR16 *)CDK2_CAPSULE_FILE_DIRECTORY, 1U, 0U);
	if (completion_started && backend_status == EFI_SUCCESS)
		backend_status = status;
	if (status == EFI_SUCCESS && (context.directory == NULL ||
	    context.directory->open == NULL || context.directory->close == NULL)) {
		status = EFI_COMPROMISED_DATA;
		backend_status = status;
	}
	transaction->processing_status = prefer_failure(
		transaction->processing_status, status);
	completion = cdk2_capsule_disk_complete(&ops, capsules, result);
	status = prefer_failure(status, completion);
	if (context.directory != NULL && context.directory->close != NULL)
		backend_status = prefer_failure(backend_status,
			context.directory->close(context.directory));
	if (context.root != NULL && context.root->close != NULL)
		backend_status = prefer_failure(backend_status,
			context.root->close(context.root));
	result->completion_status = prefer_failure(result->completion_status,
		backend_status);
	status = prefer_failure(status, backend_status);
	if (status != EFI_SUCCESS)
		result->reset_required = FALSE;
	return status;
}
