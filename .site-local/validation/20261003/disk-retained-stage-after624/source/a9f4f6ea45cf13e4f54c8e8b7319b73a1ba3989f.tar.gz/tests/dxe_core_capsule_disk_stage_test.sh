#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
config=${1:?actual config header required}
compiler=${2:-cc}
flags=${3:--std=gnu11 -Wall -Wextra -Werror -fshort-wchar}
output=$(mktemp -d "${TMPDIR:-/tmp}/disk-capsule-stage-host.XXXXXX")
printf 'Retained staging HOST artifacts: %s\n' "$output"
mkdir -p "$output/cdk2"
cp "$config" "$output/cdk2/config.h"
export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
ulimit -c 0
core_source=$root/src/modules/dxe_core/entry.c
instrumentation='-fsanitize=address,undefined -fno-sanitize-recover=all --param asan-globals=0'

# Exact joined source closure. The generic Query has support=NULL, so this
# fixture does not claim Runtime FMP support parsing, CMS or MM verification.
sources="
$root/tests/dxe_core_capsule_disk_stage_test.c
$root/src/modules/dxe_core/database.c
$root/src/modules/dxe_core/image.c
$root/src/modules/dxe_core/memory.c
$root/src/modules/dxe_core/lifecycle.c
$root/src/modules/dxe_core/presence_lifecycle.c
$root/src/modules/capsule_runtime/capsule_runtime.c
$root/src/lib/linear_boot.c
$root/src/lib/capsule_disk.c
$root/src/lib/tcg_hash/software_hash.c
$root/src/lib/tcg_hash/vendor/vboot/2sha1.c
$root/src/lib/tcg_hash/vendor/vboot/2sha256.c
$root/src/lib/tcg_hash/vendor/vboot/2sha512.c
$root/src/lib/tcg_hash/vendor/linux/lib/crypto/sm3.c
$root/src/lib/diagnostic.c
$root/src/lib/deadline.c
"

compile()
{
	# HOST-only resident-image linker spans model publication. Its RWX segment
	# is not a firmware artifact or an audit exception. Keep heap/stack ASan;
	# globals-off prevents unrelated Core boot callback tables becoming GC roots.
	# shellcheck disable=SC2086
	"$compiler" $flags "$optimization" -g -ffunction-sections -fdata-sections \
		-fno-pie -no-pie $instrumentation -DCDK2_HOST_TEST \
		-DCDK2_STAGE_SOURCE=\""$core_source"\" \
		-DCDK2_STAGE_FIXTURE=\""$root/tests/dxe_core_capsule_disk_handoff_test.c"\" \
		-I"$output" -I"$root/include" -I"$root/src/modules/dxe_core" \
		-I"$root/src/lib/tcg_hash/vendor/vboot" \
		-I"$root/src/lib/tcg_hash/vendor/linux/include" \
		-Wl,--wrap=cdk2_capsule_disk_complete_esp \
		$sources "$@"
}

for optimization in -O0 -O2; do
	compile -M
done > "$output/dependencies.make"
awk '
 { gsub(/\\/, ""); for (i = 1; i <= NF; i++)
   if ($i !~ /:$/) print $i }
' "$output/dependencies.make" | sort -u > "$output/dependencies.list"
# Includes actual compiler transitive project/system headers, copied config,
# selected source and included handoff fixture, not merely the authored file.
xargs sha256sum < "$output/dependencies.list" > "$output/inputs-before.sha256"
sha256sum "$config" "$root/tests/dxe_core_capsule_disk_stage_test.sh" \
	"$root/tests/dxe_core_capsule_disk_stage_test.ld" \
	"$(command -v "$compiler")" "$(command -v ld)" \
	"$(command -v sh)" "$(command -v awk)" >> "$output/inputs-before.sha256"
for optimization in -O0 -O2; do
	compile -Wl,--gc-sections \
		-Wl,-T,"$root/tests/dxe_core_capsule_disk_stage_test.ld" \
		-o "$output/test"
	"$output/test"
done

if grep -qx '#define CONFIG_CDK2_COREBOOT_CAPSULE_PROFILE 1' "$config" &&
   grep -qx '#define CONFIG_CDK2_NATIVE_SYSTEM_FMP 1' "$config" &&
   grep -qx '#define CONFIG_PAYLOAD_DMA_HANDOFF 1' "$config"; then
	# Exactly three grouped guards, same O2 heap/stack SAN (globals-off) as positives.
	# Every generated TU must round-trip byte-exactly to the original.
	optimization=-O2
	for cause in latch storage control; do
		case "$cause" in
		latch)
			function_name=
			expected='!filesystem_retired' ;;
		storage)
			function_name=stage_storage_binding_current
			expected='stop_calls == 1 && timer_calls == 0' ;;
		control)
			function_name=stage_control_current
			expected='pci_calls == 0' ;;
		esac
		awk -v function_name="$function_name" '
		 function_name != "" && index($0, "static uint64_t " function_name "(") {
		   selected = 1
		 }
		 function_name == "" && $0 == "\tif (runtime.teardown_begun)" {
		   start = end = NR; matches++
		 }
		 selected && index($0, "\tif (expected != NULL && (") == 1 {
		   start = end = NR; selected = 0; matches++
		 }
		 END { if (matches != 1 || end < start) exit 1; print start, end }
		' "$root/src/modules/dxe_core/entry.c" > "$output/$cause.bounds"
		read -r first last < "$output/$cause.bounds"
		awk -v first="$first" -v cause="$cause" '
		 NR == first {
		   print cause == "latch" ? "\tif (FALSE)" : "\tif (FALSE && " substr($0, 6)
		   next
		 }
		 { print }
		' "$root/src/modules/dxe_core/entry.c" > "$output/$cause.c"
		awk -v first="$first" -v last="$last" -v cause="$cause" '
		 FNR == NR { if (FNR >= first && FNR <= last) original[FNR] = $0; next }
		 FNR >= first && FNR <= last {
		   if (cause == "latch") expected = "\tif (FALSE)"
		   else expected = "\tif (FALSE && " substr(original[FNR], 6)
		   if ($0 != expected) exit 1
		   print original[FNR]; next
		 }
		 { print }
		' "$root/src/modules/dxe_core/entry.c" "$output/$cause.c" \
			> "$output/$cause.inverse.c"
		cmp "$root/src/modules/dxe_core/entry.c" "$output/$cause.inverse.c"
		core_source=$output/$cause.c
		compile -Wl,--gc-sections \
			-Wl,-T,"$root/tests/dxe_core_capsule_disk_stage_test.ld" \
			-o "$output/mutant"
		status=0
		"$output/mutant" "$cause" > "$output/$cause.log" 2>&1 || status=$?
		test "$status" -eq 134
		grep -F "$expected" "$output/$cause.log" >/dev/null
		if grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' \
		   "$output/$cause.log"; then
			exit 1
		fi
		printf 'Exact %s SAN guard discard: assertion134/full inverse/no sanitizer diagnostic PASS\n' "$cause"
	done
fi
sha256sum -c "$output/inputs-before.sha256"
