#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
config_source=${1:-$root/build/cdk2/include/cdk2/config.h}
compiler=${2:-cc}
flags=${3:--std=c11 -O2 -Wall -Wextra -Werror -fshort-wchar}
temporary=$(mktemp -d "${TMPDIR:-/tmp}/cdk2-capsule-handoff.XXXXXX")
trap 'rm -rf "$temporary"' EXIT HUP INT TERM

config="$temporary/config.h"
sed 's/^#define CONFIG_CDK2_LINEAR_BOOT 0$/#define CONFIG_CDK2_LINEAR_BOOT 1/' \
	"$config_source" > "$config"
mkdir -p "$temporary/cdk2"
cp "$config" "$temporary/cdk2/config.h"

export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1

compile_test()
{
# shellcheck disable=SC2086
"$compiler" $flags -ffunction-sections -fdata-sections -fsanitize=address,undefined \
	-fno-sanitize-recover=all \
	-DCDK2_DXE_CAPSULE_DISK_SOURCE="\"$1\"" \
	-no-pie -I"$temporary" -I"$root/build/cdk2/include" -I"$root/include" \
	-I"$root/src/lib/tcg_hash/vendor/vboot" \
	-I"$root/src/lib/tcg_hash/vendor/linux/include" \
	-I"$root/src/modules/dxe_core" -DCDK2_HOST_TEST \
	-o "$2" "$root/tests/dxe_core_capsule_disk_handoff_test.c" \
	"$root/src/modules/dxe_core/database.c" \
	"$root/src/modules/dxe_core/image.c" "$root/src/modules/dxe_core/memory.c" \
	"$root/src/modules/capsule_runtime/capsule_runtime.c" \
	"$root/src/lib/tcg_hash/software_hash.c" \
	"$root/src/lib/tcg_hash/vendor/vboot/2sha1.c" \
	"$root/src/lib/tcg_hash/vendor/vboot/2sha256.c" \
	"$root/src/lib/tcg_hash/vendor/vboot/2sha512.c" \
	"$root/src/lib/tcg_hash/vendor/linux/lib/crypto/sm3.c" \
	"$root/src/modules/dxe_core/lifecycle.c" "$root/src/lib/linear_boot.c" \
	"$root/src/modules/dxe_core/presence_lifecycle.c" \
	"$root/src/lib/capsule_disk.c" "$root/src/lib/diagnostic.c" \
	"$root/src/lib/deadline.c" -Wl,--gc-sections
}

compile_test "$root/src/modules/dxe_core/entry.c" "$temporary/test"
"$temporary/test"

awk '
	/if \(!\(runtime.processor->delivery_policy.allowed_transports & CB_CAPSULE_DELIVERY_DISK\)\)/ {
		matches++; print "\tif (FALSE)"; next
	}
	{ print }
	END { if (matches != 1) exit 1 }
' "$root/src/modules/dxe_core/entry.c" > "$temporary/missing-disk-guard.c"
compile_test "$temporary/missing-disk-guard.c" "$temporary/mutant"
set +e
"$temporary/mutant" > "$temporary/mutant.log" 2>&1
status=$?
set -e
test "$status" -eq 1
grep -q 'FAIL: disabled disk policy has no filesystem side effects' "$temporary/mutant.log"
if grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' "$temporary/mutant.log"; then
	exit 1
fi
echo 'DXE disk-delivery guard exact-source mutation: PASS'

for mutation in disk-support support-attributes; do
	case "$mutation" in
	disk-support) needle='if (delivery.allowed_transports & CB_CAPSULE_DELIVERY_DISK)'; replacement='if (TRUE)'; expected='owned disk capability alone controls bit4' ;;
	support-attributes) needle=' || attributes != 6U'; replacement=''; expected='wrong support attributes refuse publication' ;;
	esac
	awk -v needle="$needle" -v replacement="$replacement" '
		index($0, needle) {
			matches++;
			position = index($0, needle);
			$0 = substr($0, 1, position - 1) replacement substr($0, position + length(needle));
		}
		{ print }
		END { if (matches != 1) exit 1 }
	' "$root/src/modules/dxe_core/entry.c" > "$temporary/$mutation.c"
	compile_test "$temporary/$mutation.c" "$temporary/mutant"
	status=0
	"$temporary/mutant" > "$temporary/mutant.log" 2>&1 || status=$?
	test "$status" -eq 1
	grep -F "FAIL: $expected" "$temporary/mutant.log" >/dev/null
	if grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' "$temporary/mutant.log"; then
		exit 1
	fi
	echo "DXE $mutation exact-source mutation: PASS"
done

# Same normally selected header and tool; no forced RAM delivery or writer grant.
sh "$root/tests/dxe_core_capsule_disk_stage_test.sh" "$config" "$compiler" "$flags"

for mutation in request-bit request-attributes request-consume; do
	case "$mutation" in
	request-bit)
		needle='return (*indications & 4ULL) != 0U ? EFI_SUCCESS : EFI_NOT_FOUND;'
		replacement='return EFI_SUCCESS;'
		expected='unrequested or malformed disk request has no filesystem or writer side effects' ;;
	request-attributes)
		needle='if (size != sizeof(*indications) || attributes != 7U)'
		replacement='if (size != sizeof(*indications))'
		expected='actual disk request missing or malformed disposition' ;;
	request-consume)
		needle='indications &= ~4ULL;'
		replacement='indications |= 4ULL;'
		expected='loaded disk request consumes only bit4 through real variable callback' ;;
	esac
	original_line=$(awk -v needle="$needle" '
		index($0, needle) { matches++; selected = NR }
		END { if (matches != 1) exit 1; print selected }
	' "$root/src/modules/dxe_core/entry.c")
	awk -v needle="$needle" -v replacement="$replacement" '
		index($0, needle) {
			matches++;
			position = index($0, needle);
			$0 = substr($0, 1, position - 1) replacement substr($0, position + length(needle));
		}
		{ print }
		END { if (matches != 1) exit 1 }
	' "$root/src/modules/dxe_core/entry.c" > "$temporary/$mutation.c"
	awk -v selected="$original_line" -v needle="$replacement" -v replacement="$needle" '
		NR == selected {
			matches++;
			position = index($0, needle);
			if (position == 0) exit 1;
			$0 = substr($0, 1, position - 1) replacement substr($0, position + length(needle));
		}
		{ print }
		END { if (matches != 1) exit 1 }
	' "$temporary/$mutation.c" > "$temporary/$mutation-reversed.c"
	cmp "$root/src/modules/dxe_core/entry.c" "$temporary/$mutation-reversed.c"
	compile_test "$temporary/$mutation.c" "$temporary/mutant"
	status=0
	"$temporary/mutant" > "$temporary/mutant.log" 2>&1 || status=$?
	test "$status" -eq 1
	grep -F "FAIL: $expected" "$temporary/mutant.log" >/dev/null
	if grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' "$temporary/mutant.log"; then
		exit 1
	fi
	echo "DXE $mutation exact-source mutation: PASS"
done
