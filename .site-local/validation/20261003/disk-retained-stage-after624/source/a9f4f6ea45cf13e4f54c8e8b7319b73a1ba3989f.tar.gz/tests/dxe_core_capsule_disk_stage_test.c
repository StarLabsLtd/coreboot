/* SPDX-License-Identifier: GPL-2.0-only */
/* Actual Core/allocator/registry/transaction/hash/Query; modeled resident
 * publications and controller responses. No CMS/MM/native drain proof. */
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define main legacy_disk_fixture_main
#define CDK2_DXE_CAPSULE_DISK_SOURCE CDK2_STAGE_SOURCE
#include CDK2_STAGE_FIXTURE
#undef main

static bool filesystem_retired;

extern EFI_STATUS __real_cdk2_capsule_disk_complete_esp(
	struct cdk2_fat_simple_fs_protocol *, cdk2_capsule_disk_alloc_fn,
	cdk2_capsule_disk_free_fn, cdk2_capsule_disk_report_fn, void *,
	struct cdk2_capsule_list *, struct cdk2_capsule_disk_result *);

EFI_STATUS __wrap_cdk2_capsule_disk_complete_esp(
	struct cdk2_fat_simple_fs_protocol *filesystem, cdk2_capsule_disk_alloc_fn allocate,
	cdk2_capsule_disk_free_fn release, cdk2_capsule_disk_report_fn report, void *context,
	struct cdk2_capsule_list *capsules, struct cdk2_capsule_disk_result *result)
{
	/* Real FAT Stop releases its unpublished simple_fs; complete_esp inspects
	 * open_volume before the failed processing status. This HOST boundary spy
	 * models retirement without treating a sanitizer UAF as a passing cause. */
	assert(!filesystem_retired);
	return __real_cdk2_capsule_disk_complete_esp(filesystem, allocate, release,
		report, context, capsules, result);
}

#if CONFIG_CDK2_COREBOOT_CAPSULE_PROFILE && CONFIG_CDK2_NATIVE_SYSTEM_FMP && \
	CONFIG_PAYLOAD_DMA_HANDOFF

#define MODEL_CODE __attribute__((section(".stage_runtime_code"), noinline))
#define MODEL_DATA __attribute__((section(".stage_runtime_data")))
#define PCI_CODE __attribute__((section(".stage_pci_code"), noinline))
#define PCI_DATA __attribute__((section(".stage_pci_data")))
#define XHCI_CODE __attribute__((section(".stage_xhci_code"), noinline))
#define XHCI_DATA __attribute__((section(".stage_xhci_data")))
extern char stage_runtime_begin[], stage_runtime_end[], stage_pci_begin[], stage_pci_end[];
extern char stage_xhci_begin[], stage_xhci_end[];

static struct cdk2_capsule_boot_protocol model_processor MODEL_DATA;
static struct driver_binding_view model_bindings[4] MODEL_DATA;
static struct driver_binding_view model_pci_binding PCI_DATA;
static struct cdk2_local_apic_timer_control model_timer PCI_DATA;
static struct cdk2_pci_dma_control model_pci PCI_DATA;
static struct driver_binding_view model_xhci_binding XHCI_DATA;
static struct cdk2_xhci_control *model_xhci;
static unsigned query_calls, stop_calls, timer_calls, pci_calls, xhci_calls, update_calls, frees;
static uint64_t retained;
static size_t retained_pages;
static unsigned fault;
static bool retire_filesystem_on_stop;
static struct {
	struct cdk2_capsule_header header;
	unsigned char payload[4];
} stage_input;
static __typeof__(*core.runtime_storage) model_storage;
static struct cdk2_dxe_runtime_services model_services;
static struct dxe_services_context model_context;
static struct cdk2_capsule_disk_result model_result;
static struct capsule_scan_runtime model_scan;
static struct cdk2_capsule_image model_candidate;
static unsigned char source_image[] = { 1, 2, 3, 4 };
static unsigned char controller_path[] = { 1, 1, 4, 0, 0x7f, 0xff, 4, 0 };
static unsigned char namespace_path[] = { 1, 1, 4, 0, 1, 2, 4, 0, 0x7f, 0xff, 4, 0 };
static void *scanner_allocations[64];

static EFI_STATUS CDK2_MS_ABI scanner_allocate(UINT32 type, UINTN size, void **buffer)
{
	EFI_STATUS status = test_allocate_pool(type, size, buffer);
	if (status != EFI_SUCCESS)
		return status;
	for (size_t index = 0; index < ARRAY_SIZE(scanner_allocations); index++) {
		if (scanner_allocations[index] != NULL)
			continue;
		scanner_allocations[index] = *buffer;
		return status;
	}
	abort();
}

static EFI_STATUS CDK2_MS_ABI scanner_free(void *buffer)
{
	for (size_t index = 0; index < ARRAY_SIZE(scanner_allocations); index++) {
		if (scanner_allocations[index] != buffer)
			continue;
		scanner_allocations[index] = NULL;
		return test_free_pool(buffer);
	}
	abort();
}

static EFI_STATUS CDK2_MS_ABI absent_get(CHAR16 *name, EFI_GUID *guid,
	UINT32 *attributes, UINTN *size, void *data)
{
	(void)name; (void)guid; (void)attributes; (void)size; (void)data;
	if (fault == 26 || (fault == 27 && query_calls)) {
		UINT64 value = 4096;
		*size = sizeof(value);
		*attributes = 7;
		memcpy(data, &value, sizeof(value));
		return EFI_SUCCESS;
	}
	return EFI_NOT_FOUND;
}

static EFI_STATUS CDK2_MS_ABI absent_next(UINTN *size, CHAR16 *name, EFI_GUID *guid)
{
	(void)size; (void)name; (void)guid;
	if ((fault == 26 || (fault == 27 && query_calls)) && !name[0]) {
		memcpy(name, L"CapsuleUpdateData", sizeof(L"CapsuleUpdateData"));
		*size = sizeof(L"CapsuleUpdateData");
		*guid = capsule_variable_guid;
		return EFI_SUCCESS;
	}
	return EFI_NOT_FOUND;
}

static EFI_STATUS CDK2_MS_ABI pages_allocate(UINTN type, UINT32 memory_type,
	UINTN pages, UINT64 *address)
{
	EFI_STATUS status = cdk2_dxe_allocate_pages_policy(&core.memory,
		memory_type, pages, type, address);
	if (status == EFI_SUCCESS) {
		retained = *address;
		retained_pages = pages;
		if (fault == 1)
			(*address)++;
	}
	return status;
}

static EFI_STATUS CDK2_MS_ABI pages_free(UINT64 address, UINTN pages)
{
	frees++;
	assert(address == retained && pages == retained_pages);
	return cdk2_dxe_free_pages(&core.memory, (void *)(uintptr_t)address, pages);
}

static EFI_STATUS MODEL_CODE CDK2_MS_ABI model_process(
	struct cdk2_capsule_boot_protocol *protocol, const void *capsule, UINTN size)
{
	(void)protocol; (void)capsule; (void)size;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS MODEL_CODE CDK2_MS_ABI model_validate(
	struct cdk2_capsule_boot_protocol *protocol, const void *image, UINTN size)
{
	const struct cdk2_capsule_header *array[] = { image };
	const struct cdk2_capsule_policy policy = {
		.max_nonpopulate = 4096, .max_populate = 4096,
		.in_ram = TRUE, .persist = TRUE,
	};
	UINT64 maximum;
	UINT32 reset;
	(void)protocol;
	if (size != sizeof(stage_input))
		return EFI_INVALID_PARAMETER;
	return cdk2_capsule_query(array, 1, &policy, NULL, NULL, &maximum, &reset);
}

static EFI_STATUS MODEL_CODE CDK2_MS_ABI model_scatter(
	struct cdk2_capsule_boot_protocol *protocol, UINT64 address)
{
	(void)protocol; (void)address;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS MODEL_CODE CDK2_MS_ABI model_query(
	const struct cdk2_capsule_header *const *capsules, UINTN count,
	UINT64 *maximum, UINT32 *reset)
{
	const struct cdk2_capsule_policy policy = {
		.max_nonpopulate = 4096, .max_populate = 4096,
		.in_ram = TRUE, .persist = TRUE,
	};
	EFI_STATUS status = cdk2_capsule_query(capsules, count, &policy,
		NULL, NULL, maximum, reset);
	query_calls++;
	if (fault == 2)
		return EFI_DEVICE_ERROR;
	if (fault == 3)
		*maximum = 1;
	if (fault == 4)
		*reset = 0;
	if (fault == 5)
		core.database.protocol_count = CDK2_DXE_MAX_PROTOCOLS + 1;
	if (fault == 6)
		core.database.open_count = ARRAY_SIZE(core.database.opens) + 1;
	if (fault == 7)
		core.images.count = CDK2_DXE_MAX_IMAGES + 1;
	if (fault == 8)
		((unsigned char *)(uintptr_t)retained)[sizeof(stage_input) - 1]++;
	if (fault == 24)
		core.database.protocols[0].registration++;
	if (fault == 25)
		core.images.images[0].transaction->state = CDK2_DXE_IMAGE_PREPARED;
	if (fault == 28)
		model_services.update_capsule = NULL;
	return status;
}

static EFI_STATUS MODEL_CODE CDK2_MS_ABI model_update(
	const struct cdk2_capsule_header *const *capsules, UINTN count, UINT64 address)
{
	struct capsule_scatter_block *scatter = (void *)(uintptr_t)address;
	assert(count == 1 && capsules[0] == (void *)(uintptr_t)retained);
	assert(!memcmp(capsules[0], &stage_input, sizeof(stage_input)));
	assert(scatter[0].length == sizeof(stage_input) && scatter[0].address == retained);
	assert(!scatter[1].length && !scatter[1].address);
	assert(stop_calls == 4 && timer_calls == 1 && pci_calls == 1);
	assert(xhci_calls == (model_xhci != NULL));
	update_calls++;
	/* Even a returned SUCCESS cannot establish publication/reset. */
	return fault == 20 ? EFI_SUCCESS : EFI_DEVICE_ERROR;
}

static EFI_STATUS MODEL_CODE CDK2_MS_ABI binding_supported(
	struct driver_binding_view *binding, void *controller, void *path)
{
	(void)binding; (void)controller; (void)path;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS MODEL_CODE CDK2_MS_ABI binding_stop(
	struct driver_binding_view *binding, void *controller, UINTN count, void **children)
{
	(void)binding; (void)controller; (void)count; (void)children;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS PCI_CODE CDK2_MS_ABI pci_supported(
	struct driver_binding_view *binding, void *controller, void *path)
{
	(void)binding; (void)controller; (void)path;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS PCI_CODE CDK2_MS_ABI pci_stop(
	struct driver_binding_view *binding, void *controller, UINTN count, void **children)
{
	(void)binding; (void)controller; (void)count; (void)children;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS PCI_CODE CDK2_MS_ABI deactivate(
	struct cdk2_local_apic_timer_control *control)
{
	assert(control == &model_timer && core.events.current_tpl == 31);
	timer_calls++;
	if (fault == 15)
		return EFI_DEVICE_ERROR;
	if (fault == 16) {
		core.images.images[1].load_generation++;
		for (size_t index = 0; index < core.database.protocol_count; index++)
			if (core.database.protocols[index].owner_image == (void *)2)
				core.database.protocols[index].owner_generation++;
	}
	return EFI_SUCCESS;
}

static EFI_STATUS PCI_CODE CDK2_MS_ABI quiesce(struct cdk2_pci_dma_control *control)
{
	assert(control == &model_pci && core.events.current_tpl == 31);
	pci_calls++;
	if (fault == 17)
		return EFI_DEVICE_ERROR;
	if (fault == 18)
		((unsigned char *)(uintptr_t)retained)[sizeof(stage_input) - 1]++;
	if (fault == 19)
		core.database.protocol_count = CDK2_DXE_MAX_PROTOCOLS + 1;
	return EFI_SUCCESS;
}

static EFI_STATUS XHCI_CODE CDK2_MS_ABI xhci_supported(
	struct driver_binding_view *binding, void *controller, void *path)
{
	(void)binding; (void)controller; (void)path;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS XHCI_CODE CDK2_MS_ABI xhci_stop(
	struct driver_binding_view *binding, void *controller, UINTN count, void **children)
{
	(void)binding; (void)controller; (void)count; (void)children;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS XHCI_CODE CDK2_MS_ABI xhci_quiesce(
	struct cdk2_xhci_control *control, void *controller)
{
	assert(control == model_xhci && controller == (void *)30);
	assert(core.events.current_tpl == 31 && timer_calls == 1 && pci_calls == 0);
	xhci_calls++;
	if (fault == 21)
		return EFI_DEVICE_ERROR;
	if (fault == 22) {
		core.images.images[2].load_generation++;
		for (size_t index = 0; index < core.database.protocol_count; index++)
			if (core.database.protocols[index].owner_image == (void *)3)
				core.database.protocols[index].owner_generation++;
	}
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI disconnect_model(void *controller, void *image, void *child)
{
	void *expected[] = { (void *)10, (void *)11, (void *)11, (void *)12 };
	assert(stop_calls < 4 && controller == expected[stop_calls]);
	assert(image == (void *)1 && child == NULL);
	stop_calls++;
	if (stop_calls == 1 && retire_filesystem_on_stop) {
		assert(cdk2_dxe_uninstall(&core.database, selected_esp, &simple_fs_protocol,
			&active_fixture->filesystem) == EFI_SUCCESS);
		filesystem_retired = true;
	}
	if (fault == 9)
		return EFI_DEVICE_ERROR;
	if (fault == 10)
		model_bindings[1].stop = NULL;
	if (fault == 11) {
		core.images.images[0].load_generation++;
		for (size_t index = 0; index < core.database.protocol_count; index++)
			if (core.database.protocols[index].owner_image == (void *)1)
				core.database.protocols[index].owner_generation++;
	}
	if (fault == 12)
		core.images.images[0].exit_active = TRUE;
	if (fault == 13)
		core.database.open_count = ARRAY_SIZE(core.database.opens) + 1;
	if (fault == 14) {
		core.images.images[1].load_generation++;
		for (size_t index = 0; index < core.database.protocol_count; index++)
			if (core.database.protocols[index].owner_image == (void *)2)
				core.database.protocols[index].owner_generation++;
	}
	if (fault == 29) {
		struct capsule_scatter_block *scatter = (void *)(uintptr_t)
			(retained + ((sizeof(stage_input) + 7) & ~(size_t)7));
		scatter[0].length--;
	}
	return EFI_SUCCESS;
}

static void publish(void *handle, const EFI_GUID *guid, void *interface, unsigned owner)
{
	assert(cdk2_dxe_restore(&core.database, handle, guid, interface) == EFI_SUCCESS);
	struct cdk2_dxe_protocol *record = &core.database.protocols[core.database.protocol_count - 1];
	if (owner) {
		record->owner_image = (void *)(uintptr_t)owner;
		record->owner_generation = core.images.images[owner - 1].load_generation;
	}
}

static void initialize_stage(unsigned selected_fault)
{
	static const EFI_GUID boot_guid = { 0x2890d42b, 0x7f9b, 0x4a66,
		{ 0x9a, 0x12, 0x54, 0x8d, 0x6b, 0x57, 0xd8, 0x20 } };
	static const EFI_GUID timer_guid = CDK2_LOCAL_APIC_TIMER_CONTROL_GUID;
	static const EFI_GUID pci_guid = CDK2_PCI_DMA_CONTROL_GUID;
	static const EFI_GUID xhci_guid = CDK2_XHCI_CONTROL_GUID;
	static const EFI_GUID host_guid = { 0x3e745226, 0x9818, 0x45b6,
		{ 0xa2, 0xac, 0xd7, 0xcd, 0x0e, 0x8b, 0xa2, 0xbc } };
	void *storage = aligned_alloc(4096, 64 * 4096);
	assert(storage != NULL);
	memset(&core, 0, sizeof(core));
	assert(cdk2_dxe_memory_initialize(&core.memory, storage, 64) == EFI_SUCCESS);
	core.images.memory = &core.memory;
	core.images.count = 3;
	for (unsigned index = 0; index < 3; index++) {
		struct cdk2_dxe_image *image = &core.images.images[index];
		image->handle = (void *)(uintptr_t)(index + 1);
		image->base = index == 2 ? stage_xhci_begin :
			index ? stage_pci_begin : stage_runtime_begin;
		image->size = (uintptr_t)(index == 2 ? stage_xhci_end :
			index ? stage_pci_end : stage_runtime_end) -
			(uintptr_t)image->base;
		image->load_generation = 30 + index;
		image->started = image->exited = TRUE;
		image->protocol_pins = 8;
		assert(cdk2_dxe_image_transaction_prepare(&core.images, source_image,
			sizeof(source_image), NULL, 0, &image->transaction,
			&image->transaction_allocation_generation) == EFI_SUCCESS);
		/* Model resident publication, not an actual firmware loader proof. */
		image->transaction->state = CDK2_DXE_IMAGE_PUBLISHED;
	}
	assert(cdk2_dxe_database_initialize(&core.database) == EFI_SUCCESS);
	memset(&model_processor, 0, sizeof(model_processor));
	model_processor.validate_capsule = model_validate;
	model_processor.process_capsule = model_process;
	model_processor.process_scatter = model_scatter;
	model_processor.delivery_policy.allowed_transports =
		CB_CAPSULE_DELIVERY_RAM | CB_CAPSULE_DELIVERY_DISK;
	publish((void *)1, &boot_guid, &model_processor, 1);
	for (unsigned index = 0; index < 4; index++) {
		model_bindings[index] = (struct driver_binding_view) {
			.supported = binding_supported, .start = binding_supported,
			.stop = binding_stop, .image = (void *)1,
			.binding = (void *)(uintptr_t)(20 + index),
		};
		publish(model_bindings[index].binding, &driver_binding_protocol,
			&model_bindings[index], 1);
	}
	model_pci_binding = (struct driver_binding_view) {
		.supported = pci_supported, .start = pci_supported, .stop = pci_stop,
		.image = (void *)2, .binding = (void *)2,
	};
	publish((void *)2, &driver_binding_protocol, &model_pci_binding, 2);
	model_timer = (struct cdk2_local_apic_timer_control) {
		.revision = CDK2_LOCAL_APIC_TIMER_CONTROL_REVISION, .deactivate = deactivate,
	};
	model_pci = (struct cdk2_pci_dma_control) {
		.revision = CDK2_PCI_DMA_CONTROL_REVISION, .quiesce_all = quiesce,
	};
	publish((void *)2, &timer_guid, &model_timer, 2);
	publish((void *)2, &pci_guid, &model_pci, 2);
	model_xhci = NULL;
	if (selected_fault >= 21 && selected_fault <= 23) {
		UINTN span, generation;
		assert(cdk2_dxe_allocate_pool(&core.memory, 4, sizeof(*model_xhci),
			(void **)&model_xhci) == EFI_SUCCESS);
		*model_xhci = (struct cdk2_xhci_control) {
			.revision = CDK2_XHCI_CONTROL_REVISION, .controller = (void *)30,
			.poll_once = xhci_quiesce, .start_polling = xhci_quiesce,
			.stop_polling = xhci_quiesce, .quiesce = xhci_quiesce,
		};
		assert(cdk2_dxe_memory_readable_span(&core.memory, model_xhci,
			&span, &generation) == EFI_SUCCESS);
		publish((void *)30, &xhci_guid, model_xhci, 0);
		struct cdk2_dxe_protocol *record =
			&core.database.protocols[core.database.protocol_count - 1];
		record->interface_dynamic = TRUE;
		record->interface_size = sizeof(*model_xhci);
		record->interface_generation = generation;
		publish((void *)30, &host_guid, namespace_path, 0);
		model_xhci_binding = (struct driver_binding_view) {
			.supported = xhci_supported, .start = xhci_supported, .stop = xhci_stop,
			.image = (void *)3, .binding = (void *)3,
		};
		publish((void *)3, &driver_binding_protocol, &model_xhci_binding, 3);
	}
	publish((void *)12, &device_path_protocol, controller_path, 0);
	core.database.protocols[core.database.protocol_count - 1].interface_size = sizeof(controller_path);
	publish((void *)11, &device_path_protocol, namespace_path, 0);
	core.database.protocols[core.database.protocol_count - 1].interface_size = sizeof(namespace_path);
	publish((void *)11, &block_io_protocol, namespace_path, 0);
	core.database.opens[0] = (struct cdk2_dxe_open) {
		.handle = (void *)11, .guid = disk_io_protocol, .agent = (void *)21,
		.controller = (void *)10, .attributes = 0x08, .count = 1,
	};
	core.database.opens[1] = (struct cdk2_dxe_open) {
		.handle = (void *)12, .guid = pci_io_protocol, .agent = (void *)23,
		.controller = (void *)11, .attributes = 0x08, .count = 1,
	};
	core.database.open_count = 2;
	storage_bindings.fat = (struct dispatched_binding) { (void *)1, (void *)20 };
	storage_bindings.partition = (struct dispatched_binding) { (void *)1, (void *)21 };
	storage_bindings.disk = (struct dispatched_binding) { (void *)1, (void *)22 };
	storage_bindings.nvme = (struct dispatched_binding) { (void *)1, (void *)23 };
	selected_storage_backend = STORAGE_NVME;
	selected_storage_controller = (void *)12;
	selected_storage_binding = (void *)1;
	selected_storage_agent = (void *)23;
	selected_esp = (void *)10;
	memset(&model_storage, 0, sizeof(model_storage));
	memset(&model_services, 0, sizeof(model_services));
	model_storage.system_table.runtime_services = &model_services;
	model_services.get_variable = absent_get;
	model_services.get_next_variable_name = absent_next;
	model_services.query_capsule_capabilities = model_query;
	model_services.update_capsule = model_update;
	core.runtime_storage = &model_storage;
	core.boot_services.allocate_pages = pages_allocate;
	core.boot_services.free_pages = pages_free;
	core.boot_services.disconnect_controller = disconnect_model;
	memset(&model_context, 0, sizeof(model_context));
	model_context.capsule_runtime_owner = (void *)1;
	model_result = (struct cdk2_capsule_disk_result) { .candidates = 1, .loaded = 1 };
	model_scan = (struct capsule_scan_runtime) {
		.context = &model_context, .result = &model_result, .processor = &model_processor,
	};
	stage_input.header = (struct cdk2_capsule_header) {
		.guid = { 1, 2, 3, { 4, 5, 6, 7, 8, 9, 10, 11 } },
		.header_size = sizeof(stage_input.header), .image_size = sizeof(stage_input),
		.flags = CDK2_CAPSULE_PERSIST | CDK2_CAPSULE_RESET,
	};
	memcpy(stage_input.payload, "CDK2", sizeof(stage_input.payload));
	model_candidate = (struct cdk2_capsule_image) {
		.guid = stage_input.header.guid, .flags = stage_input.header.flags,
		.data = &stage_input, .size = sizeof(stage_input),
	};
	query_calls = stop_calls = timer_calls = pci_calls = xhci_calls = update_calls = frees = 0;
	retained = 0;
	retained_pages = 0;
	fault = selected_fault;
	filesystem_retired = retire_filesystem_on_stop = false;
}

static void release_stage(void)
{
	free(core.memory.base);
}

static void test_scanner_terminal(void)
{
	struct filesystem_fixture fixture = { 0 };
	struct test_capsule_delivery_hobs hobs;
	struct cdk2_linear_state state;

	initialize_stage(20);
	fixture.filesystem.open_volume = fixture_open_volume;
	fixture.root.open = fixture_open;
	fixture.root.close = fixture_close;
	fixture.directory.open = fixture_open;
	fixture.directory.close = fixture_close;
	fixture.directory.read = fixture_read;
	fixture.file.close = fixture_close;
	fixture.file.delete = fixture_delete;
	fixture.file.read = fixture_read;
	fixture.file.get_info = fixture_get_info;
	memcpy(&fixture.capsule, &stage_input, sizeof(stage_input));
	active_fixture = &fixture;
	publish(selected_esp, &simple_fs_protocol, &fixture.filesystem, 0);
	retire_filesystem_on_stop = true;
	core.boot_services.allocate_pool = scanner_allocate;
	core.boot_services.free_pool = scanner_free;
	model_services.get_variable = support_get;
	model_services.set_variable = support_set;
	request_bits = 4U | 1U;
	request_attributes = 7;
	request_size = sizeof(request_bits);
	request_get_status = request_set_status = EFI_SUCCESS;
	request_writes = process_calls = 0;
	test_capsule_delivery_hobs_init(&hobs,
		CB_CAPSULE_DELIVERY_RAM | CB_CAPSULE_DELIVERY_DISK, 1048576, 1048576);
	assert(cdk2_capsule_delivery_policy_from_hobs(&hobs,
		&model_processor.delivery_policy) == EFI_SUCCESS);
	model_context.handoff = &hobs.handoff;
	model_context.linear_state = &state;
	cdk2_linear_state_init(&state);
	state.next_phase = CDK2_LINEAR_CAPSULE_DECIDE;
	state.completed_mask = (1U << CDK2_LINEAR_CAPSULE_DECIDE) - 1U;
	assert(cdk2_linear_capsule_gate_early(&state, FALSE, TRUE,
		&model_context.capsule_outcome) == EFI_SUCCESS);
	state.next_phase = CDK2_LINEAR_CAPSULE_DISK;
	state.completed_mask = (1U << CDK2_LINEAR_CAPSULE_DISK) - 1U;
	assert(process_disk_capsules(&model_context) == EFI_DEVICE_ERROR);
	assert(update_calls == 1 && stop_calls == 4);
	assert(filesystem_retired);
	assert(fixture.open_volumes == 1 && fixture.deletes == 0);
	assert(request_writes == 1 && request_bits == 1);
	/* The HOST return is terminal: no source completion or request retry promise. */
	/* HOST fixture destruction only: the terminal firmware path deliberately
	 * leaves its scanner transaction resident until reset. No completion IO. */
	for (size_t index = 0; index < ARRAY_SIZE(scanner_allocations); index++) {
		free(scanner_allocations[index]);
		scanner_allocations[index] = NULL;
	}
	memset(&disk_capsules, 0, sizeof(disk_capsules));
	release_stage();
}

int main(int argc, char **argv)
{
	assert(argc == 1 || argc == 2);
	if (argc == 2 && !strcmp(argv[1], "latch")) {
		test_scanner_terminal();
		return 0;
	}
	if (argc == 2)
		assert(!strcmp(argv[1], "storage") || !strcmp(argv[1], "control"));
	for (unsigned scenario = 0; scenario <= 29; scenario++) {
		if (argc == 2 && scenario != (!strcmp(argv[1], "storage") ? 11U : 16U))
			continue;
		initialize_stage(scenario);
		uint64_t status = stage_disk_capsule(&model_scan, &model_candidate, 1);
		if (scenario == 11)
			assert(stop_calls == 1 && timer_calls == 0);
		if (scenario == 16)
			assert(pci_calls == 0);
		assert(EFI_ERROR(status));
		assert(core.events.current_tpl == 0);
		if (scenario == 0 || scenario == 20 || scenario == 23) {
			assert(status == EFI_DEVICE_ERROR && update_calls == 1);
			assert(model_scan.teardown_begun && !frees);
		} else {
			assert(update_calls == 0);
			if (scenario <= 8 || (scenario >= 24 && scenario <= 28))
				assert(stop_calls == 0 && !model_scan.teardown_begun);
			else
				assert(model_scan.teardown_begun);
		}
		if (scenario == 1)
			assert(!frees);
		if (scenario == 14)
			assert(timer_calls == 0);
		if (scenario == 21 || scenario == 22)
			assert(xhci_calls == 1 && pci_calls == 0);
		if (scenario == 9)
			assert(stop_calls == 1 && timer_calls == 0 && pci_calls == 0);
		if (scenario == 15)
			assert(timer_calls == 1 && pci_calls == 0);
		if (scenario == 26)
			assert(query_calls == 0);
		release_stage();
	}
	if (argc == 2)
		return 0;
	for (unsigned scenario = 0; scenario < 4; scenario++) {
		initialize_stage(0);
		if (scenario == 0) model_result.loaded = 0;
		if (scenario == 1) model_result.cleanup_failed = TRUE;
		if (scenario == 2) selected_storage_backend = STORAGE_AHCI;
		assert(stage_disk_capsule(&model_scan, &model_candidate,
			scenario == 3 ? 2 : 1) == EFI_UNSUPPORTED);
		assert(!query_calls && !stop_calls && !update_calls && !model_scan.teardown_begun);
		release_stage();
	}
	puts("DISK retained staging: actual Core lifetime/hash/allocator/Query with modeled controllers PASS");
	test_scanner_terminal();
	puts("Actual DISK scanner lifetime guard: no completion of retired FS; one open/zero delete PASS");
	return 0;
}
#else
int main(void)
{
	assert(stage_disk_capsule(NULL, NULL, 1) == EFI_UNSUPPORTED);
	puts("Nonselected retained staging: UNSUPPORTED without callbacks PASS");
	return 0;
}
#endif
