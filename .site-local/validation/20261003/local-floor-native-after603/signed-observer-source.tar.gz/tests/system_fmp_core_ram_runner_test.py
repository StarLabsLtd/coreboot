# SPDX-License-Identifier: GPL-2.0-only
"""HOST modeled runner epochs, not firmware or capsule authentication proof."""

import ast
import importlib.util
import json
import os
import struct
import subprocess
import tempfile
import unittest
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

runner_source = Path(os.environ.get("CDK2_CORE_RAM_RUNNER_SOURCE",
                                   Path(__file__).with_name("system_fmp_core_ram_native_test.py")))
spec = importlib.util.spec_from_file_location("runner", runner_source)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
from qmp_cbmem_console import checksum


def table(version, capsule):
    body = struct.pack("<II16sIII", 0x45, 36,
                       uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le,
                       version, 0x001A0009, 8388608)
    if capsule:
        body += struct.pack("<IIQI", 0x46, 20, 0x200000, 8388608)
    header = bytearray(struct.pack("<4sIIIII", b"LBIO", 24, 0, len(body),
                                  checksum(body), 2 if capsule else 1))
    struct.pack_into("<I", header, 8, checksum(header))
    return bytes(header) + body


class EpochTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directories = []
        self.bodies = {}
        self.normal = (b"CDK2 | CAPSULE_RAM | begin | NOT_STARTED\n"
                       b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n"
                       b"CDK2 | PCI_ROOTS | begin\n")
        for index in range(3):
            directory = Path(self.temporary.name) / str(index)
            directory.mkdir()
            self.directories.append(directory)
            (directory / "cbmem-observer.json").write_text(json.dumps({
                "tables": [{}], "physical_limit": 1024 * 1024 * 1024}))
            (directory / "cbmem-table-0.bin").write_bytes(table(
                0x001A000A if index == 2 else 0x001A0009, index == 1))
            self.bodies[directory] = self.normal if index != 1 else \
                b"CDK2 | CAPSULE_RAM | begin | NOT_STARTED\n"

    def check(self):
        with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get):
            runner.check_boots(self.directories, 8388608)

    def test_three_epochs(self):
        self.check()

    def test_restore_running_differs_from_attempt_history(self):
        for index, directory in enumerate(self.directories):
            (directory / "cbmem-table-0.bin").write_bytes(table(
                0x001A0009 if index == 2 else 0x001A000A, index == 1))
        with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get):
            runner.check_boots(self.directories, 8388608, 0x001A000A, 0x001A0009)
            with self.assertRaisesRegex(ValueError, "identity"):
                runner.check_boots(self.directories, 8388608, 0x001A000A, 0x001A000B)

    def test_unsigned_version_input(self):
        self.assertEqual(runner.version_number("0x001a000b"), 0x001A000B)
        for value in ("-1", "01", "4294967296", "0x100000000", "1;exit"):
            with self.assertRaises(runner.argparse.ArgumentTypeError):
                runner.version_number(value)

    def test_motion_only_before_reset_epoch_acceptance(self):
        error = runner.ConsoleSnapshotMotion("modeled eight moving headers")
        reader = SimpleNamespace(metadata=None)
        self.assertTrue(runner.unpublished_reset_console_motion(error, reader, object(), 100, 101))
        for prior, started, now in ((None, 100, 101), (object(), None, 101),
                                    (object(), 100, 111), (object(), 100, 99)):
            self.assertFalse(runner.unpublished_reset_console_motion(error, reader, prior, started, now))
        reader.metadata = {"tables": []}
        self.assertFalse(runner.unpublished_reset_console_motion(error, reader, object(), 100, 101))
        reader.metadata = None
        self.assertFalse(runner.unpublished_reset_console_motion(
            ValueError("malformed current table"), reader, object(), 100, 101))

    def test_actual_application_state_tuple(self):
        # Actual app helper, not modeled GetVariable/MM or native admission.
        root = Path(__file__).resolve().parents[1]
        source = Path(self.temporary.name) / "state.c"
        source.write_text('''#include <assert.h>
#include "system_fmp_core_ram_stage_app.c"
int main(void)
{
    struct cdk2_fmp_descriptor descriptor = {0};
    uint32_t state[5] = {0};
    descriptor.version = 0x001a0009U;
    descriptor.lowest_supported_version = 0x001a0009U;
    assert(state_matches(&descriptor, state, 0x001a0009U, 0U));
    state[0] = 1U;
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0U));
    state[0] = 0x01010101U;
    state[1] = state[4] = 0x001a000aU;
    state[2] = 0x001a0009U;
    descriptor.version = descriptor.last_attempt_version = 0x001a000aU;
    assert(state_matches(&descriptor, state, 0x001a000aU, 0x001a000aU));
    descriptor.version = 0x001a0009U;
    descriptor.last_attempt_version = state[1] = state[4] = 0x001a000bU;
    assert(state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
    assert(!state_matches(&descriptor, state, 0x001a000bU, 0x001a000bU));
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000aU));
    descriptor.lowest_supported_version++;
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
    descriptor.lowest_supported_version--;
    descriptor.last_attempt_status = 1U;
    assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
    descriptor.last_attempt_status = 0U;
    for (unsigned int index = 0; index < 5; index++) {
        uint32_t saved = state[index];
        state[index] ^= 1U;
        assert(!state_matches(&descriptor, state, 0x001a0009U, 0x001a000bU));
        state[index] = saved;
    }
    return 0;
}
''')
        for optimization in ("-O0", "-O2"):
            executable = source.with_name("state" + optimization)
            subprocess.run([os.environ.get("HOSTCC", "cc"), "-std=gnu11", "-Wall",
                            "-Wextra", "-Werror", optimization, "-ffunction-sections",
                            "-fdata-sections", "-Wl,--gc-sections", "-I" + str(root / "include"),
                            "-I" + str(root / "tests"), str(source), "-o", str(executable)],
                           check=True)
            subprocess.run([str(executable)], check=True)

    def test_uncaptured_previous_tail(self):
        # Previous capture ended before PCI; warm console retains that missing
        # old tail. It must not be misclassified as warm PCI execution.
        self.bodies[self.directories[0]] = self.normal
        self.bodies[self.directories[1]] = self.normal + \
            b"uncaptured previous boot tail\nCDK2 | CAPSULE_RAM | begin\n"
        self.bodies[self.directories[2]] = self.bodies[self.directories[1]] + self.normal
        self.check()

    def test_normal_completion_required(self):
        self.bodies[self.directories[0]] = self.normal.replace(
            b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n", b"")
        with self.assertRaisesRegex(ValueError, "RAM phase"):
            self.check()

    def test_warm_pci_refused(self):
        self.bodies[self.directories[1]] += b"CDK2 | PCI_ROOTS | begin\n"
        with self.assertRaisesRegex(ValueError, "entered PCI"):
            self.check()

    def test_wrong_installed_version(self):
        (self.directories[2] / "cbmem-table-0.bin").write_bytes(table(0x001A0009, False))
        with self.assertRaisesRegex(ValueError, "identity"):
            self.check()

    def test_missing_warm_handoff(self):
        (self.directories[1] / "cbmem-table-0.bin").write_bytes(table(0x001A0009, False))
        with self.assertRaisesRegex(ValueError, "handoff"):
            self.check()

    def test_exact_prior_chain_only_provisional_after_reset(self):
        previous = self.directories[0]
        old = (previous / "cbmem-table-0.bin").read_bytes()
        reader = SimpleNamespace(metadata={"tables": [{}]}, table_snapshots=[old])
        self.assertTrue(runner.previous_table_during_reset(reader, previous, 1))
        with self.assertRaisesRegex(ValueError, "never published"):
            runner.previous_table_during_reset(reader, previous, 11)
        reader.metadata = {"tables": [{"address": 4096}]}
        self.assertFalse(runner.previous_table_during_reset(reader, previous, 1))

    def test_same_metadata_changed_bytes_not_a_publication_retry(self):
        previous = self.directories[0]
        reader = SimpleNamespace(metadata={"tables": [{}]},
                                 table_snapshots=[b"corrupted accepted old table"])
        with self.assertRaisesRegex(ValueError, "disagrees"):
            runner.previous_table_during_reset(reader, previous, 1)

    def test_accepted_current_table_drift_remains_fatal(self):
        from qmp_cbmem_console_test import ConsoleTest
        # The production ConsoleReader's accepted-chain refusal remains active;
        # the runner's special case never globally catches/retries this error.
        fixture = ConsoleTest()
        fixture.setUp()
        fixture.test_valid_table_drift_after_acceptance()

    def test_qmp_cannot_request_guest_reset(self):
        qmp = runner.Qmp.__new__(runner.Qmp)
        with self.assertRaisesRegex(ValueError, "non-observer"):
            qmp({"execute": "system_reset"})

    def test_actual_elf32_container_vs_elf64_loaded_identity(self):
        payloads = []
        for bits in (32, 64):
            data = bytearray(256)
            data[:7] = b"\x7fELF" + bytes((1 if bits == 32 else 2, 1, 1))
            struct.pack_into("<H", data, 18, 3 if bits == 32 else 62)
            if bits == 32:
                struct.pack_into("<II", data, 24, 0x100000, 64)
                struct.pack_into("<HH", data, 42, 32, 1)
                struct.pack_into("<IIIIIIII", data, 64, 1, 128, 0x100000,
                                 0x100000, 4, 8, 7, 0)
            else:
                struct.pack_into("<QQ", data, 24, 0x100000, 64)
                struct.pack_into("<HH", data, 54, 56, 1)
                struct.pack_into("<IIQQQQQQ", data, 64, 1, 5, 128, 0x100000,
                                 0x100000, 4, 8, 4096)
            data[128:132] = b"real"
            path = Path(self.temporary.name) / f"core{bits}.elf"
            path.write_bytes(data)
            payloads.append(path)
        self.assertEqual(runner.loads(payloads[0]), runner.loads(payloads[1]))
        data[128] ^= 1
        payloads[1].write_bytes(data)
        self.assertNotEqual(runner.loads(payloads[0]), runner.loads(payloads[1]))
        for offset, format_string, value in ((4, "<B", 3), (5, "<B", 2),
                                             (18, "<H", 3), (32, "<Q", 255),
                                             (54, "<H", 32), (56, "<H", 0),
                                             (64, "<I", 0), (72, "<Q", 255),
                                             (104, "<Q", 3)):
            changed = bytearray(data)
            struct.pack_into(format_string, changed, offset, value)
            payloads[1].write_bytes(changed)
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                runner.loads(payloads[1])


class RefusalTest(unittest.TestCase):
    def setUp(self):
        EpochTest.setUp(self)
        self.refusal_boots = self.directories[:2]
        self.uart = b"".join(("CDK2_CORE_RAM_STAGE_" + marker + "\n").encode() for marker in (
            "MAIN_ENTRY", "SETUP1_SECURE0", "REAL_SYSTEM_FMP_INFO", "ACTUAL_INITIAL_ZERO_STATE",
            "QUERY_STRUCTURAL_ONLY", "UPDATE_CAPSULE_RESET"))
        self.events = [{"event": "RESET", "data": {"guest": True}}]
        self.failed = b"CDK2 | CAPSULE_RAM | begin\nCDK2 | CAPSULE_RAM | failed | "
        self.bodies[self.directories[1]] = self.failed + runner.REFUSAL_STATUS["wrong-signer"] + b" | 1 us\n"

    def refusal(self, case="wrong-signer"):
        with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get):
            runner.check_boots(self.refusal_boots, 8388608, refusal=case)

    def test_declared_status_positive(self):
        for case in runner.CASES:
            self.bodies[self.directories[1]] = self.failed + runner.REFUSAL_STATUS[case] + b" | 1 us\n"
            self.refusal(case)

    def test_refusal_exact_status(self):
        self.bodies[self.directories[1]] = self.failed + b"INVALID_PARAMETER (0x8000000000000002) | 1 us\n"
        with self.assertRaisesRegex(ValueError, "refusal status"):
            self.refusal()

    def test_refusal_failed_count(self):
        self.bodies[self.directories[1]] += self.bodies[self.directories[1]].split(b"\n", 1)[1]
        with self.assertRaisesRegex(ValueError, "refusal status"):
            self.refusal()

    def test_refusal_pci_refused(self):
        self.bodies[self.directories[1]] += b"CDK2 | PCI_ROOTS | begin\n"
        with self.assertRaisesRegex(ValueError, "entered PCI"):
            self.refusal()

    def test_refusal_completion_refused(self):
        self.bodies[self.directories[1]] += b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n"
        with self.assertRaisesRegex(ValueError, "unexpectedly completed"):
            self.refusal()

    def test_refusal_keeps_running_version(self):
        (self.directories[1] / "cbmem-table-0.bin").write_bytes(table(0x001A000A, True))
        with self.assertRaisesRegex(ValueError, "identity"):
            self.refusal()

    def test_refusal_needs_retained_capsule_handoff(self):
        (self.directories[1] / "cbmem-table-0.bin").write_bytes(table(0x001A0009, False))
        with self.assertRaisesRegex(ValueError, "handoff"):
            self.refusal()

    def test_refusal_previous_tail(self):
        self.bodies[self.directories[1]] = self.normal + b"old uncaptured tail\n" + self.bodies[self.directories[1]]
        self.refusal()

    def test_guest_reset_cardinality(self):
        runner.check_refusal_markers(self.uart, self.events)
        for events in ([], self.events * 2, [{"event": "RESET", "data": {"guest": False}}]):
            with self.assertRaisesRegex(ValueError, "guest warm reset"):
                runner.check_refusal_markers(self.uart, events)

    def test_refusal_main_markers(self):
        for line in self.uart.splitlines(keepends=True):
            for changed in (self.uart.replace(line, b""), self.uart + line):
                with self.assertRaisesRegex(ValueError, "cardinality"):
                    runner.check_refusal_markers(changed, self.events)
        for marker in (b"CDK2_CORE_RAM_STAGE_ACTUAL_PRIOR_SUCCESS_STATE",
                       b"CDK2_CORE_RAM_STAGE_FAIL",
                       b"CDK2_CORE_RAM_ACTUAL_NORMAL_CORE_COLD_RUNNING_AND_HISTORY_PASS"):
            with self.assertRaisesRegex(ValueError, "cold history"):
                runner.check_refusal_markers(self.uart + marker, self.events)

    def test_refusal_exact_firmware(self):
        initial = bytes(8388608)
        legitimate = bytes([1]) + initial[1:]
        runner.check_refusal_media(legitimate, initial, {"SMMSTORE": (0, 65536)})
        for offset in (65536, 73728):
            changed = bytearray(legitimate)
            changed[offset] ^= 1
            with self.assertRaisesRegex(ValueError, "outside the actual SMMSTORE"):
                runner.check_refusal_media(changed, initial, {"SMMSTORE": (0, 65536)})
        for region in ((1, 65536), (0, 73728)):
            with self.assertRaisesRegex(ValueError, "SMMSTORE"):
                runner.check_refusal_media(legitimate, initial, {"SMMSTORE": region})

    def test_refusal_truncated_media(self):
        for size in (32768, 73729, 8388607):
            shortened = bytes(size)
            with self.assertRaisesRegex(ValueError, "outside the actual SMMSTORE"):
                runner.check_refusal_media(shortened, shortened, {"SMMSTORE": (0, 65536)})


class CertifiedRefusalTest(unittest.TestCase):
    def setUp(self):
        EpochTest.setUp(self)
        self.bodies[self.directories[1]] = (
            b"CDK2 | CAPSULE_RAM | begin\n"
            b"CDK2 | module 0x02 | RAM capsule signature refused | 0x8000000000000007\n"
            b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n"
            b"CDK2 | PCI_ROOTS | begin\n")
        self.events = [{"event": "RESET", "data": {"guest": True}}]
        self.uart = b"\n".join(("CDK2_CORE_RAM_STAGE_" + marker).encode()
                                for marker in ("MAIN_ENTRY", "SETUP1_SECURE0",
                                               "REAL_SYSTEM_FMP_INFO") for _ in range(2))
        self.uart += b"\n" + b"\n".join(("CDK2_CORE_RAM_STAGE_" + marker).encode()
                                         for marker in ("ACTUAL_INITIAL_ZERO_STATE",
                                                        "QUERY_STRUCTURAL_ONLY", "UPDATE_CAPSULE_RESET"))
        self.uart += b"\nCDK2_CORE_RAM_CERTIFIED_REFUSAL_CONTINUED_MAIN_PASS\n"

    def certified(self, case="wrong-signer"):
        with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get):
            runner.check_boots(self.directories[:2], 8388608, refusal=case, certified=True)

    def test_certified_success(self):
        for case in ("wrong-signer", "signed-byte"):
            self.certified(case)
        runner.check_refusal_markers(self.uart, self.events, certified=True)

    def test_standard_report_marker(self):
        marker = b"\nCDK2_CORE_RAM_STANDARD_CAPSULE_REPORT_MAIN_PASS\n"
        runner.check_refusal_markers(self.uart + marker, self.events,
                                     certified=True, report=True)
        for changed in (self.uart, self.uart + marker * 2):
            with self.assertRaisesRegex(ValueError, "standard capsule report"):
                runner.check_refusal_markers(changed, self.events,
                                             certified=True, report=True)
        with self.assertRaisesRegex(ValueError, "standard capsule report"):
            runner.check_refusal_markers(self.uart + marker, self.events, certified=True)

    def test_certified_exact_classification(self):
        good = self.bodies[self.directories[1]]
        marker = b"CDK2 | module 0x02 | RAM capsule signature refused | 0x8000000000000007\n"
        for changed in (good.replace(marker, b""), good + marker,
                        good.replace(marker, marker.replace(b"0007", b"0003")),
                        good.replace(b"module 0x02", b"module 0x03")):
            self.bodies[self.directories[1]] = changed
            with self.assertRaises(ValueError):
                self.certified()
        self.bodies[self.directories[1]] = good
        with self.assertRaises(ValueError):
            self.certified("below-floor")

    def test_certified_needs_phase_completion_before_pci(self):
        good = self.bodies[self.directories[1]]
        for changed in (good.replace(b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n", b""),
                        good.replace(b"CDK2 | PCI_ROOTS | begin\n", b""),
                        good + b"CDK2 | CAPSULE_RAM | failed | DEVICE_ERROR\n"):
            self.bodies[self.directories[1]] = changed
            with self.assertRaises(ValueError):
                self.certified()

    def test_certified_guest_markers(self):
        for line in self.uart.splitlines(keepends=True):
            for changed in (self.uart.replace(line, b""), self.uart + line):
                with self.assertRaises(ValueError):
                    runner.check_refusal_markers(changed, self.events, certified=True)
        for changed in ([], self.events * 2, [{"event": "RESET", "data": {"guest": False}}]):
            with self.assertRaises(ValueError):
                runner.check_refusal_markers(self.uart, changed, certified=True)

    def test_actual_guest_exit_deadline_predicate(self):
        tree = ast.parse(runner_source.read_text())
        checks = [node for node in ast.walk(tree) if isinstance(node, ast.If) and
                  "process.poll() != 3" in ast.unparse(node.test)]
        self.assertEqual(len(checks), 1)
        code = compile(ast.fix_missing_locations(ast.Module(body=checks, type_ignores=[])),
                       str(runner_source), "exec")
        for status, now, accepted in ((3, 179, True), (3, 181, False),
                                      (None, 179, False), (2, 179, False)):
            scope = {"arguments": SimpleNamespace(expect_refusal=None), "deadline": 180,
                     "process": SimpleNamespace(poll=lambda: status, returncode=status),
                     "time": SimpleNamespace(monotonic=lambda: now)}
            if accepted:
                exec(code, scope)
            else:
                with self.assertRaises(ValueError):
                    exec(code, scope)

    def test_actual_certified_phase_failure_stops_without_timeout(self):
        tree = ast.parse(runner_source.read_text())
        checks = [node for node in ast.walk(tree) if isinstance(node, ast.If) and
                  any(isinstance(child, ast.Constant) and child.value ==
                      "certified RAM continuation reached a failed phase"
                      for child in ast.walk(node)) and
                  ast.unparse(node.test).startswith("certified and")]
        self.assertEqual(len(checks), 1)
        code = compile(ast.fix_missing_locations(ast.Module(body=checks, type_ignores=[])),
                       str(runner_source), "exec")
        failed = b"CDK2 | PLATFORM_TABLES | failed | COMPROMISED_DATA\n"
        for certified, epoch, body, rejected in (
                (True, 1, failed, True),
                (True, 1, b"CDK2 | CAPSULE_RAM | failed | DEVICE_ERROR\n", True),
                (False, 1, failed, False),
                (True, 0, failed, False),
                (True, 1, b"CDK2 | CAPSULE_RAM | complete | SUCCESS\n", False),
                (True, 1, b"not a phase: " + failed, False)):
            scope = {"certified": certified, "accepted_epoch": epoch,
                     "body": body, "re": runner.re}
            if rejected:
                with self.assertRaisesRegex(ValueError, "reached a failed phase"):
                    exec(code, scope)
            else:
                exec(code, scope)


class LocalFloorRefusalTest(unittest.TestCase):
    def setUp(self):
        CertifiedRefusalTest.setUp(self)
        self.bodies[self.directories[1]] = self.bodies[self.directories[1]].replace(
            b"RAM capsule signature refused | 0x8000000000000007",
            b"RAM capsule local floor refused | 0x8000000000000003")
        self.uart = self.uart.replace(b"CERTIFIED_REFUSAL_CONTINUED",
                                     b"LOCAL_FLOOR_REFUSAL_CONTINUED")

    def test_local_floor_success(self):
        with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get):
            runner.check_boots(self.directories[:2], 8388608,
                               refusal="below-floor", local_floor=True)
        runner.check_refusal_markers(self.uart, self.events, local_floor=True)
        runner.check_refusal_markers(self.uart + b"\nCDK2_CORE_RAM_STANDARD_CAPSULE_REPORT_MAIN_PASS\n",
                                     self.events, report=True, local_floor=True)

    def test_local_floor_exact_class(self):
        good = self.bodies[self.directories[1]]
        for changed in (good.replace(b"0003", b"0007"),
                        good.replace(b"local floor refused", b"signature refused"),
                        good + b"RAM capsule signature refused\n",
                        good.replace(b"complete | SUCCESS", b"failed | UNSUPPORTED")):
            self.bodies[self.directories[1]] = changed
            with patch.object(runner, "validate_saved_console", side_effect=self.bodies.get), \
                    self.assertRaises(ValueError):
                runner.check_boots(self.directories[:2], 8388608,
                                   refusal="below-floor", local_floor=True)
        self.bodies[self.directories[1]] = good
        for case, certified in (("wrong-signer", False), ("below-floor", True)):
            with self.assertRaises(ValueError):
                runner.check_boots(self.directories[:2], 8388608, refusal=case,
                                   certified=certified, local_floor=True)

    def test_local_floor_marker_cardinality(self):
        marker = b"CDK2_CORE_RAM_LOCAL_FLOOR_REFUSAL_CONTINUED_MAIN_PASS"
        for changed in (self.uart.replace(marker, b""), self.uart + marker,
                        self.uart + b"CDK2_CORE_RAM_CERTIFIED_REFUSAL_CONTINUED_MAIN_PASS"):
            with self.assertRaises(ValueError):
                runner.check_refusal_markers(changed, self.events, local_floor=True)
        with self.assertRaises(ValueError):
            runner.check_refusal_markers(self.uart, self.events, certified=True,
                                         local_floor=True)
        with self.assertRaises(ValueError):
            runner.check_refusal_markers(self.uart, self.events)


if __name__ == "__main__":
    unittest.main()
