/* SPDX-License-Identifier: BSD-2-Clause-Patent */
/* Real report encoder; variable, clock and policy services are HOST models. */
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include <cdk2/capsule_report.h>
#include <cdk2/pcat_rtc.h>
#include <pi/boot_mode.h>

static struct variable {
	CHAR16 name[12];
	uint8_t data[72];
	UINTN size;
	UINT32 attributes;
} variables[4];
static unsigned int writes, fail_write, locks;
static bool clock_fail, readback_bad, last_readback_bad, policy_fail;
static bool report_read_error;
static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;

static struct variable *find(CHAR16 *name)
{
	for (size_t i = 0; i < 4; i++)
		if (memcmp(name, variables[i].name, 22) == 0)
			return &variables[i];
	return NULL;
}

static EFI_STATUS CDK2_MS_ABI get(CHAR16 *name, EFI_GUID *guid,
	UINT32 *attributes, UINTN *size, void *data)
{
	struct variable *variable = find(name);

	assert(memcmp(guid, &report_guid, sizeof(*guid)) == 0);
	if (variable == NULL || variable->size == 0)
		return EFI_NOT_FOUND;
	if (report_read_error && variable->size == 72)
		return EFI_DEVICE_ERROR;
	if (*size < variable->size) {
		*size = variable->size;
		return EFI_BUFFER_TOO_SMALL;
	}
	assert(data != NULL);
	memcpy(data, variable->data, variable->size);
	*size = variable->size;
	if (attributes != NULL)
		*attributes = variable->attributes;
	if (readback_bad && variable->size == 72)
		((uint8_t *)data)[0] ^= 1;
	if (last_readback_bad && memcmp(name, L"CapsuleLast", 22) == 0)
		((uint8_t *)data)[0] ^= 1;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI set(CHAR16 *name, EFI_GUID *guid,
	UINT32 attributes, UINTN size, void *data)
{
	struct variable *variable = find(name);

	assert(memcmp(guid, &report_guid, sizeof(*guid)) == 0);
	if (++writes == fail_write)
		return EFI_DEVICE_ERROR;
	if (variable == NULL) {
		for (size_t i = 0; i < 4; i++)
			if (variables[i].name[0] == 0) {
				variable = &variables[i];
				memcpy(variable->name, name, 22);
				break;
			}
	}
	assert(variable != NULL && size <= sizeof(variable->data));
	variable->size = size;
	variable->attributes = attributes;
	if (size != 0)
		memcpy(variable->data, data, size);
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI time_get(CDK2_EFI_TIME *time,
	CDK2_TIME_CAPABILITIES *capabilities)
{
	assert(capabilities == NULL);
	memset(time, 0x5a, sizeof(*time));
	return clock_fail ? EFI_DEVICE_ERROR : EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI lock(const struct cdk2_variable_policy_entry *entry)
{
	assert(entry->version == 0x10000 && entry->offset_to_name == 44);
	assert(entry->lock_policy_type == 1 && entry->size <= 68);
	assert(memcmp(&entry->name_space, &report_guid, 16) == 0);
	locks++;
	return policy_fail ? EFI_ACCESS_DENIED : EFI_SUCCESS;
}

static struct cdk2_runtime_services_view runtime = {
	.get_variable = get, .set_variable = set, .get_time = time_get,
};
static struct cdk2_variable_policy_protocol policy = {
	.revision = 0x10000, .register_policy = lock,
};
static const EFI_GUID capsule = { .data1 = 1 }, image = { .data1 = 2 };

static void reset(uint32_t mode)
{
	memset(variables, 0, sizeof(variables));
	writes = fail_write = locks = 0;
	clock_fail = readback_bad = last_readback_bad = policy_fail = false;
	report_read_error = false;
	assert(cdk2_capsule_report_initialize(&runtime, &policy, mode) == EFI_SUCCESS);
	assert(locks == (mode == BOOT_ON_FLASH_UPDATE ? 1U : 2U));
}

int main(void)
{
	struct variable *report, *last;
	EFI_STATUS failure = EFI_DEVICE_ERROR;
	uint32_t total;

	reset(BOOT_ON_FLASH_UPDATE);
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 3, 7,
		failure) == EFI_SUCCESS);
	report = find(L"Capsule0000");
	last = find(L"CapsuleLast");
	assert(report != NULL && report->size == 72 && report->attributes == 7);
	memcpy(&total, report->data, 4);
	assert(total == 72 && memcmp(report->data + 8, &capsule, 16) == 0);
	assert(memcmp(report->data + 4, (uint8_t[4]) { 0 }, 4) == 0);
	for (size_t i = 24; i < 40; i++)
		assert(report->data[i] == 0x5a);
	assert(memcmp(report->data + 40, &failure, 8) == 0);
	assert(report->data[48] == 1 && report->data[49] == 0);
	assert(report->data[50] == 7 && report->data[51] == 3);
	assert(memcmp(report->data + 52, &image, 16) == 0);
	assert(memcmp(report->data + 68, "\0\0\0\0", 4) == 0);
	assert(last->size == 22 && last->attributes == 7);
	assert(memcmp(last->data, L"Capsule0000", 22) == 0);
	memcpy(last->data, L"Capsuleffff", 22);
	clock_fail = true;
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 255,
		failure) == EFI_SUCCESS);
	assert(memcmp(report->data + 24, (uint8_t[16]) { 0 }, 16) == 0);
	assert(report->data[50] == 255);
	assert(memcmp(last->data, L"Capsule0000", 22) == 0);
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 256,
		failure) == EFI_INVALID_PARAMETER);
	last->data[14] = 'z';
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 0,
		failure) == EFI_COMPROMISED_DATA);
	reset(BOOT_ON_FLASH_UPDATE);
	fail_write = writes + 1;
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 0,
		failure) == EFI_DEVICE_ERROR);
	assert(find(L"CapsuleLast")->size == 0);
	reset(BOOT_ON_FLASH_UPDATE);
	readback_bad = true;
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 0,
		failure) == EFI_COMPROMISED_DATA);
	assert(find(L"CapsuleLast")->size == 0);
	reset(BOOT_ON_FLASH_UPDATE);
	report_read_error = true;
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 0,
		failure) == EFI_DEVICE_ERROR);
	assert(find(L"CapsuleLast")->size == 0);
	reset(BOOT_ON_FLASH_UPDATE);
	fail_write = writes + 2;
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 0,
		failure) == EFI_DEVICE_ERROR);
	assert(find(L"Capsule0000")->size == 72 && find(L"CapsuleLast")->size == 0);
	reset(BOOT_ON_FLASH_UPDATE);
	last_readback_bad = true;
	assert(cdk2_capsule_report_fmp(&runtime, &capsule, &image, 1, 0,
		failure) == EFI_COMPROMISED_DATA);
	reset(BOOT_ON_FLASH_UPDATE);
	assert(set(L"CapsuleLast", (EFI_GUID *)&report_guid, 7, 22,
		(void *)L"Capsule0010") == EFI_SUCCESS);
	assert(cdk2_capsule_report_initialize(&runtime, &policy,
		BOOT_WITH_FULL_CONFIGURATION) == EFI_SUCCESS);
	assert(find(L"CapsuleLast")->size == 0); /* Dangling pointer is retired. */
	assert(set(L"CapsuleLast", (EFI_GUID *)&report_guid, 7, 22,
		(void *)L"Capsule00zz") == EFI_SUCCESS);
	assert(cdk2_capsule_report_initialize(&runtime, &policy,
		BOOT_WITH_FULL_CONFIGURATION) == EFI_COMPROMISED_DATA);
	assert(cdk2_capsule_report_initialize(&runtime, &policy,
		BOOT_ON_FLASH_UPDATE) == EFI_SUCCESS);
	assert(find(L"CapsuleLast")->size == 0);
	reset(BOOT_WITH_FULL_CONFIGURATION);
	policy_fail = true;
	assert(cdk2_capsule_report_initialize(&runtime, &policy,
		BOOT_WITH_FULL_CONFIGURATION) == EFI_ACCESS_DENIED);
	return 0;
}
