#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
: "${PROTECTED_ENTRY_CRYPTO_SOURCES:?use the named protected-variable-entry-test Make gate}"
: "${PROTECTED_ENTRY_CRYPTO_FLAGS:?use the named protected-variable-entry-test Make gate}"
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM
sha256sum "$root/src/lib/capsule_report.c" "$root/include/cdk2/capsule_report.h" \
	"$root/include/cdk2/capsule_runtime_abi.h" "$root/include/cdk2/esrt_abi.h" \
	"$root/include/cdk2/pcat_rtc.h" > "$temporary/report-inputs-before.sha256"
mkdir -p "$temporary/consumer-include/cdk2"
printf '%s\n' '#define CONFIG_CDK2_DIAGNOSTIC 0' \
	'#define CONFIG_CDK2_BUILD_DEBUG 0' \
	> "$temporary/consumer-include/cdk2/config.h"
for key in "$root"/src/modules/bds/keys/*.der "$root"/src/modules/bds/keys/*.bin; do
	(cd "$(dirname -- "$key")" && ${LD:-ld} -r -b binary -z noexecstack \
		"$(basename -- "$key")" -o "$temporary/key-$(basename -- "$key").o")
done
openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days 2 \
	-subj /CN=protected-entry -keyout "$temporary/key.pem" -out "$temporary/cert.pem" \
	> "$temporary/certificate.log" 2>&1
openssl x509 -in "$temporary/cert.pem" -outform DER -out "$temporary/cert.der"
perl - "$temporary" <<-'PERL'
use strict;
use warnings;
my ($directory) = @ARGV;
open my $certificate, '<:raw', "$directory/cert.der" or die $!;
local $/;
my $der = <$certificate>;
my $esl = pack('H*', 'a159c0a5e494a74a87b5ab155c2bf072') .
	pack('V3', 44 + length($der), 0, 16 + length($der)) . ("\0" x 16) . $der;
my @names = ('PK', 'db', 'dbx');
for my $index (0 .. 2) {
	my $time = pack('vC6VvCC', 2024, 1, 1, 0, 0, $index + 1, 0, 0, 0, 0, 0);
	my $name = join('', map { $_ . "\0" } split //, $names[$index]);
	my $guid = pack('H*', $index ? 'cbb219d73a3d9645a3bcdad00e67656f' :
		'61dfe48bca93d211aa0d00e098032b8c');
	for my $pair (["signed-$index.bin", $name . $guid . pack('V', 0x27) . $time . $esl],
		["time-$index.bin", $time], ["value-$index.bin", $esl]) {
		open my $output, '>:raw', "$directory/$pair->[0]" or die $!;
		print {$output} $pair->[1] or die $!;
	}
}
PERL
for index in 0 1 2; do
	openssl cms -sign -binary -in "$temporary/signed-$index.bin" \
		-signer "$temporary/cert.pem" -inkey "$temporary/key.pem" \
		-outform DER -out "$temporary/auth-$index.pk7"
	openssl cms -verify -binary -inform DER -in "$temporary/auth-$index.pk7" \
		-content "$temporary/signed-$index.bin" -CAfile "$temporary/cert.pem" \
		-out /dev/null
done
perl - "$temporary" <<-'PERL'
use strict;
use warnings;
my ($directory) = @ARGV;
for my $index (0 .. 2) {
	my @bytes;
	for my $name ("time-$index.bin", "auth-$index.pk7", "value-$index.bin") {
		open my $input, '<:raw', "$directory/$name" or die $!;
		local $/;
		push @bytes, <$input>;
	}
	my ($time, $signature, $value) = @bytes;
	open my $output, '>:raw', "$directory/update-$index.bin" or die $!;
	print {$output} $time, pack('Vvv', 24 + length($signature), 0x200, 0xef1),
		pack('H*', '9dd2af4adf68ee498aa9347d375665a7'), $signature, $value;
}
PERL

sh "$root/tests/protected_authvar_producer_build.sh" \
	"$root/tests/authvar_namespace_producer_join_test.c" "$temporary"
consumer_cc()
{
	${HOSTCC:-cc} -std=gnu11 -Wall -Wextra -Werror -O"$optimization" -g \
		"-DPROTECTED_VARIABLE_ENTRY_SOURCE=\"$entry_source\"" \
		-fshort-wchar -D_GNU_SOURCE -DCONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME=1 \
		-fsanitize=address,undefined -fno-sanitize-recover=all \
		-fno-omit-frame-pointer -ffunction-sections -fdata-sections \
		-I"$temporary/consumer-include" -I"$root/include" -I"$root/src/boot" \
		-I"$root/src/modules/dxe_core" $core_flags \
		$PROTECTED_ENTRY_CRYPTO_FLAGS "$@"
}

compile_consumer()
{
	optimization=$1
	consumer=$2
	entry_source=$3
	core_source=
	core_sources=
	core_flags=
	family=entry
	if test "${4:-}" = core; then
		family=core
		core_source=${5:-$root/src/modules/dxe_core/core.c}
		core_flags='-DPROTECTED_ENTRY_CORE_JOIN -DCDK2_HOST_TEST -fno-pie -no-pie'
		core_sources="$root/tests/protected_variable_entry_core_join_test.c $core_source
			$root/src/modules/dxe_core/presence_lifecycle.c
			$root/src/modules/dxe_core/database.c $root/src/modules/dxe_core/event.c
			$root/src/modules/dxe_core/memory.c $root/src/modules/dxe_core/image.c
			$root/src/modules/dxe_core/gcd.c $root/src/lib/direct_image_table.c
			$root/src/lib/diagnostic.c $root/src/boot/pe.c"
		core_flags="$core_flags -Wl,--wrap=cdk2_native_load_pe32_plus"
	fi
	# Objects live only in this run, separated by every differing flag family.
	# Numeric source positions preserve link order without basename collisions.
	objects="$temporary/consumer-objects-O$optimization-$family"
	mkdir -p "$objects"
	set -- $core_sources \
		$PROTECTED_ENTRY_CRYPTO_SOURCES \
		"$root/tests/protected_variable_entry_test.c" \
		"$root/src/lib/capsule_report.c" \
		"$root/src/modules/security_stub/security_stub.c" \
		"$root/src/modules/authvar_transport/image_policy.c" \
		"$root/src/modules/authvar_transport/namespace.c" \
		"$root/src/modules/authvar_transport/runtime.c" \
		"$root/src/modules/authvar_transport/transport.c" \
		"$root/src/modules/authvar_transport/native_x86.c" \
		"$root/src/modules/authvar_transport/owner.c" \
		"$root/src/modules/variable_runtime/model.c" \
		"$root/src/modules/variable_runtime/service.c" \
		"$root/src/modules/variable_runtime/diagnostic.c" \
		"$root/src/modules/bds/secure_boot.c" \
		"$temporary"/key-*.o \
		"$root/src/lib/payload_mm_authvar_service.c" \
		"$root/src/lib/image_policy_snapshot.c" \
		"$root/src/boot/coreboot.c" \
		"$root/src/boot/coreboot_checksum.c" \
		"$root/src/boot/coreboot_resource.c"
	link_objects=
	index=0
	for source_file do
		index=$((index + 1))
		case "$source_file" in
		*.o) object=$source_file ;;
		*)
			object="$objects/$index.o"
			if test "$source_file" = "$root/tests/protected_variable_entry_test.c" || \
			    test "$source_file" = "$core_source"; then
				# The fixture includes the actual entry or its compiled mutant.
				# The core source likewise must be rebuilt for each decision case.
				object="$consumer.$index.o"
				consumer_cc -c "$source_file" -o "$object"
			else
				# Fingerprint included headers and any consumed entry macro too.
				consumer_cc -E -P "$source_file" -o "$object.preprocessed"
				if test -f "$object"; then
					test "$(cat "$object.source")" = "$source_file"
					sha256sum --status -c "$object.sha256"
				else
					consumer_cc -c "$source_file" -o "$object"
					printf '%s\n' "$source_file" > "$object.source"
					sha256sum "$source_file" "$object.preprocessed" \
						> "$object.sha256"
				fi
			fi
			;;
		esac
		link_objects="$link_objects $object"
	done
	consumer_cc $link_objects -Wl,--gc-sections \
		-Wl,--wrap=cdk2_authvar_native_x86_trigger -o "$consumer"
}
awk '
/^static EFI_STATUS protected_trigger\(/ { inside = 1 }
inside && /return protected_call_current\(entry, owner, converted\)/ {
	print "\t(void)owner; (void)converted; return status;"
	changed++
	next
}
{ print }
inside && /^}/ { inside = 0 }
END { if (changed != 1) exit 1 }
' "$root/src/modules/variable_runtime/entry.c" > "$temporary/entry-no-trigger-check.c"
awk '
/if \(owner->client.scratch != pending_scratch \|\|/ {
	print "\t\t(void)pending_scratch; (void)pending_scratch_size;"
	print "\t\tif (false) {"
	changed++
	getline
	getline
	next
}
{ print }
END { if (changed != 1) exit 1 }
' "$root/src/modules/variable_runtime/entry.c" > "$temporary/entry-no-runtime-check.c"
perl -0pe '
	s/\tif \(!__atomic_compare_exchange_n\(&entry->namespace.busy, &expected, 1, false,\n\t    __ATOMIC_ACQUIRE, __ATOMIC_RELAXED\)\)\n\t\treturn EFI_NOT_READY;/\t(void)expected;/ == 1 or die "retirement namespace guard missing";
' "$root/src/modules/variable_runtime/entry.c" > "$temporary/entry-no-retire-busy.c"
perl -0pe '
	s/(unregister_policy\(\n\t\t\tcdk2_protected_image_policy_authorize, entry->image_policy\);\n)\t\tif \(EFI_ERROR\(status\)\)\n\t\t\tgoto release;/$1/ == 1 or die "retirement unregister error guard missing";
' "$root/src/modules/variable_runtime/entry.c" > "$temporary/entry-no-unregister-error.c"
perl -0pe '
	s/status = policy_router->authorize_policy\(transaction->source, transaction->source_size\);/\(void\)policy_router->authorize_policy(transaction->source, transaction->source_size); status = EFI_SUCCESS;/ == 1 or die "canonical policy decision missing";
' "$root/src/modules/dxe_core/core.c" > "$temporary/core-policy-result-discard.c"
for optimization in 0 2; do
	compile_consumer "$optimization" "$temporary/core-consumer-$optimization" \
		"$root/src/modules/variable_runtime/entry.c" core
	ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
		"$temporary/core-consumer-$optimization" "$temporary/producer-$optimization" \
		auth2-core "$temporary"
	compile_consumer "$optimization" "$temporary/core-mutant-$optimization" \
		"$root/src/modules/variable_runtime/entry.c" core \
		"$temporary/core-policy-result-discard.c"
	status=0
	(ulimit -c 0; ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
		"$temporary/core-mutant-$optimization" "$temporary/producer-$optimization" \
		auth2-core "$temporary") > "$temporary/core-mutant-$optimization.log" 2>&1 || status=$?
	test "$status" = 134
	grep -Fq 'status == EFI_SECURITY_VIOLATION && image == NULL && native_loads == before' \
		"$temporary/core-mutant-$optimization.log"
	if grep -Eq 'runtime error:|[[:alpha:]]*Sanitizer' "$temporary/core-mutant-$optimization.log"; then
		cat "$temporary/core-mutant-$optimization.log" >&2
		exit 1
	fi
	printf 'Actual core entry policy decision-discard causal mutation O%s: PASS\n' "$optimization"
	compile_consumer "$optimization" "$temporary/consumer-$optimization" \
		"$root/src/modules/variable_runtime/entry.c"
	for mode in normal capsule-report-normal capsule-report-flash \
		nonidentity endpoint-invalid general-absent router-absent install-fail \
		image-policy-ebs image-policy-va image-policy-free-va \
		image-policy-retire-busy image-policy-unregister-error \
		span-owner-base span-owner-size span-entry-base span-entry-size \
		span-policy-size \
		allocation-1 allocation-2 allocation-3 allocation-4 allocation-5 allocation-6 allocation-7 \
		event-1 event-2 event-3 namespace-busy policy-busy-control \
		call-set-ebs call-set-va call-get-ebs call-get-va \
		call-set-second-ebs call-set-second-va \
		call-set-operation-ebs call-set-operation-va \
		call-get-operation-ebs call-get-operation-va \
		call-next-operation-ebs call-next-operation-va \
		call-query-operation-ebs call-query-operation-va \
		call-next-ebs call-next-va call-query-ebs call-query-va \
		call-register-ebs-fail call-register-va-fail call-lock-ebs-fail call-lock-va-fail \
		policy-ebs policy-va policy-owner-poison policy-converted-drift \
		ready-fail runtime-fail runtime-request-drift runtime-ready-drift \
		runtime-owner-drift runtime-scratch-drift runtime-other-trigger runtime-preclosed \
		va-namespace-busy va-policy-busy va-owner-poison \
		va-alias-entry-owner va-alias-entry-message va-alias-entry-scratch va-alias-entry-mailbox \
		va-alias-service-owner va-alias-service-message va-alias-service-scratch va-alias-service-mailbox \
		va-alias-names-owner va-alias-names-message va-alias-names-scratch va-alias-names-mailbox \
		va-1 va-2 va-3 va-4 va-5 va-6 va-7 va-8 va-9 va-10 va-11 va-12 va-13 va-14; do
		ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
			"$temporary/consumer-$optimization" "$temporary/producer-$optimization" "$mode"
	done
	ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
		"$temporary/consumer-$optimization" "$temporary/producer-$optimization" \
		auth2 "$temporary"
	compile_consumer "$optimization" "$temporary/mutant-$optimization" \
		"$temporary/entry-no-trigger-check.c"
	set +e
	ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
		"$temporary/mutant-$optimization" "$temporary/producer-$optimization" \
		call-set-second-ebs > "$temporary/mutant-$optimization.log" 2>&1
	status=$?
	set -e
	test "$status" = 134
	grep -Fq 'entry->service->bank[entry->service->active].used == used' \
		"$temporary/mutant-$optimization.log"
	if grep -Eq 'runtime error:|[[:alpha:]]*Sanitizer' "$temporary/mutant-$optimization.log"; then
		cat "$temporary/mutant-$optimization.log" >&2
		exit 1
	fi
	printf 'Protected trigger continuity causal mutation O%s: PASS\n' "$optimization"
	compile_consumer "$optimization" "$temporary/runtime-mutant-$optimization" \
		"$temporary/entry-no-runtime-check.c"
	set +e
	ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
		"$temporary/runtime-mutant-$optimization" "$temporary/producer-$optimization" \
		runtime-ready-drift > "$temporary/runtime-mutant-$optimization.log" 2>&1
	status=$?
	set -e
	test "$status" = 134
	grep -Fq 'active->failed && active->protected->failed' \
		"$temporary/runtime-mutant-$optimization.log"
	if grep -Eq 'runtime error:|[[:alpha:]]*Sanitizer' "$temporary/runtime-mutant-$optimization.log"; then
		cat "$temporary/runtime-mutant-$optimization.log" >&2
		exit 1
	fi
	printf 'Pending runtime request continuity causal mutation O%s: PASS\n' "$optimization"
	for mutation in retire-busy unregister-error; do
		compile_consumer "$optimization" "$temporary/$mutation-$optimization" \
			"$temporary/entry-no-$mutation.c"
		status=0
		(ulimit -c 0; ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
			"$temporary/$mutation-$optimization" "$temporary/producer-$optimization" \
			"image-policy-$mutation") > "$temporary/$mutation-$optimization.log" 2>&1 || status=$?
		test "$status" = 134
		grep -Fq 'retire_image_policy(entry) ==' "$temporary/$mutation-$optimization.log"
		if grep -Eq 'runtime error:|[[:alpha:]]*Sanitizer' \
		    "$temporary/$mutation-$optimization.log"; then
			cat "$temporary/$mutation-$optimization.log" >&2
			exit 1
		fi
		printf 'Policy retirement %s causal mutation O%s: PASS\n' "$mutation" "$optimization"
	done
done
sha256sum -c "$temporary/report-inputs-before.sha256"
