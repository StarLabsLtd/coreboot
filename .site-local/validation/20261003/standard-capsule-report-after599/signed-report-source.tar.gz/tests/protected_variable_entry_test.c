/* SPDX-License-Identifier: GPL-2.0-only */

#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>

#include <cdk2/authvar_runtime_owner.h>
#include <cdk2/bds_secure_boot.h>
#include <cdk2/capsule_report.h>
#include <cdk2/pcat_rtc.h>
#include <pi/boot_mode.h>
#include <guid/cbmem_table_hob.h>
#include <pi/hob.h>
#include <industry_standard/pe_image.h>

/* Exercise the actual installation and private event callbacks, not a parallel owner. */
#ifndef PROTECTED_VARIABLE_ENTRY_SOURCE
#define PROTECTED_VARIABLE_ENTRY_SOURCE "../src/modules/variable_runtime/entry.c"
#endif
#include PROTECTED_VARIABLE_ENTRY_SOURCE
#include "../src/boot/coreboot_checksum.h"

static FILE *requests, *replies;
static uint8_t *shared;
static size_t allocations, releases, allocation_failure, event_count;
static size_t event_failure, install_failure, closes, calls, controls[11], conversions;
static size_t conversion_failure;
static size_t conversion_alias_at;
static void *conversion_alias;
static unsigned int fail_operation;
static void *original_scratch, *replacement_scratch;
static struct variable_policy_entry *mutating_policy;
static struct cdk2_security_router *installed_router;
uint64_t CDK2_MS_ABI security_stub_initialize(void *image, void *system);
#ifdef PROTECTED_ENTRY_CORE_JOIN
struct cdk2_security_router *protected_entry_core_router(void);
void protected_entry_core_load(bool enrolled);
#endif
static bool nonidentity;
static bool control_armed;
static unsigned int control_operation, control_occurrence;
static bool completed_protected_set;
static size_t tpl_raises, tpl_restores;

static EFI_STATUS CDK2_MS_ABI refuse_policy_unregister(cdk2_security_policy_fn *policy,
						       void *owner)
{
	assert(active && policy == cdk2_protected_image_policy_authorize &&
	       owner == active->image_policy);
	return EFI_DEVICE_ERROR;
}

static UINTN CDK2_MS_ABI test_raise(UINTN tpl)
{
	assert(tpl == 16);
	tpl_raises++;
	return 7;
}

static void CDK2_MS_ABI test_restore(UINTN tpl)
{
	assert(tpl == 7);
	tpl_restores++;
}
static struct {
	void *physical, *virtual;
	size_t size;
	int fd;
} mapping[16];
static size_t mapped;
static const char *scenario;
static pid_t producer;
static EFI_GUID global_guid = {
	0x8be4df61,
	0x93ca,
	0x11d2,
	{0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c}
};
static EFI_GUID image_guid = {
	0xd719b2cb,
	0x3d3a,
	0x4596,
	{0xa3, 0xbc, 0xda, 0xd0, 0x0e, 0x67, 0x65, 0x6f}
};

static int finish(void)
{
	int status;

	assert(!fclose(requests) && !fclose(replies));
	assert(waitpid(producer, &status, 0) == producer && WIFEXITED(status) &&
	       WEXITSTATUS(status) == 0);
	printf("Actual protected variable entry (%s): PASS (modeled trigger/HOB)\n", scenario);
	return 0;
}
static void *events[3], *contexts[3];
static notify_fn *notifications[3];
static struct variable_policy_protocol *published_policy;
static struct {
	struct cb_header header;
	struct {
		uint32_t tag, size;
		struct cb_memory_range range;
	} memory;
	struct cb_authvar_service_endpoint endpoint;
} table;
static struct {
	EFI_HOB_HANDOFF_INFO_TABLE handoff;
	struct {
		EFI_HOB_GUID_TYPE guid;
		COREBOOT_TABLE_HOB table;
	} record;
	EFI_HOB_GENERIC_HEADER end;
} hobs;

static EFI_STATUS CDK2_MS_ABI test_allocate(UINTN type, UINTN size, void **buffer)
{
	assert(type == 6 || type == 4);
	if (++allocations == allocation_failure)
		return EFI_OUT_OF_RESOURCES;
	assert(mapped < ARRAY_SIZE(mapping));
	int fd = memfd_create("variable-runtime-test", 0);

	assert(fd >= 0 && !ftruncate(fd, size));
	*buffer = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	assert(*buffer != MAP_FAILED);
	mapping[mapped++] = (typeof(mapping[0])){*buffer, NULL, size, fd};
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_free(void *buffer)
{
	if (active && buffer == active->image_policy &&
	    !strcmp(scenario, "image-policy-free-va")) {
		assert(active->namespace.busy && active->security_router == NULL);
		virtual_change(NULL, active);
	}
	releases++;
	for (size_t index = 0; index < mapped; index++) {
		if (mapping[index].physical != buffer)
			continue;
		assert(!munmap(buffer, mapping[index].size));
		if (mapping[index].virtual)
			assert(!munmap(mapping[index].virtual, mapping[index].size));
		assert(!close(mapping[index].fd));
		mapping[index].physical = NULL;
		return EFI_SUCCESS;
	}
	assert(false);
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_locate(EFI_GUID *guid, void *key, void **result)
{
	(void)key;
	/* No FTW/FVB or second nonvolatile provider is available to this profile. */
	assert(!memcmp(guid, &cdk2_security_router_guid, sizeof(*guid)));
	if (!strcmp(scenario, "router-absent"))
		return EFI_NOT_FOUND;
	*result = installed_router;
	return EFI_SUCCESS;
}

#ifndef PROTECTED_ENTRY_CORE_JOIN
static EFI_STATUS CDK2_MS_ABI test_security_install(void **handle, const EFI_GUID *guid,
						    void *protocol, ...)
{
	__builtin_ms_va_list arguments;

	(void)handle;
	__builtin_ms_va_start(arguments, protocol);
	for (size_t index = 0; index < 3; index++) {
		assert(guid && protocol);
		if (!memcmp(guid, &security_router_guid, sizeof(*guid))) {
			assert(installed_router == NULL);
			installed_router = protocol;
		}
		guid = __builtin_va_arg(arguments, const EFI_GUID *);
		if (guid)
			protocol = __builtin_va_arg(arguments, void *);
	}
	assert(guid == NULL && installed_router);
	__builtin_ms_va_end(arguments);
	return EFI_SUCCESS;
}
#endif

static EFI_STATUS CDK2_MS_ABI test_crc(void *bytes, UINTN size, UINT32 *crc)
{
	assert(bytes && size == sizeof(struct cdk2_runtime_services_view));
	*crc = 0x12345678;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_create(UINT32 type, UINTN tpl, void *notify, void *context,
					  const EFI_GUID *group, void **event)
{
	assert(type == 0x200 && (tpl == 8 || tpl == 16) && event_count < 3);
	if (event_count + 1 == event_failure)
		return EFI_OUT_OF_RESOURCES;
	size_t index = !memcmp(group, &exit_guid, sizeof(*group))    ? 0 :
		       !memcmp(group, &virtual_guid, sizeof(*group)) ? 1 :
								       2;

	assert(index < 2 || !memcmp(group, &ready_guid, sizeof(*group)));
	events[index] = (void *)(uintptr_t)(index + 1);
	notifications[index] = notify;
	contexts[index] = context;
	*event = events[index];
	event_count++;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_close(void *event)
{
	assert(event);
	closes++;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_install(void **handle, ...)
{
	__builtin_ms_va_list arguments;

	__builtin_ms_va_start(arguments, handle);
	assert(!memcmp(__builtin_va_arg(arguments, EFI_GUID *), &variable_arch_guid,
		       sizeof(EFI_GUID)));
	assert(__builtin_va_arg(arguments, void *) == NULL);
	assert(!memcmp(__builtin_va_arg(arguments, EFI_GUID *), &variable_write_guid,
		       sizeof(EFI_GUID)));
	assert(__builtin_va_arg(arguments, void *) == NULL);
	assert(!memcmp(__builtin_va_arg(arguments, EFI_GUID *), &variable_policy_guid,
		       sizeof(EFI_GUID)));
	published_policy = __builtin_va_arg(arguments, void *);
	assert(__builtin_va_arg(arguments, void *) == NULL);
	__builtin_ms_va_end(arguments);
	if (install_failure)
		return EFI_DEVICE_ERROR;
	*handle = (void *)0x1234;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_uninstall(void *handle, ...)
{
	assert(handle == (void *)0x1234);
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_convert(UINTN flags, void **pointer)
{
	assert(!flags && pointer && *pointer);
	if (++conversions == conversion_failure)
		return EFI_NOT_FOUND;
	if (conversions == conversion_alias_at) {
		*pointer = conversion_alias;
		return EFI_SUCCESS;
	}
	if (!nonidentity)
		return EFI_SUCCESS;
	for (size_t index = 0; index < mapped; index++) {
		uintptr_t address = (uintptr_t)*pointer;
		uintptr_t start = (uintptr_t)mapping[index].physical;

		if (!start || address < start || address - start >= mapping[index].size)
			continue;
		if (!mapping[index].virtual) {
			mapping[index].virtual = mmap(NULL, mapping[index].size,
						      PROT_READ | PROT_WRITE, MAP_SHARED,
						      mapping[index].fd, 0);
			assert(mapping[index].virtual != MAP_FAILED &&
			       mapping[index].virtual != mapping[index].physical);
		}
		*pointer = (uint8_t *)mapping[index].virtual + address - start;
		break;
	}
	return EFI_SUCCESS;
}

EFI_STATUS __wrap_cdk2_authvar_native_x86_trigger(void *context, UINT16 port, UINT8 value)
{
	struct cdk2_authvar_service_frame *frame = (void *)shared;

	assert(context == NULL && port == 0xb2 && value == 0xfc);
	assert(frame->operation <= 10);
	calls++;
	controls[frame->operation]++;
	if (frame->operation == CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT &&
	    (!strcmp(scenario, "image-policy-ebs") || !strcmp(scenario, "image-policy-va"))) {
		struct variable_entry *entry = active;
		struct cdk2_protected_image_policy *policy = entry->image_policy;
		const size_t before = releases;
		const size_t bytes = entry->image_policy_size;
		void *snapshot = malloc(bytes);

		assert(snapshot && policy->busy && bytes == policy->allocation_size);
		memcpy(snapshot, policy, bytes);
		if (!strcmp(scenario, "image-policy-ebs"))
			notifications[0](events[0], contexts[0]);
		else
			notifications[1](events[1], contexts[1]);
		assert(entry->failed && entry->image_policy == policy && policy->busy &&
		       entry->namespace.policy_owner_base == policy &&
		       entry->namespace.policy_owner_size == bytes && releases == before &&
		       !memcmp(snapshot, policy, bytes));
		free(snapshot);
	}
	if (frame->operation == CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME &&
	    !strcmp(scenario, "runtime-other-trigger")) {
		const size_t before = calls;

		assert(protected_trigger(NULL, port + 1, value) == EFI_DEVICE_ERROR &&
		       calls == before && active->failed);
	}
	if (control_armed &&
	    (!control_operation || (frame->operation == control_operation &&
				    controls[frame->operation] == control_occurrence))) {
		control_armed = false;
		if (strstr(scenario, "-ebs"))
			notifications[0](events[0], contexts[0]);
		else
			notifications[1](events[1], contexts[1]);
	}
	if (frame->operation == fail_operation)
		return EFI_DEVICE_ERROR;
	if (frame->operation == CDK2_AUTHVAR_SERVICE_REGISTER_POLICY && mutating_policy) {
		struct variable_entry *entry = active;
		const size_t calls_before = calls;
		CHAR16 name[] = {'R', 0};
		EFI_GUID vendor = {0};
		uint8_t value = 0x66;
		const size_t ram_before = entry->service->bank[entry->service->active].used;

		assert(set_variable(name, &vendor, 6, 1, &value) == EFI_NOT_READY);
		assert(lock_policy() == EFI_NOT_READY);
		assert(register_policy(mutating_policy) == EFI_NOT_READY);
		assert(calls == calls_before &&
		       entry->service->bank[entry->service->active].used == ram_before);
		if (!strcmp(scenario, "policy-ebs"))
			notifications[0](events[0], contexts[0]);
		else if (!strcmp(scenario, "policy-va"))
			notifications[1](events[1], contexts[1]);
		else if (!strcmp(scenario, "policy-owner-poison"))
			entry->protected->failed = true;
		else if (!strcmp(scenario, "policy-converted-drift"))
			entry->protected->converted = !entry->protected->converted;
		mutating_policy->size = 0;
		mutating_policy->max_size = 100;
	}
	assert(fwrite(shared, 1, 65536, requests) == 65536 && !fflush(requests));
	assert(fread(shared, 1, 65536, replies) == 65536);
	if (frame->operation == CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME &&
	    !strcmp(scenario, "runtime-request-drift")) {
		struct cdk2_authvar_service_frame *request =
			(void *)active->protected->client.scratch;

		/* The provider has committed; only local admission may now fail. */
		request->request_id++;
	}
	if (frame->operation == CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME &&
	    !strcmp(scenario, "runtime-ready-drift"))
		active->ready = false;
	if (frame->operation == CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME &&
	    !strcmp(scenario, "runtime-owner-drift"))
		active->protected->client.private_owner = active;
	if (frame->operation == CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME &&
	    !strcmp(scenario, "runtime-scratch-drift")) {
		original_scratch = active->protected->client.scratch;
		replacement_scratch = malloc(active->protected->client.scratch_size);
		assert(replacement_scratch);
		memcpy(replacement_scratch, original_scratch,
		       active->protected->client.scratch_size);
		active->protected->client.scratch = replacement_scratch;
	}
	if (control_operation == CDK2_AUTHVAR_SERVICE_SET &&
	    frame->operation == CDK2_AUTHVAR_SERVICE_SET && !control_armed) {
		assert(frame->completion == CDK2_AUTHVAR_SERVICE_COMPLETE &&
		       frame->status == CDK2_AUTHVAR_STATUS_SUCCESS);
		completed_protected_set = true;
	}
	return EFI_SUCCESS;
}

static struct cbuint64 packed(uint64_t value)
{
	return (struct cbuint64){value, value >> 32};
}

static void make_hobs(const struct cb_authvar_service_endpoint *endpoint)
{
	memset(&table, 0, sizeof(table));
	memset(&hobs, 0, sizeof(hobs));
	table.header.signature = CB_HEADER_SIGNATURE;
	table.header.header_bytes = sizeof(table.header);
	table.header.table_bytes = sizeof(table) - sizeof(table.header);
	table.header.table_entries = 2;
	table.memory.tag = CB_TAG_MEMORY;
	table.memory.size = sizeof(table.memory);
	table.memory.range.start = packed((uintptr_t)shared);
	table.memory.range.size = packed(65536);
	table.memory.range.type = CB_MEM_TABLE;
	table.endpoint = *endpoint;
	table.header.table_checksum =
		cdk2_coreboot_checksum16(&table.memory, table.header.table_bytes);
	table.header.header_checksum =
		cdk2_coreboot_checksum16(&table.header, sizeof(table.header));
	hobs.handoff.header =
		(EFI_HOB_GENERIC_HEADER){EFI_HOB_TYPE_HANDOFF, sizeof(hobs.handoff), 0};
	hobs.handoff.version = EFI_HOB_HANDOFF_TABLE_VERSION;
	hobs.handoff.efi_memory_bottom = (uintptr_t)&hobs;
	hobs.handoff.efi_memory_top = (uintptr_t)(&hobs + 1);
	hobs.handoff.efi_free_memory_top = (uintptr_t)(&hobs + 1);
	hobs.handoff.efi_end_of_hob_list = (uintptr_t)&hobs.end;
	hobs.handoff.efi_free_memory_bottom = (uintptr_t)(&hobs + 1);
	hobs.record.guid.header =
		(EFI_HOB_GENERIC_HEADER){EFI_HOB_TYPE_GUID_EXTENSION, sizeof(hobs.record), 0};
	hobs.record.guid.name = (EFI_GUID){
		0x9e0d4b6f, 0xa8e8, 0x4d7e, {0x9a, 0x2d, 0x31, 0x0d, 0x4c, 0x9a, 0x8f, 0x2b}
	};
	hobs.record.table.address = (uintptr_t)&table;
	hobs.record.table.size = sizeof(table);
	hobs.end = (EFI_HOB_GENERIC_HEADER){EFI_HOB_TYPE_END_OF_HOB_LIST, sizeof(hobs.end), 0};
}

static void test_owned_operands(struct variable_entry *entry)
{
	struct cdk2_authvar_runtime_owner *owner = entry->protected;
	struct variable_entry *saved_entry = malloc(sizeof(*entry));
	struct cdk2_variable_service *saved_service = malloc(sizeof(*entry->service));
	void *saved_names = malloc(entry->namespace.names_size);
	struct cdk2_authvar_runtime_owner saved_owner = *owner;
	CHAR16 name[] = {'V', 0};
	EFI_GUID vendor = {0};
	UINT8 value = 0;
	UINTN size = sizeof(value);
	UINT64 maximum = 0, remaining = 0, variable = 0;
	const size_t before = calls;
	void *aliases[] = {&entry->policy_count, &owner->runtime.entry_size, entry->service,
			   entry->names, entry->image_policy};

	assert(saved_entry != NULL && saved_service != NULL && saved_names != NULL);
	*saved_entry = *entry;
	*saved_service = *entry->service;
	memcpy(saved_names, entry->names, entry->namespace.names_size);
	for (size_t index = 0; index < ARRAY_SIZE(aliases); index++) {
		void *alias = aliases[index];

		if (alias == NULL)
			continue;

		assert(get_variable(name, &vendor, alias, &size, &value) ==
		       EFI_INVALID_PARAMETER);
		assert(get_variable(name, &vendor, NULL, alias, &value) ==
		       EFI_INVALID_PARAMETER);
		assert(get_variable(name, &vendor, NULL, &size, alias) ==
		       EFI_INVALID_PARAMETER);
		assert(get_variable(alias, &vendor, NULL, &size, &value) ==
		       EFI_INVALID_PARAMETER);
		assert(get_variable(name, alias, NULL, &size, &value) == EFI_INVALID_PARAMETER);
		size = sizeof(name);
		assert(get_next(alias, name, &vendor) == EFI_INVALID_PARAMETER);
		assert(get_next(&size, alias, &vendor) == EFI_INVALID_PARAMETER);
		assert(get_next(&size, name, alias) == EFI_INVALID_PARAMETER);
		size = sizeof(value);
		assert(set_variable(alias, &vendor, 6, 1, &value) == EFI_INVALID_PARAMETER);
		assert(set_variable(name, alias, 6, 1, &value) == EFI_INVALID_PARAMETER);
		assert(set_variable(name, &vendor, 6, 1, alias) == EFI_INVALID_PARAMETER);
		assert(query_variable(6, alias, &remaining, &variable) ==
		       EFI_INVALID_PARAMETER);
		assert(query_variable(6, &maximum, alias, &variable) == EFI_INVALID_PARAMETER);
		assert(query_variable(6, &maximum, &remaining, alias) == EFI_INVALID_PARAMETER);
		if (!entry->policy_locked)
			assert(register_policy(alias) == EFI_INVALID_PARAMETER);
		assert(calls == before && size == sizeof(value) && value == 0 && maximum == 0 &&
		       remaining == 0 && variable == 0);
		assert(!memcmp(entry, saved_entry, sizeof(*entry)) &&
		       !memcmp(owner, &saved_owner, sizeof(*owner)) &&
		       !memcmp(entry->service, saved_service, sizeof(*saved_service)) &&
		       !memcmp(entry->names, saved_names, entry->namespace.names_size));
	}
	if (!entry->policy_locked)
		assert(register_policy((void *)UINTPTR_MAX) == EFI_INVALID_PARAMETER &&
		       calls == before && !memcmp(entry, saved_entry, sizeof(*entry)) &&
		       !memcmp(owner, &saved_owner, sizeof(*owner)));
	free(saved_entry);
	free(saved_service);
	free(saved_names);
}

static EFI_STATUS CDK2_MS_ABI report_clock_model(CDK2_EFI_TIME *time,
	CDK2_TIME_CAPABILITIES *capabilities)
{
	(void)time;
	(void)capabilities;
	return EFI_UNSUPPORTED;
}

int main(int argc, char **argv)
{
	struct cb_authvar_service_endpoint descriptor;
	struct cdk2_runtime_services_view runtime = {0};
	struct cdk2_boot_services_view boot = {0};
	struct cdk2_dxe_configuration_table configuration = {hob_guid, &hobs};
	struct cdk2_dxe_system_table system = {0};
	CHAR16 name[] = {'V', 0};
	EFI_GUID vendor = {0};
	uint8_t value = 0x22;
	UINTN size;
	UINT32 attributes;
	UINT64 maximum, remaining, variable;
	int request_pipe[2], reply_pipe[2];
	_Alignas(UINT64) uint8_t policy_image[0x400] = {0};
	EFI_IMAGE_DOS_HEADER *dos = (void *)policy_image;
	EFI_IMAGE_NT_HEADERS64 *nt = (void *)(policy_image + 0x80);
	EFI_IMAGE_SECTION_HEADER *section = (void *)(nt + 1);

	dos->e_magic = EFI_IMAGE_DOS_SIGNATURE;
	dos->e_lfanew = 0x80;
	nt->signature = EFI_IMAGE_NT_SIGNATURE;
	nt->file_header.machine = IMAGE_FILE_MACHINE_X64;
	nt->file_header.number_of_sections = 1;
	nt->file_header.size_of_optional_header = sizeof(nt->optional_header);
	nt->optional_header.magic = EFI_IMAGE_NT_OPTIONAL_HDR64_MAGIC;
	nt->optional_header.section_alignment = 0x1000;
	nt->optional_header.file_alignment = 0x200;
	nt->optional_header.size_of_image = 0x2000;
	nt->optional_header.size_of_headers = 0x200;
	nt->optional_header.subsystem = 10;
	nt->optional_header.number_of_rva_and_sizes = EFI_IMAGE_NUMBER_OF_DIRECTORY_ENTRIES;
	section->misc.virtual_size = 0x100;
	section->virtual_address = 0x1000;
	section->size_of_raw_data = 0x200;
	section->pointer_to_raw_data = 0x200;
	section->characteristics = 0x60000020;

	assert((argc >= 2 && argc <= 4) && !pipe(request_pipe) && !pipe(reply_pipe));
	scenario = argc >= 3 ? argv[2] : "normal";
	nonidentity = !strcmp(scenario, "nonidentity");
	pid_t child = fork();

	assert(child >= 0);
	producer = child;
	if (!child) {
		assert(dup2(request_pipe[0], STDIN_FILENO) == STDIN_FILENO);
		assert(dup2(reply_pipe[1], STDOUT_FILENO) == STDOUT_FILENO);
		close(request_pipe[0]);
		close(request_pipe[1]);
		close(reply_pipe[0]);
		close(reply_pipe[1]);
		execl(argv[1], argv[1], NULL);
		_exit(127);
	}
	close(request_pipe[0]);
	close(reply_pipe[1]);
	requests = fdopen(request_pipe[1], "wb");
	replies = fdopen(reply_pipe[0], "rb");
	assert(requests && replies &&
	       fread(&descriptor, 1, sizeof(descriptor), replies) == sizeof(descriptor));
	int shared_fd = memfd_create("variable-mailbox-test", 0);

	assert(shared_fd >= 0 && !ftruncate(shared_fd, 65536));
	shared = mmap((void *)(uintptr_t)0x100000, 65536, PROT_READ | PROT_WRITE,
		      MAP_SHARED | MAP_FIXED_NOREPLACE, shared_fd, 0);
	assert(shared == (void *)(uintptr_t)0x100000);
	mapping[mapped++] = (typeof(mapping[0])){shared, NULL, 65536, shared_fd};
	if (!strcmp(scenario, "endpoint-invalid"))
		descriptor.revision = 4;
	if (!strcmp(scenario, "general-absent"))
		descriptor.flags &= ~CB_AUTHVAR_ENDPOINT_IMAGE_POLICY_GENERAL;
	make_hobs(&descriptor);
	runtime.header.size = sizeof(runtime);
	runtime.convert_pointer = test_convert;
	boot.allocate_pool = test_allocate;
	boot.free_pool = test_free;
	boot.locate_protocol = test_locate;
	boot.install_multiple = test_install;
	boot.uninstall_multiple = test_uninstall;
	boot.create_event_ex = test_create;
	boot.close_event = test_close;
	boot.calculate_crc32 = test_crc;
	boot.raise_tpl = test_raise;
	boot.restore_tpl = test_restore;
	system.runtime_services = &runtime;
	system.boot_services = (void *)&boot;
#ifdef PROTECTED_ENTRY_CORE_JOIN
	installed_router = protected_entry_core_router();
#else
	boot.install_multiple = test_security_install;
	assert(security_stub_initialize(NULL, &system) == EFI_SUCCESS && installed_router);
#endif
	boot.install_multiple = test_install;
	system.number_of_table_entries = 1;
	system.configuration_table = &configuration;
	if (!strncmp(scenario, "allocation-", 11))
		allocation_failure = strtoul(scenario + 11, NULL, 10);
	if (!strncmp(scenario, "event-", 6))
		event_failure = strtoul(scenario + 6, NULL, 10);
	install_failure = !strcmp(scenario, "install-fail");
	EFI_STATUS installed = cdk2_variable_runtime_entry(NULL, &system);

	if (allocation_failure || event_failure || install_failure ||
	    !strcmp(scenario, "endpoint-invalid") || !strcmp(scenario, "general-absent") ||
	    !strcmp(scenario, "router-absent")) {
		EFI_STATUS expected = install_failure ? EFI_DEVICE_ERROR :
				      !strcmp(scenario, "endpoint-invalid") ?
							EFI_COMPROMISED_DATA :
				      !strcmp(scenario, "general-absent") ? EFI_UNSUPPORTED :
				      !strcmp(scenario, "router-absent")  ? EFI_NOT_FOUND :
									    EFI_OUT_OF_RESOURCES;

		assert(installed == expected && active == NULL &&
		       runtime.get_variable == NULL && runtime.get_next_variable == NULL &&
		       runtime.set_variable == NULL && runtime.query_variable_info == NULL &&
		       releases == allocations - !!allocation_failure &&
		       closes == event_count && calls == 0);
		return finish();
	}
	assert(installed == EFI_SUCCESS);
	if (!strcmp(scenario, "capsule-report-normal") ||
	    !strcmp(scenario, "capsule-report-flash")) {
		static EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
		const EFI_GUID capsule_guid = { .data1 = 1 }, image_type = { .data1 = 2 };
		const EFI_STATUS failure = EFI_DEVICE_ERROR;
		struct cdk2_variable_policy_protocol report_policy;
		const bool flash = !strcmp(scenario, "capsule-report-flash");
		CHAR16 maximum[11], last[11];
		uint8_t report[72];
		UINTN bytes = sizeof(maximum);
		UINT32 attrs = 0;

		_Static_assert(sizeof(report_policy) == sizeof(*published_policy),
			"protected variable report policy ABI");
		memcpy(&report_policy, published_policy, sizeof(report_policy));
		runtime.get_time = report_clock_model; /* Clock modeled; variable/MM service is real. */
		assert(cdk2_capsule_report_initialize(&runtime, &report_policy,
			flash ? BOOT_ON_FLASH_UPDATE : BOOT_WITH_FULL_CONFIGURATION) == EFI_SUCCESS);
		assert(get_variable(L"CapsuleMax", &report_guid, &attrs, &bytes,
			maximum) == EFI_SUCCESS && bytes == 22 && attrs == 6 &&
			!memcmp(maximum, L"Capsuleffff", 22));
		assert(set_variable(L"CapsuleMax", &report_guid, 6, 22, maximum) ==
			EFI_WRITE_PROTECTED);
		if (!flash) {
			assert(set_variable(L"CapsuleLast", &report_guid, 7, 22, maximum) ==
				EFI_WRITE_PROTECTED);
			return finish();
		}
		assert(cdk2_capsule_report_fmp(&runtime, &capsule_guid, &image_type,
			3, 9, failure) == EFI_SUCCESS);
		bytes = sizeof(report);
		assert(get_variable(L"Capsule0000", &report_guid, &attrs, &bytes,
			report) == EFI_SUCCESS && bytes == 72 && attrs == 7);
		assert(report[50] == 9 && report[51] == 3 &&
			!memcmp(report + 40, &failure, sizeof(failure)));
		bytes = sizeof(last);
		assert(get_variable(L"CapsuleLast", &report_guid, &attrs, &bytes,
			last) == EFI_SUCCESS && bytes == 22 && attrs == 7 &&
			!memcmp(last, L"Capsule0000", 22));
		return finish();
	}
	assert(allocations == 7);
	assert(active && active->backend == NULL && active->imported == NULL &&
	       active->persistent == NULL && active->service->persist == NULL &&
	       event_count == 3);
	assert(runtime.set_variable == set_variable && runtime.get_variable == get_variable &&
	       runtime.get_next_variable == get_next &&
	       runtime.query_variable_info == query_variable);
	test_owned_operands(active);
	if (!strcmp(scenario, "image-policy-retire-busy") ||
	    !strcmp(scenario, "image-policy-unregister-error")) {
		struct variable_entry *entry = active;
		struct cdk2_protected_image_policy *policy = entry->image_policy;
		const size_t bytes = entry->image_policy_size;
		const size_t before = releases;
		void *snapshot = malloc(bytes);
		cdk2_security_policy_register_fn *unregister =
			installed_router->unregister_policy;
		const bool busy = !strcmp(scenario, "image-policy-retire-busy");

		assert(snapshot);
		memcpy(snapshot, policy, bytes);
		if (busy)
			entry->namespace.busy = 1;
		else
			installed_router->unregister_policy = refuse_policy_unregister;
		assert(retire_image_policy(entry) == (busy ? EFI_NOT_READY : EFI_DEVICE_ERROR));
		assert(releases == before && entry->image_policy == policy &&
		       entry->image_policy_size == bytes &&
		       entry->security_router == installed_router &&
		       entry->namespace.policy_owner_base == policy &&
		       entry->namespace.policy_owner_size == bytes &&
		       entry->namespace.busy == busy && !memcmp(snapshot, policy, bytes));
		entry->namespace.busy = 0;
		installed_router->unregister_policy = unregister;
		assert(retire_image_policy(entry) == EFI_SUCCESS && releases == before + 1 &&
		       entry->image_policy == NULL && entry->image_policy_size == 0 &&
		       entry->security_router == NULL &&
		       entry->namespace.policy_owner_base == NULL &&
		       entry->namespace.policy_owner_size == 0 && !entry->namespace.busy);
		const size_t before_calls = calls;

		assert(installed_router->authorize_policy(policy_image, sizeof(policy_image)) ==
			       EFI_UNSUPPORTED &&
		       calls == before_calls);
		free(snapshot);
		return finish();
	}
	if (!strcmp(scenario, "image-policy-ebs") || !strcmp(scenario, "image-policy-va") ||
	    !strcmp(scenario, "image-policy-free-va")) {
		struct variable_entry *entry = active;
		const size_t before = releases;
		const size_t bytes = entry->image_policy_size;

		if (!strcmp(scenario, "image-policy-free-va")) {
			notifications[0](events[0], contexts[0]);
			assert(active == NULL && entry->failed &&
			       entry->protected->entered_runtime && conversions == 0);
		} else {
			assert(installed_router->authorize_policy(policy_image,
								  sizeof(policy_image)) ==
				       EFI_DEVICE_ERROR &&
			       entry->failed && releases == before && entry->image_policy &&
			       !entry->image_policy->busy &&
			       entry->namespace.policy_owner_base == entry->image_policy &&
			       entry->namespace.policy_owner_size == bytes);
			for (size_t index = 0; index < entry->image_policy->capacity; index++)
				assert(entry->image_policy->snapshot[index] == 0);
			/* The actual callback has returned; a repeated control may retire now. */
			notifications[0](events[0], contexts[0]);
		}
		const size_t before_calls = calls;

		assert(entry->image_policy == NULL && entry->image_policy_size == 0 &&
		       entry->security_router == NULL &&
		       entry->namespace.policy_owner_base == NULL &&
		       entry->namespace.policy_owner_size == 0 && releases == before + 1);
		assert(installed_router->authorize_policy(policy_image, sizeof(policy_image)) ==
			       EFI_UNSUPPORTED &&
		       installed_router->register_policy(cdk2_protected_image_policy_authorize,
							 entry) == EFI_ACCESS_DENIED &&
		       calls == before_calls);
		return finish();
	}
	if (!strcmp(scenario, "normal") || !strncmp(scenario, "auth2", 5)) {
		const size_t before_policy_reads =
			controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT];

		assert(installed_router->authorize_policy(policy_image, sizeof(policy_image)) ==
			       EFI_SUCCESS &&
		       controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT] ==
			       before_policy_reads + 1);
		for (size_t index = 0; index < active->image_policy->capacity; index++)
			assert(active->image_policy->snapshot[index] == 0);
#ifdef PROTECTED_ENTRY_CORE_JOIN
		const size_t before_core_reads =
			controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT];

		protected_entry_core_load(false);
		assert(controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT] ==
		       before_core_reads + 1);
#endif
	}
	if (!strncmp(scenario, "span-", 5)) {
		struct variable_entry *entry = active;
		const size_t before = calls;
		const size_t used = entry->service->bank[entry->service->active].used;

		if (!strcmp(scenario, "span-owner-base"))
			entry->protected->runtime.owner_base = entry;
		else if (!strcmp(scenario, "span-owner-size"))
			entry->protected->runtime.owner_size--;
		else if (!strcmp(scenario, "span-entry-base"))
			entry->protected->runtime.entry_base = entry->protected;
		else if (!strcmp(scenario, "span-policy-size")) {
			entry->namespace.policy_owner_size--;
			entry->image_policy->allocation_size--;
		} else
			entry->protected->runtime.entry_size--;
		size = sizeof(value);
		assert(get_variable(name, &vendor, NULL, &size, &value) == EFI_DEVICE_ERROR);
		assert(entry->failed && calls == before &&
		       entry->service->bank[entry->service->active].used == used);
		assert(set_variable(name, &vendor, 6, 1, &value) == EFI_NOT_READY);
		assert(query_variable(6, &maximum, &remaining, &variable) == EFI_NOT_READY);
		ready_to_boot(NULL, entry);
		exit_boot(NULL, entry);
		assert(entry->failed && !entry->ready && calls == before);
		return finish();
	}
	_Alignas(CHAR16) uint8_t misaligned_name[sizeof(name) + 1];
	_Alignas(EFI_GUID) uint8_t misaligned_guid[sizeof(vendor) + 1];
	const size_t initial_used = active->service->bank[active->service->active].used;
	const size_t initial_calls = calls;

	memcpy(misaligned_name + 1, name, sizeof(name));
	memcpy(misaligned_guid + 1, &vendor, sizeof(vendor));
	assert(set_variable((void *)(misaligned_name + 1), &vendor, 6, 1, &value) ==
	       EFI_INVALID_PARAMETER);
	assert(set_variable(name, (void *)(misaligned_guid + 1), 6, 1, &value) ==
	       EFI_INVALID_PARAMETER);
	assert(set_variable((CHAR16 *)(UINTPTR_MAX & ~(_Alignof(CHAR16) - 1U)), &vendor, 6, 1,
			    &value) == EFI_INVALID_PARAMETER);
	assert(set_variable((CHAR16 *)(void *)active->protected->runtime.message, &vendor, 6, 1,
			    &value) == EFI_INVALID_PARAMETER);
	assert(calls == initial_calls &&
	       active->service->bank[active->service->active].used == initial_used);
	if (!strncmp(scenario, "call-", 5)) {
		struct variable_entry *entry = active;
		const size_t used = entry->service->bank[entry->service->active].used;
		EFI_STATUS status;

		control_armed = true;
		if (strstr(scenario, "-second-")) {
			control_operation = CDK2_AUTHVAR_SERVICE_KEY_CLASSIFY;
			control_occurrence = 2;
		} else if (strstr(scenario, "-operation-")) {
			control_operation =
				strstr(scenario, "-set-")  ? CDK2_AUTHVAR_SERVICE_SET :
				strstr(scenario, "-get-")  ? CDK2_AUTHVAR_SERVICE_GET :
				strstr(scenario, "-next-") ? CDK2_AUTHVAR_SERVICE_NEXT :
							     CDK2_AUTHVAR_SERVICE_QUERY;
			control_occurrence = 1;
		}
		if (strstr(scenario, "-register-") || strstr(scenario, "-lock-")) {
			struct variable_policy_entry policy = {
				.version = VARIABLE_POLICY_REVISION,
				.size = sizeof(policy),
				.offset_to_name = sizeof(policy),
				.max_size = 1,
			};

			fail_operation = strstr(scenario, "-register-") ?
						 CDK2_AUTHVAR_SERVICE_REGISTER_POLICY :
						 CDK2_AUTHVAR_SERVICE_LOCK_POLICY;
			status = strstr(scenario, "-register-") ? register_policy(&policy) :
								  lock_policy();
			assert(entry->policy_count == 0 && !entry->policy_locked);
		} else if (strstr(scenario, "-set-")) {
			if (control_operation == CDK2_AUTHVAR_SERVICE_SET) {
				name[0] = 'P';
				status = set_variable(name, &vendor, 7, 1, &value);
				/* The real provider completed its write before local control poison.
				 * Refusal here is terminal, not a rollback claim. */
				assert(completed_protected_set &&
				       controls[CDK2_AUTHVAR_SERVICE_SET] == 1);
			} else {
				status = set_variable(name, &vendor, 6, 1, &value);
				assert(controls[CDK2_AUTHVAR_SERVICE_KEY_CLASSIFY] ==
					       (strstr(scenario, "-second-") ? 2U : 1U) &&
				       controls[CDK2_AUTHVAR_SERVICE_SET] == 0);
			}
		} else if (strstr(scenario, "-get-")) {
			name[0] = 'P';
			size = sizeof(value);
			status = get_variable(name, &vendor, &attributes, &size, &value);
		} else if (strstr(scenario, "-next-")) {
			name[0] = 0;
			size = sizeof(name);
			status = get_next(&size, name, &vendor);
		} else {
			status = query_variable(7, &maximum, &remaining, &variable);
		}
		assert(entry->service->bank[entry->service->active].used == used);
		assert(status == EFI_DEVICE_ERROR && entry->failed && !control_armed &&
		       tpl_raises == tpl_restores && !policy_transaction_locked);
		const size_t before_calls = calls;

		assert(set_variable(name, &vendor, 6, 1, &value) == EFI_NOT_READY &&
		       get_variable(name, &vendor, &attributes, &size, &value) ==
			       EFI_NOT_READY &&
		       query_variable(6, &maximum, &remaining, &variable) == EFI_NOT_READY &&
		       calls == before_calls);
		return finish();
	}
	assert(set_variable(name, &vendor, 6, 1, &value) == EFI_SUCCESS);
	size = 1;
	assert(get_variable(name, &vendor, &attributes, &size, &value) == EFI_SUCCESS &&
	       attributes == 6 && value == 0x22);
	name[0] = 'P';
	size = 1;
	assert(get_variable(name, &vendor, &attributes, &size, &value) == EFI_SUCCESS &&
	       attributes == 7 && value == 0x11);
	name[0] = 'N';
	assert(set_variable(name, &vendor, 7, 1, &value) == EFI_SUCCESS);
	assert(query_variable(7, &maximum, &remaining, &variable) == EFI_SUCCESS &&
	       maximum != CDK2_VARIABLE_STORE_BYTES);
	assert(query_variable(6, &maximum, &remaining, &variable) == EFI_SUCCESS &&
	       maximum == CDK2_VARIABLE_STORE_BYTES);
	assert(published_policy == &policy_protocol);
	assert(cdk2_secure_boot_publish_defaults(&runtime, &boot) == EFI_SUCCESS);
	CHAR16 default_name[] = {'P', 'K', 'D', 'e', 'f', 'a', 'u', 'l', 't', 0};
	struct cdk2_authvar_key_classification classification;

	size = 0;
	assert(get_variable(default_name, &global_guid, &attributes, &size, NULL) ==
		       EFI_BUFFER_TOO_SMALL &&
	       size > 44 && size <= 65536);
	uint8_t *default_value = malloc(size);

	assert(default_value &&
	       get_variable(default_name, &global_guid, &attributes, &size, default_value) ==
		       EFI_SUCCESS &&
	       attributes == 6);
	free(default_value);
	assert(cdk2_authvar_runtime_classify(&active->protected->runtime, default_name,
					     &global_guid, &classification) == EFI_NOT_FOUND);
	if (!strncmp(scenario, "auth2", 5)) {
		CHAR16 mode_names[][11] = {
			{'S', 'e', 't', 'u', 'p', 'M', 'o', 'd', 'e', 0},
			{'S', 'e', 'c', 'u', 'r', 'e', 'B', 'o', 'o', 't', 0},
			{'V', 'e', 'n', 'd', 'o', 'r', 'K', 'e', 'y', 's', 0},
		};
		CHAR16 keys[][4] = {
			{'P', 'K', 0},
			{'d', 'b', 0},
			{'d', 'b', 'x', 0}
		};
		/* Setup PK bypass without RequireSelfSignedPK, followed by verified
		 * user-mode updates, does not mark VendorKeys modified. */
		const uint8_t before[] = {1, 0, 1}, after[] = {0, 1, 1};
		uint8_t update[8192], actual[8192];

		assert(argc == 4);
		for (size_t index = 0; index < 3; index++) {
			size = 1;
			assert(get_variable(mode_names[index], &global_guid, &attributes, &size,
					    &value) == EFI_SUCCESS &&
			       attributes == 6 && value == before[index]);
		}
		value = 0;
		assert(set_variable(mode_names[0], &global_guid, 6, 1, &value) ==
		       EFI_WRITE_PROTECTED);
		for (size_t key = 0; key < 3; key++) {
			char path[4096];
			uint32_t certificate_size;

			assert(snprintf(path, sizeof(path), "%s/update-%zu.bin", argv[3], key) <
			       (int)sizeof(path));
			FILE *input = fopen(path, "rb");

			assert(input);
			size_t bytes = fread(update, 1, sizeof(update), input);

			assert(input && bytes > 40 && !ferror(input) && fgetc(input) == EOF &&
			       !fclose(input));
			memcpy(&certificate_size, update + 16, sizeof(certificate_size));
			assert(certificate_size < bytes - 16);
			EFI_GUID *guid = key ? &image_guid : &global_guid;

			if (key == 2) {
				update[bytes - 1] ^= 1;
				assert(set_variable(keys[key], guid, 0x27, bytes, update) ==
				       EFI_SECURITY_VIOLATION);
				size = sizeof(actual);
				assert(get_variable(keys[key], guid, NULL, &size, actual) ==
				       EFI_NOT_FOUND);
				update[bytes - 1] ^= 1;
			}
			assert(set_variable(keys[key], guid, 0x27, bytes, update) ==
			       EFI_SUCCESS);
			size = sizeof(actual);
			assert(get_variable(keys[key], guid, &attributes, &size, actual) ==
				       EFI_SUCCESS &&
			       attributes == 0x27 && size == bytes - 16 - certificate_size &&
			       !memcmp(actual, update + 16 + certificate_size, size));
		}
		for (size_t index = 0; index < 3; index++) {
			size = 1;
			EFI_STATUS state = get_variable(mode_names[index], &global_guid,
							&attributes, &size, &value);

			fprintf(stderr,
				"Authoritative mode %zu: status=%llx attributes=%u value=%u\n",
				index, (unsigned long long)state, attributes, value);
			assert(state == EFI_SUCCESS && attributes == 6 &&
			       value == after[index]);
		}
		CHAR16 vendor_nv[] = {'V', 'e', 'n', 'd', 'o', 'r', 'K',
				      'e', 'y', 's', 'N', 'v', 0};
		EFI_GUID vendor_nv_guid = {
			0x9073e4e0,
			0x60ec,
			0x4b6e,
			{0x99, 0x03, 0x4c, 0x22, 0x3c, 0x26, 0x0f, 0x3c}
		};

		size = 1;
		assert(get_variable(vendor_nv, &global_guid, &attributes, &size, &value) ==
		       EFI_NOT_FOUND);
		size = 1;
		assert(get_variable(vendor_nv, &vendor_nv_guid, &attributes, &size, &value) ==
			       EFI_SUCCESS &&
		       attributes == 0x23 && value == 1);
		const size_t before_policy_reads =
			controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT];

		assert(installed_router->authorize_policy(policy_image, sizeof(policy_image)) ==
			       EFI_SECURITY_VIOLATION &&
		       controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT] ==
			       before_policy_reads + 1);
#ifdef PROTECTED_ENTRY_CORE_JOIN
		const size_t before_core_reads =
			controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT];

		protected_entry_core_load(true);
		assert(controls[CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT] ==
		       before_core_reads + 1);
#endif
	}
	if (!strcmp(scenario, "namespace-busy") || !strcmp(scenario, "policy-busy-control")) {
		active->namespace.busy = !strcmp(scenario, "namespace-busy");
		policy_transaction_locked = !strcmp(scenario, "policy-busy-control");
		notifications[0](events[0], contexts[0]);
		assert(active->failed && !controls[5] && !controls[6] &&
		       !active->service->bank[0].runtime && !active->service->bank[1].runtime);
		size = 1;
		assert(get_variable(name, &vendor, NULL, &size, &value) == EFI_NOT_READY);
		return finish();
	}
	assert(published_policy->register_policy(NULL) == EFI_INVALID_PARAMETER &&
	       !policy_transaction_locked);
	union {
		struct variable_policy_entry header;
		uint8_t bytes[70];
	} predicate = {
		.header = {
			.version = VARIABLE_POLICY_REVISION,
			.size = 70,
			.offset_to_name = 66,
			.max_size = 1,
			.lock_policy_type = 3,
		}
	};

	/* Literal header44 + state18 + state-name4 + target-name4. */
	predicate.bytes[62] = 'S';
	predicate.bytes[66] = 'T';
	const size_t before_predicate = calls;

	assert(register_policy(&predicate.header) == EFI_UNSUPPORTED &&
	       calls == before_predicate && active->policy_count == 0 &&
	       !policy_transaction_locked);
	struct {
		struct variable_policy_entry policy;
		CHAR16 name[2];
	} registration = {
		.policy = {
			.version = VARIABLE_POLICY_REVISION,
			.size = sizeof(registration),
			.offset_to_name = sizeof(struct variable_policy_entry),
			.max_size = 1,
		},
		.name = {'Q', 0}
	};
	uint8_t policy_snapshot[sizeof(registration)];

	memcpy(policy_snapshot, &registration, sizeof(registration));
	mutating_policy = &registration.policy;
	struct variable_entry *policy_entry = active;
	EFI_STATUS registered = published_policy->register_policy(&registration.policy);

	if (!strncmp(scenario, "policy-", 7)) {
		const size_t before_calls = calls;
		const size_t before_used =
			policy_entry->service->bank[policy_entry->service->active].used;

		assert(registered == EFI_DEVICE_ERROR && !policy_transaction_locked &&
		       policy_entry->policy_count == 0 && !policy_entry->policy_locked &&
		       !policy_entry->service->bank[0].runtime &&
		       !policy_entry->service->bank[1].runtime);
		if (!strcmp(scenario, "policy-va"))
			assert(active == NULL && conversions == 0);
		size = 1;
		assert(get_variable(name, &vendor, NULL, &size, &value) == EFI_NOT_READY);
		assert(set_variable(name, &vendor, 6, 1, &value) == EFI_NOT_READY &&
		       query_variable(6, &maximum, &remaining, &variable) == EFI_NOT_READY &&
		       register_policy(&registration.policy) ==
			       (active ? EFI_DEVICE_ERROR : EFI_NOT_READY) &&
		       calls == before_calls &&
		       policy_entry->service->bank[policy_entry->service->active].used ==
			       before_used);
		return finish();
	}
	assert(registered == EFI_SUCCESS);
	mutating_policy = NULL;
	assert(registration.policy.size == 0 && active->policy_count == 1 &&
	       !memcmp(active->policy[0], policy_snapshot, sizeof(policy_snapshot)));
	name[0] = 'Q';
	uint8_t too_large[2] = {1, 2};

	assert(set_variable(name, &vendor, 6, sizeof(too_large), too_large) ==
	       EFI_INVALID_PARAMETER);
	fail_operation = CDK2_AUTHVAR_SERVICE_LOCK_POLICY;
	assert(published_policy->lock() == EFI_DEVICE_ERROR && !active->policy_locked);
	fail_operation = 0;
	assert(published_policy->lock() == EFI_SUCCESS && active->policy_locked);
	if (!strcmp(scenario, "ready-fail"))
		fail_operation = CDK2_AUTHVAR_SERVICE_READY_TO_BOOT;
	notifications[2](events[2], contexts[2]);
	notifications[2](events[2], contexts[2]);
	if (!strcmp(scenario, "runtime-fail"))
		fail_operation = CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME;
	if (!strcmp(scenario, "runtime-preclosed"))
		active->protected->failed = true;
	const size_t before_runtime_releases = releases;
	notifications[0](events[0], contexts[0]);
	notifications[0](events[0], contexts[0]);
	if (replacement_scratch) {
		active->protected->client.scratch = original_scratch;
		free(replacement_scratch);
	}
	if (!strcmp(scenario, "runtime-request-drift") ||
	    !strcmp(scenario, "runtime-ready-drift") ||
	    !strcmp(scenario, "runtime-owner-drift") ||
	    !strcmp(scenario, "runtime-scratch-drift") ||
	    !strcmp(scenario, "runtime-other-trigger") ||
	    !strcmp(scenario, "runtime-preclosed")) {
		const size_t before = calls;
		const size_t used = active->service->bank[active->service->active].used;

		assert(active->failed && active->protected->failed &&
		       !active->protected->entered_runtime &&
		       !active->service->bank[0].runtime && !active->service->bank[1].runtime);
		assert(controls[CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME] ==
		       (size_t)(strcmp(scenario, "runtime-preclosed") != 0));
		size = sizeof(value);
		assert(get_variable(name, &vendor, NULL, &size, &value) == EFI_NOT_READY &&
		       set_variable(name, &vendor, 6, 1, &value) == EFI_NOT_READY &&
		       query_variable(6, &maximum, &remaining, &variable) == EFI_NOT_READY &&
		       register_policy(&registration.policy) == EFI_DEVICE_ERROR &&
		       calls == before &&
		       active->service->bank[active->service->active].used == used);
		return finish();
	}
	if (!strcmp(scenario, "ready-fail") || !strcmp(scenario, "runtime-fail")) {
		assert(active->failed && !active->protected->entered_runtime &&
		       !active->service->bank[0].runtime && !active->service->bank[1].runtime);
		assert(controls[5] == 1 && controls[6] == !strcmp(scenario, "runtime-fail"));
		return finish();
	}
	assert(controls[5] == 1 && controls[6] == 1 && active->protected->entered_runtime &&
	       active->service->bank[0].runtime && active->service->bank[1].runtime);
	assert(active->image_policy == NULL && active->image_policy_size == 0 &&
	       active->security_router == NULL && active->namespace.policy_owner_base == NULL &&
	       active->namespace.policy_owner_size == 0 &&
	       releases == before_runtime_releases + 1);
	const size_t before_closed_calls = calls;

	assert(installed_router->authorize_policy(policy_image, sizeof(policy_image)) ==
		       EFI_UNSUPPORTED &&
	       calls == before_closed_calls);
	struct variable_entry *old_entry = active;
	struct cdk2_authvar_runtime_owner *old_owner = active->protected;
	const size_t before_virtual_calls = calls;
	const size_t before_virtual_used = active->service->bank[active->service->active].used;
	if (!strncmp(scenario, "va-alias-", 9)) {
		conversion_alias_at = strstr(scenario, "-entry-")   ? 10 :
				      strstr(scenario, "-service-") ? 11 :
								      12;
		conversion_alias =
			strstr(scenario, "-owner")   ? (void *)old_owner :
			strstr(scenario, "-message") ? (void *)old_owner->runtime.message :
			strstr(scenario, "-scratch") ? (void *)old_owner->client.scratch :
						       (void *)old_owner->client.mailbox_alias;
	}

	if (!strncmp(scenario, "va-", 3)) {
		conversion_failure = strtoul(scenario + 3, NULL, 10);
		if (!strcmp(scenario, "va-namespace-busy"))
			active->namespace.busy = 1;
		if (!strcmp(scenario, "va-policy-busy"))
			policy_transaction_locked = 1;
		if (!strcmp(scenario, "va-owner-poison"))
			active->protected->failed = true;
	}
	notifications[1](events[1], contexts[1]);
	if (!strncmp(scenario, "va-", 3)) {
		assert(active == NULL && old_entry->failed &&
		       conversions == (conversion_alias_at ? 14 : conversion_failure));
		assert(calls == before_virtual_calls &&
		       old_entry->service->bank[old_entry->service->active].used ==
			       before_virtual_used);
		size = 1;
		assert(get_variable(name, &vendor, NULL, &size, &value) == EFI_NOT_READY);
		return finish();
	}
	assert(active && active->protected->converted && conversions == 14);
	test_owned_operands(active);
	if (nonidentity)
		assert(active != old_entry && active->protected != old_owner &&
		       active->service->context == active &&
		       active->namespace.protected_owner == &active->protected->runtime &&
		       active->namespace.ram_owner == active->service &&
		       active->namespace.names == active->names);
	size = 1;
	name[0] = 'V';
	assert(get_variable(name, &vendor, NULL, &size, &value) == EFI_SUCCESS);
	name[0] = 'P';
	size = 1;
	assert(get_variable(name, &vendor, NULL, &size, &value) == EFI_SUCCESS &&
	       value == 0x11);
	return finish();
}
