/* SPDX-License-Identifier: GPL-2.0-only */
#include <cdk2/variable_runtime.h>
#include <cdk2/capsule_runtime_entry.h>
#include <cdk2/capsule_report.h>
#include <pi/boot_mode.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "diagnostic_runtime_guard.h"

#define CHECK(x) do { if (!(x)) { fprintf(stderr, "failed %s:%d: %s\n", \
	__FILE__, __LINE__, #x); exit(EXIT_FAILURE); } } while (0)

typedef EFI_STATUS CDK2_MS_ABI runtime_set_fn(CHAR16 *, EFI_GUID *, UINT32,
	UINTN, void *);
typedef EFI_STATUS CDK2_MS_ABI runtime_get_fn(CHAR16 *, EFI_GUID *, UINT32 *,
	UINTN *, void *);

static UINT8 flash[1024];
static struct cdk2_fvb_protocol_view fvb;
static struct cdk2_ftw_protocol_view ftw;
static void (CDK2_MS_ABI * notifications[2])(void *, void *);
static void *notification_context[2];
static UINTN events, installs, direct_writes, conversions, authenticated_sets;
struct test_policy_entry {
	UINT32 version;
	UINT16 size, name_offset;
	EFI_GUID name_space;
	UINT32 min_size, max_size, must_have, cant_have;
	UINT8 lock_type, padding[3];
} __packed;
struct test_policy_protocol {
	UINT64 revision;
	EFI_STATUS (*disable)(void) CDK2_MS_ABI;
	EFI_STATUS (*enabled)(BOOLEAN *) CDK2_MS_ABI;
	EFI_STATUS (*register_policy)(const struct test_policy_entry *policy) CDK2_MS_ABI;
	void *dump;
	EFI_STATUS (*lock)(void) CDK2_MS_ABI;
};
static struct test_policy_protocol *published_policy;

extern void cdk2_esrt_policy_fixture(void);

EFI_STATUS cdk2_esrt_check_real_policy(const void *rule)
{
	const UINT8 *wire = rule;
	EFI_STATUS status = published_policy->register_policy(rule);

	if (wire[5] == 0 && wire[4] < 102) {
		UINT8 padded[102] __aligned(8) = {0};

		memcpy(padded, wire, wire[4]);
		padded[4] = sizeof(padded);
		CHECK(published_policy->register_policy((const void *)padded) ==
			EFI_INVALID_PARAMETER);
	}
	return status;
}

static EFI_STATUS CDK2_MS_ABI authenticated_set(CHAR16 *name, EFI_GUID *guid,
	UINT32 attributes, UINTN size, void *data)
{
	(void)name;
	(void)guid;
	(void)size;
	(void)data;
	CHECK((attributes &
		CDK2_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS) != 0U);
	authenticated_sets++;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI calculate_crc(void *data, UINTN size,
	UINT32 *result)
{
	CHECK(data != NULL && size == sizeof(struct cdk2_runtime_services_view));
	*result = 0x12345678U;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI convert_pointer(UINTN debug_disposition,
	void **address)
{
	diagnostic_runtime_guard_conversion();
	CHECK(debug_disposition == 0U && address != NULL && *address != NULL);
	conversions++;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI allocate_pool(UINTN type, UINTN size, void **buffer)
{ CHECK(type == 6U); *buffer = calloc(1U, size); return *buffer == NULL ?
	EFI_OUT_OF_RESOURCES : EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI free_pool(void *buffer)
{ free(buffer); return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI locate_handles(UINTN type, EFI_GUID *guid,
					     void *key, UINTN *count, void ***handles)
{ (void)guid; (void)key; CHECK(type == 2U); *handles = malloc(sizeof(void *));
	CHECK(*handles != NULL); (*handles)[0] = &fvb; *count = 1U;
	return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI handle_protocol(void *handle, EFI_GUID *guid,
					      void **protocol)
{ (void)guid; CHECK(handle == &fvb); *protocol = &fvb; return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI locate_protocol(EFI_GUID *guid, void *key,
					      void **protocol)
{ (void)guid; (void)key; *protocol = &ftw; return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI install(void **handle, EFI_GUID *first_guid,
	void *first, EFI_GUID *second_guid, void *second, EFI_GUID *third_guid,
	void *third, void *end)
{
	(void)first_guid;
	(void)first;
	(void)second_guid;
	(void)second;
	(void)third_guid;
	CHECK(third != NULL && end == NULL);
	published_policy = third;
	*handle = (void *)0x1234U;
	installs++;
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI uninstall(void *handle, ...)
{ CHECK(handle == (void *)0x1234U); installs--; return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI create_event(UINT32 type, UINTN tpl, void *notify,
	void *context, const EFI_GUID *group, void **event)
{ (void)group; CHECK((tpl == 8U || tpl == 16U) && events < 2U &&
	type == 0x200U);
	notifications[events] = notify; notification_context[events] = context;
	*event = (void *)(events + 1U); events++; return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI close_event(void *event)
{ (void)event; return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI block_size(void *protocol, UINT64 lba,
	UINTN *size, UINTN *blocks)
{ (void)protocol; CHECK(lba == 0U); *size = 512U; *blocks = 2U;
	return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI read_block(void *protocol, UINT64 lba,
	UINTN offset, UINTN *size, void *buffer)
{ (void)protocol; CHECK(lba < 2U && offset == 0U &&
	(*size == 512U || (lba == 0U && *size == 72U)));
	memcpy(buffer, flash + lba * 512U, *size); return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI write_block(void *protocol, UINT64 lba,
	UINTN offset, UINTN *size, const void *buffer)
{ (void)protocol; CHECK(lba < 2U && offset < 512U);
	memcpy(flash + lba * 512U + offset, buffer, *size); direct_writes++;
	return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI ftw_allocate(void *protocol, EFI_GUID *guid,
					   UINTN private_size, UINTN blocks)
{ (void)protocol; (void)guid; (void)private_size; CHECK(blocks == 1U);
	return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI ftw_write(void *protocol, UINT64 lba,
	UINTN offset, UINTN length, void *private_data, void *handle, void *buffer)
{ (void)protocol; (void)private_data; CHECK(handle == &fvb && offset == 0U &&
	lba == 0U && length == sizeof(flash)); memcpy(flash, buffer, length);
	return EFI_SUCCESS; }
static EFI_STATUS CDK2_MS_ABI ftw_abort(void *protocol)
{ (void)protocol; return EFI_SUCCESS; }

int main(void)
{
	struct cdk2_runtime_services_view runtime = { 0 };
	struct cdk2_boot_services_view boot = { 0 };
	struct cdk2_system_table_view system = { .runtime = &runtime, .boot = &boot };
	struct cdk2_variable_store empty;
	CHAR16 name[] = { 'R', 't', 0U };
	CHAR16 auth_name[] = { 'A', 'u', 0U };
	EFI_GUID guid = { 1U, 0U, 0U, { 0U } };
	EFI_GUID locked_guid = { 2U, 0U, 0U, { 0U } };
	UINT8 value = 0x5aU;
	UINTN region = sizeof(flash) - 72U;
	UINTN policy_writes;
	EFI_STATUS entry_status;
	struct {
		struct test_policy_entry policy;
		CHAR16 name[3];
	} __packed rule = { 0 };
	struct {
		struct test_policy_entry policy;
		UINT8 state[18];
		CHAR16 state_name[3];
	} __packed namespace_rule = { 0 };
	CHAR16 state_name[] = { 'O', 'n', 0U };

	memset(flash, 0xff, sizeof(flash)); memset(flash, 0, 72U);
	flash[48] = 72U;
	flash[32] = 0U; flash[33] = 4U; flash[40] = 0x5fU;
	flash[41] = 0x46U; flash[42] = 0x56U; flash[43] = 0x48U;
	flash[45] = 0x08U;
	CHECK(cdk2_variable_store_init(&empty, 512U) == EFI_SUCCESS &&
		cdk2_variable_export(&empty, flash + 72U, &region) == EFI_SUCCESS);
	fvb.get_block_size = block_size; fvb.read = read_block; fvb.write = write_block;
	ftw.allocate = ftw_allocate; ftw.write = ftw_write; ftw.abort = ftw_abort;
	boot.allocate_pool = (void *)allocate_pool; boot.free_pool = (void *)free_pool;
	boot.handle_protocol = (void *)handle_protocol;
	boot.locate_handle_buffer = (void *)locate_handles;
	boot.locate_protocol = (void *)locate_protocol;
	boot.install_multiple = (void *)install;
	boot.uninstall_multiple = (void *)uninstall;
	boot.create_event_ex = (void *)create_event;
	boot.close_event = (void *)close_event;
	boot.calculate_crc32 = calculate_crc;
	runtime.convert_pointer = (void *)convert_pointer;
	runtime.set_variable = (void *)authenticated_set;
	runtime.header.size = sizeof(runtime);
	entry_status = cdk2_variable_runtime_entry((void *)1U, &system);
	CHECK(entry_status == EFI_SUCCESS &&
		installs == 1U && events == 2U && runtime.set_variable != NULL &&
		published_policy != NULL);
	/* Exercise the real ESRT producer against the real installed consumer,
	 * not only an observer of the producer's packed layout. */
	cdk2_esrt_policy_fixture();
	{
		static EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
		struct cdk2_variable_policy_protocol report_policy = { 0 };
		CHAR16 maximum[11];
		UINTN size = sizeof(maximum);
		UINT32 attributes = 0;
		runtime_get_fn *get = runtime.get_variable;
		runtime_set_fn *set = runtime.set_variable;

		_Static_assert(offsetof(struct cdk2_variable_policy_protocol, register_policy) ==
			offsetof(struct test_policy_protocol, register_policy) &&
			offsetof(struct cdk2_variable_policy_protocol, get_info) == sizeof(*published_policy),
			"real variable policy fixture prefix ABI");
		memcpy(&report_policy, published_policy, sizeof(*published_policy));
		CHECK(cdk2_capsule_report_initialize(&runtime, &report_policy,
			BOOT_WITH_FULL_CONFIGURATION) == EFI_SUCCESS);
		CHECK(get(L"CapsuleMax", &report_guid, &attributes, &size, maximum) == EFI_SUCCESS);
		CHECK(size == 22 && attributes == 6 && memcmp(maximum, L"Capsuleffff", 22) == 0);
		CHECK(set(L"CapsuleMax", &report_guid, 6, 22, maximum) == EFI_WRITE_PROTECTED);
		CHECK(set(L"CapsuleLast", &report_guid, 7, 22, maximum) == EFI_WRITE_PROTECTED);
	}
	rule.policy.version = 0x10000U;
	rule.policy.size = sizeof(rule);
	rule.policy.name_offset = sizeof(rule.policy);
	rule.policy.name_space = guid;
	rule.policy.max_size = MAX_UINT32;
	rule.policy.lock_type = 1U;
	memcpy(rule.name, name, sizeof(name));
	CHECK(published_policy->register_policy(&rule.policy) == EFI_SUCCESS);
	CHECK(published_policy->register_policy(&rule.policy) == EFI_ALREADY_STARTED);
	CHECK(published_policy->disable() == EFI_WRITE_PROTECTED);
	namespace_rule.policy.version = 0x10000U;
	namespace_rule.policy.size = sizeof(namespace_rule);
	namespace_rule.policy.name_offset = sizeof(namespace_rule);
	namespace_rule.policy.name_space = locked_guid;
	namespace_rule.policy.max_size = MAX_UINT32;
	namespace_rule.policy.lock_type = 3U;
	/* EDK2 26.09 VariablePolicy.h: packed GUID at byte 0, value at byte
	 * 16, one padding byte, then the UTF-16 state-variable name. Keep a
	 * byte fixture independent of the implementation's C declaration. */
	static const UINT8 lock_state_wire[18] = {
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x5a, 0
	};
	memcpy(namespace_rule.state, lock_state_wire, sizeof(lock_state_wire));
	memcpy(namespace_rule.state_name, state_name, sizeof(state_name));
	namespace_rule.policy.name_offset -= 2;
	CHECK(published_policy->register_policy(&namespace_rule.policy) == EFI_INVALID_PARAMETER);
	namespace_rule.policy.name_offset += 2;
	CHECK(published_policy->register_policy(&namespace_rule.policy) ==
		EFI_SUCCESS);
	/* Reference layout: a namespace omits the name by Size==OffsetToName.
	 * Literal wire offsets avoid relying on the provider's declaration. */
	static const UINT8 namespace_wire[44] = {
		[2] = 1, [4] = 44, [6] = 44, [8] = 3,
		[28] = 0xff, [29] = 0xff, [30] = 0xff, [31] = 0xff, [40] = 1
	};
	UINT8 policy_wire[52] __aligned(8) = {0};
	EFI_GUID matching_guid = { 3, 0, 0, {0} };
	CHAR16 matching_name[4] = { 'F', '0', '1', 0 };
	memcpy(policy_wire, namespace_wire, sizeof(namespace_wire));
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_SUCCESS);
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_ALREADY_STARTED);
	policy_wire[6] = 0; /* Historical zero-offset representation is invalid. */
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_INVALID_PARAMETER);
	policy_wire[6] = 44;
	policy_wire[4] = 52;
	policy_wire[44] = '#'; policy_wire[46] = '#'; policy_wire[48] = '#';
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_SUCCESS);
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_ALREADY_STARTED);
	policy_wire[50] = 'X'; /* Missing final terminator. */
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_INVALID_PARAMETER);
	policy_wire[50] = 0;
	policy_wire[44] = 'F'; policy_wire[40] = 0;
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_SUCCESS);
	policy_wire[46] = '0'; policy_wire[40] = 1;
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_SUCCESS);
	policy_wire[48] = '1'; policy_wire[40] = 0;
	/* External ABI offsets: exact F01 rule permits requests of one byte,
	 * even when successive APPEND requests produce a larger stored value. */
	policy_wire[24] = 1;
	policy_wire[28] = 1;
	policy_wire[29] = 0; policy_wire[30] = 0; policy_wire[31] = 0;
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_SUCCESS);
	CHECK(((runtime_set_fn *)runtime.set_variable)(matching_name, &matching_guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1, &value) == EFI_SUCCESS);
	UINT32 append_attributes = CDK2_VARIABLE_NON_VOLATILE |
		CDK2_VARIABLE_BOOTSERVICE_ACCESS | CDK2_VARIABLE_RUNTIME_ACCESS |
		CDK2_VARIABLE_APPEND_WRITE;
	UINT8 append_data[2] = { 0x12, 0x34 }, stored_data[4] = {0};
	UINTN stored_size = sizeof(stored_data);
	CHECK(((runtime_set_fn *)runtime.set_variable)(matching_name, &matching_guid,
		append_attributes, 1, append_data) == EFI_SUCCESS);
	CHECK(((runtime_get_fn *)runtime.get_variable)(matching_name, &matching_guid,
		NULL, &stored_size, stored_data) == EFI_SUCCESS && stored_size == 2 &&
		stored_data[0] == value && stored_data[1] == append_data[0]);
	CHECK(((runtime_set_fn *)runtime.set_variable)(matching_name, &matching_guid,
		append_attributes, 2, append_data) == EFI_INVALID_PARAMETER);
	CHECK(((runtime_set_fn *)runtime.set_variable)(matching_name, &matching_guid,
		append_attributes, 0, NULL) == EFI_INVALID_PARAMETER);
	/* Seed one byte before registering a minimum-two-byte namespace rule.
	 * APPEND of one byte must not pass merely because the total would be two. */
	EFI_GUID minimum_guid = { 4, 0, 0, {0} };
	CHAR16 minimum_name[2] = { 'M', 0 };
	CHECK(((runtime_set_fn *)runtime.set_variable)(minimum_name, &minimum_guid,
		append_attributes & ~CDK2_VARIABLE_APPEND_WRITE, 1, &value) == EFI_SUCCESS);
	memcpy(policy_wire, namespace_wire, sizeof(namespace_wire));
	policy_wire[8] = 4; policy_wire[24] = 2; policy_wire[40] = 0;
	policy_wire[32] = 0x40; /* AttributesMustHave includes APPEND_WRITE. */
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_SUCCESS);
	CHECK(((runtime_set_fn *)runtime.set_variable)(minimum_name, &minimum_guid,
		append_attributes, 1, append_data) == EFI_INVALID_PARAMETER);
	CHECK(((runtime_set_fn *)runtime.set_variable)(minimum_name, &minimum_guid,
		append_attributes, 2, append_data) == EFI_SUCCESS);
	CHECK(((runtime_set_fn *)runtime.set_variable)(minimum_name, &minimum_guid,
		append_attributes & ~CDK2_VARIABLE_APPEND_WRITE, 2, append_data) ==
		EFI_INVALID_PARAMETER);
	/* A more specific raw-wire policy forbids APPEND instead; the request
	 * flag must be tested before the store strips it from persisted attributes. */
	policy_wire[4] = 48; policy_wire[6] = 44;
	policy_wire[32] = 0; policy_wire[36] = 0x40;
	policy_wire[44] = 'M'; policy_wire[45] = 0;
	policy_wire[46] = 0; policy_wire[47] = 0;
	CHECK(published_policy->register_policy((const void *)policy_wire) == EFI_SUCCESS);
	CHECK(((runtime_set_fn *)runtime.set_variable)(minimum_name, &minimum_guid,
		append_attributes, 2, append_data) == EFI_INVALID_PARAMETER);
	CHECK(((runtime_set_fn *)runtime.set_variable)(minimum_name, &minimum_guid,
		append_attributes & ~CDK2_VARIABLE_APPEND_WRITE, 2, append_data) == EFI_SUCCESS);
	matching_name[2] = '2';
	CHECK(((runtime_set_fn *)runtime.set_variable)(matching_name, &matching_guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1, &value) == EFI_WRITE_PROTECTED);
	matching_name[1] = '1';
	CHECK(((runtime_set_fn *)runtime.set_variable)(matching_name, &matching_guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1, &value) == EFI_SUCCESS);
	matching_name[0] = 'A';
	CHECK(((runtime_set_fn *)runtime.set_variable)(matching_name, &matching_guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1, &value) == EFI_WRITE_PROTECTED);
	CHECK(published_policy->lock() == EFI_SUCCESS);
	CHECK(published_policy->lock() == EFI_WRITE_PROTECTED);
	CHECK(published_policy->register_policy(&rule.policy) == EFI_WRITE_PROTECTED);
	CHECK(((runtime_set_fn *)runtime.set_variable)(state_name, &guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1U, &value) == EFI_SUCCESS);
	policy_writes = direct_writes;
	notifications[0]((void *)1U, notification_context[0]);
	CHECK(((runtime_set_fn *)runtime.set_variable)(auth_name, &locked_guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1U, &value) == EFI_WRITE_PROTECTED);
	CHECK(((runtime_set_fn *)runtime.set_variable)(name, &guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1U, &value) == EFI_WRITE_PROTECTED &&
		direct_writes == policy_writes);
	CHECK(((runtime_set_fn *)runtime.set_variable)(auth_name, &guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS, 1U, &value) == EFI_SUCCESS &&
		direct_writes != 0U);
	CHECK(((runtime_set_fn *)runtime.set_variable)(name, &guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS |
		CDK2_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS,
		1U, &value) == EFI_WRITE_PROTECTED && authenticated_sets == 0U);
	CHECK(((runtime_set_fn *)runtime.set_variable)(auth_name, &guid,
		CDK2_VARIABLE_NON_VOLATILE | CDK2_VARIABLE_BOOTSERVICE_ACCESS |
		CDK2_VARIABLE_RUNTIME_ACCESS |
		CDK2_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS,
		1U, &value) == EFI_UNSUPPORTED && authenticated_sets == 0U);
	diagnostic_runtime_guard_prepare();
	notifications[1]((void *)2U, notification_context[1]);
	diagnostic_runtime_guard_finish();
	CHECK(conversions == 14U && runtime.header.crc32 == 0x12345678U);
	cdk2_variable_runtime_reset_for_test();
	puts("variable runtime entry tests: PASS");
	return 0;
}
