/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_CAPSULE_CHECK_OUTCOME_H
#define CDK2_CAPSULE_CHECK_OUTCOME_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

/* Private, callback-free object installed beside the real FMP interface. */
#define CDK2_CAPSULE_CHECK_OUTCOME_GUID \
	{ 0x8ad8ed42, 0x6c87, 0x41af, { 0x8e, 0x2b, 0x29, 0x7b, 0x6d, 0x94, 0xb4, 0x09 } }

struct cdk2_capsule_check_outcome {
	const void *protocol;
	const void *image;
	size_t image_size;
	uint64_t generation;
	uint64_t transaction;
	EFI_GUID image_type;
	uint8_t image_index;
	uint8_t digest[32];
	bool signature_refused;
};

/* Opaque references: Core checks their registry ownership before reading them. */
struct cdk2_capsule_process_outcome {
	const void *capsule;
	size_t capsule_size;
	void *fmp_handle;
	const void *fmp_protocol;
	const struct cdk2_capsule_check_outcome *check;
	const void *image;
	size_t image_size;
	size_t payload_index;
	uint8_t image_index;
	uint32_t matching_checks;
	EFI_STATUS failure;
	bool active;
	bool completed;
	bool set_begun;
	bool unproved;
};

#endif
