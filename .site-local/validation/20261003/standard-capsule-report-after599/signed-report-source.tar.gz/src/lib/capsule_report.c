/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#include <cdk2/capsule_report.h>
#include <cdk2/pcat_rtc.h>
#include <pi/boot_mode.h>
#include <string.h>

typedef EFI_STATUS CDK2_MS_ABI report_get_fn(CHAR16 *, EFI_GUID *, UINT32 *,
	UINTN *, void *);
typedef EFI_STATUS CDK2_MS_ABI report_set_fn(CHAR16 *, EFI_GUID *, UINT32,
	UINTN, void *);
typedef EFI_STATUS CDK2_MS_ABI report_time_fn(CDK2_EFI_TIME *, CDK2_TIME_CAPABILITIES *);

static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
static CHAR16 last_name[] = L"CapsuleLast";
static CHAR16 max_name[] = L"CapsuleMax";

_Static_assert(sizeof(CDK2_EFI_TIME) == 16, "capsule report time ABI");
_Static_assert(sizeof(EFI_GUID) == 16 && sizeof(EFI_STATUS) == 8,
	"capsule report GUID/status ABI");

static uint64_t read_last(struct cdk2_runtime_services_view *runtime,
	CHAR16 name[12], uint16_t *index)
{
	UINTN size = 22;
	UINT32 attributes = 0;
	report_get_fn *get = (void *)runtime->get_variable;
	uint64_t status;
	uint16_t value = 0;

	memset(name, 0, 24);
	status = get(last_name, (EFI_GUID *)&report_guid, &attributes, &size, name);
	if (EFI_ERROR(status))
		return status;
	if (size != 22 || attributes != 7 || memcmp(name, L"Capsule", 14) != 0)
		return EFI_COMPROMISED_DATA;
	for (size_t i = 7; i < 11; i++) {
		unsigned int digit;

		if (name[i] >= L'0' && name[i] <= L'9')
			digit = name[i] - L'0';
		else if (name[i] >= L'a' && name[i] <= L'f')
			digit = name[i] - L'a' + 10;
		else if (name[i] >= L'A' && name[i] <= L'F')
			digit = name[i] - L'A' + 10;
		else
			return EFI_COMPROMISED_DATA;
		value = (uint16_t)((value << 4) | digit);
	}
	*index = value;
	return EFI_SUCCESS;
}

static uint64_t write_exact(struct cdk2_runtime_services_view *runtime,
	CHAR16 *name, uint32_t attributes, const void *data, size_t bytes)
{
	uint8_t readback[CDK2_CAPSULE_REPORT_FMP_SIZE];
	UINTN size = bytes;
	UINT32 actual_attributes = 0;
	report_get_fn *get = (void *)runtime->get_variable;
	report_set_fn *set = (void *)runtime->set_variable;
	uint64_t status;

	if (bytes > sizeof(readback))
		return EFI_INVALID_PARAMETER;
	status = set(name, (EFI_GUID *)&report_guid, attributes, bytes, (void *)data);
	if (EFI_ERROR(status))
		return status;
	status = get(name, (EFI_GUID *)&report_guid, &actual_attributes, &size, readback);
	if (EFI_ERROR(status))
		return status;
	return size == bytes && actual_attributes == attributes &&
		memcmp(readback, data, bytes) == 0 ? EFI_SUCCESS : EFI_COMPROMISED_DATA;
}

static uint64_t clear_last(struct cdk2_runtime_services_view *runtime)
{
	report_set_fn *set = (void *)runtime->set_variable;
	report_get_fn *get = (void *)runtime->get_variable;
	UINTN size = 0;
	uint64_t status = set(last_name, (EFI_GUID *)&report_guid, 7, 0, NULL);

	if (EFI_ERROR(status) && status != EFI_NOT_FOUND)
		return status;
	status = get(last_name, (EFI_GUID *)&report_guid, NULL, &size, NULL);
	return status == EFI_NOT_FOUND ? EFI_SUCCESS :
		EFI_ERROR(status) ? status : EFI_COMPROMISED_DATA;
}

static uint64_t lock_name(struct cdk2_variable_policy_protocol *policy, CHAR16 *name)
{
	struct {
		struct cdk2_variable_policy_entry header;
		CHAR16 name[12];
	} rule = { 0 };
	size_t length = 0;

	while (length < 12 && name[length] != 0)
		length++;
	if (length == 12)
		return EFI_INVALID_PARAMETER;
	rule.header.version = 0x10000;
	rule.header.size = sizeof(rule.header) + (length + 1) * sizeof(CHAR16);
	rule.header.offset_to_name = sizeof(rule.header);
	rule.header.name_space = report_guid;
	rule.header.max_size = UINT32_MAX;
	rule.header.lock_policy_type = 1;
	memcpy(rule.name, name, (length + 1) * sizeof(CHAR16));
	return policy->register_policy(&rule.header);
}

uint64_t cdk2_capsule_report_initialize(struct cdk2_runtime_services_view *runtime,
	struct cdk2_variable_policy_protocol *policy, uint32_t boot_mode)
{
	CHAR16 maximum[] = L"Capsuleffff", previous[12];
	uint16_t index;
	report_get_fn *get;
	uint64_t status;

	if (runtime == NULL || runtime->get_variable == NULL || runtime->set_variable == NULL ||
	    policy == NULL || policy->revision != 0x10000 || policy->register_policy == NULL)
		return EFI_UNSUPPORTED;
	get = (void *)runtime->get_variable;
	status = write_exact(runtime, max_name, 6, maximum, 22);
	if (!EFI_ERROR(status))
		status = lock_name(policy, max_name);
	if (EFI_ERROR(status))
		return status;
	if (boot_mode == BOOT_ON_FLASH_UPDATE)
		return clear_last(runtime);
	status = read_last(runtime, previous, &index);
	if (status != EFI_NOT_FOUND) {
		UINTN size = 0;

		if (EFI_ERROR(status))
			return status;
		status = get(previous, (EFI_GUID *)&report_guid, NULL, &size, NULL);
		if (status == EFI_NOT_FOUND)
			status = clear_last(runtime);
		else if (status == EFI_BUFFER_TOO_SMALL && size >= 48)
			status = EFI_SUCCESS;
		else if (!EFI_ERROR(status))
			status = EFI_COMPROMISED_DATA;
		if (EFI_ERROR(status))
			return status;
	}
	return lock_name(policy, last_name);
}

uint64_t cdk2_capsule_report_fmp(struct cdk2_runtime_services_view *runtime,
	const EFI_GUID *capsule_guid, const EFI_GUID *image_type, uint8_t image_index,
	size_t payload_index, uint64_t failure)
{
	uint8_t report[CDK2_CAPSULE_REPORT_FMP_SIZE] = { 0 };
	CDK2_EFI_TIME time = { 0 };
	CHAR16 name[12], maximum[11];
	static const CHAR16 hex[] = L"0123456789abcdef";
	uint16_t index = 0;
	uint32_t total = sizeof(report);
	report_time_fn *get_time;
	report_get_fn *get;
	UINTN maximum_size = sizeof(maximum);
	UINT32 maximum_attributes = 0;
	uint64_t status;

	if (runtime == NULL || runtime->get_variable == NULL || runtime->set_variable == NULL ||
	    runtime->get_time == NULL || capsule_guid == NULL || image_type == NULL ||
	    image_index == 0 || payload_index > UINT8_MAX || !EFI_ERROR(failure))
		return EFI_INVALID_PARAMETER;
	get = (void *)runtime->get_variable;
	status = get(max_name, (EFI_GUID *)&report_guid, &maximum_attributes,
		&maximum_size, maximum);
	if (EFI_ERROR(status))
		return status;
	if (maximum_size != sizeof(maximum) || maximum_attributes != 6 ||
	    memcmp(maximum, L"Capsuleffff", sizeof(maximum)) != 0)
		return EFI_COMPROMISED_DATA;
	status = read_last(runtime, name, &index);
	if (status == EFI_NOT_FOUND)
		index = 0;
	else if (EFI_ERROR(status))
		return status;
	else
		index = (uint16_t)(index + 1U);
	memcpy(name, L"Capsule0000", 24);
	for (size_t i = 0; i < 4; i++)
		name[10 - i] = hex[(index >> (i * 4)) & 15];
	get_time = (void *)runtime->get_time;
	if (EFI_ERROR(get_time(&time, NULL)))
		memset(&time, 0, sizeof(time));
	memcpy(report, &total, sizeof(total));
	memcpy(report + 8, capsule_guid, sizeof(*capsule_guid));
	memcpy(report + 24, &time, sizeof(time));
	memcpy(report + 40, &failure, sizeof(failure));
	report[48] = 1;
	report[50] = payload_index;
	report[51] = image_index;
	memcpy(report + 52, image_type, sizeof(*image_type));
	status = write_exact(runtime, name, 7, report, sizeof(report));
	if (!EFI_ERROR(status))
		status = write_exact(runtime, last_name, 7, name, 22);
	return status;
}
