/* SPDX-License-Identifier: GPL-2.0-only */

#define CONFIG_PAYLOAD_DMA_HANDOFF 1
#include "../src/modules/pci_bus/immutable_entry.c"

#include <stdlib.h>

#define CHECK(condition) do { if (!(condition)) __builtin_trap(); } while (0)

#if CONFIG_CDK2_DIAGNOSTIC
static unsigned int diagnostic_count;
static UINT32 diagnostic_event;
static EFI_STATUS diagnostic_status;

void cdk2_diag_emit(enum cdk2_diag_level level, enum cdk2_diag_module module,
	uint32_t event, EFI_STATUS status)
{
	CHECK(level == CDK2_DIAG_INFO && module == CDK2_DIAG_PCI_BUS);
	diagnostic_count++;
	diagnostic_event = event;
	diagnostic_status = status;
}
#endif

static unsigned int backend_accesses;
static UINT16 backend_command;
static unsigned int root_maps;
static unsigned int root_writes;
static unsigned int root_reads;
static unsigned int fail_read_call;
static unsigned int fail_write_call;
static unsigned int sticky_bme;
static unsigned int protocol_closes;
static unsigned int protocol_opens;
static unsigned int protocol_uninstalls;
static unsigned int child_frees;
static unsigned int fail_close;
static unsigned int fail_uninstall;

static int model_access(void *context, enum cdk2_pci_io_space space, int write,
	unsigned int width, uint64_t address, size_t count, void *buffer)
{
	(void)context;
	(void)space;
	(void)width;
	(void)address;
	(void)count;
	backend_accesses++;
	if (write)
		backend_command = *(UINT16 *)buffer;
	else
		*(UINT16 *)buffer = backend_command;
	return 0;
}

static EFI_STATUS CDK2_MS_ABI test_root_read(struct root_io_protocol *root,
	UINTN width, UINT64 address, UINTN count, void *buffer)
{
	(void)root;
	(void)width;
	(void)address;
	(void)count;
	root_reads++;
	if (root_reads == fail_read_call)
		return EFI_DEVICE_ERROR;
	*(UINT16 *)buffer = backend_command;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_root_write(struct root_io_protocol *root,
	UINTN width, UINT64 address, UINTN count, void *buffer)
{
	(void)root;
	(void)width;
	(void)address;
	(void)count;
	root_writes++;
	if (root_writes == fail_write_call)
		return EFI_DEVICE_ERROR;
	backend_command = *(UINT16 *)buffer;
	if (sticky_bme)
		backend_command |= 4U;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI test_root_map(struct root_io_protocol *root,
	UINTN operation, void *host, UINTN *size, UINT64 *device, void **mapping)
{
	(void)root;
	(void)operation;
	(void)host;
	(void)size;
	(void)device;
	(void)mapping;
	root_maps++;
	return EFI_DEVICE_ERROR;
}

static EFI_STATUS CDK2_MS_ABI test_free(void *buffer)
{
	free(buffer);
	return EFI_SUCCESS;
}

static int test_close_child(void *opaque, void *parent, void *child)
{
	(void)opaque;
	(void)parent;
	(void)child;
	protocol_closes++;
	return fail_close ? -1 : 0;
}

static int test_open_child(void *opaque, void *parent, void *child)
{
	(void)opaque;
	(void)parent;
	(void)child;
	protocol_opens++;
	return 0;
}

static int test_uninstall_child(void *opaque, void *handle,
	struct cdk2_pci_bus_child *child, unsigned int protocols)
{
	(void)opaque;
	(void)handle;
	(void)child;
	(void)protocols;
	protocol_uninstalls++;
	return fail_uninstall ? -1 : 0;
}

static void test_free_child(void *opaque, void *buffer)
{
	(void)opaque;
	child_frees++;
	free(buffer);
}

int main(void)
{
	static UINT8 arena[4U * 4096U] __aligned(4096);
	struct boot_services_view boot = { .free_pool = test_free };
	struct immutable_context entry = { .boot = &boot };
	struct root_io_protocol root = { .pci = { test_root_read, test_root_write },
		.map = test_root_map };
	struct cdk2_pci_bus_child child = { .root_io = &root,
		.entry_context = &entry };
	struct cdk2_pci_bus_child second = { .root_io = &root,
		.entry_context = &entry };
	struct cdk2_pci_io_model denied = { .dma_contract = 1U,
		.supported_attributes = 0x700U, .backend = { .access = model_access } };
	UINT8 host[128], output[128];
	UINT16 command = 4U;
	uint64_t device;
	void *mapping;
	size_t size;
	void *buffer;
	UINT8 dma_bytes[sizeof(struct cdk2_dma_handoff_hob) +
		2U * sizeof(struct dma_handoff_requester)] = {0};
	struct cdk2_dma_handoff_hob *dma_hob = (void *)dma_bytes;
	struct cdk2_pci_root_bridges_hob roots = { .producer_generation = 9U };
	struct immutable_context dma_entry = { .dma = dma_hob,
		.dma_size = sizeof(dma_bytes), .roots = &roots };

	memset(host, 0x5a, sizeof(host));
	memset(output, 0, sizeof(output));
	CHECK(cdk2_pci_io_access(&denied, CDK2_PCI_IO_CONFIG, 1, 0U, 4U, 1U, 1U,
		&command) != 0 && backend_accesses == 0U);
	CHECK(cdk2_pci_io_attributes(&denied, 2U, 0x400U, NULL) != 0 &&
		backend_accesses == 0U);
	denied.dma_authorized = 1U;
	CHECK(cdk2_pci_io_access(&denied, CDK2_PCI_IO_CONFIG, 1, 0U, 4U, 1U, 1U,
		&command) == 0 && backend_accesses == 1U && denied.dma_bme_owned);
	denied.dma_authorized = 0U;

	dma_hob->revision = CDK2_DMA_HANDOFF_HOB_REVISION;
	dma_hob->length = sizeof(dma_bytes);
	dma_hob->requester_count = 2U;
	dma_hob->generation = 9U;
	for (UINT32 index = 0U; index < 2U; index++)
		dma_hob->requesters[index] = (struct dma_handoff_requester) {
			.segment = 0U, .bdf = (UINT16)(0x18U + index * 8U),
			.protection_domain = (UINT16)(index + 1U),
			.flags = DMA_HANDOFF_REQUESTER_FLAGS,
			.arena_cpu_base = (UINTN)arena + (UINT64)index * 4096U,
			.arena_device_base = 0x90000000U,
			.arena_pages = 1U, .arena_flags = DMA_HANDOFF_ARENA_FLAGS };
	CHECK(validate_dma_payload(&dma_entry) == 0);
	dma_hob->generation++;
	CHECK(validate_dma_payload(&dma_entry) != 0);
	dma_hob->generation--;
	dma_hob->requesters[1].bdf = dma_hob->requesters[0].bdf;
	CHECK(validate_dma_payload(&dma_entry) != 0);
	dma_hob->requesters[1].bdf = 0x20U;
	dma_hob->requesters[1].arena_cpu_base =
		dma_hob->requesters[0].arena_cpu_base;
	CHECK(validate_dma_payload(&dma_entry) != 0);
	dma_hob->requesters[1].arena_cpu_base = (UINTN)arena + 4096U;
	dma_hob->requesters[1].arena_flags ^= DMA_HANDOFF_ARENA_WRITE;
	CHECK(validate_dma_payload(&dma_entry) != 0);
	dma_hob->requesters[1].arena_flags ^= DMA_HANDOFF_ARENA_WRITE;
	CHECK(validate_dma_payload(&dma_entry) == 0);
	child.io_status = EFI_SUCCESS;
	size = sizeof(host);
	CHECK(io_map(&child, 0U, host, &size, &device, &mapping) != 0 &&
		child.io_status == EFI_ACCESS_DENIED && root_maps == 0U);
	CHECK(io_allocate_buffer(&child, 0U, 4U, 1U, 0U) == NULL &&
		child.io_status == EFI_ACCESS_DENIED);

	child.dma = calloc(1U, sizeof(*child.dma));
	CHECK(child.dma != NULL);
	child.dma->cpu_base = (UINTN)arena;
	child.dma->device_base = 0x80000000U;
	child.dma->pages = 4U;
	child.dma->authorized = 1U;
	child.io_model.dma_contract = 1U;
	child.io_model.dma_authorized = 1U;

	size = sizeof(host);
	CHECK(io_map(&child, 0U, host, &size, &device, &mapping) == 0 &&
		mapping != NULL && device == child.dma->device_base &&
		memcmp(arena, host, sizeof(host)) == 0 && root_maps == 0U);
	CHECK(io_unmap(&child, mapping) == 0 && arena[0] == 0U);
	size = sizeof(output);
	CHECK(io_map(&child, 1U, output, &size, &device, &mapping) == 0);
	memset(arena, 0xa5, sizeof(output));
	CHECK(io_unmap(&child, mapping) == 0 && output[0] == 0xa5U &&
		arena[0] == 0U);

	size = 64U;
	CHECK(io_map(&child, 0U, arena + 33U, &size, &device, &mapping) == 0 &&
		mapping == NULL && device == child.dma->device_base + 33U);
	buffer = io_allocate_buffer(&child, 0U, 4U, 2U, 0U);
	CHECK(buffer == arena);
	CHECK(io_free_buffer(&child, 2U, buffer) == 0);
	CHECK(io_free_buffer(&child, 2U, buffer) != 0);

	buffer = io_allocate_buffer(&child, 0U, 4U, 1U, 0U);
	CHECK(buffer == arena);
	memset(buffer, 0xcc, 4096U);
	child.io_model.dma_bme_owned = 1U;
	backend_command = 7U;
	child.function.bus = 0U;
	child.function.device = 3U;
	fail_read_call = root_reads + 1U;
	CHECK(quiesce_io_function(&entry, &child.function) != 0 &&
		child.dma != NULL && child.dma->authorized &&
		child.dma->extent[0].kind == 1U && arena[0] == 0xccU &&
		root_writes == 0U);
	fail_read_call = 0U;
	fail_write_call = root_writes + 1U;
	CHECK(quiesce_io_function(&entry, &child.function) != 0 &&
		child.dma != NULL && child.dma->authorized &&
		child.dma->extent[0].kind == 1U && arena[0] == 0xccU);
	fail_write_call = 0U;
	sticky_bme = 1U;
	CHECK(quiesce_io_function(&entry, &child.function) != 0 &&
		child.io_model.dma_bme_owned && child.dma != NULL &&
		child.dma->authorized && child.dma->extent[0].kind == 1U &&
		arena[0] == 0xccU && (backend_command & 4U) != 0U);
	sticky_bme = 0U;

	second.dma = calloc(1U, sizeof(*second.dma));
	CHECK(second.dma != NULL);
	second.dma->cpu_base = (UINTN)arena + 4096U;
	second.dma->device_base = 0x81000000U;
	second.dma->pages = 1U;
	second.dma->authorized = 1U;
	second.io_model.dma_authorized = 1U;
	second.io_model.dma_bme_owned = 1U;
	second.function.class_code = 1U; /* NVMe/storage and generic use one path. */
	second.function.subclass = 8U;
	second.function.device = 4U;
	second.dma->extent[0] = (struct cdk2_pci_dma_extent) {
		.pages = 1U, .kind = 1U };
	memset(arena + 4096U, 0xdd, 4096U);
	arena[3U * 4096U] = 0xabU;
	context.driver.binding.children[0] = &child;
	context.driver.binding.children[1] = &second;
	context.driver.binding.child_count = 2U;
	context.dma_control = (struct cdk2_pci_dma_control) {
		.revision = CDK2_PCI_DMA_CONTROL_REVISION,
		.quiesce_all = quiesce_all_dma };
	CHECK(quiesce_all_dma(NULL) == EFI_INVALID_PARAMETER);
	{
		struct cdk2_pci_dma_control forged = context.dma_control;

		CHECK(quiesce_all_dma(&forged) == EFI_INVALID_PARAMETER);
	}
	fail_read_call = root_reads + 1U;
	CHECK(quiesce_all_dma(&context.dma_control) == EFI_DEVICE_ERROR &&
		context.driver.binding.child_count == 2U && child.dma != NULL &&
		second.dma != NULL && child.dma->authorized &&
		second.dma->authorized && child.dma->extent[0].kind == 1U &&
		second.dma->extent[0].kind == 1U && arena[0] == 0xccU &&
		arena[4096U] == 0xddU && arena[3U * 4096U] == 0xabU);
	/* Synchronous pre-EBS control preserves quarantine bookkeeping on failure,
	 * then clears all BME and invalidates all extents on a retry. */
	fail_read_call = 0U;
	CHECK(quiesce_all_dma(&context.dma_control) == EFI_SUCCESS &&
		!child.dma->authorized && !second.dma->authorized &&
		child.dma->extent[0].kind == 0U && second.dma->extent[0].kind == 0U &&
		arena[0] == 0U && arena[4096U] == 0U && arena[3U * 4096U] == 0U);
#if CONFIG_CDK2_DIAGNOSTIC
	CHECK(diagnostic_count == 1U &&
		diagnostic_event == CDK2_EVENT_PCI_DMA_QUIESCE &&
		diagnostic_status == EFI_SUCCESS);
#endif
	release_io_function(&entry, &child.function);
	CHECK(child.dma == NULL && (backend_command & 4U) == 0U);
	release_io_function(&entry, &second.function);
	CHECK(second.dma == NULL);

	{
		struct cdk2_pci_bus_binding binding = { .services = {
			.context = &entry, .free = test_free_child,
			.uninstall = test_uninstall_child,
			.open_parent_by_child = test_open_child,
			.close_parent_by_child = test_close_child,
			.quiesce_function = quiesce_io_function,
			.release_function = release_io_function } };
		struct cdk2_pci_bus_child *retry = calloc(1U, sizeof(*retry));
		void *parent = &binding;

		CHECK(retry != NULL);
		retry->parent = parent;
		retry->handle = retry;
		retry->root_io = &root;
		retry->entry_context = &entry;
		retry->parent_open = 1U;
		retry->installed = CDK2_PCI_CHILD_PCI_IO;
		retry->dma = calloc(1U, sizeof(*retry->dma));
		CHECK(retry->dma != NULL);
		retry->dma->cpu_base = (UINTN)arena;
		retry->dma->pages = 1U;
		retry->dma->authorized = 1U;
		retry->dma->extent[0] = (struct cdk2_pci_dma_extent) {
			.pages = 1U, .kind = 1U };
		retry->io_model.dma_bme_owned = 1U;
		memset(arena, 0xee, 4096U);
		binding.children[0] = retry;
		binding.child_count = 1U;
		backend_command = 7U;
		sticky_bme = 1U;
		CHECK(cdk2_pci_bus_stop(&binding, parent, NULL, 0U) != 0 &&
			binding.child_count == 1U && retry->dma != NULL &&
			retry->dma->authorized && retry->dma->extent[0].kind == 1U &&
			arena[0] == 0xeeU && protocol_closes == 0U &&
			protocol_uninstalls == 0U && child_frees == 0U);
		sticky_bme = 0U;
		fail_close = 1U;
		CHECK(cdk2_pci_bus_stop(&binding, parent, NULL, 0U) != 0 &&
			binding.child_count == 1U && retry->dma != NULL &&
			retry->dma->authorized && retry->dma->extent[0].kind == 1U &&
			arena[0] == 0xeeU && protocol_closes == 1U &&
			protocol_uninstalls == 0U && child_frees == 0U);
		fail_close = 0U;
		fail_uninstall = 1U;
		CHECK(cdk2_pci_bus_stop(&binding, parent, NULL, 0U) != 0 &&
			binding.child_count == 1U && retry->dma != NULL &&
			retry->dma->authorized && retry->dma->extent[0].kind == 1U &&
			arena[0] == 0xeeU && protocol_closes == 2U &&
			protocol_uninstalls == 1U && child_frees == 0U &&
			protocol_opens == 1U && retry->parent_open);
		fail_uninstall = 0U;
		CHECK(cdk2_pci_bus_stop(&binding, parent, NULL, 0U) == 0 &&
			binding.child_count == 0U && protocol_closes == 3U &&
			protocol_uninstalls == 2U && child_frees == 1U &&
			arena[0] == 0U);
	}
	return 0;
}
