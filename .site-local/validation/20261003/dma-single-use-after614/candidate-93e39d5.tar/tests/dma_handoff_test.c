/* SPDX-License-Identifier: GPL-2.0-only */

#include "coreboot.h"
#include "coreboot_checksum.h"

#include <cdk2/dma_handoff.h>
#include <string.h>
#include <unistd.h>

#define GENERATION 0x1122334455667788ULL
#define REQUESTER_COUNT 3U
#define CHECK(condition) do { if (!(condition)) __builtin_trap(); } while (0)

struct test_resource_handoff {
	struct cb_payload_resource_handoff header;
	struct cb_payload_resource_section section[2];
	struct cb_prh_pci_topology_entry topology[DMA_HANDOFF_MAX_REQUESTERS];
	struct cb_prh_boot_intent_entry boot[DMA_HANDOFF_MAX_REQUESTERS];
} __packed;

static struct cb_dma_handoff reference;
static struct test_resource_handoff resource;
static EFI_STATUS find_status;
static BOOLEAN hide_boot_intent;

EFI_STATUS cdk2_coreboot_find_unique_record(
	const struct cdk2_coreboot_handoff *handoff, UINT32 tag,
	UINT32 minimum_size, const void **record)
{
	(void)handoff;
	CHECK(tag == CB_TAG_DMA_HANDOFF);
	CHECK(minimum_size == sizeof(reference));
	if (EFI_ERROR(find_status))
		return find_status;
	*record = &reference;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_coreboot_find_payload_resource_section(
	const struct cdk2_coreboot_handoff *handoff, UINT16 type,
	const struct cb_payload_resource_section **section)
{
	CHECK(handoff != NULL && section != NULL);
	if (type == CB_PRH_SECTION_PCI_TOPOLOGY) {
		*section = &resource.section[0];
		return EFI_SUCCESS;
	}
	if (type == CB_PRH_SECTION_BOOT_INTENT && !hide_boot_intent) {
		*section = &resource.section[1];
		return EFI_SUCCESS;
	}
	return EFI_NOT_FOUND;
}

static void setup_resource(void)
{
	memset(&resource, 0, sizeof(resource));
	resource.header.revision = CB_PAYLOAD_RESOURCE_HANDOFF_REVISION_4;
	resource.header.producer_generation.lo = (UINT32)GENERATION;
	resource.header.producer_generation.hi = (UINT32)(GENERATION >> 32);
	resource.section[0] = (struct cb_payload_resource_section) {
		.type = CB_PRH_SECTION_PCI_TOPOLOGY,
		.entry_size = sizeof(resource.topology[0]),
		.entry_count = REQUESTER_COUNT,
		.offset = OFFSET_OF(struct test_resource_handoff, topology),
		.length = REQUESTER_COUNT * sizeof(resource.topology[0]),
	};
	resource.section[1] = (struct cb_payload_resource_section) {
		.type = CB_PRH_SECTION_BOOT_INTENT,
		.entry_size = sizeof(resource.boot[0]),
		.entry_count = REQUESTER_COUNT,
		.offset = OFFSET_OF(struct test_resource_handoff, boot),
		.length = REQUESTER_COUNT * sizeof(resource.boot[0]),
	};
	resource.topology[0] = (struct cb_prh_pci_topology_entry) {
		.segment = 0, .bus = 0, .device = 3, .function = 0,
	};
	resource.topology[1] = (struct cb_prh_pci_topology_entry) {
		.segment = 0, .bus = 1, .device = 0, .function = 0,
	};
	resource.topology[2] = (struct cb_prh_pci_topology_entry) {
		.segment = 0, .bus = 0, .device = 4, .function = 0,
	};
	for (UINT16 index = 0U; index < REQUESTER_COUNT; index++)
		resource.boot[index].topology_index = index;
	hide_boot_intent = FALSE;
}

static void refresh_crc(struct dma_handoff_header *header)
{
	header->crc32 = 0U;
	header->crc32 = cdk2_coreboot_calculate_crc32(header, header->size);
}

static UINT32 make_blob(UINT8 *blob)
{
	struct dma_handoff_header *header = (void *)blob;
	struct dma_handoff_requester *requesters;

	memset(blob, 0, 512);
	*header = (struct dma_handoff_header) {
		.revision = DMA_HANDOFF_REVISION,
		.size = sizeof(*header) + REQUESTER_COUNT * sizeof(*requesters),
		.header_size = sizeof(*header),
		.requester_size = sizeof(*requesters),
		.flags = DMA_HANDOFF_REQUIRED_FLAGS,
		.granule_shift = DMA_HANDOFF_GRANULE_SHIFT,
		.requester_count = REQUESTER_COUNT,
		.generation = GENERATION,
	};
	requesters = (void *)(blob + sizeof(*header));
	requesters[0] = (struct dma_handoff_requester) {
		.segment = 0, .bdf = 0x18, .protection_domain = 1,
		.flags = DMA_HANDOFF_REQUESTER_FLAGS,
		.arena_cpu_base = 0x200000, .arena_device_base = 0x800000,
		.arena_pages = 1, .arena_flags = DMA_HANDOFF_ARENA_FLAGS,
	};
	requesters[1] = (struct dma_handoff_requester) {
		.segment = 0, .bdf = 0x100, .protection_domain = 2,
		.flags = DMA_HANDOFF_REQUESTER_FLAGS,
		.arena_cpu_base = 0x204000, .arena_device_base = 0x800000,
		.arena_pages = 2, .arena_flags = DMA_HANDOFF_ARENA_FLAGS,
	};
	requesters[2] = (struct dma_handoff_requester) {
		.segment = 0, .bdf = 0x20, .protection_domain = 3,
		.flags = DMA_HANDOFF_REQUESTER_FLAGS,
		.arena_cpu_base = 0x208000, .arena_device_base = 0xa00000,
		.arena_pages = 3, .arena_flags = DMA_HANDOFF_ARENA_FLAGS,
	};
	refresh_crc(header);
	return header->size;
}

static EFI_STATUS consume(UINT8 *blob, UINT32 bytes,
	struct cdk2_dma_handoff_state *state)
{
	struct cdk2_coreboot_handoff coreboot = {
		.payload_resource_handoff_status = EFI_SUCCESS,
		.payload_resource_handoff = &resource.header,
	};

	reference = (struct cb_dma_handoff) {
		.tag = CB_TAG_DMA_HANDOFF,
		.size = sizeof(reference),
		.address = (UINTN)blob,
		.bytes = bytes,
		.revision = DMA_HANDOFF_REVISION,
	};
	find_status = EFI_SUCCESS;
	return cdk2_dma_handoff_consume(&coreboot, (UINTN)blob, bytes, state);
}

static void directory_tests(UINT8 *blob, UINT32 bytes)
{
	UINT8 table[sizeof(struct cb_header) + 2 * sizeof(struct cb_cbmem_entry)];
	UINT8 legacy[DYN_CBMEM_ALIGN_SIZE] = {0};
	struct cb_header *header = (void *)table;
	struct cb_cbmem_entry *entry = (void *)(header + 1);
	struct cbmem_root *legacy_root = (void *)legacy;
	struct cdk2_coreboot_handoff coreboot = {
		.payload_resource_handoff_status = EFI_SUCCESS,
		.payload_resource_handoff = &resource.header,
	};
	struct cdk2_dma_handoff_state state;
	uint64_t base = 0U;
	UINT64 address = (UINTN)blob;
	uint32_t size = 0U;

	memset(table, 0, sizeof(table));
	header->header_bytes = sizeof(*header);
	entry[0] = (struct cb_cbmem_entry) {
		.tag = CB_TAG_CBMEM_ENTRY,
		.size = sizeof(*entry),
		.address = { (UINT32)address, (UINT32)(address >> 32) },
		.entry_size = bytes,
		.id = CBMEM_ID_DMA_HANDOFF,
	};
	coreboot.header = header;
	coreboot.table_size = sizeof(*header) + sizeof(*entry);
	coreboot.record_count = 1U;
	reference = (struct cb_dma_handoff) {
		.tag = CB_TAG_DMA_HANDOFF,
		.size = sizeof(reference),
		.address = (UINTN)blob,
		.bytes = bytes,
		.revision = DMA_HANDOFF_REVISION,
	};
	find_status = EFI_SUCCESS;
	CHECK(cdk2_dma_handoff_find_blob(&coreboot, sizeof(struct dma_handoff_header),
		&base, &size) == EFI_SUCCESS);
	CHECK(base == (EFI_PHYSICAL_ADDRESS)(UINTN)blob && size == bytes);
	CHECK(cdk2_dma_handoff_import(&coreboot, &state) == EFI_SUCCESS);
	CHECK(state.valid);

	entry[1] = entry[0];
	coreboot.table_size = sizeof(table);
	coreboot.record_count = 2U;
	CHECK(cdk2_dma_handoff_find_blob(&coreboot, sizeof(struct dma_handoff_header),
		&base, &size) == EFI_COMPROMISED_DATA);
	CHECK(cdk2_dma_handoff_import(&coreboot, &state) == EFI_COMPROMISED_DATA);
	CHECK(!state.valid);

	entry[0].id = CBMEM_ID_SMBIOS;
	coreboot.table_size = sizeof(*header) + sizeof(*entry);
	coreboot.record_count = 1U;
	legacy_root->max_entries = 1U;
	legacy_root->num_entries = 1U;
	legacy_root->entries[0] = (struct cbmem_entry) {
		.magic = CBMEM_ENTRY_MAGIC,
		.start = (UINT32)(UINTN)blob,
		.size = bytes,
		.id = CBMEM_ID_DMA_HANDOFF,
	};
	coreboot.memory_range_count = 1U;
	coreboot.memory_ranges[0] = (struct cdk2_coreboot_memory_range) {
		.base = (UINTN)legacy,
		.size = sizeof(legacy),
		.type = CB_MEM_TABLE,
	};
	CHECK(cdk2_dma_handoff_find_blob(&coreboot, sizeof(struct dma_handoff_header),
		&base, &size) == EFI_NOT_FOUND);
	CHECK(cdk2_dma_handoff_import(&coreboot, &state) == EFI_NOT_FOUND);
	CHECK(!state.valid);
}

static void reject_mutations(void)
{
	UINT8 blob[512];
	struct dma_handoff_header *header = (void *)blob;
	struct dma_handoff_requester *requesters;
	struct cdk2_dma_handoff_state state;
	UINT32 bytes = make_blob(blob);

#define REJECT(member, value) do { \
	__typeof__(header->member) saved = header->member; \
	header->member = (value); \
	refresh_crc(header); \
	CHECK(consume(blob, bytes, &state) == EFI_COMPROMISED_DATA); \
	CHECK(!state.valid); \
	header->member = saved; \
	refresh_crc(header); \
} while (0)
	REJECT(revision, 1U);
	REJECT(size, bytes - 1U);
	REJECT(header_size, sizeof(*header) - 1U);
	REJECT(requester_size, sizeof(struct dma_handoff_requester) - 1U);
	REJECT(flags, header->flags | (1U << 15));
	REJECT(granule_shift, DMA_HANDOFF_GRANULE_SHIFT + 1U);
	REJECT(requester_count, DMA_HANDOFF_MAX_REQUESTERS + 1U);
	REJECT(generation, 0U);
	REJECT(reserved[1], 1U);
#undef REJECT
	header->crc32 ^= 1U;
	CHECK(consume(blob, bytes, &state) == EFI_COMPROMISED_DATA);
	header->crc32 ^= 1U;
	CHECK(consume(blob, bytes - 1U, &state) == EFI_COMPROMISED_DATA);
	CHECK(consume(blob, 1U, &state) == EFI_COMPROMISED_DATA);
	requesters = (void *)(blob + sizeof(*header));

#define REJECT_REQUESTER(statement) do { \
	statement; \
	refresh_crc(header); \
	CHECK(consume(blob, bytes, &state) == EFI_COMPROMISED_DATA); \
	CHECK(!state.valid); \
} while (0)
	REJECT_REQUESTER(requesters[1].bdf = requesters[0].bdf);
	requesters[1].bdf = 0x100;
	REJECT_REQUESTER(requesters[1].protection_domain =
		requesters[0].protection_domain);
	requesters[1].protection_domain = 2U;
	REJECT_REQUESTER(requesters[0].arena_flags ^= DMA_HANDOFF_ARENA_WRITE);
	requesters[0].arena_flags ^= DMA_HANDOFF_ARENA_WRITE;
	REJECT_REQUESTER(requesters[0].arena_cpu_base++);
	requesters[0].arena_cpu_base--;
	REJECT_REQUESTER(requesters[0].arena_pages = 0U);
	requesters[0].arena_pages = 1U;
	REJECT_REQUESTER(requesters[1].arena_cpu_base =
		requesters[0].arena_cpu_base);
	requesters[1].arena_cpu_base = 0x204000;
	REJECT_REQUESTER(requesters[0].arena_device_base = MAX_UINT64 - 4095U);
	requesters[0].arena_device_base = 0x800000;
	REJECT_REQUESTER(requesters[0].arena_cpu_base =
		(UINTN)blob & ~(UINT64)((1U << DMA_HANDOFF_GRANULE_SHIFT) - 1U));
	requesters[0].arena_cpu_base = 0x200000;
#undef REJECT_REQUESTER
	/* Distinct protection domains may deliberately reuse the same IOVA. */
	requesters[1].arena_device_base = requesters[0].arena_device_base;
	refresh_crc(header);
	CHECK(consume(blob, bytes, &state) == EFI_SUCCESS);
	requesters[1].arena_device_base = 0x800000;
	requesters[0].bdf = 0x28;
	refresh_crc(header);
	CHECK(consume(blob, bytes, &state) == EFI_SECURITY_VIOLATION);
	requesters[0].bdf = 0x18;
	resource.topology[0].command = 4U;
	refresh_crc(header);
	CHECK(consume(blob, bytes, &state) == EFI_SECURITY_VIOLATION);
	resource.topology[0].command = 0U;
	hide_boot_intent = TRUE;
	CHECK(consume(blob, bytes, &state) == EFI_SECURITY_VIOLATION);
	hide_boot_intent = FALSE;
	header->requester_count--;
	header->size -= sizeof(*requesters);
	refresh_crc(header);
	CHECK(consume(blob, header->size, &state) == EFI_SECURITY_VIOLATION);
	header->requester_count++;
	header->size = bytes;
	refresh_crc(header);
}

static void maximum_requester_test(void)
{
	static UINT8 blob[sizeof(struct dma_handoff_header) +
		DMA_HANDOFF_MAX_REQUESTERS * sizeof(struct dma_handoff_requester)];
	static struct cdk2_dma_handoff_state state;
	struct dma_handoff_header *header = (void *)blob;
	struct dma_handoff_requester *requesters = (void *)(header + 1);

	memset(blob, 0, sizeof(blob));
	*header = (struct dma_handoff_header) {
		.revision = DMA_HANDOFF_REVISION,
		.size = sizeof(blob),
		.header_size = sizeof(*header),
		.requester_size = sizeof(*requesters),
		.flags = DMA_HANDOFF_REQUIRED_FLAGS,
		.granule_shift = DMA_HANDOFF_GRANULE_SHIFT,
		.requester_count = DMA_HANDOFF_MAX_REQUESTERS,
		.generation = GENERATION,
	};
	resource.section[0].entry_count = DMA_HANDOFF_MAX_REQUESTERS;
	resource.section[0].length = sizeof(resource.topology);
	resource.section[1].entry_count = DMA_HANDOFF_MAX_REQUESTERS;
	resource.section[1].length = sizeof(resource.boot);
	for (UINT32 index = 0U; index < DMA_HANDOFF_MAX_REQUESTERS; index++) {
		requesters[index] = (struct dma_handoff_requester) {
			.bdf = (UINT16)index,
			.protection_domain = (UINT16)(index + 1U),
			.flags = DMA_HANDOFF_REQUESTER_FLAGS,
			.arena_cpu_base = 0x100000U + (UINT64)index * 4096U,
			.arena_device_base = 0x80000000U,
			.arena_pages = 1U,
			.arena_flags = DMA_HANDOFF_ARENA_FLAGS,
		};
		resource.topology[index] = (struct cb_prh_pci_topology_entry) {
			.bus = (UINT8)(index >> 8),
			.device = (UINT8)((index >> 3) & 0x1fU),
			.function = (UINT8)(index & 7U),
		};
		resource.boot[index].topology_index = (UINT16)index;
	}
	refresh_crc(header);
	CHECK(consume(blob, sizeof(blob), &state) == EFI_SUCCESS);
	CHECK(state.valid && state.requester_count == DMA_HANDOFF_MAX_REQUESTERS);
	setup_resource();
}

int main(int argc, char **argv)
{
	UINT8 blob[512];
	struct cdk2_dma_handoff_state state;
	UINT32 bytes;
	UINT64 copied_base;

	setup_resource();
	bytes = make_blob(blob);
	if (argc == 2 && !strcmp(argv[1], "--fixture")) {
		struct dma_handoff_header *header = (void *)blob;

		header->requester_count = 2U;
		header->size = sizeof(*header) +
			2U * sizeof(struct dma_handoff_requester);
		refresh_crc(header);
		bytes = header->size;
		return write(STDOUT_FILENO, blob, bytes) == (ssize_t)bytes ? 0 : 1;
	}
	CHECK(argc == 1);
	directory_tests(blob, bytes);
	CHECK(consume(blob, bytes, &state) == EFI_SUCCESS);
	CHECK(state.valid && state.requester_count == REQUESTER_COUNT);
	copied_base = state.requesters[0].arena_cpu_base;
	memset(blob, 0, bytes);
	CHECK(state.requesters[0].arena_cpu_base == copied_base);
	bytes = make_blob(blob);
	reject_mutations();
	maximum_requester_test();

	resource.header.producer_generation.lo++;
	CHECK(consume(blob, bytes, &state) == EFI_SECURITY_VIOLATION);
	CHECK(!state.valid);
	resource.header.producer_generation.lo--;
	find_status = EFI_NOT_FOUND;
	{
		struct cdk2_coreboot_handoff coreboot = {
			.payload_resource_handoff_status = EFI_SUCCESS,
			.payload_resource_handoff = &resource.header,
		};
		CHECK(cdk2_dma_handoff_consume(&coreboot, (UINTN)blob, bytes, &state) ==
			EFI_SECURITY_VIOLATION);
		CHECK(!state.valid);
	}
	resource.header.revision = CB_PAYLOAD_RESOURCE_HANDOFF_REVISION;
	CHECK(consume(blob, bytes, &state) == EFI_SECURITY_VIOLATION);
	return 0;
}
