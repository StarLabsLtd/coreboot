#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM

build_and_run() {
	name=$1
	shift
	cc -std=gnu11 -Wall -Wextra -Werror -ffunction-sections -fdata-sections \
		-I"$root/include" -I"$root/src/boot" "$@" \
		"$root/tests/dma_handoff_test.c" \
		"$root/src/boot/coreboot_dma_handoff.c" \
		"$root/src/boot/coreboot_checksum.c" -Wl,--gc-sections \
		-o "$temporary/$name"
	"$temporary/$name"
}

build_and_run ordinary
build_and_run optimized -O2
build_and_run sanitized -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer

cc -std=gnu11 -O2 -Wall -Wextra -Werror -Wframe-larger-than=1024 \
	-I"$root/include" -I"$root/src/boot" \
	-c "$root/src/boot/coreboot_dma_handoff.c" \
	-o "$temporary/coreboot-dma-handoff.o"

for diagnostic in 0 1; do
	mkdir -p "$temporary/include-$diagnostic/cdk2"
	printf '#define CONFIG_CDK2_DIAGNOSTIC %s\n' "$diagnostic" \
		> "$temporary/include-$diagnostic/cdk2/config.h"
	cc -std=gnu11 -O2 -Wall -Wextra -Werror -ffunction-sections -fdata-sections \
		-I"$temporary/include-$diagnostic" -I"$root/include" -I"$root/src/boot" \
		"$root/tests/pci_dma_arena_test.c" \
		"$root/src/modules/pci_bus/pci_io.c" \
		"$root/src/modules/pci_bus/binding.c" \
		"$root/src/modules/pci_bus/immutable.c" -Wl,--gc-sections \
		-o "$temporary/pci-dma-arena-$diagnostic"
	"$temporary/pci-dma-arena-$diagnostic"
done

sed 's/if (state->generation != unpack64/if (FALSE \&\& state->generation != unpack64/' \
	"$root/src/boot/coreboot_dma_handoff.c" > \
	"$temporary/coreboot-dma-handoff-generation-mutant.c"
if cmp -s "$temporary/coreboot-dma-handoff-generation-mutant.c" \
	"$root/src/boot/coreboot_dma_handoff.c"; then
	echo 'ERROR: consumer-generation mutant changed nothing' >&2
	exit 1
fi
cc -std=gnu11 -O1 -g -Wall -Wextra -Werror \
	-ffunction-sections -fdata-sections \
	-I"$root/include" -I"$root/src/boot" \
	"$root/tests/dma_handoff_test.c" \
	"$temporary/coreboot-dma-handoff-generation-mutant.c" \
	"$root/src/boot/coreboot_checksum.c" \
	-Wl,--gc-sections -o "$temporary/generation-mutant"
if "$temporary/generation-mutant" >/dev/null 2>&1; then
	echo 'ERROR: consumer accepted a blob from a foreign PRH generation' >&2
	exit 1
fi
cc -std=gnu11 -O2 -ffunction-sections -fdata-sections \
	-I"$root/include" -I"$root/src/boot" \
	"$root/tests/dma_handoff_test.c" "$root/src/boot/coreboot_dma_handoff.c" \
	"$root/src/boot/coreboot_checksum.c" \
	-Wl,--gc-sections -o "$temporary/fixture"
"$temporary/fixture" --fixture > "$temporary/cdk2-dma-handoff.bin"
test "$(wc -c < "$temporary/cdk2-dma-handoff.bin")" -eq 104
if [ -n "${DMA_HANDOFF_FIXTURE_OUTPUT:-}" ]; then
	cp "$temporary/cdk2-dma-handoff.bin" "$DMA_HANDOFF_FIXTURE_OUTPUT"
fi
printf '%s\n' \
	'DMA handoff consumer and strict PCI arena hostile tests: PASS'
