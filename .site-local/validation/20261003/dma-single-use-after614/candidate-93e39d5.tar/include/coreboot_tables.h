/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_ABI_COREBOOT_H_
#define CDK2_ABI_COREBOOT_H_

#include <stdint.h>
#include <uefi.h>

struct cbuint64 {
	UINT32 lo;
	UINT32 hi;
};

#define CB_HEADER_SIGNATURE 0x4f49424cU

struct cb_header {
	UINT32 signature;
	UINT32 header_bytes;
	UINT32 header_checksum;
	UINT32 table_bytes;
	UINT32 table_checksum;
	UINT32 table_entries;
};

struct cb_record {
	UINT32 tag;
	UINT32 size;
};

#define CB_TAG_PAYLOAD_BOOT_PRIVATE_BUFFER 0x0058U
#define CB_PAYLOAD_BOOT_PRIVATE_BUFFER_REVISION 1U
#define CB_PAYLOAD_BOOT_PRIVATE_BUFFER_SLOT_SIZE 65536U
#define CB_PAYLOAD_BOOT_PRIVATE_BUFFER_SLOT_COUNT 3U
#define CB_PAYLOAD_BOOT_PRIVATE_BUFFER_BYTES 196608U

/* Allocation metadata only; slot order is request, response, policy. */
struct cb_payload_boot_private_buffer {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t slot_size;
	struct cbuint64 physical_base;
	uint32_t bytes;
	uint32_t slot_count;
	uint32_t reserved[2];
} __packed;

_Static_assert(sizeof(struct cb_payload_boot_private_buffer) == 40U &&
	OFFSET_OF(struct cb_payload_boot_private_buffer, revision) == 8U &&
	OFFSET_OF(struct cb_payload_boot_private_buffer, header_size) == 10U &&
	OFFSET_OF(struct cb_payload_boot_private_buffer, slot_size) == 12U &&
	OFFSET_OF(struct cb_payload_boot_private_buffer, physical_base) == 16U &&
	OFFSET_OF(struct cb_payload_boot_private_buffer, bytes) == 24U &&
	OFFSET_OF(struct cb_payload_boot_private_buffer, slot_count) == 28U &&
	OFFSET_OF(struct cb_payload_boot_private_buffer, reserved) == 32U,
	"coreboot boot-private buffer record ABI");

#define CB_TAG_MEMORY 0x0001U

struct cb_memory_range {
	struct cbuint64 start;
	struct cbuint64 size;
	UINT32 type;
};

#define CB_MEM_RAM      1U
#define CB_MEM_RESERVED 2U
#define CB_MEM_ACPI     3U
#define CB_MEM_NVS      4U
#define CB_MEM_UNUSABLE 5U
#define CB_MEM_TABLE    16U

struct cb_memory {
	UINT32 tag;
	UINT32 size;
	struct cb_memory_range map[];
};

#define CB_TAG_MAINBOARD 0x0003U

struct cb_mainboard {
	UINT32 tag;
	UINT32 size;
	UINT8 vendor_index;
	UINT8 part_number_index;
	UINT8 strings[];
} __packed;

_Static_assert(sizeof(struct cb_mainboard) == 10U,
	"coreboot mainboard record prefix ABI");
_Static_assert(OFFSET_OF(struct cb_mainboard, vendor_index) == 8U &&
	OFFSET_OF(struct cb_mainboard, part_number_index) == 9U &&
	OFFSET_OF(struct cb_mainboard, strings) == 10U,
	"coreboot mainboard record field ABI");

#define CBMEM_ID_ACPI   SIGNATURE_32('I', 'P', 'C', 'A')
#define CBMEM_ID_CONSOLE 0x434f4e53U
#define CBMEM_ID_PAYLOAD_SPI_CONSOLE 0x434c5053U
#define CBMEM_ID_BOOT_SPLASH 0x42534c48U
#define CBMEM_ID_SMBIOS SIGNATURE_32('T', 'B', 'M', 'S')
/* CBMEM IDs are stored as the coreboot numeric constants, not ASCII-order
 * signatures.  Keep this equal to coreboot's CBMEM_ID_TIMESTAMP (0x54494d45).
 */
#define CBMEM_ID_TIMESTAMP 0x54494d45U
#define CBMEM_ID_DMA_HANDOFF 0x444d4148U

#define DYN_CBMEM_ALIGN_SIZE 4096U
#define IMD_ENTRY_MAGIC      (~0xc0389481U)
#define CBMEM_ENTRY_MAGIC    (~0xc0389479U)

struct cbmem_entry {
	UINT32 magic;
	UINT32 start;
	UINT32 size;
	UINT32 id;
};

struct cbmem_root {
	UINT32 max_entries;
	UINT32 num_entries;
	UINT32 locked;
	UINT32 size;
	struct cbmem_entry entries[];
};

struct imd_entry {
	UINT32 magic;
	UINT32 start_offset;
	UINT32 size;
	UINT32 id;
};

struct imd_root {
	UINT32 max_entries;
	UINT32 num_entries;
	UINT32 flags;
	UINT32 entry_align;
	UINT32 max_offset;
	struct imd_entry entries[];
};

#define CB_TAG_VERSION       0x0004U
#define CB_TAG_EXTRA_VERSION 0x0005U

struct cb_string {
	UINT32 tag;
	UINT32 size;
	UINT8 string[];
};

#define CB_TAG_SERIAL 0x000fU

#define CB_SERIAL_TYPE_IO_MAPPED     1U
#define CB_SERIAL_TYPE_MEMORY_MAPPED 2U

struct cb_serial {
	UINT32 tag;
	UINT32 size;
	UINT32 type;
	UINT32 baseaddr;
	UINT32 baud;
	UINT32 regwidth;
	UINT32 input_hertz;
	UINT32 uart_pci_addr;
};

#define CB_TAG_FORWARD 0x0011U

struct cb_forward {
	UINT32 tag;
	UINT32 size;
	UINT64 forward;
};

#define CB_TAG_TSC_INFO 0x0032U

struct cb_tsc_info {
	UINT32 tag;
	UINT32 size;
	UINT32 freq_khz;
};

#define CB_TAG_FRAMEBUFFER 0x0012U

struct cb_framebuffer {
	uint32_t tag;
	uint32_t size;
	struct cbuint64 physical_address;
	uint32_t x_resolution;
	uint32_t y_resolution;
	uint32_t bytes_per_line;
	uint8_t bits_per_pixel;
	uint8_t red_mask_pos;
	uint8_t red_mask_size;
	uint8_t green_mask_pos;
	uint8_t green_mask_size;
	uint8_t blue_mask_pos;
	uint8_t blue_mask_size;
	uint8_t reserved_mask_pos;
	uint8_t reserved_mask_size;
	uint8_t orientation;
	uint8_t flags;
	uint8_t pad;
};

_Static_assert(sizeof(struct cb_framebuffer) == 40U &&
	_Alignof(struct cb_framebuffer) == 4U &&
	OFFSET_OF(struct cb_framebuffer, physical_address) == 8U &&
	OFFSET_OF(struct cb_framebuffer, x_resolution) == 16U &&
	OFFSET_OF(struct cb_framebuffer, bits_per_pixel) == 28U &&
	OFFSET_OF(struct cb_framebuffer, orientation) == 37U &&
	OFFSET_OF(struct cb_framebuffer, flags) == 38U &&
	OFFSET_OF(struct cb_framebuffer, pad) == 39U,
	"coreboot framebuffer wire ABI");

#define CB_TAG_BOOT_SPLASH 0x0051U
#define CB_BOOT_SPLASH_REVISION 2U
#define CB_BOOT_SPLASH_DISPLAYED 0x0001U
#define CB_BOOT_SPLASH_BMP 0x0002U
#define CB_BOOT_SPLASH_FLAG_MASK (CB_BOOT_SPLASH_DISPLAYED | CB_BOOT_SPLASH_BMP)

struct cb_boot_splash {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 flags;
	struct cbuint64 framebuffer_address;
	UINT32 image_offset_x;
	UINT32 image_offset_y;
	UINT32 image_width;
	UINT32 image_height;
	struct cbuint64 bmp_address;
	UINT32 bmp_size;
} __packed;

#define CB_TAG_CBMEM_ENTRY 0x0031U

struct cb_cbmem_entry {
	UINT32 tag;
	UINT32 size;
	struct cbuint64 address;
	UINT32 entry_size;
	UINT32 id;
} __packed;

#define CB_TAG_SMMSTOREV2 0x0039U

struct cb_smmstorev2 {
	UINT32 tag;
	UINT32 size;
	UINT32 num_blocks;
	UINT32 block_size;
	UINT32 mmap_addr;
	UINT32 com_buffer;
	UINT32 com_buffer_size;
	UINT8 apm_cmd;
	UINT8 unused[3];
} __packed;

#define CB_TAG_SMRAM 0x004cU
#define CB_TAG_PAYLOAD_SPI_CONSOLE 0x0050U

struct cb_smram {
	UINT32 tag;
	UINT32 size;
	UINT64 physical_start;
	UINT64 physical_size;
} __packed;

struct cb_payload_spi_console {
	UINT32 tag;
	UINT32 size;
	UINT16 version;
	UINT16 request_header_size;
	UINT64 com_buffer;
	UINT32 com_buffer_size;
	UINT32 max_chunk;
	UINT32 boot_limit;
	UINT8 apm_cmd;
	UINT8 reserved[3];
} __packed;

#define CB_TAG_SMM_REGISTER_INFO 0x004dU
#define CB_TAG_LOCAL_APIC_TIMER_INFO 0x004eU
#define CB_TAG_S3_COMMUNICATION 0x004fU

struct cb_s3_communication {
	UINT32 tag;
	UINT32 size;
	UINT64 physical_start;
	UINT64 physical_size;
	UINT8 payload_s3_enabled;
	UINT8 reserved[7];
} __packed;

struct cb_smm_generic_register {
	UINT64 id;
	UINT64 value;
	UINT8 address_space_id;
	UINT8 register_bit_width;
	UINT8 register_bit_offset;
	UINT8 access_size;
	UINT64 address;
} __packed;

struct cb_smm_register_info {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 reserved;
	UINT32 count;
	struct cb_smm_generic_register registers[];
} __packed;

struct cb_local_apic_timer_info {
	struct cb_record header;
	UINT16 revision;
	UINT16 reserved;
	UINT64 frequency_hz;
} __packed;

#define CB_TAG_TPM_PPI_HANDOFF 0x003aU

enum lb_tmp_ppi_tpm_version {
	LB_TPM_VERSION_UNSPEC = 0,
	LB_TPM_VERSION_TPM_VERSION_1_2,
	LB_TPM_VERSION_TPM_VERSION_2,
};

struct cb_tpm_physical_presence {
	UINT32 tag;
	UINT32 size;
	UINT32 ppi_address;
	UINT8 tpm_version;
	UINT8 ppi_version;
} __packed;

#define CB_TAG_ACPI_RSDP 0x0043U

struct cb_acpi_rsdp {
	UINT32 tag;
	UINT32 size;
	struct cbuint64 rsdp_pointer;
} __packed;

#define CB_TAG_FW_INFO 0x0045U

struct lb_efi_fw_info {
	UINT32 tag;
	UINT32 size;
	UINT8 guid[16];
	UINT32 version;
	UINT32 lowest_supported_version;
	UINT32 fw_size;
} __packed;

#define CB_TAG_CAPSULE 0x0046U

struct cb_range {
	UINT32 tag;
	UINT32 size;
	UINT64 range_start;
	UINT32 range_size;
} __packed;

/*
 * Proposed coreboot-owned SystemFmp update contract.  Revision 1 described
 * geometry only and is deliberately not accepted by the native provider.
 * Revision 2 binds the firmware identity, authenticated capsule form and
 * broker-owned writable routes in one immutable table record.
 */
#define CB_TAG_CAPSULE_HANDOFF 0x0052U
#define CB_TAG_CAPSULE_BROKER_ENDPOINT 0x0054U
#define CB_TAG_CAPSULE_DELIVERY_POLICY 0x0059U
#define CB_CAPSULE_DELIVERY_POLICY_REVISION 1U
#define CB_CAPSULE_DELIVERY_RAM (1U << 0)
#define CB_CAPSULE_DELIVERY_DISK (1U << 1)

struct cb_capsule_delivery_policy {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t allowed_transports;
	struct cbuint64 max_nonpopulate;
	struct cbuint64 max_populate;
	uint32_t reserved[2];
} __packed;

_Static_assert(sizeof(struct cb_capsule_delivery_policy) == 40,
	"capsule delivery policy ABI");
_Static_assert(offsetof(struct cb_capsule_delivery_policy, allowed_transports) == 12 &&
	offsetof(struct cb_capsule_delivery_policy, max_nonpopulate) == 16 &&
	offsetof(struct cb_capsule_delivery_policy, max_populate) == 24 &&
	offsetof(struct cb_capsule_delivery_policy, reserved) == 32,
	"capsule delivery policy layout");
#define CB_TAG_AUTHVAR_SERVICE_ENDPOINT 0x0055U
#define CB_TAG_AUTHVAR_PRESENCE_ENDPOINT 0x0056U
#define CB_TAG_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_ENDPOINT 0x0057U
#define CB_CAPSULE_HANDOFF_REVISION 2U

#define CB_CAPSULE_HANDOFF_AUTHENTICATED (1U << 0)
#define CB_CAPSULE_HANDOFF_RESET_REQUIRED (1U << 1)
#define CB_CAPSULE_HANDOFF_REQUIRED_FLAGS \
	(CB_CAPSULE_HANDOFF_AUTHENTICATED | \
	 CB_CAPSULE_HANDOFF_RESET_REQUIRED)

#define CB_CAPSULE_BROKER_COREBOOT_UPDATE 1U
#define CB_CAPSULE_BROKER_APPLY_REGIONS     (1U << 0)
#define CB_CAPSULE_BROKER_PRESERVE_UNLISTED (1U << 1)
#define CB_CAPSULE_BROKER_VERIFY_READBACK   (1U << 2)
#define CB_CAPSULE_BROKER_REQUIRED_CAPABILITIES \
	(CB_CAPSULE_BROKER_APPLY_REGIONS | \
	 CB_CAPSULE_BROKER_PRESERVE_UNLISTED | \
	 CB_CAPSULE_BROKER_VERIFY_READBACK)

#define CB_CAPSULE_FORMAT_FMP_V3 3U
#define CB_CAPSULE_AUTH_EFI_PKCS7 1U
#define CB_CAPSULE_BOARD_BINDING_CBFS_BUILD_INFO_V1 1U
#define CB_CAPSULE_PAYLOAD_MSS1_V1 1U
#define CB_CAPSULE_FLAGS_PERSIST_RESET 0x00050000U

#define CB_CAPSULE_REGION_BIOS (1U << 0)
#define CB_CAPSULE_REGION_VALID_FLAGS CB_CAPSULE_REGION_BIOS

struct cb_capsule_update_region {
	struct cbuint64 image_offset;
	struct cbuint64 flash_offset;
	struct cbuint64 size;
	UINT32 flags;
	UINT32 reserved;
} __packed;

struct cb_capsule_handoff {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 header_size;
	UINT32 flags;
	UINT16 broker_type;
	UINT16 capsule_format;
	UINT16 authentication_format;
	UINT16 board_binding_format;
	UINT16 payload_format;
	UINT16 reserved16;
	UINT32 broker_capabilities;
	UINT8 image_type_guid[16];
	UINT32 version;
	UINT32 lowest_supported_version;
	UINT32 capsule_flags;
	UINT32 block_size;
	UINT32 erase_size;
	UINT32 region_count;
	struct cbuint64 image_size;
	struct cbuint64 boot_media_size;
	struct cbuint64 smmstore_offset;
	struct cbuint64 smmstore_size;
	UINT32 reserved32[2];
	struct cb_capsule_update_region regions[];
} __packed;

_Static_assert(sizeof(struct cb_capsule_update_region) == 32U,
	"capsule update region ABI");
_Static_assert(sizeof(struct cb_capsule_handoff) == 112U,
	"capsule handoff header ABI");
_Static_assert(OFFSET_OF(struct cb_capsule_handoff, broker_type) == 16U &&
	OFFSET_OF(struct cb_capsule_handoff, broker_capabilities) == 28U,
	"capsule broker ABI");
_Static_assert(OFFSET_OF(struct cb_capsule_handoff, image_type_guid) == 32U &&
	OFFSET_OF(struct cb_capsule_handoff, version) == 48U,
	"capsule identity ABI");
_Static_assert(OFFSET_OF(struct cb_capsule_handoff, image_size) == 72U &&
	OFFSET_OF(struct cb_capsule_handoff, regions) == 112U,
	"capsule bounds ABI");

#define CB_CAPSULE_BROKER_ENDPOINT_REVISION 1U
#define CB_CAPSULE_BROKER_ENDPOINT_RAM_REVISION 2U

#define CB_CAPSULE_ENDPOINT_COREBOOT_SMM_OWNER  (1U << 0)
#define CB_CAPSULE_ENDPOINT_SMM_ONLY_SPI        (1U << 1)
#define CB_CAPSULE_ENDPOINT_FIXED_COMMUNICATION (1U << 2)
#define CB_CAPSULE_ENDPOINT_DMA_PROTECTED       (1U << 3)
#define CB_CAPSULE_ENDPOINT_CPU_RENDEZVOUS      (1U << 4)
#define CB_CAPSULE_ENDPOINT_ONE_SHOT            (1U << 5)
#define CB_CAPSULE_ENDPOINT_NO_RAW_FLASH         (1U << 6)
#define CB_CAPSULE_ENDPOINT_REQUIRED_FLAGS \
	(CB_CAPSULE_ENDPOINT_COREBOOT_SMM_OWNER | \
	 CB_CAPSULE_ENDPOINT_SMM_ONLY_SPI | \
	 CB_CAPSULE_ENDPOINT_FIXED_COMMUNICATION | \
	 CB_CAPSULE_ENDPOINT_DMA_PROTECTED | \
	 CB_CAPSULE_ENDPOINT_CPU_RENDEZVOUS | \
	 CB_CAPSULE_ENDPOINT_ONE_SHOT | \
	 CB_CAPSULE_ENDPOINT_NO_RAW_FLASH)

#define CB_CAPSULE_ENDPOINT_TRANSPORT_APM_IO8 1U

struct cb_capsule_broker_endpoint {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 header_size;
	UINT32 flags;
	struct cbuint64 generation;
	struct cbuint64 communication_base;
	UINT32 communication_size;
	UINT32 message_size;
	struct cbuint64 staging_base;
	struct cbuint64 staging_size;
	UINT16 transport;
	UINT16 trigger_width;
	UINT32 trigger_address;
	UINT32 trigger_value;
	UINT32 reserved[3];
} __packed;

_Static_assert(sizeof(struct cb_capsule_broker_endpoint) == 80U,
	"capsule broker endpoint ABI");
_Static_assert(OFFSET_OF(struct cb_capsule_broker_endpoint, generation) == 16U &&
	OFFSET_OF(struct cb_capsule_broker_endpoint, communication_base) == 24U &&
	OFFSET_OF(struct cb_capsule_broker_endpoint, staging_base) == 40U &&
	OFFSET_OF(struct cb_capsule_broker_endpoint, transport) == 56U &&
	OFFSET_OF(struct cb_capsule_broker_endpoint, reserved) == 68U,
	"capsule broker endpoint layout");

#define CB_AUTHVAR_SERVICE_ENDPOINT_REVISION 5U

#define CB_AUTHVAR_ENDPOINT_COREBOOT_SMM_OWNER  (1U << 0)
#define CB_AUTHVAR_ENDPOINT_FIXED_COMMUNICATION (1U << 1)
/* Hardware protects authoritative SMM state/code and its backend, not the
 * shared mailbox against DMA. Each request must be snapshotted into SMRAM. */
#define CB_AUTHVAR_ENDPOINT_PROTECTED_AUTHORITY (1U << 2)
#define CB_AUTHVAR_ENDPOINT_CPU_RENDEZVOUS      (1U << 3)
#define CB_AUTHVAR_ENDPOINT_POLICY_IN_SMM       (1U << 4)
#define CB_AUTHVAR_ENDPOINT_NO_RAW_SMMSTORE     (1U << 5)
#define CB_AUTHVAR_ENDPOINT_SMM_BWP_REQUIRED    (1U << 6)
#define CB_AUTHVAR_ENDPOINT_LIFECYCLE_SEALED    (1U << 7)
/* Repeatable boot-services op9, not private BOOT delivery or origin proof. */
#define CB_AUTHVAR_ENDPOINT_IMAGE_POLICY_GENERAL (1U << 8)
/* Installed MM-owned predicate keys retain their class across deletion. */
#define CB_AUTHVAR_ENDPOINT_STATE_PREDICATE_PINNED (1U << 9)
#define CB_AUTHVAR_ENDPOINT_REQUIRED_FLAGS \
	(CB_AUTHVAR_ENDPOINT_COREBOOT_SMM_OWNER | \
	 CB_AUTHVAR_ENDPOINT_FIXED_COMMUNICATION | \
	 CB_AUTHVAR_ENDPOINT_PROTECTED_AUTHORITY | \
	 CB_AUTHVAR_ENDPOINT_CPU_RENDEZVOUS | \
	 CB_AUTHVAR_ENDPOINT_POLICY_IN_SMM | \
	 CB_AUTHVAR_ENDPOINT_NO_RAW_SMMSTORE | \
	 CB_AUTHVAR_ENDPOINT_SMM_BWP_REQUIRED | \
	 CB_AUTHVAR_ENDPOINT_LIFECYCLE_SEALED)

#define CB_AUTHVAR_ENDPOINT_TRANSPORT_APM_IO8 1U

struct cb_authvar_service_endpoint {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 header_size;
	UINT32 flags;
	struct cbuint64 generation;
	struct cbuint64 communication_base;
	UINT32 communication_size;
	UINT32 message_size;
	UINT16 transport;
	UINT16 trigger_width;
	UINT32 trigger_address;
	UINT32 trigger_value;
	UINT32 maximum_name_size;
	/* Logical data limit; unused bytes through message_size are zero padding. */
	UINT32 maximum_data_size;
	UINT32 reserved;
} __packed;

_Static_assert(sizeof(struct cb_authvar_service_endpoint) == 64U,
	"authenticated-variable endpoint ABI");
_Static_assert(OFFSET_OF(struct cb_authvar_service_endpoint, generation) == 16U &&
	OFFSET_OF(struct cb_authvar_service_endpoint, communication_base) == 24U &&
	OFFSET_OF(struct cb_authvar_service_endpoint, transport) == 40U &&
	OFFSET_OF(struct cb_authvar_service_endpoint, maximum_name_size) == 52U &&
	OFFSET_OF(struct cb_authvar_service_endpoint, reserved) == 60U,
	"authenticated-variable endpoint layout");

#define CB_AUTHVAR_PRESENCE_ENDPOINT_REVISION 1U

#define CB_AUTHVAR_PRESENCE_COREBOOT_SMM_OWNER  (1U << 0)
#define CB_AUTHVAR_PRESENCE_FIXED_COMMUNICATION (1U << 1)
#define CB_AUTHVAR_PRESENCE_DMA_PROTECTED       (1U << 2)
#define CB_AUTHVAR_PRESENCE_CPU_RENDEZVOUS      (1U << 3)
#define CB_AUTHVAR_PRESENCE_ONE_SHOT_CAPABILITY (1U << 4)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_SEALED    (1U << 5)
#define CB_AUTHVAR_PRESENCE_REQUIRED_FLAGS \
	(CB_AUTHVAR_PRESENCE_COREBOOT_SMM_OWNER | \
	 CB_AUTHVAR_PRESENCE_FIXED_COMMUNICATION | \
	 CB_AUTHVAR_PRESENCE_DMA_PROTECTED | \
	 CB_AUTHVAR_PRESENCE_CPU_RENDEZVOUS | \
	 CB_AUTHVAR_PRESENCE_ONE_SHOT_CAPABILITY | \
	 CB_AUTHVAR_PRESENCE_LIFECYCLE_SEALED)

#define CB_AUTHVAR_PRESENCE_TRANSPORT_APM_IO8 1U
#define CB_AUTHVAR_PRESENCE_ENTER_SETUP_MODE 1U
#define CB_AUTHVAR_PRESENCE_CAPABILITY_SIZE 32U

struct cb_authvar_presence_endpoint {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 header_size;
	UINT32 flags;
	struct cbuint64 generation;
	struct cbuint64 communication_base;
	UINT32 communication_size;
	UINT32 message_size;
	UINT16 transport;
	UINT16 trigger_width;
	UINT32 trigger_address;
	UINT32 trigger_value;
	UINT32 action_scope;
	UINT32 capability_size;
	UINT32 reserved;
} __packed;

/* The capability bytes are provisioned out of band, never in this table. */

_Static_assert(sizeof(struct cb_authvar_presence_endpoint) == 64U,
	"authenticated-variable presence endpoint ABI");
_Static_assert(OFFSET_OF(struct cb_authvar_presence_endpoint, generation) == 16U &&
	OFFSET_OF(struct cb_authvar_presence_endpoint, communication_base) == 24U &&
	OFFSET_OF(struct cb_authvar_presence_endpoint, transport) == 40U &&
	OFFSET_OF(struct cb_authvar_presence_endpoint, action_scope) == 52U &&
	OFFSET_OF(struct cb_authvar_presence_endpoint, reserved) == 60U,
	"authenticated-variable presence endpoint layout");

#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_ENDPOINT_REVISION 1U
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SMM_OWNER (1U << 0)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_FIXED_COMMUNICATION (1U << 1)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_AUTHORITY_DMA_PROTECTED (1U << 2)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CPU_RENDEZVOUS (1U << 3)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_EXACT_GENERATION (1U << 4)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOOT_EPOCH_SCOPED (1U << 5)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SOURCE_SCOPED (1U << 6)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SYNCHRONOUS_CLOSED_PROOF (1U << 7)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_ONE_SHOT_SOURCES (1U << 8)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_TERMINAL_BEFORE_EBS (1U << 9)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_REQUIRED_FLAGS ((1U << 10) - 1U)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_TRANSPORT_APM_IO8 1U
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_PRE_EXTERNAL_IMAGE (1U << 0)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_PAYLOAD_FAILURE_OR_RETURN (1U << 1)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLOSED_REPROOF (1U << 2)
#define CB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SOURCE_MASK ((1U << 3) - 1U)

struct cb_authvar_presence_lifecycle_close_endpoint {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 header_size;
	UINT32 flags;
	struct cbuint64 generation;
	struct cbuint64 communication_base;
	UINT32 communication_size;
	UINT32 message_size;
	UINT16 transport;
	UINT16 trigger_width;
	UINT32 trigger_address;
	UINT32 trigger_value;
	UINT32 source_mask;
	UINT32 reserved[2];
} __packed;

_Static_assert(sizeof(struct cb_authvar_presence_lifecycle_close_endpoint) == 64U,
	"authenticated-variable presence lifecycle-close endpoint ABI");
_Static_assert(OFFSET_OF(struct cb_authvar_presence_lifecycle_close_endpoint,
	generation) == 16U &&
	OFFSET_OF(struct cb_authvar_presence_lifecycle_close_endpoint,
	communication_base) == 24U &&
	OFFSET_OF(struct cb_authvar_presence_lifecycle_close_endpoint, transport) == 40U &&
	OFFSET_OF(struct cb_authvar_presence_lifecycle_close_endpoint, source_mask) == 52U &&
	OFFSET_OF(struct cb_authvar_presence_lifecycle_close_endpoint, reserved) == 56U,
	"authenticated-variable presence lifecycle-close endpoint layout");

#define CB_TAG_CFR_ROOT 0x0047U

struct cb_cfr {
	UINT32 tag;
	UINT32 size;
	UINT32 version;
	UINT32 checksum;
};

#define CB_TAG_PAYLOAD_RESOURCE_HANDOFF 0x004bU
#define CB_TAG_DMA_HANDOFF 0x0053U

struct cb_dma_handoff {
	UINT32 tag;
	UINT32 size;
	UINT64 address;
	UINT32 bytes;
	UINT16 revision;
	UINT16 reserved;
} __packed;

#define CB_PAYLOAD_RESOURCE_HANDOFF_REVISION 3U
#define CB_PAYLOAD_RESOURCE_HANDOFF_REVISION_4 4U

#define CB_PRH_PCI_ROOT_TOPOLOGY_ONLY 0x00000001U

#define CB_PRH_SECTION_MEMORY_POLICY    1U
#define CB_PRH_SECTION_X86_CACHE_STATE  2U
#define CB_PRH_SECTION_PCI_ROOT_BRIDGES 3U
#define CB_PRH_SECTION_PCI_ASSIGNMENTS  4U
#define CB_PRH_SECTION_BOOT_INTENT      5U
#define CB_PRH_SECTION_RUNTIME_POLICY   6U
#define CB_PRH_SECTION_FRAMEBUFFER      7U
#define CB_PRH_SECTION_PCI_TOPOLOGY     8U

#define CB_PRH_SECTION_FLAG_MANDATORY     0x0001U
#define CB_PRH_SECTION_FLAG_AUTHORITATIVE 0x0002U
#define CB_PRH_SECTION_FLAG_VALID_MASK \
	(CB_PRH_SECTION_FLAG_MANDATORY | CB_PRH_SECTION_FLAG_AUTHORITATIVE)

#define CB_PRH_LIFETIME_COLD_BOOT          0x0000000000000001ULL
#define CB_PRH_LIFETIME_S3_RESUME          0x0000000000000002ULL
#define CB_PRH_LIFETIME_END_OF_DXE         0x0000000000000004ULL
#define CB_PRH_LIFETIME_EXIT_BOOT_SERVICES 0x0000000000000008ULL
#define CB_PRH_LIFETIME_RUNTIME            0x0000000000000010ULL
#define CB_PRH_LIFETIME_VALID_UNTIL_MASK \
	(CB_PRH_LIFETIME_END_OF_DXE | CB_PRH_LIFETIME_EXIT_BOOT_SERVICES | \
	 CB_PRH_LIFETIME_RUNTIME)
#define CB_PRH_LIFETIME_VALID_MASK \
	(CB_PRH_LIFETIME_COLD_BOOT | CB_PRH_LIFETIME_S3_RESUME | \
	 CB_PRH_LIFETIME_VALID_UNTIL_MASK)

#define CB_PRH_GCD_MEMORY_TYPE_NON_EXISTENT 0U
#define CB_PRH_GCD_MEMORY_TYPE_RESERVED     1U
#define CB_PRH_GCD_MEMORY_TYPE_SYSTEM       2U
#define CB_PRH_GCD_MEMORY_TYPE_MMIO         3U
#define CB_PRH_GCD_MEMORY_TYPE_PERSISTENT   4U
#define CB_PRH_GCD_MEMORY_TYPE_RELIABLE     5U
#define CB_PRH_GCD_MEMORY_TYPE_UNACCEPTED   6U

#define CB_PRH_MEMORY_CACHE_AUTHORITATIVE      0x00000001U
#define CB_PRH_MEMORY_PROTECTION_AUTHORITATIVE 0x00000002U
#define CB_PRH_MEMORY_GCD_AUTHORITATIVE        0x00000004U
#define CB_PRH_MEMORY_EFI_TYPE_AUTHORITATIVE   0x00000008U
#define CB_PRH_MEMORY_DELEGATED_TO_PAYLOAD     0x80000000U
#define CB_PRH_MEMORY_OWNER_FLAG_VALID_MASK                                      \
	(CB_PRH_MEMORY_CACHE_AUTHORITATIVE | CB_PRH_MEMORY_PROTECTION_AUTHORITATIVE | \
	 CB_PRH_MEMORY_GCD_AUTHORITATIVE | CB_PRH_MEMORY_EFI_TYPE_AUTHORITATIVE |     \
	 CB_PRH_MEMORY_DELEGATED_TO_PAYLOAD)

#define CB_PRH_X86_CACHE_FLAG_BSP_AP_SYNC 0x00000001U
#define CB_PRH_X86_CACHE_FLAG_S3_VALID    0x00000002U
#define CB_PRH_X86_CACHE_FLAG_FIXED_VALID 0x00000004U
#define CB_PRH_X86_CACHE_FLAG_VALID_MASK                                      \
	(CB_PRH_X86_CACHE_FLAG_BSP_AP_SYNC | CB_PRH_X86_CACHE_FLAG_S3_VALID | \
	 CB_PRH_X86_CACHE_FLAG_FIXED_VALID)

#define CB_PRH_PCI_RESOURCE_IO              1U
#define CB_PRH_PCI_RESOURCE_MMIO32          2U
#define CB_PRH_PCI_RESOURCE_MMIO64          3U
#define CB_PRH_PCI_RESOURCE_PREFETCH_MMIO32 4U
#define CB_PRH_PCI_RESOURCE_PREFETCH_MMIO64 5U
#define CB_PRH_PCI_ASSIGNMENT_64BIT 0x01U

#define CB_PRH_PCI_TOPOLOGY_PATH_ONLY       0x01U
#define CB_PRH_PCI_TOPOLOGY_FLAG_VALID_MASK CB_PRH_PCI_TOPOLOGY_PATH_ONLY
#define CB_PRH_PCI_TOPOLOGY_PARENT_ROOT     0xffffU
#define CB_PRH_PCI_TOPOLOGY_MAX_ENTRIES     512U

#define CB_PRH_FRAMEBUFFER_GEOMETRY_AUTHORITATIVE 0x00000001U
#define CB_PRH_FRAMEBUFFER_PCI_OWNER_AUTHORITATIVE 0x00000002U
#define CB_PRH_FRAMEBUFFER_MEMORY_DELEGATED       0x80000000U
#define CB_PRH_FRAMEBUFFER_OWNER_FLAG_VALID_MASK_REV3 \
	(CB_PRH_FRAMEBUFFER_GEOMETRY_AUTHORITATIVE | CB_PRH_FRAMEBUFFER_MEMORY_DELEGATED)
#define CB_PRH_FRAMEBUFFER_OWNER_FLAG_VALID_MASK \
	CB_PRH_FRAMEBUFFER_OWNER_FLAG_VALID_MASK_REV3
#define CB_PRH_FRAMEBUFFER_OWNER_FLAG_VALID_MASK_REV4                    \
	(CB_PRH_FRAMEBUFFER_OWNER_FLAG_VALID_MASK_REV3 |                  \
	 CB_PRH_FRAMEBUFFER_PCI_OWNER_AUTHORITATIVE)

struct cb_payload_resource_section {
	UINT16 type;
	UINT16 flags;
	UINT16 header_length;
	UINT16 entry_size;
	UINT32 entry_count;
	UINT32 offset;
	UINT32 length;
} __packed;

struct cb_payload_resource_handoff {
	UINT32 tag;
	UINT32 size;
	UINT16 revision;
	UINT16 header_length;
	UINT16 section_header_length;
	UINT16 flags;
	UINT32 crc32;
	UINT32 section_count;
	UINT32 producer_stage;
	struct cbuint64 producer_generation;
	struct cbuint64 lifetime_flags;
	struct cb_payload_resource_section sections[];
} __packed;

struct cb_prh_memory_policy_entry {
	struct cbuint64 base;
	struct cbuint64 length;
	struct cbuint64 capabilities;
	struct cbuint64 attributes;
	UINT32 gcd_type;
	UINT32 efi_memory_type;
	UINT32 owner_flags;
	UINT32 reserved;
} __packed;

struct cb_prh_x86_cache_state {
	struct cbuint64 mtrr_default_type_msr;
	struct cbuint64 pat_msr;
	struct cbuint64 fixed_mtrr_crc64;
	UINT32 variable_count;
	UINT32 physical_address_bits;
	UINT32 flags;
	UINT32 reserved;
} __packed;

struct cb_prh_x86_variable_mtrr {
	struct cbuint64 phys_base_msr;
	struct cbuint64 phys_mask_msr;
} __packed;

struct cb_prh_pci_root_bridge_entry {
	UINT16 segment;
	UINT8 bus_start;
	UINT8 bus_end;
	UINT32 flags;
	struct cbuint64 io_base;
	struct cbuint64 io_length;
	struct cbuint64 mem32_base;
	struct cbuint64 mem32_length;
	struct cbuint64 mem64_base;
	struct cbuint64 mem64_length;
	struct cbuint64 pref_mem32_base;
	struct cbuint64 pref_mem32_length;
	struct cbuint64 pref_mem64_base;
	struct cbuint64 pref_mem64_length;
} __packed;

struct cb_prh_pci_assignment_entry {
	UINT16 segment;
	UINT8 bus;
	UINT8 device;
	UINT8 function;
	UINT8 bar;
	UINT8 resource_type;
	UINT8 flags;
	struct cbuint64 base;
	struct cbuint64 length;
	struct cbuint64 attributes;
} __packed;

struct cb_prh_pci_topology_entry {
	UINT16 segment;
	UINT8 bus;
	UINT8 device;
	UINT8 function;
	UINT8 header_type;
	UINT16 parent_index;
	UINT16 vendor_id;
	UINT16 device_id;
	UINT16 command;
	UINT8 class_code;
	UINT8 subclass;
	UINT8 programming_interface;
	UINT8 secondary_bus;
	UINT8 subordinate_bus;
	UINT8 flags;
	UINT32 reserved;
} __packed;

struct cb_prh_boot_intent_entry {
	UINT16 topology_index;
	UINT16 flags;
	UINT32 reserved;
} __packed;

struct cb_prh_framebuffer_entry {
	struct cbuint64 physical_address;
	struct cbuint64 size;
	UINT32 x_resolution;
	UINT32 y_resolution;
	UINT32 bytes_per_line;
	UINT8 bits_per_pixel;
	UINT8 red_mask_pos;
	UINT8 red_mask_size;
	UINT8 green_mask_pos;
	UINT8 green_mask_size;
	UINT8 blue_mask_pos;
	UINT8 blue_mask_size;
	UINT8 reserved_mask_pos;
	UINT8 reserved_mask_size;
	union {
		UINT8 reserved[3];
		struct {
			UINT16 topology_index;
			UINT8 bar;
		} __packed;
	} __packed;
	UINT32 owner_flags;
} __packed;

#define CB_TAG_BOOT_INFO 0x00a1U

struct cb_boot_info {
	UINT32 tag;
	UINT32 size;
	UINT8 is_disk_capsules_boot;
	UINT8 pad[3];
} __packed;

#define CB_TAG_BOOT_MODE 0x00cdU

enum cb_boot_mode {
	LB_BOOT_MODE_NORMAL,
	LB_BOOT_MODE_LOW_BATTERY,
	LB_BOOT_MODE_LOW_BATTERY_CHARGING,
	LB_BOOT_MODE_OFFMODE_CHARGING,
	LB_BOOT_MODE_RTC_WAKE,
	LB_BOOT_MODE_NO_BATTERY,
	LB_BOOT_MODE_FLASH_UPDATE,
	LB_BOOT_MODE_S4_RESUME,
};

struct lb_boot_mode {
	UINT32 tag;
	UINT32 size;
	enum cb_boot_mode boot_mode;
} __packed;

#endif
