/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_CLIENT_H
#define CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_CLIENT_H

#include <cdk2/payload_mm_authvar_presence.h>

/* Internal fixed-action client; no public protocol or generic variable input. */
enum cdk2_authvar_presence_client_status {
	CDK2_AUTHVAR_PRESENCE_CLIENT_SUCCESS = 0,
	CDK2_AUTHVAR_PRESENCE_CLIENT_INVALID,
	CDK2_AUTHVAR_PRESENCE_CLIENT_CLOSED,
	CDK2_AUTHVAR_PRESENCE_CLIENT_BUSY,
	CDK2_AUTHVAR_PRESENCE_CLIENT_CACHE_FAILED,
	CDK2_AUTHVAR_PRESENCE_CLIENT_TRIGGER_FAILED,
	CDK2_AUTHVAR_PRESENCE_CLIENT_BAD_RESPONSE,
	CDK2_AUTHVAR_PRESENCE_CLIENT_EXECUTION_FAILED,
	CDK2_AUTHVAR_PRESENCE_CLIENT_RESET_RETURNED,
};

typedef EFI_STATUS cdk2_authvar_presence_client_cache_fn(void *context,
	void *base, UINTN size);
typedef void cdk2_authvar_presence_client_barrier_fn(void *context);
typedef EFI_STATUS cdk2_authvar_presence_client_trigger_fn(void *context,
	UINT16 port, UINT8 value);
typedef void cdk2_authvar_presence_client_reset_fn(void *context);
typedef void cdk2_authvar_presence_client_fatal_fn(void *context);

struct cdk2_authvar_presence_client_port {
	void *context;
	cdk2_authvar_presence_client_cache_fn *publish;
	cdk2_authvar_presence_client_cache_fn *acquire;
	cdk2_authvar_presence_client_barrier_fn *barrier;
	cdk2_authvar_presence_client_trigger_fn *trigger_apm_io8;
	cdk2_authvar_presence_client_reset_fn *cold_reset;
	cdk2_authvar_presence_client_fatal_fn *reset_returned_fatal;
};

enum cdk2_authvar_presence_client_state {
	CDK2_AUTHVAR_PRESENCE_CLIENT_EMPTY = 0,
	CDK2_AUTHVAR_PRESENCE_CLIENT_INITIALIZING,
	CDK2_AUTHVAR_PRESENCE_CLIENT_READY,
	CDK2_AUTHVAR_PRESENCE_CLIENT_IN_FLIGHT,
	CDK2_AUTHVAR_PRESENCE_CLIENT_CONSUMED,
};

struct cdk2_authvar_presence_client {
	struct cdk2_authvar_presence_endpoint endpoint;
	struct cdk2_authvar_presence_endpoint sealed_endpoint;
	struct cdk2_authvar_presence_client_port port;
	struct cdk2_authvar_presence_client_port sealed_port;
	UINT8 capability[CB_AUTHVAR_PRESENCE_CAPABILITY_SIZE];
	UINT8 sealed_capability[CB_AUTHVAR_PRESENCE_CAPABILITY_SIZE];
	UINT64 request_id;
	UINT32 state;
};

/* The destination must be zero-initialized before its first initialization. */
enum cdk2_authvar_presence_client_status
cdk2_authvar_presence_client_init(
	struct cdk2_authvar_presence_client *client,
	const struct cdk2_authvar_presence_endpoint *endpoint,
	const UINT8 capability[CB_AUTHVAR_PRESENCE_CAPABILITY_SIZE],
	const struct cdk2_authvar_presence_client_port *port);

enum cdk2_authvar_presence_client_status
cdk2_authvar_presence_client_enter_setup_mode(
	struct cdk2_authvar_presence_client *client);

#endif
