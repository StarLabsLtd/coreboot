/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_PCI_DMA_CONTROL_H
#define CDK2_PCI_DMA_CONTROL_H

#include <uefi.h>

#define CDK2_PCI_DMA_CONTROL_GUID \
	{ 0xc260a9f7, 0xa4f9, 0x438e, \
	  { 0x9e, 0x6a, 0x49, 0x1c, 0x68, 0x37, 0x3a, 0xd2 } }
#define CDK2_PCI_DMA_CONTROL_REVISION 1U

struct cdk2_pci_dma_control;
typedef EFI_STATUS CDK2_MS_ABI cdk2_pci_dma_quiesce_all_fn(
	struct cdk2_pci_dma_control *control);

struct cdk2_pci_dma_control {
	UINT32 revision;
	cdk2_pci_dma_quiesce_all_fn *quiesce_all;
};

#endif
