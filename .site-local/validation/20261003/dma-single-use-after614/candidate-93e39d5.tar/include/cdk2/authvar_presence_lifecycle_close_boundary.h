/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOUNDARY_H
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOUNDARY_H

#include <cdk2/dxe_image_transaction.h>
#include <cdk2/payload_mm_authvar_presence_lifecycle_close_client.h>

struct cdk2_authvar_presence_external_image_identity {
	void *handle;
	UINT64 load_generation;
	struct cdk2_dxe_image_transaction *transaction;
	UINT64 transaction_allocation_generation;
	UINT64 transaction_generation;
	void *base;
	UINTN size;
	cdk2_dxe_image_entry_fn *entry;
};

typedef EFI_STATUS cdk2_authvar_presence_external_image_validate_fn(
	void *context,
	const struct cdk2_authvar_presence_external_image_identity *identity);

struct cdk2_authvar_presence_lifecycle_close_boundary_authority {
	void *context;
	UINTN context_size;
	cdk2_authvar_presence_external_image_validate_fn * validate;
};

/*
 * Calls are made under serialized DXE image-database ownership.  The identity,
 * image slot, and transaction must not be raw-written concurrently; detecting
 * transient mutate-and-restore writes is outside this API's contract.  The
 * frozen authority callback must validate the exact live image slot and
 * transaction ownership, including the load, allocation, and transaction
 * generations.  The boundary copies the identity before invoking callbacks
 * and never exposes caller-owned storage to either callback.
 */
EFI_STATUS cdk2_authvar_presence_lifecycle_close_boundary_init(
	struct cdk2_authvar_presence_lifecycle_close_client *client,
	const struct cdk2_authvar_presence_lifecycle_close_boundary_authority
		*authority);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_boundary_claim(
	const struct cdk2_authvar_presence_external_image_identity *identity);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_boundary_pre_external(
	const struct cdk2_authvar_presence_external_image_identity *identity);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_boundary_payload_return(
	const struct cdk2_authvar_presence_external_image_identity *identity);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_boundary_successful_ebs_reproof(
	const struct cdk2_authvar_presence_external_image_identity *identity);

#ifdef CDK2_HOST_TEST
enum cdk2_authvar_presence_lifecycle_close_boundary_test_window {
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOUNDARY_CLAIM_PRE,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOUNDARY_CLAIM_POST,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOUNDARY_TRANSITION_PRE,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOUNDARY_TRANSITION_POST,
};
typedef void cdk2_authvar_presence_lifecycle_close_boundary_test_hook_fn(
	enum cdk2_authvar_presence_lifecycle_close_boundary_test_window window,
	void *context);
void cdk2_authvar_presence_lifecycle_close_boundary_test_hook(
	cdk2_authvar_presence_lifecycle_close_boundary_test_hook_fn * hook,
	void *context);
void cdk2_authvar_presence_lifecycle_close_boundary_test_reset(void);
#endif

#endif
