/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_IMAGE_POLICY_SNAPSHOT_H
#define CDK2_IMAGE_POLICY_SNAPSHOT_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Paired contract; no authoritative delivery or policy activation is implied. */
#define CDK2_IMAGE_POLICY_SNAPSHOT_OPERATION 9U
#define CDK2_IMAGE_POLICY_SNAPSHOT_FRAME_REVISION 3U
#define CDK2_IMAGE_POLICY_SNAPSHOT_ENDPOINT_REVISION 5U
#define CDK2_IMAGE_POLICY_SNAPSHOT_REVISION 1U
#define CDK2_IMAGE_POLICY_SNAPSHOT_HEADER_SIZE 96U
/* Selected future factory-limit profile, not a universal producer limit. */
#define CDK2_IMAGE_POLICY_SNAPSHOT_MAX_VARIABLE_SIZE (1024U * 1024U)
#define CDK2_IMAGE_POLICY_SNAPSHOT_MAX_SIZE \
	(CDK2_IMAGE_POLICY_SNAPSHOT_HEADER_SIZE + \
	 4U * CDK2_IMAGE_POLICY_SNAPSHOT_MAX_VARIABLE_SIZE)

enum cdk2_image_policy_snapshot_key {
	/* PK/global namespace; db/dbx/dbt/image-security namespace, fixed order. */
	CDK2_IMAGE_POLICY_SNAPSHOT_PK,
	CDK2_IMAGE_POLICY_SNAPSHOT_DB,
	CDK2_IMAGE_POLICY_SNAPSHOT_DBX,
	CDK2_IMAGE_POLICY_SNAPSHOT_DBT,
	CDK2_IMAGE_POLICY_SNAPSHOT_KEYS,
};

enum cdk2_image_policy_snapshot_mode {
	CDK2_IMAGE_POLICY_SNAPSHOT_SETUP = 1U,
	CDK2_IMAGE_POLICY_SNAPSHOT_SECURE_BOOT = 2U,
	CDK2_IMAGE_POLICY_SNAPSHOT_VENDOR_KEYS = 4U,
};

struct cdk2_image_policy_snapshot_blob {
	const uint8_t *data;
	uint32_t size;
	uint32_t attributes;
};

struct cdk2_image_policy_snapshot_view {
	uint32_t modes;
	struct cdk2_image_policy_snapshot_blob blobs[CDK2_IMAGE_POLICY_SNAPSHOT_KEYS];
};

/*
 * Shape/profile decoding only: no authoritative producer, DMA delivery lease,
 * certificate trust or permission to execute is established. Inputs must stay
 * immutable for the call and the lifetime of successful borrowed blob views.
 * Validate every descriptor/padding byte before publishing any output. Failure
 * leaves output unchanged; output must be aligned, nonwrapping and disjoint.
 * Known stored attributes are preserved, not authenticated-key requirements.
 * NV+TIME/BS admission belongs to the separate policy consumer. This does not
 * validate individual ESL/certificate data or the actual protected index rules.
 */
bool cdk2_image_policy_snapshot_decode_shape(const void *data, size_t size,
	struct cdk2_image_policy_snapshot_view *output);

/*
 * Copy into caller-owned private scratch and publish views of that copy only
 * after validating its complete framing. No origin, attributes authority,
 * malicious-writer coherence, DMA protection or variable-state epoch is proved.
 * Real consumers still require their own protected immutable source/copy lease.
 * Scratch is byte-addressable, disjoint from source/output and exclusively owned;
 * output is aligned. Preflight/invalid-source/capacity refusal changes neither.
 * Post-copy invalid/torn framing may change scratch but never publishes output.
 * Output remains unchanged on every failure. Successful views borrow scratch,
 * which the caller must keep immutable for the full consumer lifetime.
 */
bool cdk2_image_policy_snapshot_copy_shape(const void *data, size_t size,
	void *scratch, size_t capacity, struct cdk2_image_policy_snapshot_view *output);

#endif
