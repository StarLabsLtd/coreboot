/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_SD_DXE_H
#define CDK2_SD_DXE_H

#include <cdk2/disk_io.h>
#include <cdk2/partition.h>
#include <cdk2/sdmmc_pci.h>

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
typedef EFI_STATUS CDK2_MS_ABI cdk2_sd_diagnostic_write_fn(
	void *, UINTN *, void *);
extern void *cdk2_sd_diagnostic_context;
extern cdk2_sd_diagnostic_write_fn *cdk2_sd_diagnostic_write;
#define CDK2_SD_DIAG_SET(context, write) do { \
	cdk2_sd_diagnostic_context = (context); \
	cdk2_sd_diagnostic_write = (write); \
} while (0)
void cdk2_sd_diagnostic(const char *message, UINTN length);
void cdk2_sd_diagnostic_transfer(void);
#define CDK2_SD_DIAG(message) \
	cdk2_sd_diagnostic((message), sizeof(message) - 1U)
#define CDK2_SD_DIAG_TRANSFER() cdk2_sd_diagnostic_transfer()
#else
#define CDK2_SD_DIAG(message) do { } while (0)
#define CDK2_SD_DIAG_TRANSFER() do { } while (0)
#endif

#define CDK2_SD_MAX_DEVICES 8U
#define CDK2_SD_MAX_CONTROLLERS 8U
#define CDK2_SD_BLOCK_SIZE 512U
#ifndef EFI_MEDIA_CHANGED
#define EFI_MEDIA_CHANGED EFIERR(13)
#endif
#ifndef EFI_WRITE_PROTECTED
#define EFI_WRITE_PROTECTED EFIERR(8)
#endif
#ifndef EFI_VOLUME_CORRUPTED
#define EFI_VOLUME_CORRUPTED EFIERR(10)
#endif

struct cdk2_sd_geometry {
	UINT32 media_id, block_size, io_align;
	UINT64 last_block;
	BOOLEAN sector_addressing, read_only, removable;
};

struct cdk2_sd_card {
	UINT8 slot;
	UINT16 rca;
	UINT8 cid[16], csd[16];
	struct cdk2_sd_geometry media;
};

struct cdk2_sd_transfer {
	UINT16 command;
	UINT32 argument, bytes;
	void *buffer;
	BOOLEAN write;
};

typedef EFI_STATUS cdk2_sd_set_clock_fn(void *context,
	struct cdk2_sdmmc_protocol *pass_thru, UINT8 slot, UINT32 frequency);
typedef EFI_STATUS cdk2_sd_media_state_fn(void *context,
	struct cdk2_sdmmc_protocol *pass_thru, UINT8 slot, BOOLEAN *present,
	BOOLEAN *read_only);

struct cdk2_sd_transport {
	struct cdk2_sdmmc_protocol *pass_thru;
	UINT8 slot;
	void *service_context;
	cdk2_sd_set_clock_fn *set_clock;
	cdk2_sd_media_state_fn *media_state;
	void (*stall)(void *context, UINTN microseconds);
	UINT32 operating_ocr;
};

typedef void CDK2_MS_ABI cdk2_sd_event_notify_fn(void *, void *);
typedef EFI_STATUS cdk2_sd_event_create_fn(void *, cdk2_sd_event_notify_fn *,
	void *, void **);
typedef EFI_STATUS cdk2_sd_event_close_fn(void *, void *);
typedef EFI_STATUS cdk2_sd_event_signal_fn(void *, void *);
typedef EFI_STATUS cdk2_sd_event_consume_fn(void *, void *);
typedef UINTN cdk2_sd_lock_fn(void *);
typedef void cdk2_sd_unlock_fn(void *, UINTN);
struct cdk2_sd_async_services {
	void *context;
	cdk2_sd_event_create_fn *create;
	cdk2_sd_event_close_fn *close;
	cdk2_sd_event_signal_fn *signal;
	cdk2_sd_event_consume_fn *consume;
	cdk2_sd_lock_fn *lock;
	cdk2_sd_unlock_fn *unlock;
};

struct cdk2_sd_block {
	struct cdk2_block_io block;
	struct cdk2_block_io2 block2;
	struct cdk2_block_media media;
	struct cdk2_sd_transport *transport;
	struct cdk2_sd_card *card;
	struct cdk2_sd_async_services async_services;
	struct cdk2_sdmmc_command async_command;
	struct cdk2_sdmmc_status async_status;
	struct cdk2_sdmmc_packet async_packet;
	struct cdk2_block_io2_token *async_token;
	UINT8 *async_buffer;
	UINT64 async_lba;
	UINTN async_remaining, async_chunk;
	void *completion_event;
	BOOLEAN async_active, async_write;
};

struct cdk2_sd_disk_info;
typedef EFI_STATUS CDK2_MS_ABI cdk2_sd_info_data_fn(
	struct cdk2_sd_disk_info *, void *, UINT32 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_sd_info_sense_fn(
	struct cdk2_sd_disk_info *, void *, UINT32 *, UINT8 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_sd_info_ide_fn(
	struct cdk2_sd_disk_info *, UINT32 *, UINT32 *);
struct cdk2_sd_disk_info {
	EFI_GUID interface;
	cdk2_sd_info_data_fn *inquiry, *identify;
	cdk2_sd_info_sense_fn *sense;
	cdk2_sd_info_ide_fn *which_ide;
	struct cdk2_sd_card *card;
};

struct cdk2_sd_bound_child {
	void *handle, *path;
	struct cdk2_sd_card card;
	struct cdk2_sd_transport transport;
	struct cdk2_sd_block block;
	struct cdk2_sd_disk_info info;
	BOOLEAN installed, linked;
};

struct cdk2_sd_bound_controller {
	void *handle, *parent_path;
	struct cdk2_sdmmc_protocol *pass_thru;
	struct cdk2_sd_bound_child *child[CDK2_SD_MAX_DEVICES];
	UINTN count;
	BOOLEAN parent_open, marker;
};

typedef EFI_STATUS cdk2_sd_open_parent_fn(void *context, void *handle,
	struct cdk2_sdmmc_protocol **pass_thru, void **parent_path);
typedef EFI_STATUS cdk2_sd_close_parent_fn(void *context, void *handle);
typedef EFI_STATUS cdk2_sd_allocate_fn(void *context, UINTN size,
	void **buffer);
typedef void cdk2_sd_release_fn(void *context, void *buffer);
typedef EFI_STATUS cdk2_sd_marker_fn(void *context, void *handle,
	struct cdk2_sd_bound_controller *controller);
typedef EFI_STATUS cdk2_sd_append_path_fn(void *context, void *parent,
	void *node, void **path);
typedef EFI_STATUS cdk2_sd_child_protocol_fn(void *context,
	struct cdk2_sd_bound_child *child);
typedef EFI_STATUS cdk2_sd_child_link_fn(void *context, void *parent,
	void *child);
typedef EFI_STATUS cdk2_sd_operating_ocr_fn(void *context,
	struct cdk2_sdmmc_protocol *pass_thru, UINT8 slot, UINT32 *ocr);

struct cdk2_sd_binding_services {
	void *context;
	cdk2_sd_open_parent_fn *open_parent;
	cdk2_sd_close_parent_fn *close_parent;
	cdk2_sd_allocate_fn *allocate;
	cdk2_sd_release_fn *release;
	cdk2_sd_marker_fn *mark, *unmark;
	cdk2_sd_append_path_fn *append_path;
	cdk2_sd_child_protocol_fn *install_child, *uninstall_child;
	cdk2_sd_child_link_fn *link_child, *unlink_child;
	cdk2_sd_media_state_fn *media_state;
	cdk2_sd_set_clock_fn *set_clock;
	void (*stall)(void *context, UINTN microseconds);
	cdk2_sd_operating_ocr_fn *get_operating_ocr;
};

struct cdk2_sd_binding {
	struct cdk2_sd_binding_services services;
	struct cdk2_sd_bound_controller *controller[CDK2_SD_MAX_CONTROLLERS];
	UINTN count;
};

EFI_STATUS cdk2_sd_parse_csd(const UINT8 csd[16], UINT32 io_align,
	BOOLEAN removable, struct cdk2_sd_geometry *media);
EFI_STATUS cdk2_sd_validate_io(const struct cdk2_sd_geometry *media,
	UINT32 media_id, UINT64 lba, UINTN bytes, const void *buffer,
	BOOLEAN write);
EFI_STATUS cdk2_sd_build_transfer(const struct cdk2_sd_card *card,
	UINT64 lba, UINTN bytes, void *buffer, BOOLEAN write,
	struct cdk2_sd_transfer *transfer);
EFI_STATUS cdk2_sd_discover_card(struct cdk2_sd_transport *transport,
	UINT32 io_align, BOOLEAN removable, struct cdk2_sd_card *card);
EFI_STATUS cdk2_sd_transfer_sync(struct cdk2_sd_transport *transport,
	const struct cdk2_sd_card *card, UINT64 lba, UINTN bytes, void *buffer,
	BOOLEAN write);
EFI_STATUS cdk2_sd_block_init(struct cdk2_sd_block *block,
	struct cdk2_sd_transport *transport, struct cdk2_sd_card *card);
EFI_STATUS cdk2_sd_block_enable_async(struct cdk2_sd_block *block,
	const struct cdk2_sd_async_services *services);
EFI_STATUS cdk2_sd_block_disable_async(struct cdk2_sd_block *block);
EFI_STATUS cdk2_sd_disk_info_init(struct cdk2_sd_disk_info *info,
	struct cdk2_sd_card *card);
EFI_STATUS cdk2_sd_binding_init(struct cdk2_sd_binding *binding,
	const struct cdk2_sd_binding_services *services);
EFI_STATUS cdk2_sd_binding_start(struct cdk2_sd_binding *binding,
	void *controller, const UINT8 *target_slot);
EFI_STATUS cdk2_sd_binding_stop(struct cdk2_sd_binding *binding,
	void *controller, UINTN child_count, void **children);

#endif
