/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_HANDOFF_H
#define CDK2_SYSTEM_FMP_HANDOFF_H

#include <coreboot_tables.h>

#include <stdint.h>

#define CDK2_SYSTEM_FMP_MAX_REGIONS 16U

struct cdk2_coreboot_handoff;

struct cdk2_system_fmp_region {
	uint64_t image_offset;
	uint64_t flash_offset;
	uint64_t size;
	uint32_t flags;
};

struct cdk2_system_fmp_handoff {
	EFI_GUID image_type;
	uint32_t version;
	uint32_t lowest_supported_version;
	uint32_t capsule_flags;
	uint32_t block_size;
	uint32_t erase_size;
	uint32_t region_count;
	uint64_t image_size;
	uint64_t boot_media_size;
	uint64_t smmstore_offset;
	uint64_t smmstore_size;
	struct cdk2_system_fmp_region regions[CDK2_SYSTEM_FMP_MAX_REGIONS];
};

EFI_STATUS cdk2_system_fmp_handoff_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_handoff *handoff);

#endif
