/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_SIGNATURE_DATABASE_H
#define CDK2_SIGNATURE_DATABASE_H

#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

struct cdk2_signature_database_record {
	const uint8_t *type;
	const uint8_t *owner;
	const uint8_t *header;
	size_t header_size;
	const uint8_t *data;
	size_t size;
};

typedef EFI_STATUS cdk2_signature_database_visit_fn(void *context,
	const struct cdk2_signature_database_record *record);

/*
 * Validate every ESL before visiting any entry. NULL visitor validates only.
 * An empty database is valid; each present list must contain nonempty records.
 * GUIDs are borrowed 16-byte UEFI wire values. All input bytes must remain
 * immutable throughout the call, including inside visitors. This is structural
 * validation only, not signature-type interpretation or image authorization.
 * The record descriptor itself is valid only during its visitor call.
 */
EFI_STATUS cdk2_signature_database_walk(const void *data, size_t size,
	cdk2_signature_database_visit_fn *visit, void *context);

#endif
