/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_AUTHENTICODE_SPC_H
#define CDK2_AUTHENTICODE_SPC_H

#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

struct cdk2_authenticode_spc {
	const uint8_t *signed_data;
	size_t signed_size;
};

/*
 * Bind encapsulated Authenticode ContentInfo to an expected SHA-256 image
 * digest. This neither verifies its signature nor establishes trust. The
 * returned SPC sequence body is borrowed: callers must retain immutable input
 * through any subsequent signature verification. Output changes only on success.
 */
EFI_STATUS cdk2_authenticode_spc_sha256(const void *content_info, size_t size,
	const uint8_t image_digest[32], struct cdk2_authenticode_spc *result);

#endif
