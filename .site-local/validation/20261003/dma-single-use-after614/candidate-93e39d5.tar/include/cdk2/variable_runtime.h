/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_VARIABLE_RUNTIME_H
#define CDK2_VARIABLE_RUNTIME_H

#include <uefi.h>
#include <cdk2/ftw_entry.h>

#ifndef EFI_VOLUME_CORRUPTED
#define EFI_VOLUME_CORRUPTED EFIERR(10)
#endif

#define CDK2_VARIABLE_STORE_BYTES (512U * 1024U)
#define CDK2_VARIABLE_ARENA_BYTES (2U * CDK2_VARIABLE_STORE_BYTES)
#define CDK2_VARIABLE_MIN_RECORD_BYTES 64U
#define CDK2_VARIABLE_MAX_RECORDS \
	(CDK2_VARIABLE_STORE_BYTES / CDK2_VARIABLE_MIN_RECORD_BYTES)
#define CDK2_VARIABLE_MAX_BLOCKS 256U

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
typedef EFI_STATUS CDK2_MS_ABI cdk2_variable_diagnostic_write_fn(
	void *, UINTN *, void *);
void cdk2_variable_diagnostic_set(void *context,
	cdk2_variable_diagnostic_write_fn *write);
void cdk2_variable_diagnostic(const char *message);
#define CDK2_VARIABLE_DIAG(message) cdk2_variable_diagnostic(message)
#else
#define CDK2_VARIABLE_DIAG(message) do { } while (0)
#endif

#define CDK2_VARIABLE_NON_VOLATILE 0x00000001U
#define CDK2_VARIABLE_BOOTSERVICE_ACCESS 0x00000002U
#define CDK2_VARIABLE_RUNTIME_ACCESS 0x00000004U
#define CDK2_VARIABLE_HARDWARE_ERROR_RECORD 0x00000008U
#define CDK2_VARIABLE_AUTHENTICATED_WRITE_ACCESS 0x00000010U
#define CDK2_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS 0x00000020U
#define CDK2_VARIABLE_APPEND_WRITE 0x00000040U

struct cdk2_variable_record {
	EFI_GUID guid;
	UINTN name_bytes, name_offset, data_bytes, data_offset, flash_offset;
	UINT32 attributes;
	UINT8 authentication[28];
	BOOLEAN occupied;
};

struct cdk2_variable_store {
	struct cdk2_variable_record record[CDK2_VARIABLE_MAX_RECORDS];
	UINT8 data[CDK2_VARIABLE_ARENA_BYTES];
	UINTN capacity, used, storage_used, nonvolatile_storage_used,
		volatile_storage_used, arena_used;
	UINT8 erase_byte;
	BOOLEAN runtime, needs_reclaim;
};

typedef EFI_STATUS cdk2_variable_persist_fn(void *context,
	const struct cdk2_variable_store *store);
typedef UINTN cdk2_variable_lock_fn(void *context);
typedef void cdk2_variable_unlock_fn(void *context, UINTN state);
struct cdk2_variable_service {
	struct cdk2_variable_store bank[2];
	UINT8 active;
	void *context;
	cdk2_variable_persist_fn *persist;
	cdk2_variable_lock_fn *lock;
	cdk2_variable_unlock_fn *unlock;
};

EFI_STATUS cdk2_variable_service_init(struct cdk2_variable_service *service,
	UINTN capacity, void *context, cdk2_variable_persist_fn *persist,
	cdk2_variable_lock_fn *lock, cdk2_variable_unlock_fn *unlock);
EFI_STATUS cdk2_variable_service_get(struct cdk2_variable_service *service,
	const CHAR16 *name, const EFI_GUID *guid, UINT32 *attributes,
	UINTN *data_size, void *data);
EFI_STATUS cdk2_variable_service_next(struct cdk2_variable_service *service,
	UINTN *name_size, CHAR16 *name, EFI_GUID *guid);
EFI_STATUS cdk2_variable_service_set(struct cdk2_variable_service *service,
	const CHAR16 *name, const EFI_GUID *guid, UINT32 attributes,
	UINTN data_size, const void *data);
EFI_STATUS cdk2_variable_service_query(struct cdk2_variable_service *service,
	UINT32 attributes, UINT64 *maximum_storage, UINT64 *remaining_storage,
	UINT64 *maximum_variable);
void cdk2_variable_service_enter_runtime(struct cdk2_variable_service *service);

struct cdk2_variable_backend {
	struct cdk2_fvb_protocol_view *fvb;
	struct cdk2_ftw_protocol_view *ftw;
	void *fvb_handle;
	UINT8 *image;
	UINTN image_size, fv_header_size, blocks;
	UINTN block_offset[CDK2_VARIABLE_MAX_BLOCKS];
	UINTN block_size[CDK2_VARIABLE_MAX_BLOCKS];
	struct cdk2_variable_store *scratch_current, *scratch_persistent;
	UINT8 *scratch_image;
	UINT8 erase_byte;
};
EFI_STATUS cdk2_variable_backend_init(struct cdk2_variable_backend *backend,
	struct cdk2_fvb_protocol_view *fvb, void *fvb_handle,
	struct cdk2_ftw_protocol_view *ftw, void *image, UINTN image_size,
	struct cdk2_variable_store *store);
EFI_STATUS cdk2_variable_backend_persist(void *context,
	const struct cdk2_variable_store *store);
EFI_STATUS cdk2_variable_backend_repair(struct cdk2_variable_backend *backend,
	const struct cdk2_variable_store *store);
UINTN cdk2_variable_ftw_batch_begin(UINTN end);
UINTN cdk2_variable_backend_runtime_remaining(
	const struct cdk2_variable_backend *backend);

EFI_STATUS CDK2_MS_ABI cdk2_variable_runtime_entry(void *image, void *system);
void cdk2_variable_runtime_reset_for_test(void);

EFI_STATUS cdk2_variable_store_init(struct cdk2_variable_store *store,
	UINTN capacity);
EFI_STATUS cdk2_variable_get(struct cdk2_variable_store *store,
	const CHAR16 *name, const EFI_GUID *guid, UINT32 *attributes,
	UINTN *data_size, void *data);
EFI_STATUS cdk2_variable_next(struct cdk2_variable_store *store,
	UINTN *name_size, CHAR16 *name, EFI_GUID *guid);
EFI_STATUS cdk2_variable_set(struct cdk2_variable_store *store,
	const CHAR16 *name, const EFI_GUID *guid, UINT32 attributes,
	UINTN data_size, const void *data);
EFI_STATUS cdk2_variable_import_value(struct cdk2_variable_store *store,
	const CHAR16 *name, const EFI_GUID *guid, UINT32 attributes,
	UINTN data_size, const void *data);
const UINT8 *cdk2_variable_record_data(const struct cdk2_variable_store *store,
	const struct cdk2_variable_record *record);
const CHAR16 *cdk2_variable_record_name(const struct cdk2_variable_store *store,
	const struct cdk2_variable_record *record);
struct cdk2_variable_record *cdk2_variable_record_find(
	struct cdk2_variable_store *store, const CHAR16 *name,
	UINTN name_bytes, const EFI_GUID *guid);
EFI_STATUS cdk2_variable_query(struct cdk2_variable_store *store,
	UINT32 attributes, UINT64 *maximum_storage, UINT64 *remaining_storage,
	UINT64 *maximum_variable);
void cdk2_variable_enter_runtime(struct cdk2_variable_store *store);
EFI_STATUS cdk2_variable_import(struct cdk2_variable_store *store,
	const void *image, UINTN image_size);
EFI_STATUS cdk2_variable_export(const struct cdk2_variable_store *store,
	void *image, UINTN *image_size);

#endif
