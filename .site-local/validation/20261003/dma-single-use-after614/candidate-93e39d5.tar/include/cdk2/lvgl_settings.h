/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_LVGL_SETTINGS_H_
#define CDK2_LVGL_SETTINGS_H_

#include <cdk2/capsule_runtime_abi.h>

struct cdk2_lvgl_settings {
	UINT8 scale;
	UINT8 centered;
	UINT8 height_percent;
	UINT8 aspect_width;
	UINT8 aspect_height;
	UINT8 model_in_subtitle;
} __packed;

struct cdk2_lvgl_settings_transaction {
	struct cdk2_runtime_services_view *runtime;
	struct cdk2_lvgl_settings original;
	struct cdk2_lvgl_settings working;
	BOOLEAN active;
};

/* Initialize before begin; runtime must outlive the transaction. */
#define CDK2_LVGL_SETTINGS_TRANSACTION_INITIALIZER { 0 }

void cdk2_lvgl_settings_defaults(struct cdk2_lvgl_settings *settings);
BOOLEAN cdk2_lvgl_settings_valid(const struct cdk2_lvgl_settings *settings);
EFI_STATUS cdk2_lvgl_settings_load(struct cdk2_runtime_services_view *runtime,
	struct cdk2_lvgl_settings *settings);
EFI_STATUS cdk2_lvgl_settings_transaction_begin(
	struct cdk2_runtime_services_view *runtime,
	struct cdk2_lvgl_settings_transaction *transaction);
EFI_STATUS cdk2_lvgl_settings_transaction_validate(
	const struct cdk2_lvgl_settings_transaction *transaction);
/* A failed commit leaves the transaction active for correction or discard. */
EFI_STATUS cdk2_lvgl_settings_transaction_commit(
	struct cdk2_lvgl_settings_transaction *transaction);
void cdk2_lvgl_settings_transaction_discard(
	struct cdk2_lvgl_settings_transaction *transaction);

#endif
