/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_CPU_ARCH_H
#define CDK2_CPU_ARCH_H

#include <uefi.h>

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_diagnostic_write_fn(
	void *, UINTN *, void *);
void cdk2_cpu_diagnostic_set(void *context,
	cdk2_cpu_diagnostic_write_fn *write);
void cdk2_cpu_diagnostic(const char *message);
#define CDK2_CPU_DIAG(message) cdk2_cpu_diagnostic(message)
#else
#define CDK2_CPU_DIAG(message) do { } while (0)
#endif

struct cdk2_cpu_arch;
typedef void CDK2_MS_ABI cdk2_cpu_interrupt_fn(UINTN type, void *context);
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_flush_fn(struct cdk2_cpu_arch *cpu,
	UINT64 start, UINT64 length, UINT32 type);
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_state_fn(struct cdk2_cpu_arch *cpu);
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_get_state_fn(
	struct cdk2_cpu_arch *cpu, BOOLEAN *state);
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_init_fn(struct cdk2_cpu_arch *cpu,
	UINT32 type);
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_register_fn(
	struct cdk2_cpu_arch *cpu, UINTN type, cdk2_cpu_interrupt_fn *handler);
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_timer_fn(struct cdk2_cpu_arch *cpu,
	UINT32 index, UINT64 *value, UINT64 *period);
typedef EFI_STATUS CDK2_MS_ABI cdk2_cpu_attributes_fn(
	struct cdk2_cpu_arch *cpu, UINT64 base, UINT64 length, UINT64 attributes);

struct cdk2_cpu_arch {
	cdk2_cpu_flush_fn *flush_data_cache;
	cdk2_cpu_state_fn *enable_interrupt;
	cdk2_cpu_state_fn *disable_interrupt;
	cdk2_cpu_get_state_fn *get_interrupt_state;
	cdk2_cpu_init_fn *init;
	cdk2_cpu_register_fn *register_interrupt_handler;
	cdk2_cpu_timer_fn *get_timer_value;
	cdk2_cpu_attributes_fn *set_memory_attributes;
	UINT32 number_of_timers;
	UINT32 dma_buffer_alignment;
};

typedef void cdk2_cpu_flush_hardware_fn(BOOLEAN invalidate_only);
typedef void cdk2_cpu_set_interrupt_fn(BOOLEAN enabled);
typedef BOOLEAN cdk2_cpu_get_interrupt_fn(void);
typedef EFI_STATUS cdk2_cpu_register_hardware_fn(UINTN type,
	cdk2_cpu_interrupt_fn *handler);
typedef UINT64 cdk2_cpu_read_timer_fn(void);
typedef EFI_STATUS cdk2_cpu_set_attributes_fn(UINT64 base, UINT64 length,
	UINT64 attributes);

struct cdk2_cpu_arch_ops {
	cdk2_cpu_flush_hardware_fn *flush;
	cdk2_cpu_set_interrupt_fn *set_interrupt;
	cdk2_cpu_get_interrupt_fn *get_interrupt;
	cdk2_cpu_register_hardware_fn *register_interrupt;
	cdk2_cpu_read_timer_fn *read_timer;
	cdk2_cpu_set_attributes_fn *set_attributes;
};

typedef UINT64 *cdk2_cpu_map_page_fn(UINT64 physical);
typedef EFI_STATUS cdk2_cpu_allocate_page_fn(UINT64 *physical);
typedef void cdk2_cpu_free_page_fn(UINT64 physical);
typedef EFI_STATUS cdk2_cpu_flush_tlb_fn(BOOLEAN global);
typedef EFI_STATUS cdk2_cpu_flush_cache_fn(void);
typedef BOOLEAN cdk2_cpu_page_hidden_fn(const UINT64 *entry);
typedef EFI_STATUS cdk2_cpu_set_page_hidden_fn(const UINT64 *entry,
	BOOLEAN hidden);
typedef EFI_STATUS cdk2_cpu_reserve_hidden_fn(UINTN entries);

struct cdk2_cpu_page_ops {
	cdk2_cpu_map_page_fn *map_page;
	cdk2_cpu_allocate_page_fn *allocate_page;
	cdk2_cpu_free_page_fn *free_page;
	cdk2_cpu_flush_tlb_fn *flush_tlb;
	cdk2_cpu_flush_cache_fn *flush_cache;
	cdk2_cpu_page_hidden_fn *page_hidden;
	cdk2_cpu_set_page_hidden_fn *set_page_hidden;
	cdk2_cpu_reserve_hidden_fn *reserve_hidden;
	UINT64 pat;
	BOOLEAN nx;
};

EFI_STATUS cdk2_cpu_arch_init(const struct cdk2_cpu_arch_ops *ops,
	UINT64 timer_period);
struct cdk2_cpu_arch *cdk2_cpu_arch_protocol(void);
EFI_STATUS cdk2_cpu_set_page_attributes(const struct cdk2_cpu_page_ops *ops,
	UINT64 root, UINTN levels, UINT64 base, UINT64 length, UINT64 attributes);
EFI_STATUS cdk2_cpu_interrupt_init(void);
void cdk2_cpu_interrupt_set_synchronize(EFI_STATUS (*synchronize)(void));
void cdk2_cpu_interrupt_set_current_processor(
	EFI_STATUS (*current_processor)(UINTN *processor));
EFI_STATUS cdk2_cpu_interrupt_ap_storage_size(UINTN processors, UINTN *size);
EFI_STATUS cdk2_cpu_interrupt_set_ap_storage(void *storage, UINTN size);
EFI_STATUS cdk2_cpu_interrupt_load(void);
EFI_STATUS cdk2_cpu_interrupt_prepare_bsp_switch(void);
EFI_STATUS cdk2_cpu_interrupt_adopt_current(void);
EFI_STATUS cdk2_cpu_interrupt_restore_ap(void);
void cdk2_cpu_interrupt_restore(void);
EFI_STATUS cdk2_cpu_interrupt_register(UINTN type,
	cdk2_cpu_interrupt_fn *handler);
#ifdef CDK2_CPU_INTERRUPT_TEST
void cdk2_cpu_interrupt_test_set_idt(void *base, UINT16 limit);
void cdk2_cpu_interrupt_test_set_current_idt(void *base, UINT16 limit);
void *cdk2_cpu_interrupt_test_current_idt(void);
#endif
#ifdef CDK2_CPU_DRIVER_TEST
EFI_STATUS cdk2_cpu_driver_test_flush_tlb(BOOLEAN global);
UINTN cdk2_cpu_driver_test_tlb_flush_count(void);
EFI_STATUS cdk2_cpu_driver_test_mul_div(UINT64 multiplicand,
	UINT32 multiplier, UINT64 divisor, UINT64 *result);
UINT64 cdk2_cpu_driver_test_page_address(UINT64 physical, UINT64 mask);
EFI_STATUS cdk2_cpu_driver_test_validate_pat(UINT64 expected, UINT64 actual);
EFI_STATUS cdk2_cpu_driver_test_page_state(UINT64 expected_root,
	UINT64 actual_root, BOOLEAN nx_required, BOOLEAN nx_active);
#endif

#endif
