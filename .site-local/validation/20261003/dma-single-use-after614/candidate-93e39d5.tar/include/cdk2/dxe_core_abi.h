/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_DXE_CORE_ABI_H_
#define CDK2_DXE_CORE_ABI_H_

#include <uefi.h>

struct cdk2_dxe_table_header {
	UINT64 signature;
	UINT32 revision;
	UINT32 header_size;
	UINT32 crc32;
	UINT32 reserved;
};

struct cdk2_dxe_boot_services {
	struct cdk2_dxe_table_header header;
	void *raise_tpl;
	void *restore_tpl;
	void *allocate_pages;
	void *free_pages;
	void *get_memory_map;
	void *allocate_pool;
	void *free_pool;
	void *create_event;
	void *set_timer;
	void *wait_for_event;
	void *signal_event;
	void *close_event;
	void *check_event;
	void *install_protocol;
	void *reinstall_protocol;
	void *uninstall_protocol;
	void *handle_protocol;
	void *reserved;
	void *register_protocol_notify;
	void *locate_handle;
	void *locate_device_path;
	void *install_configuration_table;
	void *load_image;
	void *start_image;
	void *exit;
	void *unload_image;
	void *exit_boot_services;
	void *get_next_monotonic_count;
	void *stall;
	void *set_watchdog_timer;
	void *connect_controller;
	void *disconnect_controller;
	void *open_protocol;
	void *close_protocol;
	void *open_protocol_information;
	void *protocols_per_handle;
	void *locate_handle_buffer;
	void *locate_protocol;
	void *install_multiple;
	void *uninstall_multiple;
	void *calculate_crc32;
	void *copy_mem;
	void *set_mem;
	void *create_event_ex;
};

struct cdk2_dxe_runtime_services {
	struct cdk2_dxe_table_header header;
	void *get_time;
	void *set_time;
	void *get_wakeup_time;
	void *set_wakeup_time;
	void *set_virtual_address_map;
	void *convert_pointer;
	void *get_variable;
	void *get_next_variable_name;
	void *set_variable;
	void *get_next_high_monotonic_count;
	void *reset_system;
	void *update_capsule;
	void *query_capsule_capabilities;
	void *query_variable_info;
};

struct cdk2_dxe_services {
	struct cdk2_dxe_table_header header;
	void *add_memory_space;
	void *allocate_memory_space;
	void *free_memory_space;
	void *remove_memory_space;
	void *get_memory_space_descriptor;
	void *set_memory_space_attributes;
	void *get_memory_space_map;
	void *add_io_space;
	void *allocate_io_space;
	void *free_io_space;
	void *remove_io_space;
	void *get_io_space_descriptor;
	void *get_io_space_map;
	void *dispatch;
	void *schedule;
	void *trust;
	void *process_firmware_volume;
};

struct cdk2_dxe_configuration_table {
	EFI_GUID guid;
	void *table;
};

struct cdk2_dxe_system_table {
	struct cdk2_dxe_table_header header;
	CHAR16 *firmware_vendor;
	UINT32 firmware_revision;
	UINT32 padding;
	void *console_in_handle;
	void *console_in;
	void *console_out_handle;
	void *console_out;
	void *standard_error_handle;
	void *standard_error;
	void *runtime_services;
	struct cdk2_dxe_boot_services *boot_services;
	UINTN number_of_table_entries;
	struct cdk2_dxe_configuration_table *configuration_table;
};

typedef char cdk2_dxe_bs_allocate_pool_offset
	[(offsetof(struct cdk2_dxe_boot_services, allocate_pool) == 64) ? 1 : -1];
typedef char cdk2_dxe_bs_open_offset
	[(offsetof(struct cdk2_dxe_boot_services, open_protocol) == 280) ? 1 : -1];
typedef char cdk2_dxe_bs_create_event_ex_offset
	[(offsetof(struct cdk2_dxe_boot_services, create_event_ex) == 368) ? 1 : -1];
typedef char cdk2_dxe_system_boot_offset
	[(offsetof(struct cdk2_dxe_system_table, boot_services) == 96) ? 1 : -1];
typedef char cdk2_dxe_runtime_size
	[(sizeof(struct cdk2_dxe_runtime_services) == 136) ? 1 : -1];
typedef char cdk2_dxe_services_size
	[(sizeof(struct cdk2_dxe_services) == 160) ? 1 : -1];

#endif
