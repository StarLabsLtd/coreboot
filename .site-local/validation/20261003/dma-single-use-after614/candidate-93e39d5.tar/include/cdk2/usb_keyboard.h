/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_USB_KEYBOARD_H
#define CDK2_USB_KEYBOARD_H

#include <cdk2/usb_bus.h>

#define CDK2_USB_KEYBOARD_KEYS 6U
#define CDK2_USB_KEYBOARD_QUEUE 32U
#define CDK2_USB_KEYBOARD_CONTROLLERS 16U
#define CDK2_USB_KEYBOARD_NOTIFICATIONS 16U
#define CDK2_USB_KEYBOARD_REPEAT_DELAY 50U
#define CDK2_USB_KEYBOARD_REPEAT_RATE 5U
#define CDK2_USB_KEYBOARD_LAYOUT_KEYS 256U
#define CDK2_USB_KEYBOARD_LAYOUT_DEPENDENCIES 255U
#define CDK2_KEY_SHIFT_VALID 0x80000000U
#define CDK2_KEY_LEFT_SHIFT 0x00000002U
#define CDK2_KEY_RIGHT_SHIFT 0x00000001U
#define CDK2_KEY_LEFT_CONTROL 0x00000008U
#define CDK2_KEY_RIGHT_CONTROL 0x00000004U
#define CDK2_KEY_LEFT_ALT 0x00000020U
#define CDK2_KEY_RIGHT_ALT 0x00000010U
#define CDK2_KEY_LEFT_LOGO 0x00000080U
#define CDK2_KEY_RIGHT_LOGO 0x00000040U
#define CDK2_KEY_SHIFT_STATE_VALID 0x80000000U
#define CDK2_KEY_TOGGLE_STATE_VALID 0x80U
#define CDK2_KEY_STATE_EXPOSED 0x40U

struct cdk2_usb_keyboard_report {
	UINT8 modifiers, reserved, keys[CDK2_USB_KEYBOARD_KEYS];
};

struct cdk2_usb_keyboard_key {
	UINT16 scan_code, unicode_char;
	UINT32 shift_state;
	UINT8 toggle_state, reserved[3];
};

struct cdk2_simple_text_input;
struct cdk2_simple_text_input_ex;
typedef EFI_STATUS CDK2_MS_ABI cdk2_text_reset_fn(
	struct cdk2_simple_text_input *, BOOLEAN);
typedef EFI_STATUS CDK2_MS_ABI cdk2_text_read_fn(
	struct cdk2_simple_text_input *, void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_text_reset_ex_fn(
	struct cdk2_simple_text_input_ex *, BOOLEAN);
typedef EFI_STATUS CDK2_MS_ABI cdk2_text_read_ex_fn(
	struct cdk2_simple_text_input_ex *, struct cdk2_usb_keyboard_key *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_text_set_state_fn(
	struct cdk2_simple_text_input_ex *, UINT8 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_key_notify_fn(
	struct cdk2_usb_keyboard_key *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_text_register_fn(
	struct cdk2_simple_text_input_ex *, struct cdk2_usb_keyboard_key *,
	cdk2_key_notify_fn *, void **);
typedef EFI_STATUS CDK2_MS_ABI cdk2_text_unregister_fn(
	struct cdk2_simple_text_input_ex *, void *);
struct cdk2_simple_text_input {
	cdk2_text_reset_fn *reset;
	cdk2_text_read_fn *read_key_stroke;
	void *wait_for_key;
};
struct cdk2_simple_text_input_ex {
	cdk2_text_reset_ex_fn *reset;
	cdk2_text_read_ex_fn *read_key_stroke_ex;
	void *wait_for_key_ex;
	cdk2_text_set_state_fn *set_state;
	cdk2_text_register_fn *register_key_notify;
	cdk2_text_unregister_fn *unregister_key_notify;
};
struct cdk2_usb_keyboard_notification {
	struct cdk2_usb_keyboard_key key;
	cdk2_key_notify_fn *notify;
	UINTN generation;
	BOOLEAN active;
};

struct cdk2_usb_keyboard_layout_key {
	UINT8 code;
	CHAR16 normal, shifted, altgr, shifted_altgr;
	UINT16 modifier, affected;
};

struct cdk2_usb_keyboard_layout_dependency {
	UINT8 dead_code, code;
	CHAR16 normal, shifted, altgr, shifted_altgr;
	UINT16 affected;
};

struct cdk2_usb_keyboard_layout {
	const struct cdk2_usb_keyboard_layout_key *keys;
	UINTN key_count;
	const struct cdk2_usb_keyboard_layout_dependency *dependencies;
	UINTN dependency_count;
};

struct cdk2_usb_keyboard_mapping {
	CHAR16 normal, shifted, altgr, shifted_altgr;
	UINT16 modifier, affected;
	BOOLEAN present;
};

struct cdk2_usb_keyboard {
	struct cdk2_usb_keyboard_report previous;
	struct cdk2_usb_keyboard_key queue[CDK2_USB_KEYBOARD_QUEUE];
	UINTN head, count;
	UINTN repeat_ticks;
	struct cdk2_usb_keyboard_key repeat_key;
	UINT8 repeat_code, repeat_modifiers;
	BOOLEAN caps_lock, num_lock, scroll_lock, repeat_composed;
	struct cdk2_usb_keyboard_mapping layout[CDK2_USB_KEYBOARD_LAYOUT_KEYS];
	struct cdk2_usb_keyboard_layout_dependency dependencies[
		CDK2_USB_KEYBOARD_LAYOUT_DEPENDENCIES];
	UINT16 dependency_count;
	UINT8 pending_dead, pending_dead_modifiers;
	BOOLEAN layout_active;
};

typedef UINTN CDK2_MS_ABI cdk2_usb_keyboard_raise_tpl_fn(UINTN);
typedef void CDK2_MS_ABI cdk2_usb_keyboard_restore_tpl_fn(UINTN);

struct cdk2_usb_keyboard_device {
	struct cdk2_usb_keyboard keyboard;
	struct cdk2_simple_text_input input;
	struct cdk2_simple_text_input_ex input_ex;
	struct cdk2_usb_keyboard_notification notifications[
		CDK2_USB_KEYBOARD_NOTIFICATIONS];
	struct cdk2_usb_io_protocol *usb;
	UINT8 interface, endpoint, interval;
	UINT16 packet_size;
	UINTN active_calls, notification_generation;
	BOOLEAN active, recovery_pending, producer_busy, resetting, stopping;
	BOOLEAN quiescing, quiesced;
	cdk2_usb_keyboard_raise_tpl_fn *raise_tpl;
	cdk2_usb_keyboard_restore_tpl_fn *restore_tpl;
};

struct cdk2_usb_keyboard_controller {
	struct cdk2_usb_keyboard_device device;
	void *handle, *wait, *wait_ex, *repeat_timer;
	BOOLEAN installed, opened;
};
typedef EFI_STATUS cdk2_usb_keyboard_open_fn(void *, void *,
	struct cdk2_usb_io_protocol **);
typedef EFI_STATUS cdk2_usb_keyboard_close_fn(void *, void *);
typedef EFI_STATUS cdk2_usb_keyboard_event_fn(void *,
	struct cdk2_usb_keyboard_controller *, BOOLEAN, void **);
typedef EFI_STATUS cdk2_usb_keyboard_close_event_fn(void *, void *);
typedef EFI_STATUS cdk2_usb_keyboard_timer_fn(void *, void *, BOOLEAN);
typedef EFI_STATUS cdk2_usb_keyboard_publish_fn(void *, void *,
	struct cdk2_usb_keyboard_controller *);
typedef EFI_STATUS cdk2_usb_keyboard_remove_fn(void *, void *,
	struct cdk2_usb_keyboard_controller *);
typedef EFI_STATUS cdk2_usb_keyboard_allocate_fn(void *, UINTN, void **);
typedef void cdk2_usb_keyboard_release_fn(void *, void *);
struct cdk2_usb_keyboard_binding_services {
	void *context;
	cdk2_usb_keyboard_open_fn *open;
	cdk2_usb_keyboard_close_fn *close;
	cdk2_usb_keyboard_event_fn *create_event;
	cdk2_usb_keyboard_event_fn *create_repeat_event;
	cdk2_usb_keyboard_close_event_fn *close_event;
	cdk2_usb_keyboard_timer_fn *set_repeat_timer;
	cdk2_usb_keyboard_publish_fn *publish;
	cdk2_usb_keyboard_remove_fn *remove;
	cdk2_usb_keyboard_allocate_fn *allocate;
	cdk2_usb_keyboard_release_fn *release;
	cdk2_usb_keyboard_raise_tpl_fn *raise_tpl;
	cdk2_usb_keyboard_restore_tpl_fn *restore_tpl;
};
struct cdk2_usb_keyboard_binding {
	struct cdk2_usb_keyboard_binding_services services;
	struct cdk2_usb_keyboard_controller *controllers[
		CDK2_USB_KEYBOARD_CONTROLLERS];
	UINTN count;
	BOOLEAN lifecycle_busy, quiesced;
};

EFI_STATUS cdk2_usb_keyboard_init(struct cdk2_usb_keyboard *keyboard);
EFI_STATUS cdk2_usb_keyboard_set_layout(struct cdk2_usb_keyboard *keyboard,
	const struct cdk2_usb_keyboard_layout *layout);
EFI_STATUS cdk2_usb_keyboard_report(struct cdk2_usb_keyboard *keyboard,
	const void *report, UINTN length);
EFI_STATUS cdk2_usb_keyboard_repeat_tick(struct cdk2_usb_keyboard *keyboard);
EFI_STATUS cdk2_usb_keyboard_read(struct cdk2_usb_keyboard *keyboard,
	struct cdk2_usb_keyboard_key *key);
EFI_STATUS cdk2_usb_keyboard_start_io(struct cdk2_usb_keyboard_device *device,
	struct cdk2_usb_io_protocol *usb);
EFI_STATUS cdk2_usb_keyboard_stop_io(struct cdk2_usb_keyboard_device *device);
EFI_STATUS cdk2_usb_keyboard_reset_io(struct cdk2_usb_keyboard_device *device);
EFI_STATUS cdk2_usb_keyboard_reset_io_owned(
	struct cdk2_usb_keyboard_device *device);
EFI_STATUS cdk2_usb_keyboard_call_enter(
	struct cdk2_usb_keyboard_device *device);
void cdk2_usb_keyboard_call_leave(struct cdk2_usb_keyboard_device *device);
EFI_STATUS cdk2_usb_keyboard_producer_enter(
	struct cdk2_usb_keyboard_device *device);
void cdk2_usb_keyboard_producer_leave(
	struct cdk2_usb_keyboard_device *device);
EFI_STATUS cdk2_usb_keyboard_service(struct cdk2_usb_keyboard_device *device);
EFI_STATUS cdk2_usb_keyboard_set_state(
	struct cdk2_usb_keyboard_device *device, UINT8 state);
EFI_STATUS cdk2_usb_keyboard_set_state_owned(
	struct cdk2_usb_keyboard_device *device, UINT8 state);
EFI_STATUS cdk2_usb_keyboard_protocol_init(
	struct cdk2_usb_keyboard_device *device, void *wait, void *wait_ex);
EFI_STATUS cdk2_usb_keyboard_binding_init(
	struct cdk2_usb_keyboard_binding *binding,
	const struct cdk2_usb_keyboard_binding_services *services);
EFI_STATUS cdk2_usb_keyboard_binding_supported(
	struct cdk2_usb_keyboard_binding *binding, void *controller);
EFI_STATUS cdk2_usb_keyboard_binding_start(
	struct cdk2_usb_keyboard_binding *binding, void *controller);
EFI_STATUS cdk2_usb_keyboard_binding_stop(
	struct cdk2_usb_keyboard_binding *binding, void *controller);
EFI_STATUS cdk2_usb_keyboard_binding_quiesce(void *context);

#endif
