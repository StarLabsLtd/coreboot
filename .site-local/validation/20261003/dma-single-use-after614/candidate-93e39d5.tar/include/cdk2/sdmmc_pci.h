/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_SDMMC_PCI_H
#define CDK2_SDMMC_PCI_H

#include <cdk2/diagnostic.h>
#include <uefi.h>
#include <cdk2/pci_io_abi.h>

#define CDK2_SDMMC_MAX_SLOTS 6U
#ifndef EFI_NO_MEDIA
#define EFI_NO_MEDIA EFIERR(12)
#endif
#ifndef EFI_ABORTED
#define EFI_ABORTED EFIERR(21)
#endif

struct cdk2_sdmmc_slot {
	UINT8 number, bar;
	BOOLEAN present, removable, emmc, write_protected;
	UINT32 base_clock_hz, maximum_block_length;
	UINT64 voltage_mask;
};

struct cdk2_sdmmc_controller {
	struct cdk2_sdmmc_slot slot[CDK2_SDMMC_MAX_SLOTS];
	UINTN count;
	UINT32 io_align;
};

struct cdk2_sdmmc_pci {
	struct cdk2_efi_pci_io_protocol *pci;
	void *delay_context;
	void (*delay)(void *context, UINTN microseconds);
	UINT64 original_attributes;
	UINT32 base_clock_hz[8];
	UINT32 operating_ocr[8];
	UINT16 version[8];
	UINT32 maximum_block_length[8];
	BOOLEAN present[8], removable[8], emmc[8], app_cmd[8];
	BOOLEAN attributes_owned;
};

enum cdk2_sdmmc_async_phase {
	CDK2_SDMMC_ASYNC_IDLE,
	CDK2_SDMMC_ASYNC_READ_SLOT_INFO,
	CDK2_SDMMC_ASYNC_RESET_CLEAR_NORMAL,
	CDK2_SDMMC_ASYNC_RESET_CLEAR_ERROR,
	CDK2_SDMMC_ASYNC_RESET_LINES,
	CDK2_SDMMC_ASYNC_RESET_WAIT_LINES,
	CDK2_SDMMC_ASYNC_READ_PRESENT,
	CDK2_SDMMC_ASYNC_SET_CLOCK,
	CDK2_SDMMC_ASYNC_WAIT_CLOCK,
	CDK2_SDMMC_ASYNC_WRITE_BLOCK_SIZE,
	CDK2_SDMMC_ASYNC_WRITE_BLOCK_COUNT,
	CDK2_SDMMC_ASYNC_WRITE_TRANSFER,
	CDK2_SDMMC_ASYNC_WRITE_ARGUMENT,
	CDK2_SDMMC_ASYNC_WRITE_COMMAND,
	CDK2_SDMMC_ASYNC_WAIT_COMMAND,
	CDK2_SDMMC_ASYNC_CLEAR_COMMAND,
	CDK2_SDMMC_ASYNC_READ_RESPONSE,
	CDK2_SDMMC_ASYNC_WAIT_BUFFER,
	CDK2_SDMMC_ASYNC_CLEAR_BUFFER,
	CDK2_SDMMC_ASYNC_TRANSFER_WORD,
	CDK2_SDMMC_ASYNC_WAIT_COMPLETE,
	CDK2_SDMMC_ASYNC_CLEAR_COMPLETE,
	CDK2_SDMMC_ASYNC_RECOVER_CLEAR_NORMAL,
	CDK2_SDMMC_ASYNC_RECOVER_CLEAR_ERROR,
	CDK2_SDMMC_ASYNC_RECOVER_RESET,
	CDK2_SDMMC_ASYNC_RECOVER_WAIT_RESET,
	CDK2_SDMMC_ASYNC_DONE
};

struct cdk2_sdmmc_async {
	struct cdk2_sdmmc_pci *adapter;
	struct cdk2_sdmmc_packet *packet;
	void *event;
	enum cdk2_sdmmc_async_phase phase, resume_phase;
	EFI_STATUS result;
	UINT64 elapsed;
	UINTN recovery_elapsed;
	UINT32 transfer_offset, word_offset;
	UINT16 block_size, block_count, transfer_mode, command, interrupt;
	UINT8 slot, bar, reset;
	BOOLEAN write_data, command_issued;
};

struct cdk2_sdmmc_command { UINT16 index; UINT32 argument, type, response; };
struct cdk2_sdmmc_status { UINT32 response[4]; };
struct cdk2_sdmmc_packet {
	struct cdk2_sdmmc_command *command;
	struct cdk2_sdmmc_status *status;
	UINT64 timeout;
	void *in_buffer, *out_buffer;
	UINT32 in_length, out_length;
	EFI_STATUS transaction_status;
};

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
void cdk2_sdmmc_diagnostic(const char *message);
void cdk2_sdmmc_diagnostic_status(const char *message, EFI_STATUS status);
#else
#define cdk2_sdmmc_diagnostic(message) do { } while (0)
#define cdk2_sdmmc_diagnostic_status(message, status) do { } while (0)
#endif

struct cdk2_sdmmc_protocol;
struct cdk2_sdmmc_mode { UINT32 attributes, io_align; };
typedef EFI_STATUS CDK2_MS_ABI cdk2_sdmmc_pass_fn(struct cdk2_sdmmc_protocol *,
	UINT8, struct cdk2_sdmmc_packet *, void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_sdmmc_next_fn(struct cdk2_sdmmc_protocol *,
	UINT8 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_sdmmc_build_fn(struct cdk2_sdmmc_protocol *,
	UINT8, void **);
typedef EFI_STATUS CDK2_MS_ABI cdk2_sdmmc_get_fn(struct cdk2_sdmmc_protocol *,
	void *, UINT8 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_sdmmc_reset_fn(struct cdk2_sdmmc_protocol *,
	UINT8);
struct cdk2_sdmmc_protocol {
	struct cdk2_sdmmc_mode *mode;
	cdk2_sdmmc_pass_fn *pass;
	cdk2_sdmmc_next_fn *next;
	cdk2_sdmmc_build_fn *build_path;
	cdk2_sdmmc_get_fn *get_slot;
	cdk2_sdmmc_reset_fn *reset;
};

typedef EFI_STATUS cdk2_sdmmc_execute_fn(void *, UINT8,
	struct cdk2_sdmmc_packet *);
typedef EFI_STATUS cdk2_sdmmc_submit_fn(void *, UINT8,
	struct cdk2_sdmmc_packet *, void *);
typedef EFI_STATUS cdk2_sdmmc_cancel_fn(void *, UINT8);
typedef EFI_STATUS cdk2_sdmmc_refresh_fn(void *, UINT8, BOOLEAN *);
typedef EFI_STATUS cdk2_sdmmc_clock_fn(void *, UINT8, UINT32);
typedef EFI_STATUS cdk2_sdmmc_pool_fn(void *, UINTN, void **);
struct cdk2_sdmmc_protocol_instance {
	struct cdk2_sdmmc_protocol protocol;
	struct cdk2_sdmmc_mode mode;
	struct cdk2_sdmmc_controller *controller;
	void *context;
	cdk2_sdmmc_execute_fn *execute;
	cdk2_sdmmc_submit_fn *submit;
	cdk2_sdmmc_cancel_fn *cancel;
	BOOLEAN *async_active;
	cdk2_sdmmc_refresh_fn *refresh;
	cdk2_sdmmc_clock_fn *clock;
	cdk2_sdmmc_pool_fn *allocate;
	BOOLEAN *busy;
	UINT32 signature;
};

typedef EFI_STATUS cdk2_sdmmc_open_fn(void *, void *, void **);
typedef EFI_STATUS cdk2_sdmmc_close_fn(void *, void *);
typedef EFI_STATUS cdk2_sdmmc_install_fn(void *, void *,
	struct cdk2_sdmmc_protocol *);
typedef EFI_STATUS cdk2_sdmmc_uninstall_fn(void *, void *,
	struct cdk2_sdmmc_protocol *);
typedef void cdk2_sdmmc_delay_fn(void *, UINTN);
struct cdk2_sdmmc_binding_controller;
typedef EFI_STATUS cdk2_sdmmc_async_prepare_fn(void *,
	struct cdk2_sdmmc_binding_controller *);
typedef EFI_STATUS cdk2_sdmmc_async_release_fn(void *,
	struct cdk2_sdmmc_binding_controller *);
struct cdk2_sdmmc_binding_services {
	void *context;
	cdk2_sdmmc_open_fn *open;
	cdk2_sdmmc_close_fn *close;
	cdk2_sdmmc_install_fn *install;
	cdk2_sdmmc_uninstall_fn *uninstall;
	cdk2_sdmmc_delay_fn *delay;
	cdk2_sdmmc_async_prepare_fn *prepare_async;
	cdk2_sdmmc_async_release_fn *release_async;
};
struct cdk2_sdmmc_binding_controller {
	void *handle, *pci;
	BOOLEAN parent_open, protocol_installed;
	struct cdk2_sdmmc_pci adapter;
	struct cdk2_sdmmc_controller controller;
	struct cdk2_sdmmc_protocol_instance protocol;
	struct cdk2_sdmmc_async async;
	void *timer;
	BOOLEAN active;
};
struct cdk2_sdmmc_binding {
	struct cdk2_sdmmc_binding_services services;
	struct cdk2_sdmmc_binding_controller controller[8];
	UINTN count;
};

EFI_STATUS cdk2_sdmmc_add_slot(struct cdk2_sdmmc_controller *controller,
	const struct cdk2_sdmmc_slot *slot);
EFI_STATUS cdk2_sdmmc_next_slot(const struct cdk2_sdmmc_controller *controller,
	UINT8 *slot);
EFI_STATUS cdk2_sdmmc_validate_packet(
	const struct cdk2_sdmmc_controller *controller, UINT8 slot,
	const struct cdk2_sdmmc_packet *packet);
EFI_STATUS cdk2_sdmmc_transfer_geometry(
	const struct cdk2_sdmmc_command *command, UINT32 bytes,
	UINT32 maximum_block_length, UINT16 *block_size, UINT16 *block_count);
EFI_STATUS cdk2_sdmmc_pci_init(struct cdk2_sdmmc_pci *adapter,
	struct cdk2_efi_pci_io_protocol *pci);
EFI_STATUS cdk2_sdmmc_pci_discover(struct cdk2_sdmmc_pci *adapter,
	struct cdk2_sdmmc_controller *controller);
EFI_STATUS cdk2_sdmmc_pci_release(struct cdk2_sdmmc_pci *adapter);
EFI_STATUS cdk2_sdmmc_pci_reacquire(struct cdk2_sdmmc_pci *adapter);
EFI_STATUS cdk2_sdmmc_protocol_operating_ocr(
	struct cdk2_sdmmc_protocol *protocol, UINT8 slot, UINT32 *ocr);
EFI_STATUS cdk2_sdmmc_pci_execute(void *context, UINT8 slot,
	struct cdk2_sdmmc_packet *packet);
EFI_STATUS cdk2_sdmmc_pci_apply_bus_width(struct cdk2_sdmmc_pci *adapter,
	UINT8 slot, UINT8 bar, UINT16 command, UINT32 argument, UINT32 response);
EFI_STATUS cdk2_sdmmc_pci_refresh(void *context, UINT8 slot,
	BOOLEAN *present);
EFI_STATUS cdk2_sdmmc_async_prepare(struct cdk2_sdmmc_async *request,
	struct cdk2_sdmmc_pci *adapter, UINT8 slot,
	struct cdk2_sdmmc_packet *packet, void *event);
EFI_STATUS cdk2_sdmmc_async_step(struct cdk2_sdmmc_async *request);
EFI_STATUS cdk2_sdmmc_async_abort(struct cdk2_sdmmc_async *request);
void cdk2_sdmmc_async_complete(struct cdk2_sdmmc_async *request,
	EFI_STATUS status);
void cdk2_sdmmc_normalize_response(struct cdk2_sdmmc_packet *packet,
	UINT32 response[4]);
EFI_STATUS cdk2_sdmmc_protocol_init(
	struct cdk2_sdmmc_protocol_instance *instance,
	struct cdk2_sdmmc_controller *controller, void *context,
	cdk2_sdmmc_execute_fn *execute, cdk2_sdmmc_pool_fn *allocate);
EFI_STATUS cdk2_sdmmc_protocol_enable_async(
	struct cdk2_sdmmc_protocol_instance *instance,
	cdk2_sdmmc_submit_fn *submit, cdk2_sdmmc_cancel_fn *cancel,
	BOOLEAN *active);
void cdk2_sdmmc_protocol_enable_refresh(
	struct cdk2_sdmmc_protocol_instance *instance,
	cdk2_sdmmc_refresh_fn *refresh);
void cdk2_sdmmc_protocol_set_busy(
	struct cdk2_sdmmc_protocol_instance *instance, BOOLEAN *busy);
EFI_STATUS cdk2_sdmmc_protocol_media_state(struct cdk2_sdmmc_protocol *protocol,
	UINT8 slot, BOOLEAN *present, BOOLEAN *read_only);
EFI_STATUS cdk2_sdmmc_protocol_set_clock(struct cdk2_sdmmc_protocol *protocol,
	UINT8 slot, UINT32 frequency);
EFI_STATUS cdk2_sdmmc_pci_set_slot_clock(void *adapter,
	UINT8 slot, UINT32 frequency);
EFI_STATUS cdk2_sdmmc_binding_init(struct cdk2_sdmmc_binding *binding,
	const struct cdk2_sdmmc_binding_services *services);
EFI_STATUS cdk2_sdmmc_binding_start(struct cdk2_sdmmc_binding *binding,
	void *handle, cdk2_sdmmc_pool_fn *allocate);
EFI_STATUS cdk2_sdmmc_binding_stop(struct cdk2_sdmmc_binding *binding,
	void *handle);

#endif
