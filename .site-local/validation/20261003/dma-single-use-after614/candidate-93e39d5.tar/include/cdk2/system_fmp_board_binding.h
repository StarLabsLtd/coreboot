/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_BOARD_BINDING_H
#define CDK2_SYSTEM_FMP_BOARD_BINDING_H

#include <stddef.h>
#include <uefi.h>

#define CDK2_SYSTEM_FMP_BOARD_IDENTITY_SIZE 64U
#define CDK2_SYSTEM_FMP_BOARD_VERSION_SIZE 256U
#define CDK2_SYSTEM_FMP_BUILD_INFO_SIZE 512U
#define CDK2_SYSTEM_FMP_BOARD_MAX_ROM_SIZE (64U * 1024U * 1024U)
#define CDK2_SYSTEM_FMP_BOARD_MAX_FMAP_AREAS 64U
#define CDK2_SYSTEM_FMP_BOARD_MAX_CBFS_FILES 128U

struct cdk2_coreboot_handoff;

enum cdk2_system_fmp_board_binding_fact {
	CDK2_SYSTEM_FMP_BOARD_UNBOUND,
	CDK2_SYSTEM_FMP_BOARD_BOUND,
};

struct cdk2_system_fmp_board_binding_result {
	enum cdk2_system_fmp_board_binding_fact fact;
};

struct cdk2_system_fmp_board_identity {
	uint8_t vendor[CDK2_SYSTEM_FMP_BOARD_IDENTITY_SIZE];
	size_t vendor_size;
	uint8_t part[CDK2_SYSTEM_FMP_BOARD_IDENTITY_SIZE];
	size_t part_size;
};

EFI_STATUS cdk2_system_fmp_board_identity_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_board_identity *identity);

EFI_STATUS cdk2_system_fmp_board_bind_identity(
	const struct cdk2_system_fmp_board_identity *identity,
	const void *image, size_t image_size,
	struct cdk2_system_fmp_board_binding_result *result);

/*
 * Compare one authenticated, payload-checked raw coreboot ROM with the unique
 * live LB_MAINBOARD identity. The caller must pass the image/image_size span
 * returned by successful cdk2_system_fmp_payload_check() after successful
 * cdk2_system_fmp_authenticate(). The owner must keep that exact span immutable
 * through the eventual flash operation; this unselected leaf does not
 * authenticate, copy, pin or protect it from DMA.
 */
EFI_STATUS cdk2_system_fmp_board_bind(
	const struct cdk2_coreboot_handoff *coreboot,
	const void *image, size_t image_size,
	struct cdk2_system_fmp_board_binding_result *result);

#endif
