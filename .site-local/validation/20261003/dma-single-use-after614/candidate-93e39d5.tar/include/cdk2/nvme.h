/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_NVME_H
#define CDK2_NVME_H

#include <uefi.h>
#include <cdk2/partition.h>
#include <cdk2/pci_io_abi.h>
#include <cdk2/diagnostic.h>

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
void cdk2_nvme_diagnostic(const char *message, UINTN length);
void cdk2_nvme_diagnostic_command(BOOLEAN admin);
void cdk2_nvme_diagnostic_flush_commands(void);
#define CDK2_NVME_DIAG(message) \
	cdk2_nvme_diagnostic((message), sizeof(message) - 1U)
#define CDK2_NVME_DIAG_COMMAND(admin) cdk2_nvme_diagnostic_command(admin)
#define CDK2_NVME_DIAG_FLUSH_COMMANDS() cdk2_nvme_diagnostic_flush_commands()
#else
#define CDK2_NVME_DIAG(message) do { } while (0)
#define CDK2_NVME_DIAG_COMMAND(admin) ((void)(admin))
#define CDK2_NVME_DIAG_FLUSH_COMMANDS() do { } while (0)
#endif

#define CDK2_NVME_PAGE_SIZE 4096U
#define CDK2_NVME_MAX_NAMESPACES 64U
#define CDK2_NVME_MAX_CONTROLLERS 8U
#define CDK2_NVME_ADMIN_ENTRIES 32U
#ifndef EFI_WRITE_PROTECTED
#define EFI_WRITE_PROTECTED EFIERR(8)
#endif
#ifndef EFI_NO_MEDIA
#define EFI_NO_MEDIA EFIERR(12)
#endif
#ifndef EFI_MEDIA_CHANGED
#define EFI_MEDIA_CHANGED EFIERR(13)
#endif

struct cdk2_nvme_capability {
	UINT32 maximum_queue_entries;
	UINT8 doorbell_stride, timeout_500ms, minimum_page_shift;
	BOOLEAN contiguous_queues, subsystem_reset, nvm_command_set;
};

struct cdk2_nvme_namespace {
	UINT64 blocks, eui64;
	UINT32 id, block_size, metadata_size;
	UINT16 relative_performance;
	BOOLEAN active, read_only;
};

struct cdk2_nvme_topology {
	struct cdk2_nvme_namespace namespace[CDK2_NVME_MAX_NAMESPACES];
	UINTN count;
};

struct cdk2_nvme_command {
	UINT8 opcode, flags;
	UINT16 command_id;
	UINT32 namespace_id;
	UINT64 reserved, metadata, data[2];
	UINT32 dword[6];
};

struct cdk2_nvme_completion {
	UINT32 result, reserved;
	UINT16 submission_head, submission_id, command_id, status;
};

struct cdk2_nvme_dma {
	void *host, *mapping;
	UINT64 device;
	UINTN bytes;
};

typedef EFI_STATUS cdk2_nvme_read32_fn(void *, UINT32, UINT32 *);
typedef EFI_STATUS cdk2_nvme_read64_fn(void *, UINT32, UINT64 *);
typedef EFI_STATUS cdk2_nvme_write32_fn(void *, UINT32, UINT32);
typedef EFI_STATUS cdk2_nvme_write64_fn(void *, UINT32, UINT64);
typedef EFI_STATUS cdk2_nvme_allocate_fn(void *, UINTN, UINTN,
	struct cdk2_nvme_dma *);
typedef void cdk2_nvme_release_fn(void *, struct cdk2_nvme_dma *);
typedef EFI_STATUS cdk2_nvme_flush_fn(void *);
typedef void cdk2_nvme_delay_fn(void *, UINTN);

struct cdk2_nvme_services {
	void *context;
	cdk2_nvme_read32_fn *read32;
	cdk2_nvme_read64_fn *read64;
	cdk2_nvme_write32_fn *write32;
	cdk2_nvme_write64_fn *write64;
	cdk2_nvme_allocate_fn *allocate;
	cdk2_nvme_release_fn *release;
	cdk2_nvme_flush_fn *flush;
	cdk2_nvme_delay_fn *delay;
};

struct cdk2_nvme_queue {
	struct cdk2_nvme_dma submission, completion;
	UINT16 entries, submission_tail, completion_head, command_id;
	UINT8 phase;
};

struct cdk2_nvme_controller {
	struct cdk2_nvme_services services;
	struct cdk2_nvme_capability capability;
	struct cdk2_nvme_queue admin, io;
	UINT16 io_queue_entries;
	UINT32 version;
	BOOLEAN enabled, write_cache, volatile_write_cache_supported,
		abrupt_shutdown, io_busy;
};

struct cdk2_nvme_pci_adapter {
	struct cdk2_efi_pci_io_protocol *pci;
	void *delay_context;
	cdk2_nvme_delay_fn *delay;
	UINT64 original_attributes;
	UINT64 owned_attributes;
	struct cdk2_nvme_dma allocations[8];
	UINTN allocation_count;
	BOOLEAN dma64;
};

typedef EFI_STATUS cdk2_nvme_open_parent_fn(void *, void *, void **);
typedef EFI_STATUS cdk2_nvme_close_parent_fn(void *, void *);
typedef EFI_STATUS cdk2_nvme_prepare_fn(void *, void *, void *,
	struct cdk2_nvme_controller **);
typedef EFI_STATUS cdk2_nvme_release_controller_fn(void *,
	struct cdk2_nvme_controller *);
typedef EFI_STATUS cdk2_nvme_discover_fn(void *, struct cdk2_nvme_controller *,
	struct cdk2_nvme_topology *);
typedef EFI_STATUS cdk2_nvme_parent_fn(void *, void *,
	struct cdk2_nvme_controller *);
typedef EFI_STATUS cdk2_nvme_install_child_fn(void *, void *,
	struct cdk2_nvme_namespace *, void **);
typedef EFI_STATUS cdk2_nvme_uninstall_child_fn(void *, void *,
	struct cdk2_nvme_namespace *);
typedef EFI_STATUS cdk2_nvme_child_link_fn(void *, void *, void *);
typedef EFI_STATUS cdk2_nvme_pool_fn(void *, UINTN, void **);

struct cdk2_nvme_binding_services {
	void *context;
	cdk2_nvme_open_parent_fn *open_parent;
	cdk2_nvme_close_parent_fn *close_parent;
	cdk2_nvme_prepare_fn *prepare;
	cdk2_nvme_release_controller_fn *release_controller;
	cdk2_nvme_discover_fn *discover;
	cdk2_nvme_parent_fn *install_parent, *uninstall_parent;
	cdk2_nvme_install_child_fn *install_child;
	cdk2_nvme_uninstall_child_fn *uninstall_child;
	cdk2_nvme_child_link_fn *link_child, *unlink_child;
};

struct cdk2_nvme_binding_controller {
	void *handle, *pci;
	struct cdk2_nvme_controller *controller;
	struct cdk2_nvme_topology topology;
	void *children[CDK2_NVME_MAX_NAMESPACES];
	struct cdk2_nvme_namespace child_namespace[CDK2_NVME_MAX_NAMESPACES];
	BOOLEAN child_linked[CDK2_NVME_MAX_NAMESPACES];
	BOOLEAN parent_installed, released;
	UINTN child_count;
};

struct cdk2_nvme_binding {
	struct cdk2_nvme_binding_services services;
	struct cdk2_nvme_binding_controller controller[CDK2_NVME_MAX_CONTROLLERS];
	UINTN count;
};

struct cdk2_nvme_pass_mode { UINT32 attributes, io_align, version; };
struct cdk2_nvme_pass_command {
	UINT32 command, namespace_id;
	UINT64 reserved2, metadata_pointer, prp1, prp2;
	UINT32 dword10, dword11, dword12, dword13, dword14, dword15;
	UINT32 flags;
};
struct cdk2_nvme_pass_completion { UINT32 dword[4]; };
struct cdk2_nvme_pass_packet {
	UINT64 command_timeout;
	void *transfer_buffer;
	UINT32 transfer_length;
	void *metadata_buffer;
	UINT32 metadata_length;
	UINT8 queue_type;
	struct cdk2_nvme_pass_command *command;
	struct cdk2_nvme_pass_completion *completion;
};
struct cdk2_nvme_pass_protocol;
typedef EFI_STATUS CDK2_MS_ABI cdk2_nvme_pass_fn(
	struct cdk2_nvme_pass_protocol *, UINT32, struct cdk2_nvme_pass_packet *,
	void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_nvme_next_fn(
	struct cdk2_nvme_pass_protocol *, UINT32 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_nvme_build_path_fn(
	struct cdk2_nvme_pass_protocol *, UINT32, void **);
typedef EFI_STATUS CDK2_MS_ABI cdk2_nvme_get_namespace_fn(
	struct cdk2_nvme_pass_protocol *, void *, UINT32 *);
struct cdk2_nvme_pass_protocol {
	struct cdk2_nvme_pass_mode *mode;
	cdk2_nvme_pass_fn *pass;
	cdk2_nvme_next_fn *next;
	cdk2_nvme_build_path_fn *build_path;
	cdk2_nvme_get_namespace_fn *get_namespace;
};
struct cdk2_nvme_pass_instance {
	struct cdk2_nvme_pass_protocol protocol;
	struct cdk2_nvme_pass_mode mode;
	struct cdk2_nvme_controller *controller;
	struct cdk2_nvme_topology *topology;
	void *pool_context;
	cdk2_nvme_pool_fn *allocate_pool;
};

struct cdk2_nvme_block_request;
typedef EFI_STATUS cdk2_nvme_block_submit_fn(void *context,
	const struct cdk2_nvme_block_request *request);
struct cdk2_nvme_block_instance {
	struct cdk2_block_media media;
	struct cdk2_block_io block;
	struct cdk2_block_io2 block2;
	struct cdk2_nvme_controller *controller;
	const struct cdk2_nvme_namespace *namespace;
	void *async_context;
	cdk2_nvme_block_submit_fn *submit;
	void (*cancel)(void *context, EFI_STATUS status);
};

struct cdk2_nvme_block_request {
	struct cdk2_nvme_block_instance *instance;
	struct cdk2_block_io2_token *token;
	void *buffer;
	UINT64 lba;
	UINTN bytes;
	UINT32 media_id;
	BOOLEAN write, flush;
};
struct cdk2_nvme_block_queue {
	struct cdk2_nvme_block_request request[16];
	UINTN head, count;
};

EFI_STATUS cdk2_nvme_decode_capability(UINT64 value,
	struct cdk2_nvme_capability *capability);
EFI_STATUS cdk2_nvme_parse_namespace(UINT32 id, const void *identify,
	UINTN length, struct cdk2_nvme_namespace *namespace);
EFI_STATUS cdk2_nvme_add_namespace(struct cdk2_nvme_topology *topology,
	const struct cdk2_nvme_namespace *namespace);
EFI_STATUS cdk2_nvme_validate_io(const struct cdk2_nvme_namespace *namespace,
	UINT64 lba, UINTN blocks, UINTN buffer_size, BOOLEAN write);
EFI_STATUS cdk2_nvme_controller_init(struct cdk2_nvme_controller *controller,
	const struct cdk2_nvme_services *services);
EFI_STATUS cdk2_nvme_admin_submit(struct cdk2_nvme_controller *controller,
	struct cdk2_nvme_command *command, struct cdk2_nvme_completion *completion);
EFI_STATUS cdk2_nvme_admin_submit_timeout(struct cdk2_nvme_controller *controller,
	struct cdk2_nvme_command *command, struct cdk2_nvme_completion *completion,
	UINT64 timeout_100ns);
EFI_STATUS cdk2_nvme_controller_destroy(struct cdk2_nvme_controller *controller);
EFI_STATUS cdk2_nvme_controller_reset(struct cdk2_nvme_controller *controller);
EFI_STATUS cdk2_nvme_discover(struct cdk2_nvme_controller *controller,
	struct cdk2_nvme_topology *topology);
EFI_STATUS cdk2_nvme_io_queue_init(struct cdk2_nvme_controller *controller,
	UINT16 entries);
EFI_STATUS cdk2_nvme_io_submit(struct cdk2_nvme_controller *controller,
	struct cdk2_nvme_command *command, struct cdk2_nvme_completion *completion);
EFI_STATUS cdk2_nvme_io_submit_timeout(struct cdk2_nvme_controller *controller,
	struct cdk2_nvme_command *command, struct cdk2_nvme_completion *completion,
	UINT64 timeout_100ns);
EFI_STATUS cdk2_nvme_transfer(struct cdk2_nvme_controller *controller,
	const struct cdk2_nvme_namespace *namespace, UINT64 lba, UINTN blocks,
	void *buffer, BOOLEAN write);
EFI_STATUS cdk2_nvme_pci_adapter_init(struct cdk2_nvme_pci_adapter *adapter,
	struct cdk2_efi_pci_io_protocol *pci, void *delay_context,
	cdk2_nvme_delay_fn *delay);
EFI_STATUS cdk2_nvme_pci_adapter_enable(struct cdk2_nvme_pci_adapter *adapter);
void cdk2_nvme_pci_services(struct cdk2_nvme_pci_adapter *adapter,
	struct cdk2_nvme_services *services);
EFI_STATUS cdk2_nvme_pci_adapter_release(struct cdk2_nvme_pci_adapter *adapter);
EFI_STATUS cdk2_nvme_binding_init(struct cdk2_nvme_binding *binding,
	const struct cdk2_nvme_binding_services *services);
EFI_STATUS cdk2_nvme_binding_start(struct cdk2_nvme_binding *binding,
	void *handle);
EFI_STATUS cdk2_nvme_binding_start_parent(struct cdk2_nvme_binding *binding,
	void *handle);
EFI_STATUS cdk2_nvme_binding_start_selected(struct cdk2_nvme_binding *binding,
	void *handle, UINT32 namespace_id);
EFI_STATUS cdk2_nvme_binding_start_namespace(struct cdk2_nvme_binding *binding,
	void *handle, UINT32 namespace_id);
EFI_STATUS cdk2_nvme_binding_stop(struct cdk2_nvme_binding *binding,
	void *handle, UINTN child_count, void **children);
EFI_STATUS cdk2_nvme_pass_init(struct cdk2_nvme_pass_instance *instance,
	struct cdk2_nvme_controller *controller, struct cdk2_nvme_topology *topology,
	UINT32 io_align, void *pool_context,
	cdk2_nvme_pool_fn *allocate_pool);
EFI_STATUS cdk2_nvme_block_init(struct cdk2_nvme_block_instance *instance,
	struct cdk2_nvme_controller *controller,
	const struct cdk2_nvme_namespace *namespace, UINT32 io_align);
EFI_STATUS cdk2_nvme_block_enable_async(
	struct cdk2_nvme_block_instance *instance, void *context,
	EFI_STATUS (*submit)(void *context,
		const struct cdk2_nvme_block_request *request));
void cdk2_nvme_block_set_cancel(struct cdk2_nvme_block_instance *instance,
	void (*cancel)(void *context, EFI_STATUS status));
EFI_STATUS cdk2_nvme_block_execute_request(
	const struct cdk2_nvme_block_request *request);
EFI_STATUS cdk2_nvme_block_queue_submit(struct cdk2_nvme_block_queue *queue,
	const struct cdk2_nvme_block_request *request);
EFI_STATUS cdk2_nvme_block_queue_pop(struct cdk2_nvme_block_queue *queue,
	struct cdk2_nvme_block_request *request);
BOOLEAN cdk2_nvme_block_queue_quiescent(
	const struct cdk2_nvme_block_queue *queue);
void cdk2_nvme_block_queue_cancel(struct cdk2_nvme_block_queue *queue,
	EFI_STATUS status, void *context,
	void (*complete)(void *context, struct cdk2_block_io2_token *token));

#endif
