/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_TEST_KEY_H
#define CDK2_SYSTEM_FMP_TEST_KEY_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define CDK2_FMP_KEY_DIGEST_SIZE 32U

/* Boot-lifetime diagnostic state; never an authorization decision. */
struct cdk2_fmp_test_key_state {
	bool test_key_used;
};

struct cdk2_fmp_test_key_input {
	const uint8_t *certificates;
	size_t certificates_size;
	const uint8_t *test_key_digest;
	size_t test_key_digest_size;
};

enum cdk2_fmp_test_key_result {
	CDK2_FMP_KEY_NOT_CHECKED,
	CDK2_FMP_KEY_ALREADY_FLAGGED,
	CDK2_FMP_KEY_NO_MATCH,
	CDK2_FMP_KEY_MATCH,
	CDK2_FMP_KEY_HASH_ERROR,
	CDK2_FMP_KEY_MALFORMED,
};

typedef bool cdk2_fmp_key_sha256_fn(void *context, const uint8_t *data,
	size_t size, uint8_t digest[CDK2_FMP_KEY_DIGEST_SIZE]);

/*
 * The owner prepares/releases its existing hash context. A NULL hash callback
 * represents unavailable hash resources, including allocation failure. This
 * diagnostic helper has no EFI protocol dependency or authentication role.
 */
enum cdk2_fmp_test_key_result cdk2_fmp_test_key_detect(
	struct cdk2_fmp_test_key_state *state,
	const struct cdk2_fmp_test_key_input *input,
	cdk2_fmp_key_sha256_fn *sha256, void *context);

#endif
