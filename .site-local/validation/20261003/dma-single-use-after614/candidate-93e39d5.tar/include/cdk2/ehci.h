/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_EHCI_H
#define CDK2_EHCI_H

#include <uefi.h>
#include <cdk2/diagnostic.h>
#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
void cdk2_ehci_diagnostic(const char *message);
#define CDK2_EHCI_DIAG(message) cdk2_ehci_diagnostic(message)
#else
#define CDK2_EHCI_DIAG(message) do { } while (0)
#endif
#include <cdk2/pci_io_abi.h>
#include <cdk2/xhci.h>

#define CDK2_EHCI_FRAME_COUNT 1024U
#define CDK2_EHCI_TERMINATE 1U

struct cdk2_ehci_qtd {
	UINT32 next, alternate, token, buffers[5], buffers_high[5];
	UINT32 padding[3];
};

struct cdk2_ehci_qh {
	UINT32 horizontal, endpoint, endpoint_capability, current;
	struct cdk2_ehci_qtd overlay;
	UINT32 padding[12];
};

typedef EFI_STATUS cdk2_ehci_read32_fn(void *, UINT32, UINT32 *);
typedef EFI_STATUS cdk2_ehci_write32_fn(void *, UINT32, UINT32);
typedef void cdk2_ehci_delay_fn(void *, UINTN);

struct cdk2_ehci_dma {
	void *host, *mapping;
	UINT64 device;
	UINTN bytes, pages;
};

typedef EFI_STATUS cdk2_ehci_dma_alloc_fn(void *, UINTN, UINTN,
	struct cdk2_ehci_dma *);
typedef void cdk2_ehci_dma_free_fn(void *, struct cdk2_ehci_dma *);
typedef EFI_STATUS cdk2_ehci_dma_map_fn(void *, void *, UINTN, BOOLEAN,
	struct cdk2_ehci_dma *);
typedef void cdk2_ehci_dma_unmap_fn(void *, struct cdk2_ehci_dma *);
typedef EFI_STATUS cdk2_ehci_flush_fn(void *);
typedef UINTN cdk2_ehci_lock_fn(void *);
typedef void cdk2_ehci_unlock_fn(void *, UINTN);

struct cdk2_ehci_services {
	void *context;
	cdk2_ehci_read32_fn *read32;
	cdk2_ehci_write32_fn *write32;
	cdk2_ehci_delay_fn *delay;
	cdk2_ehci_dma_alloc_fn *allocate;
	cdk2_ehci_dma_free_fn *release;
	cdk2_ehci_dma_map_fn *map;
	cdk2_ehci_dma_unmap_fn *unmap;
	cdk2_ehci_flush_fn *flush;
	void *lock_context;
	cdk2_ehci_lock_fn *lock;
	cdk2_ehci_unlock_fn *unlock;
};

#define CDK2_EHCI_PCI_ALLOCATIONS 32U
struct cdk2_ehci_pci_record {
	void *host, *mapping;
	UINTN pages;
};

struct cdk2_ehci_pci_adapter {
	struct cdk2_efi_pci_io_protocol *pci;
	struct cdk2_ehci_pci_record records[CDK2_EHCI_PCI_ALLOCATIONS];
	void *delay_context;
	cdk2_ehci_delay_fn *delay;
	UINT64 original_attributes;
	BOOLEAN attributes_owned, dma64;
};

struct cdk2_ehci_controller {
	struct cdk2_ehci_services services;
	UINT32 capability_length, structural, capability;
	UINT8 ports;
	UINTN last_transfer_elapsed;
	BOOLEAN dma64, running;
};

struct cdk2_ehci_transfer {
	struct cdk2_ehci_dma descriptors, data;
	struct cdk2_ehci_qh *qh;
	struct cdk2_ehci_qtd *qtds;
	UINT32 initial_tokens[128];
	UINTN count, requested, data_first, data_count;
	UINT16 packet;
	UINT8 toggle, initial_toggle, pid;
	BOOLEAN device_writes, data_owned, release_safe;
	void *caller;
	UINTN caller_bytes, data_offset;
};

struct cdk2_ehci_usb2 {
	struct cdk2_usb2_hc_protocol protocol;
	struct cdk2_ehci_controller *controller;
	UINT32 asynchronous_head;
	UINT32 *periodic_frames;
	UINT32 periodic_device;
	UINTN state;
	UINT16 high_speed_ports;
	struct {
		struct cdk2_ehci_transfer transfer;
		struct cdk2_ehci_dma buffer;
		cdk2_usb2_async_callback_fn *callback;
		void *context;
		UINTN interval, length;
		UINT8 address, endpoint, toggle;
		BOOLEAN active;
	} async[8];
};

EFI_STATUS cdk2_ehci_validate_class(UINT8 base, UINT8 subclass, UINT8 interface);
EFI_STATUS cdk2_ehci_probe(struct cdk2_ehci_controller *controller,
	const struct cdk2_ehci_services *services);
EFI_STATUS cdk2_ehci_reset(struct cdk2_ehci_controller *controller);
EFI_STATUS cdk2_ehci_start(struct cdk2_ehci_controller *controller,
	UINT32 periodic, UINT32 asynchronous);
EFI_STATUS cdk2_ehci_stop(struct cdk2_ehci_controller *controller);
EFI_STATUS cdk2_ehci_route_ports(struct cdk2_ehci_controller *controller,
	BOOLEAN route_to_ehci);
UINT32 cdk2_ehci_decode_token(UINT32 token);
EFI_STATUS cdk2_ehci_build_qtd(struct cdk2_ehci_qtd *qtd, UINT32 next,
	UINT32 alternate, UINT32 buffer, UINTN length, UINT8 pid, UINT8 toggle,
	BOOLEAN interrupt);
EFI_STATUS cdk2_ehci_build_qh(struct cdk2_ehci_qh *qh, UINT32 horizontal,
	UINT32 first_qtd, UINT8 address, UINT8 endpoint, UINT16 packet,
	UINT8 speed, UINT8 multiplier);
EFI_STATUS cdk2_ehci_pci_adapter_init(struct cdk2_ehci_pci_adapter *adapter,
	struct cdk2_efi_pci_io_protocol *pci, void *delay_context,
	cdk2_ehci_delay_fn *delay);
void cdk2_ehci_pci_services(struct cdk2_ehci_pci_adapter *adapter,
	struct cdk2_ehci_services *services);
EFI_STATUS cdk2_ehci_pci_adapter_release(struct cdk2_ehci_pci_adapter *adapter);
EFI_STATUS cdk2_ehci_pci_claim_legacy(struct cdk2_ehci_pci_adapter *adapter,
	UINT8 capability_offset);
EFI_STATUS cdk2_ehci_transfer_prepare(struct cdk2_ehci_controller *controller,
	struct cdk2_ehci_transfer *transfer, UINT8 address, UINT8 endpoint,
	UINT8 speed, UINT16 packet, UINT8 pid, UINT8 toggle, void *buffer,
	UINTN length);
EFI_STATUS cdk2_ehci_transfer_execute(struct cdk2_ehci_controller *controller,
	struct cdk2_ehci_transfer *transfer, UINT32 asynchronous_head,
	UINTN timeout, UINTN *actual, UINT8 *toggle, UINT32 *result);
void cdk2_ehci_transfer_release(struct cdk2_ehci_controller *controller,
	struct cdk2_ehci_transfer *transfer);
EFI_STATUS cdk2_ehci_control_prepare(struct cdk2_ehci_controller *controller,
	struct cdk2_ehci_transfer *transfer, UINT8 address, UINT8 speed,
	UINT16 packet, const struct cdk2_usb_request *request, UINTN direction,
	void *buffer, UINTN length);
EFI_STATUS cdk2_ehci_usb2_init(struct cdk2_ehci_usb2 *usb2,
	struct cdk2_ehci_controller *controller, UINT32 asynchronous_head,
	UINT32 *periodic_frames, UINT32 periodic_device);
void cdk2_ehci_usb2_poll(struct cdk2_ehci_usb2 *usb2);
void cdk2_ehci_usb2_release(struct cdk2_ehci_usb2 *usb2);

#endif
