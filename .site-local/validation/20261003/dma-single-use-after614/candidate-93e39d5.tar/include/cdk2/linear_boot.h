/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_LINEAR_BOOT_H
#define CDK2_LINEAR_BOOT_H

#include <uefi.h>
#include <stddef.h>
#include <stdint.h>

/*
 * This order is the boot contract.  A plan may execute a contiguous slice,
 * but it must resume at state.next_phase and may never skip or reorder an ID.
 */
enum cdk2_linear_phase_id {
	CDK2_LINEAR_HANDOFF_VALIDATE,
	CDK2_LINEAR_SPLASH_EARLY,
	CDK2_LINEAR_DXE_SERVICES,
	CDK2_LINEAR_ARCH_PROTOCOLS,
	CDK2_LINEAR_VARIABLES_MIN,
	CDK2_LINEAR_CAPSULE_DECIDE,
	CDK2_LINEAR_CAPSULE_RAM,
	CDK2_LINEAR_PLATFORM_TABLES,
	CDK2_LINEAR_PCI_ROOTS,
	CDK2_LINEAR_PCI_ENUMERATE,
	CDK2_LINEAR_STORAGE_CONTROLLERS,
	CDK2_LINEAR_BLOCK_DISCOVERY,
	CDK2_LINEAR_FILESYSTEMS,
	CDK2_LINEAR_CAPSULE_DISK,
	CDK2_LINEAR_DISPLAY_ADOPT,
	CDK2_LINEAR_INPUT_UI,
	CDK2_LINEAR_BOOT_POLICY,
	CDK2_LINEAR_OS_HANDOFF,
	CDK2_LINEAR_PHASE_COUNT,
};

#define CDK2_LINEAR_STATE_REVISION 8U
#define CDK2_LINEAR_LOADER_PATH_CHARS 256U
#define CDK2_LINEAR_BOOT_PATH_BYTES 512U
#define CDK2_LINEAR_STATE_SPLASH_VISIBLE 0x00000001U
#define CDK2_LINEAR_STATE_COREBOOT_SPLASH 0x00000020U
#define CDK2_LINEAR_STATE_BOOT_ATTEMPTED  0x00000010U
#define CDK2_LINEAR_STATE_CAPSULE_SHIFT 1U
#define CDK2_LINEAR_STATE_CAPSULE_MASK  0x0000000eU
#define CDK2_LINEAR_STATE_FLAG_MASK (CDK2_LINEAR_STATE_SPLASH_VISIBLE | \
	CDK2_LINEAR_STATE_CAPSULE_MASK | CDK2_LINEAR_STATE_BOOT_ATTEMPTED | \
	CDK2_LINEAR_STATE_COREBOOT_SPLASH)

enum cdk2_linear_capsule_outcome {
	CDK2_LINEAR_CAPSULE_RESULT_UNKNOWN,
	CDK2_LINEAR_CAPSULE_RESULT_NONE,
	CDK2_LINEAR_CAPSULE_RESULT_RAM,
	CDK2_LINEAR_CAPSULE_RESULT_DISK,
	CDK2_LINEAR_CAPSULE_RESULT_DISK_DEFERRED,
};

/* Value-only state, suitable for the native-to-DXE GUID HOB. */
struct cdk2_linear_state {
	UINT16 revision;
	UINT16 length;
	UINT16 next_phase;
	UINT16 reserved;
	UINT32 completed_mask;
	UINT32 flags;
	UINT64 splash_framebuffer;
	UINT32 splash_bytes_per_line;
	UINT32 splash_x_resolution;
	UINT32 splash_y_resolution;
	UINT32 splash_image_offset_x;
	UINT32 splash_image_offset_y;
	UINT32 splash_image_width;
	UINT32 splash_image_height;
	UINT64 splash_bmp_address;
	UINT32 splash_bmp_size;
	UINT32 reserved2;
	UINT32 boot_device_path_offset;
	UINT32 boot_device_path_size;
	UINT32 boot_device_path_generation;
	UINT32 boot_device_path_hash;
	UINT32 boot_loader_size;
	CHAR16 boot_loader_path[CDK2_LINEAR_LOADER_PATH_CHARS];
	UINT8 boot_device_path[CDK2_LINEAR_BOOT_PATH_BYTES];
} __packed;

typedef uint64_t cdk2_linear_phase_fn(void *context);
typedef uint64_t cdk2_linear_clock_fn(void *context);
typedef void cdk2_linear_report_fn(enum cdk2_linear_phase_id phase,
	const char *name, uint64_t status, uint64_t elapsed_ticks,
	uint8_t required, uint8_t begin, void *context);

struct cdk2_linear_phase {
	enum cdk2_linear_phase_id id;
	const char *name;
	cdk2_linear_phase_fn *run;
	uint8_t required;
};

struct cdk2_linear_plan {
	const struct cdk2_linear_phase *phases;
	size_t count;
	cdk2_linear_clock_fn *clock;
	cdk2_linear_report_fn *report;
	void *context;
};

extern const EFI_GUID cdk2_linear_state_hob_guid;

void cdk2_linear_state_init(struct cdk2_linear_state *state);
uint64_t cdk2_linear_state_validate(const struct cdk2_linear_state *state);
uint64_t cdk2_linear_state_from_hob(void *hob_list,
	struct cdk2_linear_state *state);
uint64_t cdk2_linear_state_update_hob(void *hob_list,
	const struct cdk2_linear_state *state);
uint64_t cdk2_linear_boot_path_set(struct cdk2_linear_state *state,
	const void *path, uint32_t size, uint32_t generation);
uint64_t cdk2_linear_capture_splash(struct cdk2_linear_state *state,
	uint64_t framebuffer, uint32_t bytes_per_line,
	uint32_t x_resolution, uint32_t y_resolution);
uint64_t cdk2_linear_capture_coreboot_splash(struct cdk2_linear_state *state,
	uint32_t image_offset_x, uint32_t image_offset_y,
	uint32_t image_width, uint32_t image_height,
	uint64_t bmp_address, uint32_t bmp_size);
uint8_t cdk2_linear_display_clear_allowed(
	const struct cdk2_linear_state *state);
uint64_t cdk2_linear_input_ui_validate(
	const struct cdk2_linear_state *state, size_t graphics_outputs,
	size_t text_inputs, size_t text_input_exs, uint32_t boot_timeout);
uint64_t cdk2_linear_capsule_gate_early(struct cdk2_linear_state *state,
	uint8_t ram_present, uint8_t disk_supported,
	enum cdk2_linear_capsule_outcome *outcome);
uint64_t cdk2_linear_capsule_finalize_disk(struct cdk2_linear_state *state,
	uint64_t discovery_status,
	enum cdk2_linear_capsule_outcome *outcome);
uint64_t cdk2_linear_capsule_finalize_ram(struct cdk2_linear_state *state,
	enum cdk2_linear_capsule_outcome *outcome);
enum cdk2_linear_capsule_outcome cdk2_linear_capsule_outcome(
	const struct cdk2_linear_state *state);
uint64_t cdk2_linear_capsule_disk_required(
	const struct cdk2_linear_state *state, uint8_t *required);
uint64_t cdk2_linear_run(const struct cdk2_linear_plan *plan,
	struct cdk2_linear_state *state, size_t *completed);

#endif
