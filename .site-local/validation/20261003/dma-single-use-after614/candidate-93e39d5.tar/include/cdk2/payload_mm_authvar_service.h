/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_PAYLOAD_MM_AUTHVAR_SERVICE_H
#define CDK2_PAYLOAD_MM_AUTHVAR_SERVICE_H

#include <coreboot_tables.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

#define CDK2_AUTHVAR_SERVICE_REVISION 3U
#define CDK2_AUTHVAR_POLICY_MIN_SIZE 44U
#define CDK2_AUTHVAR_POLICY_MAX_SIZE 512U
#define CDK2_AUTHVAR_SERVICE_HEADER_SIZE 144U
#define CDK2_AUTHVAR_SERVICE_MIN_MESSAGE_SIZE 512U
#define CDK2_AUTHVAR_SERVICE_MAX_MESSAGE_SIZE (64U * 1024U)
#define CDK2_AUTHVAR_SERVICE_PENDING MAX_UINT32
#define CDK2_AUTHVAR_SERVICE_COMPLETE 0U
#define CDK2_AUTHVAR_SERVICE_STATUS_PENDING MAX_UINT64

/* Fixed-width EFI_STATUS values carried by the wire ABI. */
#define CDK2_AUTHVAR_STATUS_ERROR_BIT (1ULL << 63)
#define CDK2_AUTHVAR_STATUS_SUCCESS 0ULL
#define CDK2_AUTHVAR_STATUS_INVALID_PARAMETER \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 2ULL)
#define CDK2_AUTHVAR_STATUS_UNSUPPORTED \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 3ULL)
#define CDK2_AUTHVAR_STATUS_BUFFER_TOO_SMALL \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 5ULL)
#define CDK2_AUTHVAR_STATUS_DEVICE_ERROR \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 7ULL)
#define CDK2_AUTHVAR_STATUS_WRITE_PROTECTED \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 8ULL)
#define CDK2_AUTHVAR_STATUS_OUT_OF_RESOURCES \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 9ULL)
#define CDK2_AUTHVAR_STATUS_NOT_FOUND \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 14ULL)
#define CDK2_AUTHVAR_STATUS_ACCESS_DENIED \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 15ULL)
#define CDK2_AUTHVAR_STATUS_ALREADY_STARTED \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 20ULL)
#define CDK2_AUTHVAR_STATUS_SECURITY_VIOLATION \
	(CDK2_AUTHVAR_STATUS_ERROR_BIT | 26ULL)

#define CDK2_AUTHVAR_ATTR_NON_VOLATILE        (1U << 0)
#define CDK2_AUTHVAR_ATTR_BOOTSERVICE_ACCESS  (1U << 1)
#define CDK2_AUTHVAR_ATTR_RUNTIME_ACCESS      (1U << 2)
#define CDK2_AUTHVAR_ATTR_HARDWARE_ERROR      (1U << 3)
#define CDK2_AUTHVAR_ATTR_AUTHENTICATED_WRITE (1U << 4)
#define CDK2_AUTHVAR_ATTR_TIME_AUTHENTICATED  (1U << 5)
#define CDK2_AUTHVAR_ATTR_APPEND_WRITE        (1U << 6)
#define CDK2_AUTHVAR_ATTR_SUPPORTED \
	(CDK2_AUTHVAR_ATTR_NON_VOLATILE | \
	 CDK2_AUTHVAR_ATTR_BOOTSERVICE_ACCESS | \
	 CDK2_AUTHVAR_ATTR_RUNTIME_ACCESS | \
	 CDK2_AUTHVAR_ATTR_HARDWARE_ERROR | \
	 CDK2_AUTHVAR_ATTR_TIME_AUTHENTICATED | \
	 CDK2_AUTHVAR_ATTR_APPEND_WRITE)

enum cdk2_authvar_service_operation {
	CDK2_AUTHVAR_SERVICE_GET = 1,
	CDK2_AUTHVAR_SERVICE_NEXT = 2,
	CDK2_AUTHVAR_SERVICE_SET = 3,
	CDK2_AUTHVAR_SERVICE_QUERY = 4,
	CDK2_AUTHVAR_SERVICE_READY_TO_BOOT = 5,
	CDK2_AUTHVAR_SERVICE_ENTER_RUNTIME = 6,
	CDK2_AUTHVAR_SERVICE_REGISTER_POLICY = 7,
	CDK2_AUTHVAR_SERVICE_LOCK_POLICY = 8,
	CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT = 9,
	CDK2_AUTHVAR_SERVICE_KEY_CLASSIFY = 10,
};

#define CDK2_AUTHVAR_KEY_CLASSIFICATION_REVISION 1U
#define CDK2_AUTHVAR_KEY_CLASSIFICATION_SIZE 16U
#define CDK2_AUTHVAR_KEY_PERSISTENT 1U
#define CDK2_AUTHVAR_KEY_SYNTHETIC 2U
#define CDK2_AUTHVAR_KEY_VOLATILE_PINNED 3U
#define CDK2_AUTHVAR_KEY_VISIBLE 1U

struct cdk2_authvar_service_frame {
	UINT32 revision;
	UINT32 header_size;
	UINT32 operation;
	UINT32 flags;
	UINT64 generation;
	UINT64 request_id;
	UINT8 vendor_guid[16];
	UINT32 attributes;
	UINT32 name_size;
	UINT32 data_size;
	UINT32 name_capacity;
	UINT32 data_capacity;
	UINT32 reserved0;
	UINT64 maximum_storage;
	UINT64 remaining_storage;
	UINT64 maximum_variable;
	UINT64 status;
	UINT32 result_name_size;
	UINT32 result_data_size;
	UINT32 result_attributes;
	UINT8 result_vendor_guid[16];
	UINT32 reserved[2];
	UINT32 completion;
} __aligned(8);

_Static_assert(sizeof(struct cdk2_authvar_service_frame) ==
	CDK2_AUTHVAR_SERVICE_HEADER_SIZE,
	"authenticated-variable service frame ABI");
_Static_assert(_Alignof(struct cdk2_authvar_service_frame) == 8U,
	"authenticated-variable service frame alignment");
_Static_assert(OFFSET_OF(struct cdk2_authvar_service_frame, generation) == 16U &&
	OFFSET_OF(struct cdk2_authvar_service_frame, vendor_guid) == 32U &&
	OFFSET_OF(struct cdk2_authvar_service_frame, maximum_storage) == 72U &&
	OFFSET_OF(struct cdk2_authvar_service_frame, status) == 96U &&
	OFFSET_OF(struct cdk2_authvar_service_frame, result_vendor_guid) == 116U &&
	OFFSET_OF(struct cdk2_authvar_service_frame, completion) == 140U,
	"authenticated-variable service frame layout");

EFI_STATUS cdk2_authvar_service_endpoint_validate(
	const struct cb_authvar_service_endpoint *endpoint);
EFI_STATUS cdk2_authvar_service_request_validate(
	const struct cb_authvar_service_endpoint *endpoint, const void *message,
	UINTN message_size);
EFI_STATUS cdk2_authvar_service_response_validate(
	const struct cb_authvar_service_endpoint *endpoint, const void *request,
	const void *response, UINTN message_size);

#endif
