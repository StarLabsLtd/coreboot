/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_STATE_H
#define CDK2_SYSTEM_FMP_STATE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

#define CDK2_FMP_STATE_WIRE_SIZE 20U
#define CDK2_FMP_STATE_VARIABLE_ATTRIBUTES 0x00000003U

#define CDK2_FMP_LAST_ATTEMPT_SUCCESS 0x00000000U
#define CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL 0x00000001U
#define CDK2_FMP_LAST_ATTEMPT_VERSION_TOO_LOW 0x00001010U
#define CDK2_FMP_LAST_ATTEMPT_DEVICE_MIN 0x00001800U
#define CDK2_FMP_LAST_ATTEMPT_DEVICE_MAX 0x00001fffU

enum cdk2_system_fmp_state_key {
	CDK2_FMP_STATE,
	CDK2_FMP_LEGACY_VERSION,
	CDK2_FMP_LEGACY_LOWEST_VERSION,
	CDK2_FMP_LEGACY_LAST_ATTEMPT_STATUS,
	CDK2_FMP_LEGACY_LAST_ATTEMPT_VERSION,
};

struct cdk2_system_fmp_state {
	bool version_valid;
	bool lowest_version_valid;
	bool last_attempt_status_valid;
	bool last_attempt_version_valid;
	uint32_t version;
	uint32_t lowest_version;
	uint32_t last_attempt_status;
	uint32_t last_attempt_version;
};

struct cdk2_system_fmp_state_identity {
	EFI_GUID namespace_guid;
	uint64_t hardware_instance;
};

/*
 * This interface is only for a trusted, rollback-protected Payload-MM state
 * owner.  It is not payload-visible storage or a generic SMMSTORE transport.
 * The future adapter maps a key to FmpState, FmpVersion, FmpLsv,
 * LastAttemptStatus or LastAttemptVersion under the FmpDxe caller GUID.  A
 * nonzero hardware instance appends its 16 uppercase hexadecimal digits.
 * The namespace is trusted capsule/platform identity; the generic FmpDxe INF
 * FILE_GUID is not authoritative.  read() takes buffer capacity in *size and
 * returns the stored size in *size.  write() success means an atomic,
 * reset-safe commit to protected nonvolatile media; failure leaves the prior
 * value readable and unchanged.
 */
typedef EFI_STATUS cdk2_system_fmp_state_read_fn(void *context,
	enum cdk2_system_fmp_state_key key,
	const struct cdk2_system_fmp_state_identity *identity,
	void *data, size_t *size);
typedef EFI_STATUS cdk2_system_fmp_state_write_fn(void *context,
	enum cdk2_system_fmp_state_key key,
	const struct cdk2_system_fmp_state_identity *identity,
	uint32_t attributes, const void *data, size_t size);
typedef EFI_STATUS cdk2_system_fmp_state_remove_fn(void *context,
	enum cdk2_system_fmp_state_key key,
	const struct cdk2_system_fmp_state_identity *identity);

struct cdk2_system_fmp_state_store {
	cdk2_system_fmp_state_read_fn *read;
	cdk2_system_fmp_state_write_fn *write;
	cdk2_system_fmp_state_remove_fn *remove;
	void *context;
};

struct cdk2_system_fmp_update_request {
	uint32_t incoming_version;
	uint32_t incoming_lowest_version;
	uint32_t trusted_lowest_version;
	bool track_current_version;
};

struct cdk2_system_fmp_update_result {
	bool writer_called;
	uint32_t effective_lowest_version;
	uint32_t last_attempt_status;
};

typedef EFI_STATUS cdk2_system_fmp_apply_fn(void *context,
	uint32_t *last_attempt_status);

EFI_STATUS cdk2_system_fmp_state_load_or_migrate(
	const struct cdk2_system_fmp_state_store *store,
	const struct cdk2_system_fmp_state_identity *identity,
	struct cdk2_system_fmp_state *state);

/*
 * request is trusted, pre-authenticated metadata, not data decoded here.
 * apply is called only after the unsuccessful attempt checkpoint is durable.
 * The phase owner must complete load_or_migrate() during initialization;
 * execute() rejects a missing, malformed or unreadable combined state.
 */
EFI_STATUS cdk2_system_fmp_state_execute(
	const struct cdk2_system_fmp_state_store *store,
	const struct cdk2_system_fmp_state_identity *identity,
	const struct cdk2_system_fmp_update_request *request,
	cdk2_system_fmp_apply_fn *apply, void *apply_context,
	struct cdk2_system_fmp_update_result *result);

#endif
