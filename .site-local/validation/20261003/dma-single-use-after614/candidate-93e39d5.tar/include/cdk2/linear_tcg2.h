/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_LINEAR_TCG2_H_
#define CDK2_LINEAR_TCG2_H_

#include <protocol/tcg2.h>

struct cdk2_linear_tcg2_publication {
	UINTN protocol_count;
	EFI_TCG2_PROTOCOL *protocol;
	UINTN protocol_span;
	UINT64 protocol_generation;
	UINTN interface_size;
	UINT64 interface_generation;
	BOOLEAN interface_dynamic;
	BOOLEAN owner_present;
	BOOLEAN owner_valid;
	UINTN final_count;
	EFI_TCG2_FINAL_EVENTS_TABLE *final;
	UINTN final_span;
	UINT64 final_generation;
};

static inline BOOLEAN cdk2_linear_tcg2_static_owner_span(const void *interface,

	void *owner_handle, UINT64 owner_generation, void *image_handle,
	const void *image_base, UINTN image_size, UINT64 image_generation,
	UINTN protocol_pins, UINTN *span, UINT64 *generation)
{
	UINTN base = (UINTN)image_base, point = (UINTN)interface;

	if (span == NULL || generation == NULL || interface == NULL ||
	    owner_handle == NULL || owner_generation == 0U ||
	    owner_handle != image_handle || owner_generation != image_generation ||
	    protocol_pins == 0U || image_base == NULL ||
	    image_size < sizeof(EFI_TCG2_PROTOCOL) ||
	    base > MAX_UINTN - image_size || point < base ||
	    point > base + image_size - sizeof(EFI_TCG2_PROTOCOL))
		return FALSE;
	*span = base + image_size - point;
	*generation = image_generation;
	return TRUE;
}

static inline EFI_STATUS cdk2_linear_tcg2_validate(
	const struct cdk2_linear_tcg2_publication *view)
{
	EFI_TCG2_PROTOCOL *protocol;
	EFI_TCG2_FINAL_EVENTS_TABLE *final;

	if (view == NULL || view->protocol_count != 1U ||
	    view->protocol == NULL || view->protocol_span < sizeof(*protocol) ||
	    view->protocol_generation == 0U)
		return EFI_COMPROMISED_DATA;
	if (view->interface_dynamic) {
		if (view->interface_size < sizeof(*protocol) ||
		    view->interface_generation != view->protocol_generation ||
		    view->owner_present)
			return EFI_COMPROMISED_DATA;
	} else if (view->interface_size != 0U || view->interface_generation != 0U ||
	    !view->owner_present || !view->owner_valid) {
		return EFI_COMPROMISED_DATA;
	}
	protocol = view->protocol;
	if (protocol->get_capability == NULL || protocol->get_event_log == NULL ||
	    protocol->hash_log_extend_event == NULL ||
	    protocol->submit_command == NULL ||
	    protocol->get_active_pcr_banks == NULL ||
	    protocol->set_active_pcr_banks == NULL ||
	    protocol->get_result_of_set_active_pcr_banks == NULL)
		return EFI_COMPROMISED_DATA;
	if (view->final_count != 1U || view->final == NULL ||
	    view->final_span < sizeof(*final) || view->final_generation == 0U)
		return EFI_COMPROMISED_DATA;
	final = view->final;
	if (final->version != EFI_TCG2_FINAL_EVENTS_TABLE_VERSION ||
	    final->number_of_events != 0U)
		return EFI_COMPROMISED_DATA;
	return EFI_SUCCESS;
}

#endif
