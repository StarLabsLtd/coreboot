/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_AUTHVAR_NAMESPACE_H
#define CDK2_AUTHVAR_NAMESPACE_H

#include <stddef.h>
#include <stdint.h>
#include <cdk2/authvar_runtime.h>
#include <cdk2/variable_runtime.h>

struct cdk2_authvar_namespace {
	struct cdk2_authvar_runtime *protected_owner;
	struct cdk2_variable_service *ram_owner;
	uint16_t *names;
	size_t names_size;
	/* Whole boot-policy allocation; retain exclusion until retirement and free. */
	void *policy_owner_base;
	size_t policy_owner_size;
	uint8_t busy;
};

/*
 * Private composition used by the default-off protected runtime entry. This
 * binder itself publishes no EFI runtime slots or delivery authority. The caller
 * exclusively assigns an initialized RAM service with persist == NULL and no NV
 * records. Direct owner writes are outside this serialization contract. Neither
 * this binder nor key classification supplies an authenticated delivery lease or
 * a cross-owner variable-state epoch. Bind at BOOT before entering runtime.
 * Names is private scratch for one endpoint-sized name, not caller output.
 */
EFI_STATUS cdk2_authvar_namespace_init(struct cdk2_authvar_namespace *namespace,
	struct cdk2_authvar_runtime *protected_owner,
	struct cdk2_variable_service *ram_owner, void *names, size_t names_size);
/* Local operand geometry only; not delivery provenance or authority. */
int cdk2_authvar_namespace_outside_private(const struct cdk2_authvar_namespace *namespace,
	const void *buffer, uint64_t size);
/* Requires the caller's bound, admitted namespace; performs no transaction. */
EFI_STATUS cdk2_authvar_namespace_key_size(struct cdk2_authvar_namespace *namespace,
	const CHAR16 *name, const EFI_GUID *vendor, uint32_t maximum,
	int empty_allowed, uint32_t *bytes);
EFI_STATUS cdk2_authvar_namespace_get(struct cdk2_authvar_namespace *namespace,
	const CHAR16 *name, const EFI_GUID *vendor, UINT32 *attributes,
	UINTN *data_size, void *data);
EFI_STATUS cdk2_authvar_namespace_set(struct cdk2_authvar_namespace *namespace,
	const CHAR16 *name, const EFI_GUID *vendor, UINT32 attributes,
	UINTN data_size, const void *data);
/*
 * Register a state policy while namespace ownership is held. Existing RAM
 * predicates cannot be silently hidden or migrated. The real MM registration
 * independently chooses and permanently reserves its current protected class.
 */
EFI_STATUS cdk2_authvar_namespace_register_state_policy(
	struct cdk2_authvar_namespace *namespace, const void *policy, size_t policy_size);
EFI_STATUS cdk2_authvar_namespace_next(struct cdk2_authvar_namespace *namespace,
	UINTN *name_size, CHAR16 *name, EFI_GUID *vendor);
EFI_STATUS cdk2_authvar_namespace_query(struct cdk2_authvar_namespace *namespace,
	UINT32 attributes, UINT64 *maximum_storage, UINT64 *remaining_storage,
	UINT64 *maximum_variable);
EFI_STATUS cdk2_authvar_namespace_enter_runtime(
	struct cdk2_authvar_namespace *namespace);

#endif
