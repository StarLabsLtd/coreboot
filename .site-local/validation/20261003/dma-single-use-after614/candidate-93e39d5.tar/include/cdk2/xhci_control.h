/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_XHCI_CONTROL_H
#define CDK2_XHCI_CONTROL_H

#include <uefi.h>

#define CDK2_XHCI_CONTROL_REVISION 2U
#define CDK2_XHCI_CONTROL_GUID \
	{ 0x5417799c, 0x6e46, 0x4c0b, \
		{ 0xa1, 0xb9, 0x4b, 0x3a, 0xb5, 0xd2, 0xc8, 0x17 } }

struct cdk2_xhci_control;
typedef EFI_STATUS CDK2_MS_ABI cdk2_xhci_control_fn(
	struct cdk2_xhci_control *control, void *controller);

struct cdk2_xhci_control {
	UINT32 revision;
	void *controller;
	cdk2_xhci_control_fn *poll_once;
	/* Periodic polling is armed only at the external-loader boundary. */
	cdk2_xhci_control_fn *start_polling;
	cdk2_xhci_control_fn *stop_polling;
	/* DXE calls at high TPL after masking APIC; never frees or closes events. */
	cdk2_xhci_control_fn *quiesce;
};

#endif
