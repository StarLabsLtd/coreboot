/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_PCI_ENUMERATE_H
#define CDK2_PCI_ENUMERATE_H

#include <stddef.h>
#include <stdint.h>

#define CDK2_PCI_ENUMERATE_MAX_DEVICES 256U

struct cdk2_pci_assignment_record;

typedef int cdk2_pci_enumerate_read_fn(void *context, uint16_t segment,
	uint8_t bus, uint8_t device, uint8_t function, uint16_t offset,
	uint32_t *value);

struct cdk2_pci_enumerated_device {
	uint16_t segment;
	uint8_t bus, device, function;
	uint16_t vendor, device_id, command;
	uint8_t class_code, subclass, programming_interface;
	uint8_t assignment_count;
};

struct cdk2_pci_enumeration {
	struct cdk2_pci_enumerated_device device[CDK2_PCI_ENUMERATE_MAX_DEVICES];
	size_t count, assignment_count;
};

int cdk2_pci_enumerate_assigned(
	const struct cdk2_pci_assignment_record *assignments,
	size_t assignment_count, cdk2_pci_enumerate_read_fn *read,
	void *context, struct cdk2_pci_enumeration *enumeration);

#endif
