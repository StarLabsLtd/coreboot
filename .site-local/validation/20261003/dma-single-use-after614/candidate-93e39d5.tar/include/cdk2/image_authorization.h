/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_IMAGE_AUTHORIZATION_H
#define CDK2_IMAGE_AUTHORIZATION_H

#include <stddef.h>
#include <uefi.h>

/*
 * Pure SHA256/SHA384/SHA512 PE image-hash and RSA2048/SHA256 CMS policy
 * subset, not an installed Security2 protocol.
 * All image/database snapshots must remain immutable throughout this call.
 * Unsupported database types or signature envelopes return EFI_UNSUPPORTED;
 * callers must never translate that result into permission to execute.
 */
EFI_STATUS cdk2_image_authorize(const void *image, size_t image_size,
	const void *allowed, size_t allowed_size,
	const void *forbidden, size_t forbidden_size);

/* Pure policy using a caller-attested trusted immutable dbt X509-only ESL snapshot.
 * Arbitrary dbt-shaped bytes are not authoritative: the caller owns retrieval,
 * authenticated-variable provenance and immutability for the complete call.
 * Does not retrieve protected variables or install/activate image policy.
 * Only a signature-bound verified RFC3161 token no later than every matching
 * supported revocation time can remove a timed-certificate veto.
 */
EFI_STATUS cdk2_image_authorize_with_dbt(const void *image, size_t image_size,
	const void *allowed, size_t allowed_size,
	const void *forbidden, size_t forbidden_size,
	const void *timestamp_anchors, size_t timestamp_anchors_size);

#endif
