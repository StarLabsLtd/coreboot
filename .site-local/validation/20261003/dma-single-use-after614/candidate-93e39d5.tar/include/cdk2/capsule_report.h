/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_CAPSULE_REPORT_H
#define CDK2_CAPSULE_REPORT_H

#include <cdk2/esrt_abi.h>
#include <stddef.h>
#include <stdint.h>

#define CDK2_CAPSULE_REPORT_GUID \
	{ 0x39b68c46, 0xf7fb, 0x441b, { 0xb6, 0xec, 0x16, 0xb0, 0xf6, 0x98, 0x21, 0xf3 } }
#define CDK2_CAPSULE_REPORT_FMP_SIZE 72U

uint64_t cdk2_capsule_report_initialize(struct cdk2_runtime_services_view *runtime,
	struct cdk2_variable_policy_protocol *policy, uint32_t boot_mode);
uint64_t cdk2_capsule_report_fmp(struct cdk2_runtime_services_view *runtime,
	const EFI_GUID *capsule_guid, const EFI_GUID *image_type, uint8_t image_index,
	size_t payload_index, uint64_t failure);

#endif
