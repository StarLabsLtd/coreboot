/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_EC_BATTERY_H_
#define CDK2_EC_BATTERY_H_

#include <uefi.h>

#define CDK2_EC_UNKNOWN_PERCENT 0xffU

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
#include <cdk2/diagnostic.h>
void cdk2_ec_battery_diagnostic(const char *message);
#define CDK2_EC_BATTERY_DIAG(message) cdk2_ec_battery_diagnostic(message)
#else
#define CDK2_EC_BATTERY_DIAG(message) do { } while (0)
#endif

enum cdk2_ec_type {
	CDK2_EC_UNKNOWN,
	CDK2_EC_CHROME,
	CDK2_EC_MERLIN,
	CDK2_EC_THINKPAD,
	CDK2_EC_THINKPAD_LEGACY,
	CDK2_EC_SBS,
};

typedef EFI_STATUS cdk2_ec_read_fn(void *, UINT8, UINT8 *);
typedef EFI_STATUS cdk2_ec_write_fn(void *, UINT8, UINT8);
typedef EFI_STATUS cdk2_ec_read_word_fn(void *, UINT8, UINT16 *);

struct cdk2_ec_io {
	cdk2_ec_read_fn *read;
	cdk2_ec_write_fn *write;
	void *context;
	cdk2_ec_read_word_fn *read_word;
};

enum cdk2_battery_capacity_kind {
	CDK2_BATTERY_CAPACITY_WORDS,
	CDK2_BATTERY_CAPACITY_DWORDS,
	CDK2_BATTERY_CAPACITY_PERCENT,
	CDK2_BATTERY_CAPACITY_SBS,
};

struct cdk2_battery_profile {
	enum cdk2_ec_type type;
	enum cdk2_battery_capacity_kind capacity_kind;
	UINT8 probe_register, status_register, presence_register;
	UINT8 remaining_register, full_register, percentage_register;
	UINT8 current_register, selector_register, selector_value;
	UINT16 present_mask, charging_mask, discharging_mask, critical_mask;
	UINT16 error_mask;
	BOOLEAN selector_required;
};

struct cdk2_ec_battery {
	struct cdk2_ec_io io;
	enum cdk2_ec_type type;
	const struct cdk2_battery_profile *profile;
	BOOLEAN present;
};

typedef UINT8 cdk2_ec_port_read_fn(void *, UINT16);
typedef void cdk2_ec_port_write_fn(void *, UINT16, UINT8);
typedef EFI_STATUS cdk2_ec_stall_fn(void *, UINTN);

struct cdk2_ec_port {
	cdk2_ec_port_read_fn *read;
	cdk2_ec_port_write_fn *write;
	cdk2_ec_stall_fn *stall;
	void *context;
	UINTN timeout_us;
	UINT16 data_port, command_port;
	UINT8 read_command, write_command, output_full_mask, input_full_mask;
};

struct cdk2_ec_port_profile {
	struct cdk2_ec_port *port;
	BOOLEAN chrome;
};

EFI_STATUS cdk2_ec_port_read(void *context, UINT8 offset, UINT8 *value);
EFI_STATUS cdk2_ec_port_write(void *context, UINT8 offset, UINT8 value);
EFI_STATUS cdk2_ec_port_read_word(void *context, UINT8 command, UINT16 *value);

EFI_STATUS cdk2_ec_battery_detect(struct cdk2_ec_battery *battery,
	const struct cdk2_ec_io *chrome, const struct cdk2_ec_io *merlin,
	const struct cdk2_ec_io *thinkpad);
EFI_STATUS cdk2_ec_battery_select(struct cdk2_ec_battery *battery,
	enum cdk2_ec_type type, const struct cdk2_ec_io *io);
EFI_STATUS cdk2_ec_battery_select_profile(struct cdk2_ec_battery *battery,
	const struct cdk2_battery_profile *profile, const struct cdk2_ec_io *io);
const struct cdk2_battery_profile *cdk2_ec_battery_compat_profile(
	enum cdk2_ec_type type);
EFI_STATUS cdk2_ec_battery_info(struct cdk2_ec_battery *battery,
	UINT8 *percentage, BOOLEAN *present, BOOLEAN *charging);
EFI_STATUS cdk2_ec_battery_critical(struct cdk2_ec_battery *battery,
	BOOLEAN *critical);

#endif
