/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_LVGL_SETTINGS_FORM_H_
#define CDK2_LVGL_SETTINGS_FORM_H_

#include <cdk2/lvgl_settings.h>
#include <cdk2/lvgl_renderer.h>

#define CDK2_LVGL_SETTINGS_CONTROL_COUNT 6U
#define CDK2_LVGL_SETTINGS_STATEMENT_COUNT 8U

enum cdk2_lvgl_settings_control {
	CDK2_LVGL_SETTINGS_SCALE = 1,
	CDK2_LVGL_SETTINGS_CENTERED,
	CDK2_LVGL_SETTINGS_HEIGHT,
	CDK2_LVGL_SETTINGS_ASPECT_WIDTH,
	CDK2_LVGL_SETTINGS_ASPECT_HEIGHT,
	CDK2_LVGL_SETTINGS_MODEL,
};

EFI_STATUS cdk2_lvgl_settings_build_form(
	struct cdk2_lvgl_settings_transaction *transaction,
	struct cdk2_lvgl_form *form, struct cdk2_lvgl_statement *statements,
	UINTN statement_capacity);

#endif
