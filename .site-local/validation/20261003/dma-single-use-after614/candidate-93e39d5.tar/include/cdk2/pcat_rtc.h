/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_PCAT_RTC_H_
#define CDK2_PCAT_RTC_H_

#include <uefi.h>
#ifdef CDK2_DEBUG
typedef EFI_STATUS CDK2_MS_ABI cdk2_pcat_rtc_diagnostic_write_fn(void *, UINTN *, void *);
extern void *cdk2_pcat_rtc_diagnostic_context;
extern cdk2_pcat_rtc_diagnostic_write_fn *cdk2_pcat_rtc_diagnostic_write;
#define CDK2_PCAT_RTC_DIAG_SET(context, write) do { \
	cdk2_pcat_rtc_diagnostic_context = (context); \
	cdk2_pcat_rtc_diagnostic_write = (write); \
} while (0)
void cdk2_pcat_rtc_diagnostic(const char *, UINTN);
#define CDK2_PCAT_RTC_DIAG(message) cdk2_pcat_rtc_diagnostic((message), sizeof(message) - 1U)
#else
#define CDK2_PCAT_RTC_DIAG(message) do { } while (0)
#endif

typedef struct {
	UINT16 year;
	UINT8 month;
	UINT8 day;
	UINT8 hour;
	UINT8 minute;
	UINT8 second;
	UINT8 pad1;
	UINT32 nanosecond;
	INT16 timezone;
	UINT8 daylight;
	UINT8 pad2;
} CDK2_EFI_TIME;

typedef struct {
	UINT32 resolution;
	UINT32 accuracy;
	BOOLEAN sets_to_zero;
} CDK2_TIME_CAPABILITIES;

#endif
