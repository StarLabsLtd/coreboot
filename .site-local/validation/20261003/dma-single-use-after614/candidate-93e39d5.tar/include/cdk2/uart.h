/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_UART_H_
#define CDK2_UART_H_

#include <stdbool.h>
#include <stdint.h>

#define CDK2_UART_NONE 0U
#define CDK2_UART_PIO 1U
#define CDK2_UART_MMIO 2U

/* Include the complete last register access, not just its starting address. */
static inline bool cdk2_uart_registers_valid(uint8_t type, uint64_t base,
	uint32_t width, uint32_t stride, uint32_t last_register)
{
	uint64_t last_offset = (uint64_t)last_register * stride;

	if (type == CDK2_UART_NONE)
		return true;
	if (base == 0 || stride == 0 || (width != 1 && width != 2 && width != 4))
		return false;
	if (type == CDK2_UART_PIO)
		return last_offset <= UINT16_MAX && base <= UINT16_MAX - last_offset;
	if (type != CDK2_UART_MMIO || base % width || stride % width)
		return false;
	last_offset += width - 1;
	return last_offset <= UINTPTR_MAX && base <= UINTPTR_MAX - last_offset;
}

#endif
