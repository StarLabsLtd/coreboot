/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_NATIVE_VISIBILITY_H_
#define CDK2_NATIVE_VISIBILITY_H_

/*
 * Native PE images are closed, statically linked units. Mark declarations,
 * not only definitions, hidden so GCC emits direct PC-relative addresses.
 * PE/COFF ld does not relax ELF GOTPCRELX loads into address-form LEAs.
 */
#pragma GCC visibility push(hidden)

#endif
