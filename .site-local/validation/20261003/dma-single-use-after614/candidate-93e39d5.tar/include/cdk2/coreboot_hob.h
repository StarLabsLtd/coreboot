/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_COREBOOT_HOB_H
#define CDK2_COREBOOT_HOB_H

#include <stdint.h>

struct cdk2_coreboot_handoff;

/* Read the unique bounded coreboot table HOB, then use the canonical parser. */
uint64_t cdk2_coreboot_handoff_from_hobs(const void *hob_list,
	struct cdk2_coreboot_handoff *handoff);

#endif
