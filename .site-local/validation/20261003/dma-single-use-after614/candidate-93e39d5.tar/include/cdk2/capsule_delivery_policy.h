/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_CAPSULE_DELIVERY_POLICY_H
#define CDK2_CAPSULE_DELIVERY_POLICY_H

#include <cdk2/hob.h>
#include <coreboot_tables.h>
#include <stdint.h>
#include <string.h>

#define CDK2_CAPSULE_DELIVERY_POLICY_HOB_GUID \
	{ 0x8b9442c6, 0x6317, 0x4d89, { 0xab, 0x8f, 0xad, 0x6c, 0xa4, 0x3e, 0x95, 0x12 } }

struct cdk2_capsule_delivery_policy {
	uint32_t allowed_transports;
	uint64_t max_nonpopulate;
	uint64_t max_populate;
};

/* Descriptive delivery limits do not replace a provider's separate write admission. */
static inline EFI_STATUS cdk2_capsule_delivery_policy_validate(
	const struct cb_capsule_delivery_policy *record, size_t size,
	struct cdk2_capsule_delivery_policy *policy)
{
	struct cdk2_capsule_delivery_policy candidate;

	if (policy == NULL)
		return EFI_INVALID_PARAMETER;
	*policy = (struct cdk2_capsule_delivery_policy) { 0 };
	if (record == NULL || size != sizeof(*record) ||
	    record->tag != CB_TAG_CAPSULE_DELIVERY_POLICY || record->size != sizeof(*record) ||
	    record->revision != CB_CAPSULE_DELIVERY_POLICY_REVISION ||
	    record->header_size != sizeof(*record) || record->reserved[0] || record->reserved[1] ||
	    (record->allowed_transports & ~(CB_CAPSULE_DELIVERY_RAM | CB_CAPSULE_DELIVERY_DISK)))
		return EFI_COMPROMISED_DATA;
	candidate = (struct cdk2_capsule_delivery_policy) {
		.allowed_transports = record->allowed_transports,
		.max_nonpopulate = (uint64_t)record->max_nonpopulate.hi << 32 |
			record->max_nonpopulate.lo,
		.max_populate = (uint64_t)record->max_populate.hi << 32 | record->max_populate.lo,
	};
	if (candidate.max_nonpopulate > UINT32_MAX || candidate.max_populate > UINT32_MAX ||
	    (candidate.allowed_transports && !candidate.max_nonpopulate) ||
	    (!candidate.allowed_transports && (candidate.max_nonpopulate || candidate.max_populate)))
		return EFI_COMPROMISED_DATA;
	*policy = candidate;
	return EFI_SUCCESS;
}

static inline EFI_STATUS cdk2_capsule_delivery_policy_from_hobs(const void *hob_list,
	struct cdk2_capsule_delivery_policy *policy)
{
	const EFI_GUID policy_guid = CDK2_CAPSULE_DELIVERY_POLICY_HOB_GUID;
	const EFI_HOB_HANDOFF_INFO_TABLE *handoff = hob_list;
	const EFI_HOB_GENERIC_HEADER *hob;
	const struct cb_capsule_delivery_policy *record = NULL;
	EFI_STATUS status;

	if (policy == NULL)
		return EFI_INVALID_PARAMETER;
	*policy = (struct cdk2_capsule_delivery_policy) { 0 };
	if (hob_list == NULL)
		return EFI_NOT_FOUND;
	status = cdk2_hob_list_validate(hob_list);
	if (EFI_ERROR(status))
		return status;
	for (hob = hob_list; (UINTN)hob < handoff->efi_end_of_hob_list;
	     hob = (const void *)((const uint8_t *)hob + hob->hob_length)) {
		const EFI_HOB_GUID_TYPE *guid_hob = (const void *)hob;

		if (hob->hob_type != EFI_HOB_TYPE_GUID_EXTENSION)
			continue;
		if (hob->hob_length < sizeof(*guid_hob))
			return EFI_COMPROMISED_DATA;
		if (memcmp(&guid_hob->name, &policy_guid, sizeof(policy_guid)))
			continue;
		if (record != NULL || hob->hob_length != sizeof(*guid_hob) + sizeof(*record))
			return EFI_COMPROMISED_DATA;
		record = (const void *)(guid_hob + 1);
	}
	return record == NULL ? EFI_NOT_FOUND :
		cdk2_capsule_delivery_policy_validate(record, sizeof(*record), policy);
}

#endif
