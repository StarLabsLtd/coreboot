/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_CAPSULE_RUNTIME_ENTRY_H
#define CDK2_CAPSULE_RUNTIME_ENTRY_H

#include <cdk2/capsule_runtime_abi.h>

EFI_STATUS CDK2_MS_ABI cdk2_capsule_runtime_entry(void *image_handle,
	struct cdk2_system_table_view *system_table);
EFI_STATUS cdk2_capsule_cache_writeback_range_all_cpus(UINT64 address,
	UINT64 length);

#endif
