/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_AUTHVAR_TRANSPORT_H
#define CDK2_AUTHVAR_TRANSPORT_H

#include <cdk2/payload_mm_authvar_service.h>

struct cdk2_coreboot_handoff;

struct cdk2_authvar_endpoint {
	struct cb_authvar_service_endpoint descriptor;
	UINT64 generation;
	EFI_PHYSICAL_ADDRESS communication_base;
	BOOLEAN valid;
};

typedef EFI_STATUS cdk2_authvar_trigger_fn(void *context, UINT16 port, UINT8 value);
typedef EFI_STATUS cdk2_authvar_cache_fn(void *context, void *base, UINTN size);
typedef void cdk2_authvar_barrier_fn(void *context);

struct cdk2_authvar_client {
	struct cdk2_authvar_endpoint endpoint;
	/* CPU mapping of the fixed mailbox; unlike communication_base, convertible. */
	UINT8 *mailbox_alias;
	void *context;
	cdk2_authvar_trigger_fn *trigger;
	cdk2_authvar_cache_fn *cache;
	cdk2_authvar_barrier_fn *barrier;
	/* Caller-owned private runtime storage, disjoint from the physical mailbox. */
	UINT8 *scratch;
	UINTN scratch_size;
	void *private_owner;
	UINTN private_owner_size;
	UINT64 last_request_id;
	BOOLEAN busy;
};

EFI_STATUS cdk2_authvar_endpoint_validate(const struct cb_authvar_service_endpoint *wire,
	struct cdk2_authvar_endpoint *endpoint);
EFI_STATUS cdk2_authvar_endpoint_from_coreboot(const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_authvar_endpoint *endpoint);
EFI_STATUS cdk2_authvar_client_call(struct cdk2_authvar_client *client,
	const void *request, void *response, UINTN size);
EFI_STATUS cdk2_authvar_client_rebase_private(struct cdk2_authvar_client *client,
	UINT8 *mailbox_alias, UINT8 *scratch, UINTN scratch_size, void *context,
	cdk2_authvar_trigger_fn *trigger, cdk2_authvar_cache_fn *cache,
	cdk2_authvar_barrier_fn *barrier);

#endif
