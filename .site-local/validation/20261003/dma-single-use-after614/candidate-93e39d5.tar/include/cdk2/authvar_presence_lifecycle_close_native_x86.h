/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_NATIVE_X86_H
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_NATIVE_X86_H

#include <cdk2/payload_mm_authvar_presence_lifecycle_close_client.h>

enum cdk2_authvar_presence_lifecycle_close_client_status
cdk2_authvar_presence_lifecycle_close_native_x86_init(
	struct cdk2_authvar_presence_lifecycle_close_client *client,
	const struct cdk2_authvar_presence_lifecycle_close_endpoint *endpoint);

#ifdef CDK2_HOST_TEST
typedef EFI_STATUS cdk2_authvar_presence_lifecycle_close_native_x86_test_fn(
	UINT16 port, UINT32 *eax, UINT32 *ecx, void *context);

void cdk2_authvar_presence_lifecycle_close_native_x86_test_hook(
	cdk2_authvar_presence_lifecycle_close_native_x86_test_fn *hook,
	void *context);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_native_x86_test_trigger(
	UINT16 port, UINT8 command, UINT64 input, UINT64 *result);
#endif

#endif
