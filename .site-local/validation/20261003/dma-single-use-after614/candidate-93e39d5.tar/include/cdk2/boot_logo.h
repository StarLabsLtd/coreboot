/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_BOOT_LOGO_H_
#define CDK2_BOOT_LOGO_H_

#include <uefi.h>

struct cdk2_boot_logo_surface {
	UINT32 *pixels;
	UINT32 pixels_per_line;
	UINT32 width;
	UINT32 height;
	UINT8 red_mask_pos;
	UINT8 red_mask_size;
	UINT8 green_mask_pos;
	UINT8 green_mask_size;
	UINT8 blue_mask_pos;
	UINT8 blue_mask_size;
	UINT8 reserved_mask_pos;
	UINT8 reserved_mask_size;
};

struct cdk2_boot_logo_layout {
	UINT32 x;
	UINT32 y;
	UINT32 width;
	UINT32 height;
	UINT32 scale;
};

EFI_STATUS cdk2_boot_logo_layout_for_surface(const struct cdk2_boot_logo_surface *surface,
	struct cdk2_boot_logo_layout *layout);
EFI_STATUS cdk2_boot_logo_draw(const struct cdk2_boot_logo_surface *surface,
	struct cdk2_boot_logo_layout *layout);
EFI_STATUS cdk2_boot_logo_bmp(const struct cdk2_boot_logo_layout *layout,
	void *buffer, UINTN capacity, UINTN *size);

#endif
