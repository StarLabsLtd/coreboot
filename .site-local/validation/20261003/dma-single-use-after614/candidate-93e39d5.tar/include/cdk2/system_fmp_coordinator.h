/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_COORDINATOR_H
#define CDK2_SYSTEM_FMP_COORDINATOR_H

#include <cdk2/system_fmp_handoff.h>
#include <cdk2/system_fmp_payload.h>
#include <cdk2/system_fmp_state.h>

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

struct cdk2_coreboot_handoff;

typedef EFI_STATUS cdk2_system_fmp_board_bind_fn(void *context,
	const uint8_t *image, size_t image_size,
	const EFI_GUID image_type[1]);
typedef EFI_STATUS cdk2_system_fmp_broker_apply_fn(void *context,
	const struct cdk2_system_fmp_handoff *handoff,
	const uint8_t *image, size_t image_size,
	uint32_t *last_attempt_status);

struct cdk2_system_fmp_coordinator_config {
	const struct cdk2_coreboot_handoff *coreboot;
	const void *certificate_xdr;
	size_t certificate_xdr_size;
	const struct cdk2_system_fmp_state_identity *state_identity;
	const struct cdk2_system_fmp_state_store *state_store;
	const struct cdk2_system_fmp_dependency_version *dependency_versions;
	size_t dependency_version_count;
	cdk2_system_fmp_board_bind_fn *board_bind;
	void *board_context;
	cdk2_system_fmp_broker_apply_fn *broker_apply;
	void *broker_context;
	bool track_current_version;
};

/*
 * Historical local-state admission oracle only. New protected composition
 * uses system_fmp_session; this owner remains unselected and has no production
 * call site while its state model is retained for differential deletion work.
 */

struct cdk2_system_fmp_coordinator {
	struct cdk2_system_fmp_handoff handoff;
	struct cdk2_system_fmp_state_identity state_identity;
	struct cdk2_system_fmp_state_store state_store;
	const void *certificate_xdr;
	size_t certificate_xdr_size;
	const struct cdk2_system_fmp_dependency_version *dependency_versions;
	size_t dependency_version_count;
	cdk2_system_fmp_board_bind_fn *board_bind;
	void *board_context;
	cdk2_system_fmp_broker_apply_fn *broker_apply;
	void *broker_context;
	uint32_t check_lowest_version;
	bool track_current_version;
	bool initialized;
	bool active;
};

struct cdk2_system_fmp_transaction_request {
	enum cdk2_system_fmp_operation operation;
	const EFI_GUID *image_type;
	uint8_t image_index;
	const void *authenticated_image;
	size_t authenticated_image_size;
};

struct cdk2_system_fmp_transaction_result {
	uint32_t image_updatable;
	uint32_t last_attempt_status;
	uint32_t effective_lowest_version;
	bool writer_called;
};

/*
 * Zero-initialize, then initialize one exclusive owner exactly once.
 * Certificate and dependency storage remain immutable, and no other writer
 * may mutate this owner's durable FMP state.
 */
EFI_STATUS cdk2_system_fmp_coordinator_initialize(
	struct cdk2_system_fmp_coordinator *coordinator,
	const struct cdk2_system_fmp_coordinator_config *config);

/*
 * The authenticated image must remain immutable through broker completion.
 * The phase owner supplies DMA exclusion and does not expose this dormant leaf.
 */
EFI_STATUS cdk2_system_fmp_coordinator_execute(
	struct cdk2_system_fmp_coordinator *coordinator,
	const struct cdk2_system_fmp_transaction_request *request,
	struct cdk2_system_fmp_transaction_result *result);

#endif
