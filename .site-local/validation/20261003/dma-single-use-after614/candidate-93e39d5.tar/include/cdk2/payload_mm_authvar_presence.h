/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_H
#define CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_H

#include <coreboot_tables.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

struct cdk2_coreboot_handoff;

#define CDK2_AUTHVAR_PRESENCE_REVISION 1U
#define CDK2_AUTHVAR_PRESENCE_MESSAGE_SIZE 80U
#define CDK2_AUTHVAR_PRESENCE_PENDING MAX_UINT32
#define CDK2_AUTHVAR_PRESENCE_COMPLETE 0U
#define CDK2_AUTHVAR_PRESENCE_STATUS_PENDING MAX_UINT64

#define CDK2_AUTHVAR_PRESENCE_STATUS_ERROR_BIT (1ULL << 63)
#define CDK2_AUTHVAR_PRESENCE_STATUS_SUCCESS 0ULL
#define CDK2_AUTHVAR_PRESENCE_STATUS_UNSUPPORTED \
	(CDK2_AUTHVAR_PRESENCE_STATUS_ERROR_BIT | 3ULL)
#define CDK2_AUTHVAR_PRESENCE_STATUS_DEVICE_ERROR \
	(CDK2_AUTHVAR_PRESENCE_STATUS_ERROR_BIT | 7ULL)
#define CDK2_AUTHVAR_PRESENCE_STATUS_WRITE_PROTECTED \
	(CDK2_AUTHVAR_PRESENCE_STATUS_ERROR_BIT | 8ULL)
#define CDK2_AUTHVAR_PRESENCE_STATUS_ACCESS_DENIED \
	(CDK2_AUTHVAR_PRESENCE_STATUS_ERROR_BIT | 15ULL)
#define CDK2_AUTHVAR_PRESENCE_STATUS_SECURITY_VIOLATION \
	(CDK2_AUTHVAR_PRESENCE_STATUS_ERROR_BIT | 26ULL)

struct cdk2_authvar_presence_message {
	UINT32 revision;
	UINT32 size;
	UINT32 action;
	UINT32 flags;
	UINT64 generation;
	UINT64 request_id;
	UINT8 capability[CB_AUTHVAR_PRESENCE_CAPABILITY_SIZE];
	UINT64 status;
	UINT32 reserved;
	UINT32 completion;
} __aligned(8);

/*
 * A validated, owned copy of the coreboot presence metadata.  This is
 * descriptive state only: it does not expose a callable transport or grant
 * physical-presence authority.
 */
struct cdk2_authvar_presence_endpoint {
	struct cb_authvar_presence_endpoint descriptor;
	UINT64 generation;
	EFI_PHYSICAL_ADDRESS communication_base;
	BOOLEAN available;
};

_Static_assert(sizeof(struct cdk2_authvar_presence_message) ==
	CDK2_AUTHVAR_PRESENCE_MESSAGE_SIZE,
	"authenticated-variable presence message ABI");
_Static_assert(_Alignof(struct cdk2_authvar_presence_message) == 8U,
	"authenticated-variable presence message alignment");
_Static_assert(OFFSET_OF(struct cdk2_authvar_presence_message, generation) == 16U &&
	OFFSET_OF(struct cdk2_authvar_presence_message, request_id) == 24U &&
	OFFSET_OF(struct cdk2_authvar_presence_message, capability) == 32U &&
	OFFSET_OF(struct cdk2_authvar_presence_message, status) == 64U &&
	OFFSET_OF(struct cdk2_authvar_presence_message, reserved) == 72U &&
	OFFSET_OF(struct cdk2_authvar_presence_message, completion) == 76U,
	"authenticated-variable presence message layout");
_Static_assert(CB_AUTHVAR_PRESENCE_REQUIRED_FLAGS == 0x3fU,
	"authenticated-variable presence endpoint flags");
_Static_assert(CDK2_AUTHVAR_PRESENCE_STATUS_ERROR_BIT == (1ULL << 63),
	"authenticated-variable presence status encoding");

EFI_STATUS cdk2_authvar_presence_endpoint_validate(
	const struct cb_authvar_presence_endpoint *endpoint);
EFI_STATUS cdk2_authvar_presence_endpoint_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_authvar_presence_endpoint *endpoint);
EFI_STATUS cdk2_authvar_presence_request_validate(
	const struct cb_authvar_presence_endpoint *endpoint,
	const void *request, UINTN message_size);
EFI_STATUS cdk2_authvar_presence_response_validate(
	const struct cb_authvar_presence_endpoint *endpoint,
	const void *request, const void *response, UINTN message_size);

#endif
