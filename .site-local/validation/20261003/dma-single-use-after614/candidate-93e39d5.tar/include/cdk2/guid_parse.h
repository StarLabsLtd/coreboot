/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_GUID_PARSE_H
#define CDK2_GUID_PARSE_H

#include <stdbool.h>
#include <uefi.h>

bool cdk2_guid_parse(const char *text, EFI_GUID *guid);

#endif
