/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_RUNTIME_ARCH_H
#define CDK2_RUNTIME_ARCH_H

#include <uefi.h>

#define CDK2_RUNTIME_OPTIONAL_POINTER 0x00000001U
#define CDK2_RUNTIME_DESCRIPTOR_VERSION 1U
#define CDK2_RUNTIME_PAGE_SIZE 4096U
#define CDK2_RUNTIME_MAX_DESCRIPTORS 4096U

struct cdk2_runtime_memory_descriptor {
	UINT32 type;
	UINT32 padding;
	UINT64 physical_start;
	UINT64 virtual_start;
	UINT64 number_of_pages;
	UINT64 attributes;
};

struct cdk2_runtime_map {
	const UINT8 *descriptors;
	UINTN map_size;
	UINTN descriptor_size;
};

struct cdk2_runtime_table_header {
	UINT64 signature;
	UINT32 revision;
	UINT32 header_size;
	UINT32 crc32;
	UINT32 reserved;
};

typedef EFI_STATUS CDK2_MS_ABI cdk2_runtime_crc32_fn(const void *, UINTN,
	UINT32 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_runtime_set_map_fn(UINTN, UINTN, UINT32,
	void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_runtime_convert_fn(UINTN, void **);

struct cdk2_runtime_service_slots {
	struct cdk2_runtime_table_header *boot_header;
	struct cdk2_runtime_table_header *runtime_header;
	cdk2_runtime_crc32_fn **calculate_crc32;
	cdk2_runtime_set_map_fn **set_virtual_address_map;
	cdk2_runtime_convert_fn **convert_pointer;
};

typedef EFI_STATUS CDK2_MS_ABI cdk2_runtime_install_fn(void **,
	const EFI_GUID *, void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_runtime_uninstall_fn(void *,
	const EFI_GUID *, void *);

struct cdk2_runtime_publication_ops {
	void *context;
	cdk2_runtime_install_fn *install;
	cdk2_runtime_uninstall_fn *uninstall;
};

struct cdk2_runtime_publication {
	struct cdk2_runtime_service_slots slots;
	void *protocol;
	void *handle;
};

typedef void CDK2_MS_ABI cdk2_runtime_notify_fn(void *, void *);
typedef void cdk2_runtime_relocate_fn(UINT64, UINT64, UINTN, void *);
typedef void cdk2_runtime_invalidate_fn(void *, UINTN);

struct cdk2_runtime_event {
	void *event;
	cdk2_runtime_notify_fn *notify;
	void *context;
};

struct cdk2_runtime_image {
	void *base;
	UINTN size;
	void *relocation_data;
	int is_runtime_driver;
};

struct cdk2_runtime_pointer_group {
	void ***slots;
	UINTN count;
};

struct cdk2_runtime_transition {
	struct cdk2_runtime_event *events;
	UINTN event_count;
	struct cdk2_runtime_image *images;
	UINTN image_count;
	struct cdk2_runtime_pointer_group runtime_services;
	struct cdk2_runtime_pointer_group system_table;
	struct cdk2_runtime_pointer_group configuration_tables;
	struct cdk2_runtime_table_header *runtime_header;
	struct cdk2_runtime_table_header *system_header;
	cdk2_runtime_relocate_fn *relocate;
	cdk2_runtime_invalidate_fn *invalidate;
};

struct cdk2_runtime_state {
	int at_runtime;
	int virtual_mode;
	struct cdk2_runtime_map active_map;
};

struct cdk2_runtime_list_entry {
	struct cdk2_runtime_list_entry *forward, *back;
};

struct cdk2_runtime_arch_protocol {
	struct cdk2_runtime_list_entry image_head, event_head;
	UINTN memory_descriptor_size;
	UINT32 memory_descriptor_version;
	UINTN memory_map_size;
	void *memory_map_physical, *memory_map_virtual;
	BOOLEAN virtual_mode, at_runtime;
};

typedef char cdk2_runtime_arch_image_head_offset[
	(offsetof(struct cdk2_runtime_arch_protocol, image_head) == 0) ? 1 : -1];
typedef char cdk2_runtime_arch_event_head_offset[
	(offsetof(struct cdk2_runtime_arch_protocol, event_head) == 16) ? 1 : -1];
typedef char cdk2_runtime_arch_descriptor_offset[
	(offsetof(struct cdk2_runtime_arch_protocol, memory_descriptor_size) == 32) ? 1 : -1];
typedef char cdk2_runtime_arch_map_offset[
	(offsetof(struct cdk2_runtime_arch_protocol, memory_map_size) == 48) ? 1 : -1];
typedef char cdk2_runtime_arch_flags_offset[
	(offsetof(struct cdk2_runtime_arch_protocol, virtual_mode) == 72) ? 1 : -1];
typedef char cdk2_runtime_arch_size[
	(sizeof(struct cdk2_runtime_arch_protocol) == 80) ? 1 : -1];

EFI_STATUS cdk2_runtime_map_init(struct cdk2_runtime_map *map,
	const void *descriptors, UINTN map_size, UINTN descriptor_size,
	UINT32 descriptor_version);
EFI_STATUS cdk2_runtime_convert_pointer(const struct cdk2_runtime_map *map,
	UINTN disposition, void **address);
EFI_STATUS cdk2_runtime_convert_range(const struct cdk2_runtime_map *map,
	const void *address, UINTN size, void **converted);
EFI_STATUS CDK2_MS_ABI cdk2_runtime_calculate_crc32(const void *data, UINTN size,
	UINT32 *crc);
EFI_STATUS cdk2_runtime_publish(struct cdk2_runtime_publication *publication,
	const struct cdk2_runtime_publication_ops *ops,
	cdk2_runtime_crc32_fn *crc32, cdk2_runtime_set_map_fn *set_map,
	cdk2_runtime_convert_fn *convert);
EFI_STATUS cdk2_runtime_set_virtual_map(struct cdk2_runtime_state *state,
	UINTN map_size, UINTN descriptor_size, UINT32 descriptor_version,
	const void *virtual_map, struct cdk2_runtime_transition *transition);

#endif
