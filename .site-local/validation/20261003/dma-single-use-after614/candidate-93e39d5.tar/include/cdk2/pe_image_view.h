/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_PE_IMAGE_VIEW_H_
#define CDK2_PE_IMAGE_VIEW_H_

#include <uefi.h>
#include <industry_standard/pe_image.h>

#define CDK2_PE_MAX_SECTIONS 96U

struct cdk2_pe_image_view {
	const UINT8 *image;
	UINTN image_size;
	UINTN pe_offset;
	UINTN section_offset;
	UINTN checksum_offset;
	UINTN security_offset;
	UINT16 machine;
	UINT16 magic;
	UINT16 subsystem;
	UINT16 section_count;
	UINT16 optional_size;
	UINT32 size_of_headers;
	UINT32 size_of_image;
	UINT32 address_of_entry_point;
	UINT32 section_alignment;
	UINT32 file_alignment;
	UINT32 directory_count;
	UINT32 certificate_offset;
	UINT32 certificate_size;
	UINT64 image_base;
	BOOLEAN has_security_directory;
};

EFI_STATUS cdk2_pe_image_view_open(const void *image, UINTN image_size,
	struct cdk2_pe_image_view *view);
EFI_STATUS cdk2_pe_image_section(const struct cdk2_pe_image_view *view,
	UINT32 index, EFI_IMAGE_SECTION_HEADER *section);
EFI_STATUS cdk2_pe_image_directory(const struct cdk2_pe_image_view *view,
	UINT32 index, EFI_IMAGE_DATA_DIRECTORY *directory);
BOOLEAN cdk2_pe_image_view_native_supported(
	const struct cdk2_pe_image_view *view);

#endif
