/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_ATA_ATAPI_PASS_THRU_H_
#define CDK2_ATA_ATAPI_PASS_THRU_H_

#include <stddef.h>
#include <stdint.h>
#include <uefi.h>
#include <cdk2/diagnostic.h>
#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
#define CDK2_ATA_ATAPI_DIAG(event, status) \
	cdk2_diag_emit_compact(CDK2_DIAG_ATA_ATAPI, (event), (status))
#else
#define CDK2_ATA_ATAPI_DIAG(event, status) do { } while (0)
#endif

#define CDK2_ATA_MAX_DEVICES 64U
#define CDK2_ATA_MAX_CONTROLLERS 8U
#define CDK2_ATA_ASYNC_DEPTH 16U
#define CDK2_ATA_NO_PORT_MULTIPLIER 0xffffU
#define CDK2_ATA_PASS_THRU_ATTRIBUTES_PHYSICAL 0x0001U
#define CDK2_ATA_PASS_THRU_ATTRIBUTES_LOGICAL 0x0002U
#define CDK2_ATA_PASS_THRU_ATTRIBUTES_NONBLOCKIO 0x0004U
#define CDK2_EXT_SCSI_TARGET_BYTES 16U
#define CDK2_EXT_SCSI_DIRECTION_READ 0U
#define CDK2_EXT_SCSI_DIRECTION_WRITE 1U
#define CDK2_EXT_SCSI_DIRECTION_BIDIRECTIONAL 2U
#define CDK2_ATAPI_FEATURE_DMA 0x01U

enum cdk2_ata_mode { CDK2_ATA_IDE, CDK2_ATA_AHCI };
enum cdk2_ata_device_type { CDK2_ATA_DISK, CDK2_ATAPI_DEVICE, CDK2_PORT_MULTIPLIER };

struct cdk2_ata_device {
	UINT16 port, multiplier;
	UINT8 type, packet_size;
	UINT32 block_size, alignment;
};
struct cdk2_ata_topology {
	enum cdk2_ata_mode mode;
	struct cdk2_ata_device devices[CDK2_ATA_MAX_DEVICES];
	size_t count;
	struct {
		const UINT16 *iterator;
		UINT16 port;
		UINTN generation;
	} direct_iterators[8];
	UINTN direct_iterator_next, enumeration_generation;
};

#pragma pack(push, 1)
struct cdk2_device_path_header { UINT8 type, subtype; UINT8 length[2]; };
struct cdk2_atapi_device_path {
	struct cdk2_device_path_header header;
	UINT8 primary_secondary, slave_master;
	UINT16 lun;
};
struct cdk2_sata_device_path {
	struct cdk2_device_path_header header;
	UINT16 hba_port, multiplier, lun;
};
#pragma pack(pop)

struct cdk2_ata_pass_thru_mode { UINT32 attributes, io_align; };
struct cdk2_ata_command_block {
	UINT8 reserved1[2], command, features, sector_number, cylinder_low;
	UINT8 cylinder_high, device_head, sector_number_exp, cylinder_low_exp;
	UINT8 cylinder_high_exp, features_exp, sector_count, sector_count_exp;
	UINT8 reserved2[6];
};
struct cdk2_ata_status_block {
	UINT8 reserved1[2], status, error, sector_number, cylinder_low;
	UINT8 cylinder_high, device_head, sector_number_exp, cylinder_low_exp;
	UINT8 cylinder_high_exp, reserved2, sector_count, sector_count_exp;
	UINT8 reserved3[6];
};
struct cdk2_ata_command_packet {
	struct cdk2_ata_status_block *asb;
	struct cdk2_ata_command_block *acb;
	UINT64 timeout;
	void *in_data, *out_data;
	UINT32 in_length, out_length;
	UINT8 protocol, length;
};
struct cdk2_ata_pass_thru_protocol;
typedef EFI_STATUS CDK2_MS_ABI cdk2_ata_pass_thru_fn(
	struct cdk2_ata_pass_thru_protocol *, UINT16, UINT16,
	struct cdk2_ata_command_packet *, void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ata_next_port_fn(
	struct cdk2_ata_pass_thru_protocol *, UINT16 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ata_next_device_fn(
	struct cdk2_ata_pass_thru_protocol *, UINT16, UINT16 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ata_build_path_fn(
	struct cdk2_ata_pass_thru_protocol *, UINT16, UINT16, void **);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ata_get_device_fn(
	struct cdk2_ata_pass_thru_protocol *, void *, UINT16 *, UINT16 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ata_reset_port_fn(
	struct cdk2_ata_pass_thru_protocol *, UINT16);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ata_reset_device_fn(
	struct cdk2_ata_pass_thru_protocol *, UINT16, UINT16);
struct cdk2_ata_pass_thru_protocol {
	struct cdk2_ata_pass_thru_mode *mode;
	cdk2_ata_pass_thru_fn *pass_thru;
	cdk2_ata_next_port_fn *get_next_port;
	cdk2_ata_next_device_fn *get_next_device;
	cdk2_ata_build_path_fn *build_device_path;
	cdk2_ata_get_device_fn *get_device;
	cdk2_ata_reset_port_fn *reset_port;
	cdk2_ata_reset_device_fn *reset_device;
};

EFI_STATUS cdk2_ata_topology_init(struct cdk2_ata_topology *topology,
	enum cdk2_ata_mode mode);
EFI_STATUS cdk2_ata_add_device(struct cdk2_ata_topology *topology, UINT16 port,
	UINT16 multiplier, enum cdk2_ata_device_type type);
EFI_STATUS cdk2_ata_get_next_port(struct cdk2_ata_topology *topology, UINT16 *port);
EFI_STATUS cdk2_ata_get_next_device(struct cdk2_ata_topology *topology, UINT16 port,
	UINT16 *multiplier);
EFI_STATUS cdk2_ata_build_device_path(const struct cdk2_ata_topology *topology,
	UINT16 port, UINT16 multiplier, void *path, size_t *path_size);
EFI_STATUS cdk2_ata_get_device(const struct cdk2_ata_topology *topology,
	const void *path, size_t path_size, UINT16 *port, UINT16 *multiplier);
EFI_STATUS cdk2_ata_validate_transfer(UINT8 protocol, UINT8 length,
	const void *in_buffer, UINT32 in_length, const void *out_buffer,
	UINT32 out_length, UINT32 io_align);
EFI_STATUS cdk2_ata_normalize_transfer(const struct cdk2_ata_device *device,
	struct cdk2_ata_command_packet *packet);

struct cdk2_ata_controller;
struct cdk2_ata_protocol_bundle;
struct cdk2_ahci_engine;
struct cdk2_ide_engine;
struct cdk2_ata_binding_services {
	void *context;
	EFI_STATUS (*open_path)(void *context, void *controller);
	EFI_STATUS (*close_path)(void *context, void *controller);
	EFI_STATUS (*open_ide)(void *context, void *controller, void **ide);
	EFI_STATUS (*close_ide)(void *context, void *controller);
	EFI_STATUS (*get_pci)(void *context, void *controller, void **pci);
	EFI_STATUS (*read_class)(void *context, void *pci, UINT8 code[3]);
	EFI_STATUS (*get_attributes)(void *context, void *pci, UINT64 *original,
		UINT64 *supported);
	EFI_STATUS (*enable_attributes)(void *context, void *pci, UINT64 attributes);
	EFI_STATUS (*restore_attributes)(void *context, void *pci, UINT64 attributes);
	EFI_STATUS (*discover_ide)(void *context, struct cdk2_ata_controller *controller,
		struct cdk2_ata_topology *topology);
	EFI_STATUS (*discover_ahci)(void *context, struct cdk2_ata_controller *controller,
		UINT32 *capability,
		UINT32 *ports_implemented, struct cdk2_ata_topology *topology);
	EFI_STATUS (*prepare_engines)(void *context, struct cdk2_ata_controller *controller);
	EFI_STATUS (*release_engines)(void *context, struct cdk2_ata_controller *controller);
	EFI_STATUS (*create_protocols)(void *context,
		struct cdk2_ata_controller *controller,
		struct cdk2_ata_protocol_bundle **protocols);
	void (*destroy_protocols)(void *context,
		struct cdk2_ata_protocol_bundle *protocols);
	EFI_STATUS (*install)(void *context, void *controller,
		struct cdk2_ata_protocol_bundle *protocols);
	EFI_STATUS (*uninstall)(void *context, void *controller,
		struct cdk2_ata_protocol_bundle *protocols);
	EFI_STATUS (*quiesce)(void *context, struct cdk2_ata_controller *controller);
	void (*relocate)(void *context, struct cdk2_ata_controller *controller);
};
struct cdk2_ata_controller {
	void *handle, *pci, *ide;
	struct cdk2_ata_topology topology;
	UINT64 original_attributes, enabled_attributes;
	UINT32 ahci_capability, ports_implemented;
	UINT8 programming_interface, started, protocols_installed;
	struct cdk2_ahci_engine *ahci;
	struct cdk2_ide_engine *ide_engine;
	struct cdk2_ata_protocol_bundle *protocols;
	void *backend;
};

struct cdk2_ata_async_task {
	struct cdk2_ata_command_packet *packet;
	EFI_STATUS *completion_status;
	void *event;
	UINT16 port, multiplier;
	EFI_STATUS status;
	UINT32 block_size;
	UINT8 block_units;
	UINT8 active, issued, completed, signaled, results_finalized, command_completed;
	UINT8 atapi, cdb_size;
	UINT8 cdb[16];
};
struct cdk2_ata_async_services {
	void *context;
	EFI_STATUS (*begin)(void *context, struct cdk2_ata_controller *controller,
		struct cdk2_ata_async_task *task);
	EFI_STATUS (*poll)(void *context, struct cdk2_ata_controller *controller,
		struct cdk2_ata_async_task *task, BOOLEAN *complete);
	EFI_STATUS (*abort)(void *context, struct cdk2_ata_controller *controller,
		struct cdk2_ata_async_task *task);
	EFI_STATUS (*arm)(void *context, struct cdk2_ata_controller *controller);
	EFI_STATUS (*signal)(void *context, void *event);
};
struct cdk2_ata_async_controller {
	struct cdk2_ata_controller *controller;
	struct cdk2_ata_async_services services;
	struct cdk2_ata_async_task queue[CDK2_ATA_ASYNC_DEPTH];
	UINTN head, count;
	BOOLEAN polling, stopping, armed;
};
EFI_STATUS cdk2_ata_async_init(struct cdk2_ata_async_controller *async,
	struct cdk2_ata_controller *controller,
	const struct cdk2_ata_async_services *services);
EFI_STATUS cdk2_ata_async_submit(struct cdk2_ata_async_controller *async,
	UINT16 port, UINT16 multiplier, struct cdk2_ata_command_packet *packet,
	void *event);
EFI_STATUS cdk2_ata_async_submit_atapi(struct cdk2_ata_async_controller *async,
	UINT16 port, UINT16 multiplier, struct cdk2_ata_command_packet *packet,
	const UINT8 *cdb, UINT8 cdb_size, void *event);
EFI_STATUS cdk2_ata_async_submit_atapi_priority(
	struct cdk2_ata_async_controller *async, UINT16 port, UINT16 multiplier,
	struct cdk2_ata_command_packet *packet, const UINT8 *cdb, UINT8 cdb_size,
	void *event);
EFI_STATUS cdk2_ata_async_poll(struct cdk2_ata_async_controller *async);
EFI_STATUS cdk2_ata_async_rearm(struct cdk2_ata_async_controller *async);
EFI_STATUS cdk2_ata_async_cancel(struct cdk2_ata_async_controller *async,
	UINT16 port, UINT16 multiplier, BOOLEAN match_multiplier);
EFI_STATUS cdk2_ata_async_stop(struct cdk2_ata_async_controller *async);
struct cdk2_ata_binding {
	struct cdk2_ata_binding_services services;
	struct cdk2_ata_controller controllers[CDK2_ATA_MAX_CONTROLLERS];
	size_t count;
};

struct cdk2_ext_scsi_packet;
struct cdk2_ata_protocol_services {
	void *context;
	EFI_STATUS (*allocate)(void *context, size_t size, void **buffer);
	void (*release)(void *context, void *buffer);
	EFI_STATUS (*submit)(void *context, struct cdk2_ata_controller *controller,
		UINT16 port, UINT16 multiplier, struct cdk2_ata_command_packet *packet,
		void *event);
	EFI_STATUS (*submit_scsi)(void *context,
		struct cdk2_ata_controller *controller, UINT16 port, UINT16 multiplier,
		struct cdk2_ext_scsi_packet *packet, void *event);
	EFI_STATUS (*cancel)(void *context, struct cdk2_ata_controller *controller);
	EFI_STATUS (*cancel_scope)(void *context,
		struct cdk2_ata_controller *controller, UINT16 port, UINT16 multiplier,
		BOOLEAN match_multiplier);
	EFI_STATUS (*wait)(void *context, struct cdk2_ata_controller *controller);
	void (*done)(void *context, struct cdk2_ata_controller *controller);
};
struct cdk2_ata_protocol_instance {
	struct cdk2_ata_pass_thru_protocol protocol;
	struct cdk2_ata_pass_thru_mode mode;
	struct cdk2_ata_controller *controller;
	struct cdk2_ata_protocol_services services;
};
EFI_STATUS cdk2_ata_protocol_init(struct cdk2_ata_protocol_instance *instance,
	struct cdk2_ata_controller *controller,
	const struct cdk2_ata_protocol_services *services, UINT32 io_align);

struct cdk2_ext_scsi_mode { UINT32 adapter_id, attributes, io_align; };
struct cdk2_ext_scsi_packet {
	UINT64 timeout;
	void *in_data, *out_data, *sense_data, *cdb;
	UINT32 in_length, out_length;
	UINT8 cdb_length, direction, host_status, target_status, sense_length;
};
struct cdk2_ext_scsi_protocol;
typedef EFI_STATUS CDK2_MS_ABI cdk2_ext_scsi_pass_fn(
	struct cdk2_ext_scsi_protocol *, UINT8 *, UINT64,
	struct cdk2_ext_scsi_packet *, void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ext_scsi_next_lun_fn(
	struct cdk2_ext_scsi_protocol *, UINT8 **, UINT64 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ext_scsi_build_path_fn(
	struct cdk2_ext_scsi_protocol *, UINT8 *, UINT64, void **);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ext_scsi_get_lun_fn(
	struct cdk2_ext_scsi_protocol *, void *, UINT8 **, UINT64 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ext_scsi_reset_channel_fn(
	struct cdk2_ext_scsi_protocol *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ext_scsi_reset_target_fn(
	struct cdk2_ext_scsi_protocol *, UINT8 *, UINT64);
typedef EFI_STATUS CDK2_MS_ABI cdk2_ext_scsi_next_target_fn(
	struct cdk2_ext_scsi_protocol *, UINT8 **);
struct cdk2_ext_scsi_protocol {
	struct cdk2_ext_scsi_mode *mode;
	cdk2_ext_scsi_pass_fn *pass_thru;
	cdk2_ext_scsi_next_lun_fn *get_next_target_lun;
	cdk2_ext_scsi_build_path_fn *build_device_path;
	cdk2_ext_scsi_get_lun_fn *get_target_lun;
	cdk2_ext_scsi_reset_channel_fn *reset_channel;
	cdk2_ext_scsi_reset_target_fn *reset_target_lun;
	cdk2_ext_scsi_next_target_fn *get_next_target;
};
struct cdk2_ext_scsi_instance {
	struct cdk2_ext_scsi_protocol protocol;
	struct cdk2_ext_scsi_mode mode;
	struct cdk2_ata_controller *controller;
	struct cdk2_ata_protocol_services services;
	UINT8 target[CDK2_EXT_SCSI_TARGET_BYTES];
	UINT8 previous[CDK2_EXT_SCSI_TARGET_BYTES];
	UINT64 previous_lun;
	UINT8 enumerated;
};
struct cdk2_ata_protocol_bundle {
	struct cdk2_ata_protocol_instance ata;
	struct cdk2_ext_scsi_instance ext_scsi;
};
EFI_STATUS cdk2_ext_scsi_init(struct cdk2_ext_scsi_instance *instance,
	struct cdk2_ata_controller *controller,
	const struct cdk2_ata_protocol_services *services, UINT32 io_align);

EFI_STATUS cdk2_ata_binding_init(struct cdk2_ata_binding *binding,
	const struct cdk2_ata_binding_services *services);
EFI_STATUS cdk2_ata_binding_supported(struct cdk2_ata_binding *binding,
	void *controller);
EFI_STATUS cdk2_ata_binding_start(struct cdk2_ata_binding *binding, void *controller);
EFI_STATUS cdk2_ata_binding_stop(struct cdk2_ata_binding *binding, void *controller);

#define CDK2_AHCI_MAX_SLOTS 32U
#define CDK2_AHCI_MAX_PRDT 64U
#define CDK2_AHCI_PRDT_MAX_BYTES 0x400000U
enum cdk2_ahci_dma_operation { CDK2_AHCI_BUS_MASTER_READ, CDK2_AHCI_BUS_MASTER_WRITE };
struct cdk2_ahci_prdt { UINT64 address; UINT32 bytes; UINT8 interrupt; };
struct cdk2_ahci_command {
	UINT8 fis[20], atapi[16];
	struct cdk2_ahci_prdt prdt[CDK2_AHCI_MAX_PRDT];
	UINT16 prdt_count;
	UINT8 atapi_command, write, multiplier;
};
struct cdk2_ahci_dma_services {
	void *context;
	EFI_STATUS (*allocate)(void *context, size_t size, size_t alignment,
		void **host, UINT64 *device);
	EFI_STATUS (*release)(void *context, void *host, size_t size);
	EFI_STATUS (*map)(void *context, enum cdk2_ahci_dma_operation operation,
		void *host, size_t *size, UINT64 *device, void **mapping);
	EFI_STATUS (*unmap)(void *context, void *mapping);
	EFI_STATUS (*flush)(void *context);
	UINT32 (*read)(void *context, UINT16 port, UINT16 register_offset);
	EFI_STATUS (*write)(void *context, UINT16 port, UINT16 register_offset,
		UINT32 value);
	UINT64 (*time)(void *context);
	void (*delay)(void *context, UINTN microseconds);
};
struct cdk2_ahci_allocation { void *host; UINT64 device; size_t size; };
struct cdk2_ahci_engine {
	struct cdk2_ahci_dma_services services;
	struct cdk2_ahci_allocation command_list, received_fis;
	struct cdk2_ahci_allocation command_tables[CDK2_AHCI_MAX_SLOTS];
	UINT32 capability, ports_implemented, active_slots;
	UINT32 original_command[32], original_clb[32], original_clbu[32];
	UINT32 original_fb[32], original_fbu[32], original_ie[32], configured_ports;
	void *recovery_mappings[CDK2_AHCI_MAX_PRDT];
	UINT16 recovery_mapping_count, recovery_port;
	UINT8 recovery_slot, recovery_pending;
	UINT16 active_port;
	UINT8 slots, initialized;
};
enum cdk2_ahci_async_phase {
	CDK2_AHCI_ASYNC_SLOT, CDK2_AHCI_ASYNC_MAP,
	CDK2_AHCI_ASYNC_TABLE_CLEAR, CDK2_AHCI_ASYNC_TABLE_BUILD,
	CDK2_AHCI_ASYNC_HEADER_BUILD, CDK2_AHCI_ASYNC_PREP_FLUSH,
	CDK2_AHCI_ASYNC_SNAPSHOT, CDK2_AHCI_ASYNC_PRIOR_READ,
	CDK2_AHCI_ASYNC_RESTORE_STOP, CDK2_AHCI_ASYNC_RESTORE_WAIT_CR,
	CDK2_AHCI_ASYNC_RESTORE_FRE_STOP, CDK2_AHCI_ASYNC_RESTORE_WAIT_FR,
	CDK2_AHCI_ASYNC_RESTORE_PROGRAM,
	CDK2_AHCI_ASYNC_CONFIG_STOP, CDK2_AHCI_ASYNC_WAIT_CR,
	CDK2_AHCI_ASYNC_CONFIG_FRE_STOP, CDK2_AHCI_ASYNC_WAIT_FR,
	CDK2_AHCI_ASYNC_PROGRAM, CDK2_AHCI_ASYNC_TFD,
	CDK2_AHCI_ASYNC_ISSUE, CDK2_AHCI_ASYNC_CI,
	CDK2_AHCI_ASYNC_ABORT_STOP, CDK2_AHCI_ASYNC_ABORT_WAIT,
	CDK2_AHCI_ASYNC_ABORT_RESTART, CDK2_AHCI_ASYNC_CLEAN_UNMAP,
	CDK2_AHCI_ASYNC_CLEAN_FLUSH, CDK2_AHCI_ASYNC_CLEAN_RELEASE,
	CDK2_AHCI_ASYNC_DONE
};
struct cdk2_ahci_async_request {
	struct cdk2_ahci_engine *engine;
	struct cdk2_ata_command_packet *packet;
	struct cdk2_ahci_command command;
	void *mappings[CDK2_AHCI_MAX_PRDT];
	UINT8 *buffer;
	size_t remaining, table_offset;
	UINT64 deadline, timeout;
	EFI_STATUS terminal_status;
	UINT32 original_command, prior_runtime_command;
	UINT16 port, prior_port, mapping_count, serialize_index;
	UINT8 slot, slot_probe, snapshot_index, program_index, restore_index;
	UINT8 issued, aborting, cleaned, operation, slot_owned, deadline_started;
	UINT8 rollback_pending;
	enum cdk2_ahci_async_phase phase;
};
EFI_STATUS cdk2_ahci_async_prepare(struct cdk2_ahci_async_request *request,
	struct cdk2_ahci_engine *engine, UINT16 port, UINT16 multiplier,
	struct cdk2_ata_command_packet *packet, UINT64 timeout);
EFI_STATUS cdk2_ahci_atapi_async_prepare(struct cdk2_ahci_async_request *request,
	struct cdk2_ahci_engine *engine, UINT16 port, UINT16 multiplier,
	struct cdk2_ata_command_packet *packet, const UINT8 *cdb, size_t cdb_size,
	UINT64 timeout);
EFI_STATUS cdk2_ahci_async_step(struct cdk2_ahci_async_request *request,
	BOOLEAN *complete);
EFI_STATUS cdk2_ahci_async_abort(struct cdk2_ahci_async_request *request,
	BOOLEAN *complete);

EFI_STATUS cdk2_ahci_engine_init(struct cdk2_ahci_engine *engine,
	const struct cdk2_ahci_dma_services *services, UINT32 capability,
	UINT32 ports_implemented);
void cdk2_ahci_engine_destroy(struct cdk2_ahci_engine *engine);
EFI_STATUS cdk2_ahci_reset_controller(struct cdk2_ahci_engine *engine,
	UINT64 timeout);
EFI_STATUS cdk2_ahci_reset_port(struct cdk2_ahci_engine *engine, UINT16 port,
	UINT64 timeout);
EFI_STATUS cdk2_ahci_recover(struct cdk2_ahci_engine *engine, UINT64 timeout);
EFI_STATUS cdk2_ahci_enable_pma(struct cdk2_ahci_engine *engine, UINT16 port,
	UINT64 timeout);
EFI_STATUS cdk2_ahci_build_command(const struct cdk2_ata_command_packet *packet,
	UINT16 multiplier, const UINT8 *atapi, size_t atapi_size,
	struct cdk2_ahci_command *command);
EFI_STATUS cdk2_ahci_execute(struct cdk2_ahci_engine *engine, UINT16 port,
	UINT16 multiplier, struct cdk2_ata_command_packet *packet,
	const UINT8 *atapi, size_t atapi_size,
	UINT64 timeout);
EFI_STATUS cdk2_ahci_capture_status(struct cdk2_ahci_engine *engine,
	UINT16 port, UINT16 multiplier, struct cdk2_ata_status_block *asb);

#define CDK2_IDE_MAX_PRD 64U
struct cdk2_ide_channel { UINT16 command, control, bus_master; };
struct cdk2_ide_prd { UINT32 address; UINT16 count, end; };
struct cdk2_ide_services {
	void *context;
	UINT8 (*read8)(void *context, UINT16 port);
	UINT16 (*read16)(void *context, UINT16 port);
	EFI_STATUS (*write8)(void *context, UINT16 port, UINT8 value);
	EFI_STATUS (*write16)(void *context, UINT16 port, UINT16 value);
	EFI_STATUS (*write32)(void *context, UINT16 port, UINT32 value);
	EFI_STATUS (*map)(void *context, enum cdk2_ahci_dma_operation operation,
		void *host, size_t *size, UINT64 *device, void **mapping);
	EFI_STATUS (*unmap)(void *context, void *mapping);
	EFI_STATUS (*flush)(void *context);
	EFI_STATUS (*set_timing)(void *context, UINT8 channel, UINT8 device);
	UINT64 (*time)(void *context);
	void (*delay)(void *context, UINTN microseconds);
};
struct cdk2_ide_engine {
	struct cdk2_ide_services services;
	struct cdk2_ide_channel channels[2];
	struct cdk2_ide_prd prd[CDK2_IDE_MAX_PRD];
	UINT8 channel_count, initialized, bus_master_supported;
};
enum cdk2_ide_async_phase {
	CDK2_IDE_ASYNC_MAP, CDK2_IDE_ASYNC_BUILD_PRD, CDK2_IDE_ASYNC_MAP_PRD,
	CDK2_IDE_ASYNC_FLUSH, CDK2_IDE_ASYNC_WRITE_PRDT,
	CDK2_IDE_ASYNC_CLEAR_STATUS, CDK2_IDE_ASYNC_READY,
	CDK2_IDE_ASYNC_TIMING, CDK2_IDE_ASYNC_SELECTED_READY,
	CDK2_IDE_ASYNC_TASKFILE,
	CDK2_IDE_ASYNC_BM_START, CDK2_IDE_ASYNC_POLL,
	CDK2_IDE_ASYNC_PIO_WAIT, CDK2_IDE_ASYNC_PIO_TRANSFER,
	CDK2_IDE_ASYNC_ATAPI_CDB_WAIT, CDK2_IDE_ASYNC_ATAPI_CDB,
	CDK2_IDE_ASYNC_ATAPI_DATA_WAIT, CDK2_IDE_ASYNC_ATAPI_DATA,
	CDK2_IDE_ASYNC_COMMAND_WAIT, CDK2_IDE_ASYNC_RESET_ASSERT,
	CDK2_IDE_ASYNC_RESET_DEASSERT, CDK2_IDE_ASYNC_RESET_WAIT,
	CDK2_IDE_ASYNC_STOP, CDK2_IDE_ASYNC_UNMAP_PRD,
	CDK2_IDE_ASYNC_UNMAP_DATA, CDK2_IDE_ASYNC_FINAL_FLUSH,
	CDK2_IDE_ASYNC_DONE
};
struct cdk2_ide_async_request {
	struct cdk2_ide_engine *engine;
	struct cdk2_ata_command_packet *packet;
	struct cdk2_ata_command_block owned_acb;
	const struct cdk2_ata_command_block *acb;
	void *mappings[CDK2_IDE_MAX_PRD], *prd_mapping;
	UINT8 *buffer, cdb[16];
	UINT64 mapped_device, deadline, timeout, reset_deadline, reset_timeout;
	size_t remaining, mapped_remaining, total, transferred;
	size_t phase_remaining, phase_transfer;
	UINT16 mapping_count, entries;
	UINT8 channel, device, task_index, bm_command, started, issued, cleaned, dma, write;
	UINT8 atapi, cdb_size, cdb_index, phase_read, status_captured;
	EFI_STATUS terminal_status;
	enum cdk2_ide_async_phase phase;
};

EFI_STATUS cdk2_ide_async_prepare(struct cdk2_ide_async_request *request,
	struct cdk2_ide_engine *engine, UINT8 channel, UINT8 device,
	struct cdk2_ata_command_packet *packet, UINT64 timeout);
EFI_STATUS cdk2_ide_atapi_async_prepare(struct cdk2_ide_async_request *request,
	struct cdk2_ide_engine *engine, UINT8 channel, UINT8 device,
	struct cdk2_ata_command_packet *packet, const UINT8 *cdb, size_t cdb_size,
	UINT64 timeout);
EFI_STATUS cdk2_ide_async_step(struct cdk2_ide_async_request *request,
	BOOLEAN *complete);
EFI_STATUS cdk2_ide_async_abort(struct cdk2_ide_async_request *request,
	BOOLEAN *complete);

EFI_STATUS cdk2_ide_engine_init(struct cdk2_ide_engine *engine,
	const struct cdk2_ide_services *services, const struct cdk2_ide_channel *channels,
	UINT8 channel_count);
EFI_STATUS cdk2_ide_reset(struct cdk2_ide_engine *engine, UINT8 channel,
	UINT64 timeout);
EFI_STATUS cdk2_ide_capture_status(struct cdk2_ide_engine *engine,
	UINT8 channel, UINT8 device, struct cdk2_ata_status_block *asb);
EFI_STATUS cdk2_ide_execute(struct cdk2_ide_engine *engine, UINT8 channel,
	UINT8 device, struct cdk2_ata_command_packet *packet, UINT64 timeout);
EFI_STATUS cdk2_ide_atapi_execute(struct cdk2_ide_engine *engine, UINT8 channel,
	UINT8 device, struct cdk2_ata_command_packet *packet, const UINT8 *cdb,
	size_t cdb_size, UINT64 timeout);

#endif
