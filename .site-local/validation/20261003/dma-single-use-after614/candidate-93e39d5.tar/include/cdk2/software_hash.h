/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SOFTWARE_HASH_H
#define CDK2_SOFTWARE_HASH_H
#include <stdint.h>
#include <cdk2/tcg2_measure.h>
#include <industry_standard/tpm20.h>
struct cdk2_software_hash {
	TPMI_ALG_HASH algorithm;
	UINT64 bytes;
	UINT64 context[48];
};
EFI_STATUS cdk2_software_hash_init(struct cdk2_software_hash *hash, TPMI_ALG_HASH algorithm);
EFI_STATUS cdk2_software_hash_update(struct cdk2_software_hash *hash,
				     const void *data, UINTN size);
EFI_STATUS cdk2_software_hash_final(struct cdk2_software_hash *hash,
				    uint8_t *digest, uint16_t size);
EFI_STATUS cdk2_software_hash_spans(void *context, TPMI_ALG_HASH algorithm,
				    const struct cdk2_tcg2_span *spans, uint32_t count,
				    uint8_t *digest, uint16_t size);
#endif
