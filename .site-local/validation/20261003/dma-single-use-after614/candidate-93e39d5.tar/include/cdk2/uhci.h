/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_UHCI_H
#define CDK2_UHCI_H

#include <uefi.h>

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
typedef EFI_STATUS CDK2_MS_ABI cdk2_uhci_diagnostic_write_fn(
	void *, UINTN *, void *);
extern void *cdk2_uhci_diagnostic_context;
extern cdk2_uhci_diagnostic_write_fn *cdk2_uhci_diagnostic_write;
#define CDK2_UHCI_DIAG_SET(context, write) do { \
	cdk2_uhci_diagnostic_context = (context); \
	cdk2_uhci_diagnostic_write = (write); \
} while (0)
void cdk2_uhci_diagnostic(const char *message, UINTN length);
#define CDK2_UHCI_DIAG(message) \
	cdk2_uhci_diagnostic((message), sizeof(message) - 1U)
#ifdef CDK2_DIAGNOSTIC
#define cdk2_uhci_diagnostic_ready() TRUE
#else
#define cdk2_uhci_diagnostic_ready() (cdk2_uhci_diagnostic_write != NULL)
#endif
#else
#define CDK2_UHCI_DIAG(message) do { } while (0)
#define cdk2_uhci_diagnostic_ready() FALSE
#endif
#include <cdk2/pci_io_abi.h>
#include <cdk2/xhci.h>

#define CDK2_UHCI_FRAME_COUNT 1024U
#define CDK2_UHCI_MAX_PORTS 15U
#define CDK2_UHCI_TERMINATE 1U
#define CDK2_UHCI_LINK_QH 2U

struct cdk2_uhci_td {
	UINT32 link, status, token, buffer;
} __packed;

struct cdk2_uhci_qh {
	UINT32 horizontal, element;
} __packed;

struct cdk2_uhci_dma {
	void *host, *token;
	UINT32 device;
	UINTN bytes;
};

typedef EFI_STATUS cdk2_uhci_read16_fn(void *, UINT16, UINT16 *);
typedef EFI_STATUS cdk2_uhci_write16_fn(void *, UINT16, UINT16);
typedef EFI_STATUS cdk2_uhci_write32_fn(void *, UINT16, UINT32);
typedef void cdk2_uhci_delay_fn(void *, UINTN);
typedef EFI_STATUS cdk2_uhci_dma_alloc_fn(void *, UINTN, UINTN,
	struct cdk2_uhci_dma *);
typedef void cdk2_uhci_dma_free_fn(void *, struct cdk2_uhci_dma *);
typedef EFI_STATUS cdk2_uhci_dma_map_fn(void *, void *, UINTN, BOOLEAN,
	struct cdk2_uhci_dma *);
typedef void cdk2_uhci_dma_unmap_fn(void *, struct cdk2_uhci_dma *);
typedef EFI_STATUS cdk2_uhci_flush_fn(void *);
typedef UINTN cdk2_uhci_lock_fn(void *);
typedef void cdk2_uhci_unlock_fn(void *, UINTN);

struct cdk2_uhci_services {
	void *context;
	cdk2_uhci_read16_fn *read16;
	cdk2_uhci_write16_fn *write16;
	cdk2_uhci_write32_fn *write32;
	cdk2_uhci_delay_fn *delay;
	cdk2_uhci_dma_alloc_fn *allocate;
	cdk2_uhci_dma_free_fn *release;
	cdk2_uhci_dma_map_fn *map;
	cdk2_uhci_dma_unmap_fn *unmap;
	cdk2_uhci_flush_fn *flush;
	void *lock_context;
	cdk2_uhci_lock_fn *lock;
	cdk2_uhci_unlock_fn *unlock;
};

struct cdk2_uhci_controller {
	struct cdk2_uhci_services services;
	UINT32 *frames;
	UINT32 saved_frames[CDK2_UHCI_FRAME_COUNT];
	UINT32 frame_device;
	UINT8 ports;
	UINTN state;
	UINTN last_transfer_elapsed;
	BOOLEAN running;
};

struct cdk2_uhci_transfer {
	struct cdk2_uhci_dma descriptors, data;
	struct cdk2_uhci_qh *qh;
	struct cdk2_uhci_td *tds;
	UINT16 count;
	UINT16 data_first, data_count;
	UINT8 toggle;
	void *caller;
	UINTN caller_bytes;
	BOOLEAN bounce_in;
};

struct cdk2_uhci_usb2 {
	struct cdk2_usb2_hc_protocol protocol;
	struct cdk2_uhci_controller *controller;
	struct {
		struct cdk2_uhci_transfer transfer;
		struct cdk2_uhci_dma buffer;
		cdk2_usb2_async_callback_fn *callback;
		void *context;
		UINTN interval, length;
		UINT64 generation;
		UINT8 address, endpoint, toggle;
		BOOLEAN active;
	} async[8];
	UINT64 next_generation;
};

#define CDK2_UHCI_PCI_ALLOCATIONS 32U
struct cdk2_uhci_pci_record {
	void *host, *mapping;
	UINTN pages;
};
struct cdk2_uhci_pci_adapter {
	struct cdk2_efi_pci_io_protocol *pci;
	struct cdk2_uhci_pci_record records[CDK2_UHCI_PCI_ALLOCATIONS];
	void *delay_context;
	cdk2_uhci_delay_fn *delay;
	UINT64 original_attributes;
	UINT8 bar;
	BOOLEAN attributes_owned;
};

EFI_STATUS cdk2_uhci_validate_class(UINT8 base, UINT8 subclass, UINT8 interface);
UINTN cdk2_uhci_poll_rate(UINTN interval);
EFI_STATUS cdk2_uhci_build_td(struct cdk2_uhci_td *td, UINT32 next,
	UINT32 buffer, UINT8 pid, UINT8 address, UINT8 endpoint, UINT8 toggle,
	UINT16 length, BOOLEAN low_speed, BOOLEAN interrupt);
EFI_STATUS cdk2_uhci_initialize(struct cdk2_uhci_controller *controller,
	const struct cdk2_uhci_services *services, UINT32 *frames,
	UINT32 frame_device);
EFI_STATUS cdk2_uhci_stop(struct cdk2_uhci_controller *controller);
EFI_STATUS cdk2_uhci_set_state(struct cdk2_uhci_controller *controller,
	UINTN state);
EFI_STATUS cdk2_uhci_get_port(struct cdk2_uhci_controller *controller,
	UINT8 port, struct cdk2_usb_port_status *status);
EFI_STATUS cdk2_uhci_port_feature(struct cdk2_uhci_controller *controller,
	UINT8 port, UINTN feature, BOOLEAN set);
EFI_STATUS cdk2_uhci_transfer_prepare(struct cdk2_uhci_controller *controller,
	struct cdk2_uhci_transfer *transfer, UINT8 address, UINT8 endpoint,
	UINT8 pid, UINT8 toggle, UINT16 maximum_packet, void *buffer,
	UINTN length, BOOLEAN low_speed);
EFI_STATUS cdk2_uhci_control_prepare(struct cdk2_uhci_controller *controller,
	struct cdk2_uhci_transfer *transfer, UINT8 address, UINT8 speed,
	UINT16 maximum_packet, const struct cdk2_usb_request *request,
	UINTN direction, void *buffer, UINTN length);
EFI_STATUS cdk2_uhci_transfer_execute(struct cdk2_uhci_controller *controller,
	struct cdk2_uhci_transfer *transfer, UINTN timeout, UINTN *actual,
	UINT8 *toggle, UINT32 *result);
void cdk2_uhci_transfer_release(struct cdk2_uhci_controller *controller,
	struct cdk2_uhci_transfer *transfer);
EFI_STATUS cdk2_uhci_usb2_init(struct cdk2_uhci_usb2 *usb2,
	struct cdk2_uhci_controller *controller);
void cdk2_uhci_usb2_poll(struct cdk2_uhci_usb2 *usb2);
EFI_STATUS cdk2_uhci_usb2_release(struct cdk2_uhci_usb2 *usb2);
EFI_STATUS cdk2_uhci_pci_adapter_init(struct cdk2_uhci_pci_adapter *adapter,
	struct cdk2_efi_pci_io_protocol *pci, void *delay_context,
	cdk2_uhci_delay_fn *delay);
void cdk2_uhci_pci_services(struct cdk2_uhci_pci_adapter *adapter,
	struct cdk2_uhci_services *services);
EFI_STATUS cdk2_uhci_pci_adapter_release(struct cdk2_uhci_pci_adapter *adapter);

#endif
