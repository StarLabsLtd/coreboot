/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_H
#define CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_H

#include <coreboot_tables.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

struct cdk2_coreboot_handoff;

#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_REVISION 1U
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_MESSAGE_SIZE 64U
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_PENDING MAX_UINT32
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPLETE 0U
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_PENDING MAX_UINT64
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_ERROR_BIT (1ULL << 63)
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_SUCCESS 0ULL
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_INVALID_PARAMETER \
	(CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_ERROR_BIT | 2ULL)
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_UNSUPPORTED \
	(CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_ERROR_BIT | 3ULL)
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_DEVICE_ERROR \
	(CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_ERROR_BIT | 7ULL)
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_ACCESS_DENIED \
	(CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_ERROR_BIT | 15ULL)
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_SECURITY_VIOLATION \
	(CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_STATUS_ERROR_BIT | 26ULL)
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_WIRE_SENTINEL \
	0xfffffffffffffffeULL
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_WIRE_SUCCESS \
	0x434c4f5345414bfeULL

struct cdk2_authvar_presence_lifecycle_close_message {
	UINT32 revision;
	UINT32 size;
	UINT32 source;
	UINT32 flags;
	UINT64 generation;
	UINT64 request_id;
	UINT64 status;
	UINT32 reserved[5];
	UINT32 completion;
} __aligned(8);

struct cdk2_authvar_presence_lifecycle_close_endpoint {
	struct cb_authvar_presence_lifecycle_close_endpoint descriptor;
	UINT64 generation;
	EFI_PHYSICAL_ADDRESS communication_base;
	BOOLEAN available;
};

_Static_assert(sizeof(struct cdk2_authvar_presence_lifecycle_close_message) ==
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_MESSAGE_SIZE,
	"authenticated-variable presence lifecycle-close message ABI");
_Static_assert(_Alignof(struct cdk2_authvar_presence_lifecycle_close_message) == 8U,
	"authenticated-variable presence lifecycle-close message alignment");
_Static_assert(OFFSET_OF(struct cdk2_authvar_presence_lifecycle_close_message,
	generation) == 16U &&
	OFFSET_OF(struct cdk2_authvar_presence_lifecycle_close_message,
	request_id) == 24U &&
	OFFSET_OF(struct cdk2_authvar_presence_lifecycle_close_message,
	status) == 32U &&
	OFFSET_OF(struct cdk2_authvar_presence_lifecycle_close_message,
	completion) == 60U,
	"authenticated-variable presence lifecycle-close message layout");

EFI_STATUS cdk2_authvar_presence_lifecycle_close_endpoint_validate(
	const struct cb_authvar_presence_lifecycle_close_endpoint *endpoint);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_endpoint_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_authvar_presence_lifecycle_close_endpoint *endpoint);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_request_validate(
	const struct cb_authvar_presence_lifecycle_close_endpoint *endpoint,
	const void *message, UINTN message_size);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_response_validate(
	const struct cb_authvar_presence_lifecycle_close_endpoint *endpoint,
	const void *request, const void *response, UINTN message_size);

#endif
