/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_DIAGNOSTIC_H
#define CDK2_DIAGNOSTIC_H

#include <cdk2/config.h>
#include <cdk2/linear_boot.h>
#include <cdk2/uart.h>
#include <uefi.h>

#include <stddef.h>
#include <stdint.h>

enum cdk2_diag_level {
	CDK2_DIAG_DEBUG,
	CDK2_DIAG_INFO,
	CDK2_DIAG_WARN,
	CDK2_DIAG_ERROR,
};

enum cdk2_diag_module {
	CDK2_DIAG_NATIVE = 1,
	CDK2_DIAG_DXE_MAIN = 2,
	CDK2_DIAG_DXE_DISPATCH = 3,
	CDK2_DIAG_BDS = 4,
	/* Reserve module IDs once so independently reviewable parity topics keep
	 * the same wire format regardless of their eventual merge order. */
	CDK2_DIAG_TCG2 = 5,
	CDK2_DIAG_TERMINAL = 7,
	CDK2_DIAG_SDMMC = 8,
	CDK2_DIAG_EC_BATTERY = 9,
	CDK2_DIAG_ACPI_TABLE = 10,
	CDK2_DIAG_FTW = 11,
	CDK2_DIAG_PI_SMM_CPU = 12,
	CDK2_DIAG_PI_SMM_IPL = 13,
	CDK2_DIAG_PI_SMM_CORE = 14,
	CDK2_DIAG_SHELL = 15,
	CDK2_DIAG_EHCI = 16,
	CDK2_DIAG_USB_BUS = 17,
	CDK2_DIAG_EMMC = 18,
	CDK2_DIAG_ATA_ATAPI = 19,
	CDK2_DIAG_PCI_BUS = 20,
	CDK2_DIAG_PARTITION = 21,
	CDK2_DIAG_USB_MASS = 22,
	CDK2_DIAG_PCI_HOST = 23,
	CDK2_DIAG_SCSI_DISK = 24,
	CDK2_DIAG_SMBIOS = 25,
	CDK2_DIAG_FAT = 26,
	CDK2_DIAG_ATA_BUS = 27,
	CDK2_DIAG_BL_SUPPORT_SMM = 28,
	CDK2_DIAG_SATA_CONTROLLER = 29,
	CDK2_DIAG_NVME = 30,
	CDK2_DIAG_XHCI = 31,
	CDK2_DIAG_UHCI = 32,
	CDK2_DIAG_SD_DXE = 33,
	CDK2_DIAG_VARIABLE_RUNTIME = 34,
	CDK2_DIAG_GRAPHICS_OUTPUT = 35,
	CDK2_DIAG_CPU_ARCH = 36,
	CDK2_DIAG_RESET_SYSTEM = 37,
	CDK2_DIAG_GRAPHICS_CONSOLE = 38,
	CDK2_DIAG_SMMSTORE = 39,
};

enum cdk2_diag_event {
	CDK2_EVENT_NATIVE_ENTRY = 0x1000,
	CDK2_EVENT_NATIVE_CONTEXT_READY,
	/* 0x1002 was the removed native module-table failure event. */
	CDK2_EVENT_NATIVE_DXE_HANDOFF = 0x1003,
	CDK2_EVENT_DXE_ENTRY = 0x1100,
	CDK2_EVENT_DXE_CORE_READY,
	CDK2_EVENT_DXE_FV_FOUND,
	CDK2_EVENT_DXE_FV_INVALID,
	CDK2_EVENT_DXE_DISPATCH_BEGIN = 0x1200,
	CDK2_EVENT_DXE_DRIVER_START,
	CDK2_EVENT_DXE_DRIVER_FAILED,
	CDK2_EVENT_DXE_DISPATCH_END,
	CDK2_EVENT_BDS_DRIVER_ENTRY = 0x1300,
	CDK2_EVENT_BDS_PROTOCOL_READY,
	CDK2_EVENT_BDS_BOOT_BEGIN,
	CDK2_EVENT_BDS_BOOTNEXT_FAILED,
	CDK2_EVENT_BDS_BOOTORDER_FAILED,
	CDK2_EVENT_BDS_REMOVABLE_FAILED,
	CDK2_EVENT_BDS_SHELL_FAILED,
	CDK2_EVENT_BDS_FW_UI_RESULT,
	CDK2_EVENT_BDS_SETUP_WAIT_BEGIN,
	CDK2_EVENT_BDS_SETUP_WAIT_RESULT,
	/* 0x130a was the removed setup-package publication event. */
	CDK2_EVENT_BDS_OS_INDICATIONS_RESULT = 0x130b,
	CDK2_EVENT_BDS_WATCHDOG_RESULT,
	CDK2_EVENT_BDS_ANTI_TAMPER_BEGIN,
	CDK2_EVENT_BDS_ANTI_TAMPER_RESULT,
	CDK2_EVENT_BDS_DEFERRED_CAPSULE_BEGIN,
	CDK2_EVENT_BDS_DEFERRED_CAPSULE_RESULT,
	CDK2_EVENT_BDS_CONNECT_ALL_BEGIN,
	CDK2_EVENT_BDS_CONNECT_ALL_END,
	CDK2_EVENT_BDS_SIMPLE_FS_HANDLES,
	CDK2_EVENT_BDS_DISK_CAPSULE_BEGIN,
	CDK2_EVENT_BDS_DISK_CAPSULE_RESULT,
	CDK2_EVENT_BDS_DRIVER_ORDER_BEGIN,
	CDK2_EVENT_BDS_DRIVER_ORDER_END,
	CDK2_EVENT_BDS_BLOCK_IO_HANDLES,
	CDK2_EVENT_BDS_DISK_IO_HANDLES,
	CDK2_EVENT_BDS_PCI_IO_HANDLES,
	CDK2_EVENT_BDS_MENU_RETURN,
	CDK2_EVENT_BDS_REMOVABLE_RETURN,
	CDK2_EVENT_BDS_FIXED_FALLBACK_RESULT,
	CDK2_EVENT_BDS_FIXED_RETURN,
	CDK2_EVENT_BDS_FINAL_RETURN,
	CDK2_EVENT_BDS_BOOT_PASS_RETURN,
	/* Optional USB discovery has its own deadline; keep menu timeout separate. */
	CDK2_EVENT_BDS_USB_SCAN_BEGIN = 0x1330,
	CDK2_EVENT_BDS_USB_SCAN_TIMEOUT,
	CDK2_EVENT_BDS_USB_SCAN_END,
	CDK2_EVENT_ATA_ATAPI_ENTRY = 0x1400,
	CDK2_EVENT_ATA_ATAPI_PUBLISH_FAILED,
	CDK2_EVENT_ATA_ATAPI_READY,
	/* All admitted PCI requesters passed BME clear/readback and arena scrub. */
	CDK2_EVENT_PCI_DMA_QUIESCE = 0x1450,
	/* Two stable CBMEM IDs per linear phase: begin, then completion. */
	CDK2_EVENT_LINEAR_PHASE_BASE = 0x1600,
};

/* These IDs are part of the CBMEM timestamp ABI. Do not derive them from
 * enum cdk2_linear_phase_id: execution order may change independently. */
static inline uint32_t
cdk2_diag_linear_phase_begin_event(enum cdk2_linear_phase_id phase)
{
	switch (phase) {
	case CDK2_LINEAR_HANDOFF_VALIDATE: return 0x1600U;
	case CDK2_LINEAR_SPLASH_EARLY: return 0x1602U;
	case CDK2_LINEAR_DXE_SERVICES: return 0x1604U;
	case CDK2_LINEAR_ARCH_PROTOCOLS: return 0x1606U;
	case CDK2_LINEAR_VARIABLES_MIN: return 0x1608U;
	case CDK2_LINEAR_CAPSULE_DECIDE: return 0x160aU;
	case CDK2_LINEAR_CAPSULE_RAM: return 0x160cU;
	case CDK2_LINEAR_PLATFORM_TABLES: return 0x160eU;
	case CDK2_LINEAR_PCI_ROOTS: return 0x1610U;
	case CDK2_LINEAR_PCI_ENUMERATE: return 0x1612U;
	case CDK2_LINEAR_STORAGE_CONTROLLERS: return 0x1614U;
	case CDK2_LINEAR_BLOCK_DISCOVERY: return 0x1616U;
	case CDK2_LINEAR_FILESYSTEMS: return 0x1618U;
	case CDK2_LINEAR_CAPSULE_DISK: return 0x161aU;
	case CDK2_LINEAR_DISPLAY_ADOPT: return 0x161cU;
	case CDK2_LINEAR_INPUT_UI: return 0x161eU;
	case CDK2_LINEAR_BOOT_POLICY: return 0x1622U;
	case CDK2_LINEAR_OS_HANDOFF: return 0x1624U;
	default: return CDK2_EVENT_LINEAR_PHASE_BASE;
	}
}

#define CDK2_EVENT_LINEAR_PHASE_BEGIN(phase) \
	cdk2_diag_linear_phase_begin_event(phase)
#define CDK2_EVENT_LINEAR_PHASE_END(phase) \
	(CDK2_EVENT_LINEAR_PHASE_BEGIN(phase) + 1U)

/* Persisted in the final TIME slot when the table cannot accept another
 * record.  Consumers must treat this as loss of one or more later events. */
#define CDK2_EVENT_TIME_OVERFLOW 0x16feU

/* Optional expensive-operation boundaries.  These IDs are stable wire values;
 * callers must omit them when the TIME table has no room after core phases. */
enum cdk2_linear_subphase_event {
	CDK2_EVENT_SUBPHASE_USB_SCAN_BEGIN = 0x164a,
	CDK2_EVENT_SUBPHASE_USB_SCAN_END,
};

/* Stable, allocation-free DxeCore parity ranges. Existing 0x1100/0x1200
 * events remain published wire identifiers and are not renumbered. */
enum cdk2_dxe_diag_range {
	CDK2_DXE_DIAG_SECTION_BASE = 0x1800,
	CDK2_DXE_DIAG_IMAGE_BASE = 0x1820,
	CDK2_DXE_DIAG_MEMORY_PROTECTION_BASE = 0x1840,
	CDK2_DXE_DIAG_MEMORY_ATTRIBUTES_BASE = 0x1860,
	CDK2_DXE_DIAG_MISC_BASE = 0x1880,
	CDK2_DXE_DIAG_HANDLE_DATABASE_BASE = 0x18a0,
	CDK2_DXE_DIAG_GCD_BASE = 0x1900,
	CDK2_DXE_DIAG_MEMORY_BASE = 0x1960,
	CDK2_DXE_DIAG_FIRMWARE_VOLUME_BASE = 0x19a0,
	CDK2_DXE_DIAG_EVENT_TPL_BASE = 0x19c0,
	CDK2_DXE_DIAG_DEPENDENCY_BASE = 0x1a00,
	CDK2_DXE_DIAG_DISPATCHER_BASE = 0x1a40,
	CDK2_DXE_DIAG_MAIN_BASE = 0x1a60,
};

struct cdk2_diag_timestamp_entry {
	UINT32 entry_id;
	INT64 entry_stamp;
} __packed;

struct cdk2_diag_timestamp_table {
	UINT64 base_time;
	UINT16 max_entries;
	UINT16 tick_freq_mhz;
	UINT32 num_entries;
	struct cdk2_diag_timestamp_entry entries[];
} __packed;

/* The on-wire coreboot CBMEM console layout.  Bits 31-28 of cursor are
 * flags; bit 31 records that the body has wrapped at least once. */
#define CDK2_CBMEM_CONSOLE_MAX_SIZE 0x10000000U
#define CDK2_CBMEM_CONSOLE_CURSOR_MASK (CDK2_CBMEM_CONSOLE_MAX_SIZE - 1U)
#define CDK2_CBMEM_CONSOLE_OVERFLOW 0x80000000U

struct cdk2_cbmem_console {
	UINT32 size;
	UINT32 cursor;
	UINT8 body[];
};

/* CDK2 appends only after coreboot has handed normal execution to the
 * payload.  The emission lock is local to one linked CDK2 image; it cannot
 * coordinate coreboot, SMM, or another image.  Those contexts must not append
 * to the same console while that image owns payload execution. */

typedef void cdk2_diag_putc_fn(char character, void *context);
typedef uint64_t cdk2_diag_clock_fn(void *context);
typedef uint64_t cdk2_diag_owner_fn(void *context);

enum cdk2_diag_sink_provenance {
	CDK2_DIAG_SINK_CUSTOM = 0,
	CDK2_DIAG_SINK_SERIAL,
};

struct cdk2_diag_config {
	cdk2_diag_putc_fn *putc;
	void *putc_context;
	enum cdk2_diag_sink_provenance putc_provenance;
	struct cdk2_cbmem_console *cbmem_console;
	size_t cbmem_console_bytes;
	void *spi_console_buffer;
	size_t spi_console_buffer_bytes;
	uint32_t spi_console_max_chunk;
	uint32_t spi_console_boot_limit;
	uint8_t spi_console_apm_cmd;
	volatile uint32_t *spi_console_remaining;
	struct cdk2_diag_timestamp_table *timestamps;
	size_t timestamp_bytes;
	cdk2_diag_clock_fn *clock;
	void *clock_context;
	uint64_t clock_hz;
	/* A stable, nonzero token for the current execution context.  CDK2 uses
	 * it only to distinguish recursion from another CDK2 writer. */
	cdk2_diag_owner_fn *owner;
	void *owner_context;
	volatile UINT64 *emission_owner;
};

#define CDK2_DIAG_HANDOFF_REVISION 5U
#define CDK2_DIAG_SERIAL_NONE CDK2_UART_NONE
#define CDK2_DIAG_SERIAL_PIO CDK2_UART_PIO
#define CDK2_DIAG_SERIAL_MMIO CDK2_UART_MMIO

/* Shared handoff: loaded images construct local callbacks while coordinating
 * record emission through emission_owner in the writable HOB payload. */
struct cdk2_diag_handoff {
	UINT16 revision;
	UINT16 length;
	UINT8 serial_type;
	UINT8 register_width;
	UINT16 register_stride;
	UINT64 register_base;
	UINT32 baud_rate;
	UINT32 input_hertz;
	UINT64 timestamp_base;
	UINT64 cbmem_console_base;
	UINT32 timestamp_bytes;
	UINT32 cbmem_console_bytes;
	UINT64 spi_console_buffer;
	UINT32 spi_console_buffer_bytes;
	UINT32 spi_console_max_chunk;
	UINT32 spi_console_boot_limit;
	UINT8 spi_console_apm_cmd;
	UINT8 spi_console_reserved[3];
	UINT32 reserved;
	volatile UINT32 spi_console_remaining;
	volatile UINT64 emission_owner;
} __packed;

extern const EFI_GUID cdk2_diag_handoff_guid;

void cdk2_diag_configure(const struct cdk2_diag_config *config);
void cdk2_diag_runtime_transition(void);
EFI_STATUS cdk2_diag_configure_hob(void *hob_list);
EFI_STATUS cdk2_diag_configure_system_table(void *system_table);
#if CONFIG_CDK2_DIAGNOSTIC
#define CDK2_DIAG_CONFIGURE_OPTIONAL_SYSTEM_TABLE(system_table) \
	((void)cdk2_diag_configure_system_table(system_table))
#else
#define CDK2_DIAG_CONFIGURE_OPTIONAL_SYSTEM_TABLE(system_table) ((void)0)
#endif
#if defined(CDK2_DIAG_UNIT_TEST)
void cdk2_diag_test_spi_status(UINT32 status);
EFI_STATUS cdk2_diag_test_cbmem_validate(
	const struct cdk2_cbmem_console *console, UINTN total_bytes);
UINTN cdk2_diag_test_cbmem_write(struct cdk2_cbmem_console *console,
	UINTN total_bytes, const void *buffer, UINTN count);
void cdk2_diag_test_set_putc(cdk2_diag_putc_fn putc, void *context);
BOOLEAN cdk2_diag_test_direct_serial_allowed(BOOLEAN debug,
	BOOLEAN cbmem_configured);
UINT64 cdk2_diag_test_x86_owner_token(UINT32 topology_ebx,
	UINT32 topology_ecx, UINT32 topology_edx, BOOLEAN amd_extended,
	UINT32 amd_eax, UINT32 legacy_ebx);
BOOLEAN cdk2_diag_test_acquire_owner(volatile UINT64 *shared_owner, UINT64 owner);
void cdk2_diag_test_release_owner(volatile UINT64 *shared_owner, UINT64 owner);
void cdk2_diag_test_set_release_hook(void (*hook)(void *context), void *context);
#endif
void cdk2_diag_emit(enum cdk2_diag_level level, enum cdk2_diag_module module,
	uint32_t event, EFI_STATUS status);
/* Emit a console record without treating it as a timing boundary. */
void cdk2_diag_emit_console(enum cdk2_diag_level level,
	enum cdk2_diag_module module, uint32_t event, EFI_STATUS status);
void cdk2_diag_emit_compact(enum cdk2_diag_module module, uint32_t event,
	EFI_STATUS status);
void cdk2_diag_message(enum cdk2_diag_module module, const char *message);
void cdk2_diag_message_status(enum cdk2_diag_module module,
	const char *message, EFI_STATUS status);
void cdk2_diag_value(enum cdk2_diag_module module, const char *label,
	uint64_t value);
void cdk2_diag_bytes(enum cdk2_diag_module module, const char *label,
	const void *bytes, size_t count);
/* Read the active diagnostic clock for bounded optional-device work. */
uint64_t cdk2_diag_now(void);
void cdk2_diag_phase(const char *phase, const char *operation,
	EFI_STATUS status, uint64_t elapsed_ticks);
void cdk2_diag_phase_event(uint32_t event, const char *phase,
	const char *operation, EFI_STATUS status, uint64_t elapsed_ticks);
void cdk2_diag_phase_event_at(uint32_t event, uint64_t event_ticks,
	const char *phase, const char *operation, EFI_STATUS status,
	uint64_t elapsed_ticks);
/* Optional timing pair: omitted when fewer than two slots remain after the
 * mandatory linear-phase budget, preserving core timing visibility. */
BOOLEAN cdk2_diag_optional_phase_pair_at(uint32_t begin_event, uint32_t end_event,
	uint64_t begin_ticks, uint64_t end_ticks, const char *phase,
	uint64_t elapsed_ticks, EFI_STATUS status);

/*
 * DXE modules cannot assume that the console or allocator is available while
 * reporting their earliest failures.  The debug profile therefore retains a
 * tiny, allocation-free literal transport matching the native entry path.
 */
#if defined(CDK2_DEBUG) || CONFIG_CDK2_DIAGNOSTIC
static inline void cdk2_diag_literal(const char *message)
{
	cdk2_diag_message(CDK2_DIAG_NATIVE, message);
}
#define CDK2_DIAG_LITERAL(message) cdk2_diag_literal(message)
#else
#define CDK2_DIAG_LITERAL(message) do { } while (0)
#endif

#endif
