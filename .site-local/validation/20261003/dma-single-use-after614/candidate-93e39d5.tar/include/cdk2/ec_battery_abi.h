/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_EC_BATTERY_ABI_H
#define CDK2_EC_BATTERY_ABI_H

#include <uefi.h>

typedef EFI_STATUS CDK2_MS_ABI cdk2_battery_info_fn(UINT8 *, BOOLEAN *,
	BOOLEAN *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_battery_critical_fn(BOOLEAN *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_battery_refresh_fn(void);

struct cdk2_battery_protocol {
	cdk2_battery_info_fn *get_info;
	cdk2_battery_critical_fn *get_critical;
	cdk2_battery_refresh_fn *refresh;
};

static const EFI_GUID cdk2_battery_protocol_guid = {
	0x8a3b2c1d, 0x4e5f, 0x6a7b,
	{ 0x8c, 0x9d, 0x0e, 0x1f, 0x2a, 0x3b, 0x4c, 0x5d }
};

#endif
