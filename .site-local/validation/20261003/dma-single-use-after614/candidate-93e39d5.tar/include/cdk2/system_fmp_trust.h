/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_TRUST_H
#define CDK2_SYSTEM_FMP_TRUST_H

#include <stdint.h>
#include <uefi.h>

#define CDK2_SYSTEM_FMP_STARLABS_CERTIFICATES_SIZE 1442U

extern const uint8_t cdk2_system_fmp_starlabs_certificates[
	CDK2_SYSTEM_FMP_STARLABS_CERTIFICATES_SIZE];

#endif
