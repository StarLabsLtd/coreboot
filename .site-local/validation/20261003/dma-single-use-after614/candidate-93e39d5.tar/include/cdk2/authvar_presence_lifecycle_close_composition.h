/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION_H
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_COMPOSITION_H

#include <uefi.h>

#include <cdk2/authvar_presence_lifecycle_close_boundary.h>

struct cdk2_dxe_core;
struct cdk2_dxe_runtime_services;

EFI_STATUS cdk2_authvar_presence_lifecycle_close_composition_initialize(
	void *hob_list, struct cdk2_dxe_core *core,
	struct cdk2_dxe_runtime_services *runtime);
EFI_STATUS
cdk2_authvar_presence_lifecycle_close_composition_retire_local_authority(void);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_composition_claim(
	const struct cdk2_authvar_presence_external_image_identity *identity);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_composition_pre_external(
	const struct cdk2_authvar_presence_external_image_identity *identity,
	BOOLEAN *applied);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_composition_payload_return(
	const struct cdk2_authvar_presence_external_image_identity *identity);
EFI_STATUS
cdk2_authvar_presence_lifecycle_close_composition_successful_ebs_reproof(
	const struct cdk2_authvar_presence_external_image_identity *identity);

#ifdef CDK2_HOST_TEST
void cdk2_authvar_presence_lifecycle_close_composition_test_reset(void);
EFI_STATUS cdk2_authvar_presence_lifecycle_close_composition_test_port(
	const struct cdk2_authvar_presence_lifecycle_close_port *port);
#endif

#endif
