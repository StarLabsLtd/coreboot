/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_TRANSPORT_H
#define CDK2_SYSTEM_FMP_TRANSPORT_H

#include <coreboot_tables.h>
#include <stddef.h>
#include <stdint.h>

#define CDK2_SYSTEM_FMP_TRANSPORT_SIZE 168U
#define CDK2_SYSTEM_FMP_TRANSPORT_REVISION_1 1U
#define CDK2_SYSTEM_FMP_TRANSPORT_REVISION 2U
#define CDK2_SYSTEM_FMP_TRANSPORT_RAM_REVISION 3U
#define CDK2_SYSTEM_FMP_INTENT_REVISION 1U
#define CDK2_SYSTEM_FMP_DIGEST_SHA256 1U
#define CDK2_SYSTEM_FMP_DIGEST_SIZE 32U
#define CDK2_SYSTEM_FMP_TRANSPORT_EXECUTE 1U
#define CDK2_SYSTEM_FMP_TRANSPORT_READ_INFO 2U
#define CDK2_SYSTEM_FMP_TRANSPORT_CLOSE_RAM 3U
#define CDK2_SYSTEM_FMP_RESULT_SUCCESS 0U
#define CDK2_SYSTEM_FMP_RESULT_EXECUTION 1U
#define CDK2_SYSTEM_FMP_RESULT_SIGNATURE_REFUSED 2U
#define CDK2_SYSTEM_FMP_LAST_ATTEMPT_SUCCESS 0U
#define CDK2_SYSTEM_FMP_LAST_ATTEMPT_UNSUCCESSFUL 1U
#define CDK2_SYSTEM_FMP_RESULT_PENDING MAX_UINT32

#define CDK2_SYSTEM_FMP_REQUEST_OFFSET 0U
#define CDK2_SYSTEM_FMP_INTENT_OFFSET 40U
#define CDK2_SYSTEM_FMP_RESULT_OFFSET 128U
#define CDK2_SYSTEM_FMP_INFO_OFFSET 40U

#define CDK2_SYSTEM_FMP_INFO_STATE_LAST_ATTEMPT_STATUS_VALID (1U << 0)
#define CDK2_SYSTEM_FMP_INFO_STATE_LAST_ATTEMPT_VERSION_VALID (1U << 1)
#define CDK2_SYSTEM_FMP_INFO_STATE_VALID_FLAGS \
	(CDK2_SYSTEM_FMP_INFO_STATE_LAST_ATTEMPT_STATUS_VALID | \
	 CDK2_SYSTEM_FMP_INFO_STATE_LAST_ATTEMPT_VERSION_VALID)

enum cdk2_system_fmp_transport_operation {
	CDK2_SYSTEM_FMP_CHECK = 1,
	CDK2_SYSTEM_FMP_SET = 2,
};

enum cdk2_system_fmp_transport_status {
	CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS = 0,
	CDK2_SYSTEM_FMP_TRANSPORT_INVALID,
	CDK2_SYSTEM_FMP_TRANSPORT_CLOSED,
	CDK2_SYSTEM_FMP_TRANSPORT_BUSY,
	CDK2_SYSTEM_FMP_TRANSPORT_CAPACITY,
	CDK2_SYSTEM_FMP_TRANSPORT_HASH_FAILED,
	CDK2_SYSTEM_FMP_TRANSPORT_CACHE_FAILED,
	CDK2_SYSTEM_FMP_TRANSPORT_TRIGGER_FAILED,
	CDK2_SYSTEM_FMP_TRANSPORT_BAD_RESPONSE,
	CDK2_SYSTEM_FMP_TRANSPORT_EXECUTION_FAILED,
	CDK2_SYSTEM_FMP_TRANSPORT_SIGNATURE_REFUSED,
};

struct cdk2_system_fmp_request {
	UINT32 revision;
	UINT32 size;
	UINT32 operation;
	UINT32 flags;
	UINT64 generation;
	UINT64 transaction;
	UINT32 intent_size;
	UINT32 result_size;
} __aligned(8);

struct cdk2_system_fmp_intent {
	UINT32 revision;
	UINT32 size;
	UINT32 operation;
	UINT32 flags;
	UINT64 broker_generation;
	UINT64 transaction;
	UINT64 capsule_size;
	UINT32 digest_algorithm;
	UINT32 digest_size;
	UINT8 digest[CDK2_SYSTEM_FMP_DIGEST_SIZE];
	UINT32 attempted_version;
	UINT32 reserved;
} __aligned(8);

struct cdk2_system_fmp_result {
	UINT32 revision;
	UINT32 size;
	UINT64 generation;
	UINT64 transaction;
	UINT32 attempted_version;
	UINT32 reserved;
	UINT32 last_attempt_status;
	UINT32 result;
} __aligned(8);

struct cdk2_system_fmp_transport_info {
	UINT32 revision;
	UINT32 size;
	UINT64 generation;
	UINT64 transaction;
	EFI_GUID image_type;
	UINT64 hardware_instance;
	UINT32 current_version;
	UINT32 lowest_supported_version;
	UINT32 image_size;
	UINT32 capabilities;
	UINT32 state_flags;
	UINT32 last_attempt_version;
	UINT32 last_attempt_status;
	UINT32 reserved[12];
	UINT32 result;
} __aligned(8);

_Static_assert(sizeof(struct cdk2_system_fmp_request) == 40U,
	"SystemFmp request ABI");
_Static_assert(_Alignof(struct cdk2_system_fmp_request) == 8U &&
	offsetof(struct cdk2_system_fmp_request, generation) == 16U &&
	offsetof(struct cdk2_system_fmp_request, transaction) == 24U &&
	offsetof(struct cdk2_system_fmp_request, intent_size) == 32U,
	"SystemFmp request layout");
_Static_assert(sizeof(struct cdk2_system_fmp_intent) == 88U,
	"SystemFmp intent ABI");
_Static_assert(_Alignof(struct cdk2_system_fmp_intent) == 8U &&
	offsetof(struct cdk2_system_fmp_intent, broker_generation) == 16U &&
	offsetof(struct cdk2_system_fmp_intent, capsule_size) == 32U &&
	offsetof(struct cdk2_system_fmp_intent, digest) == 48U &&
	offsetof(struct cdk2_system_fmp_intent, attempted_version) == 80U,
	"SystemFmp intent layout");
_Static_assert(sizeof(struct cdk2_system_fmp_result) == 40U,
	"SystemFmp result ABI");
_Static_assert(_Alignof(struct cdk2_system_fmp_result) == 8U &&
	offsetof(struct cdk2_system_fmp_result, generation) == 8U &&
	offsetof(struct cdk2_system_fmp_result, transaction) == 16U &&
	offsetof(struct cdk2_system_fmp_result, last_attempt_status) == 32U &&
	offsetof(struct cdk2_system_fmp_result, result) == 36U,
	"SystemFmp result layout");
_Static_assert(CDK2_SYSTEM_FMP_INTENT_OFFSET ==
	CDK2_SYSTEM_FMP_REQUEST_OFFSET + sizeof(struct cdk2_system_fmp_request) &&
	CDK2_SYSTEM_FMP_RESULT_OFFSET ==
	CDK2_SYSTEM_FMP_INTENT_OFFSET + sizeof(struct cdk2_system_fmp_intent) &&
	CDK2_SYSTEM_FMP_TRANSPORT_SIZE ==
	CDK2_SYSTEM_FMP_RESULT_OFFSET + sizeof(struct cdk2_system_fmp_result),
	"SystemFmp transport layout");
_Static_assert(sizeof(struct cdk2_system_fmp_transport_info) == 128U,
	"SystemFmp info response ABI");
_Static_assert(_Alignof(struct cdk2_system_fmp_transport_info) == 8U &&
	offsetof(struct cdk2_system_fmp_transport_info, generation) == 8U &&
	offsetof(struct cdk2_system_fmp_transport_info, image_type) == 24U &&
	offsetof(struct cdk2_system_fmp_transport_info, hardware_instance) == 40U &&
	offsetof(struct cdk2_system_fmp_transport_info, current_version) == 48U &&
	offsetof(struct cdk2_system_fmp_transport_info, state_flags) == 64U &&
	offsetof(struct cdk2_system_fmp_transport_info, reserved) == 76U &&
	offsetof(struct cdk2_system_fmp_transport_info, result) == 124U,
	"SystemFmp info response layout");
_Static_assert(CDK2_SYSTEM_FMP_INFO_OFFSET +
		sizeof(struct cdk2_system_fmp_transport_info) ==
	CDK2_SYSTEM_FMP_TRANSPORT_SIZE &&
	CDK2_SYSTEM_FMP_REQUEST_OFFSET +
		sizeof(struct cdk2_system_fmp_request) ==
	CDK2_SYSTEM_FMP_INFO_OFFSET,
	"SystemFmp info transport layout");

struct cdk2_coreboot_handoff;

struct cdk2_system_fmp_transport {
	uint16_t revision;
	uint64_t generation;
	EFI_GUID image_type;
	uint32_t current_version;
	uint32_t lowest_supported_version;
	uint32_t image_size;
	uint32_t capabilities;
	uint64_t communication_base;
	uint32_t communication_size;
	uint32_t message_size;
	uint64_t staging_base;
	uint64_t staging_size;
	uint16_t trigger_port;
	uint8_t trigger_value;
	uint8_t valid;
};

typedef EFI_STATUS cdk2_system_fmp_hash_fn(void *context, const void *data,
	UINTN size, UINT8 digest[CDK2_SYSTEM_FMP_DIGEST_SIZE]);
typedef EFI_STATUS cdk2_system_fmp_cache_fn(void *context, void *base,
	UINTN size);
typedef void cdk2_system_fmp_barrier_fn(void *context);
typedef EFI_STATUS cdk2_system_fmp_trigger_fn(void *context, UINT16 port,
	UINT8 value);

/* The platform supplies the architecture-specific cache and APM operations. */
struct cdk2_system_fmp_transport_port {
	void *context;
	cdk2_system_fmp_hash_fn *sha256;
	cdk2_system_fmp_cache_fn *publish;
	cdk2_system_fmp_cache_fn *acquire;
	cdk2_system_fmp_barrier_fn *barrier;
	cdk2_system_fmp_trigger_fn *trigger_apm_io8;
};

struct cdk2_system_fmp_client {
	struct cdk2_system_fmp_transport endpoint;
	struct cdk2_system_fmp_transport_port port;
	uint64_t transaction;
	size_t staged_size;
	uint8_t communication_dirty;
	uint8_t staging_dirty;
	uint8_t initialized;
	uint8_t busy;
	uint8_t ram_closed;
};

struct cdk2_system_fmp_outcome {
	/* A refusal is usable only with its matching clean transport status. */
	uint64_t transaction;
	uint64_t generation;
	uint32_t attempted_version;
	uint32_t last_attempt_status;
	uint32_t broker_result;
	uint8_t trigger_invoked;
	uint8_t response_authenticated;
};

struct cdk2_system_fmp_info {
	EFI_GUID image_type;
	uint64_t hardware_instance;
	uint32_t current_version;
	uint32_t lowest_supported_version;
	uint32_t image_size;
	uint32_t capabilities;
	uint32_t state_flags;
	uint32_t last_attempt_version;
	uint32_t last_attempt_status;
};

EFI_STATUS cdk2_system_fmp_transport_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_transport *transport);

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_init(
	struct cdk2_system_fmp_client *client,
	const struct cdk2_system_fmp_transport *endpoint,
	const struct cdk2_system_fmp_transport_port *port);
enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_execute(
	struct cdk2_system_fmp_client *client,
	enum cdk2_system_fmp_transport_operation operation, const void *image,
	UINTN image_size, UINT32 attempted_version,
	struct cdk2_system_fmp_outcome *outcome);
enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_read_info(
	struct cdk2_system_fmp_client *client,
	struct cdk2_system_fmp_info *info);
enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_close_ram(
	struct cdk2_system_fmp_client *client);
enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_close(
	struct cdk2_system_fmp_client *client);

#endif
