/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_H
#define CDK2_PAYLOAD_MM_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_H

#include <cdk2/payload_mm_authvar_presence_lifecycle_close.h>

enum cdk2_authvar_presence_lifecycle_close_client_status {
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_SUCCESS = 0,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_INVALID,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_CLOSED,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_BUSY,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_CACHE_FAILED,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_TRIGGER_FAILED,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_BAD_RESPONSE,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_EXECUTION_FAILED,
};

typedef EFI_STATUS cdk2_authvar_presence_lifecycle_close_cache_fn(
	void *context, void *base, UINTN size);
typedef void cdk2_authvar_presence_lifecycle_close_barrier_fn(void *context);
/*
 * Put input[31:0] in EAX and input[63:32] in ECX, issue OUTB with AL to port,
 * then return the resulting ECX:EAX pair. Command must equal input[7:0].
 */
typedef EFI_STATUS cdk2_authvar_presence_lifecycle_close_trigger_fn(
	void *context, UINT16 port, UINT8 command, UINT64 input, UINT64 *result);

struct cdk2_authvar_presence_lifecycle_close_port {
	void *context;
	UINTN context_size;
	cdk2_authvar_presence_lifecycle_close_cache_fn *publish;
	cdk2_authvar_presence_lifecycle_close_cache_fn *acquire;
	cdk2_authvar_presence_lifecycle_close_barrier_fn *barrier;
	cdk2_authvar_presence_lifecycle_close_trigger_fn *trigger_apm_io8;
};

enum cdk2_authvar_presence_lifecycle_close_client_state {
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_EMPTY = 0,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_INITIALIZING,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_READY,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_IN_FLIGHT,
	CDK2_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLIENT_POISONED,
};

struct cdk2_authvar_presence_lifecycle_close_client {
	struct cdk2_authvar_presence_lifecycle_close_endpoint endpoint;
	struct cdk2_authvar_presence_lifecycle_close_endpoint sealed_endpoint;
	struct cdk2_authvar_presence_lifecycle_close_port port;
	struct cdk2_authvar_presence_lifecycle_close_port sealed_port;
	UINT64 request_id;
	UINT32 consumed_sources;
	UINT32 state;
};

/* Client storage must be zero-initialized before its first initialization. */
enum cdk2_authvar_presence_lifecycle_close_client_status
cdk2_authvar_presence_lifecycle_close_client_init(
	struct cdk2_authvar_presence_lifecycle_close_client *client,
	const struct cdk2_authvar_presence_lifecycle_close_endpoint *endpoint,
	const struct cdk2_authvar_presence_lifecycle_close_port *port);

enum cdk2_authvar_presence_lifecycle_close_client_status
cdk2_authvar_presence_lifecycle_close_pre_external_image(
	struct cdk2_authvar_presence_lifecycle_close_client *client);
enum cdk2_authvar_presence_lifecycle_close_client_status
cdk2_authvar_presence_lifecycle_close_payload_failure_or_return(
	struct cdk2_authvar_presence_lifecycle_close_client *client);
enum cdk2_authvar_presence_lifecycle_close_client_status
cdk2_authvar_presence_lifecycle_close_closed_reproof(
	struct cdk2_authvar_presence_lifecycle_close_client *client);

#endif
