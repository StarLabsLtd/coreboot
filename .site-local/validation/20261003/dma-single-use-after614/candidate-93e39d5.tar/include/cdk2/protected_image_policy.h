/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_PROTECTED_IMAGE_POLICY_H
#define CDK2_PROTECTED_IMAGE_POLICY_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <cdk2/authvar_namespace.h>
#include <cdk2/authvar_runtime_owner.h>
#include <cdk2/security_router.h>

/*
 * Boot-owned consumer context and bounded snapshot workspace. The registered
 * context allocation is excluded from public variable operands as one span.
 * Its fields describe that allocation; they are not independent authority.
 */
struct cdk2_protected_image_policy {
	struct cdk2_authvar_namespace *namespace;
	struct cdk2_authvar_runtime_owner *owner;
	size_t capacity;
	size_t allocation_size;
	bool busy;
	uint8_t snapshot[];
};

/* Returns zero unless the owner has a usable GENERAL endpoint. */
size_t cdk2_protected_image_policy_allocation_size(
	const struct cdk2_authvar_runtime_owner *owner);

/* Initialize caller-owned storage before binding its full span to namespace. */
EFI_STATUS cdk2_protected_image_policy_init(void *allocation, size_t allocation_size,
	struct cdk2_authvar_namespace *namespace,
	struct cdk2_authvar_runtime_owner *owner);

/* Canonical-image callback; owner is the exact registered context allocation. */
EFI_STATUS CDK2_MS_ABI cdk2_protected_image_policy_authorize(
	const void *image, UINTN image_size, void *owner);

#endif
