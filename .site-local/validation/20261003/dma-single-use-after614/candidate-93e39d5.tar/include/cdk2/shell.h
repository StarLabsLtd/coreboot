/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_SHELL_H_
#define CDK2_SHELL_H_

#include <uefi.h>
#include <cdk2/diagnostic.h>

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
void cdk2_shell_diagnostic(const char *message);
#define CDK2_SHELL_DIAG(message) cdk2_shell_diagnostic(message)
#else
#define CDK2_SHELL_DIAG(message) do { } while (0)
#endif

enum cdk2_shell_command_type {
	CDK2_SHELL_COMMAND_IGNORE,
	CDK2_SHELL_COMMAND_IMAGE,
	CDK2_SHELL_COMMAND_CHANGE_DIRECTORY,
	CDK2_SHELL_COMMAND_CHANGE_FILESYSTEM,
	CDK2_SHELL_COMMAND_EXIT
};

struct cdk2_shell_command {
	enum cdk2_shell_command_type type;
	CHAR16 path[260];
	CHAR16 options[260];
	UINTN options_size;
};

EFI_STATUS cdk2_shell_parse_line(const CHAR16 *line, UINTN length,
	struct cdk2_shell_command *command);
EFI_STATUS cdk2_shell_parse_script_line(const UINT8 *script, UINTN size,
	BOOLEAN unicode, UINTN *offset, struct cdk2_shell_command *command);
EFI_STATUS CDK2_MS_ABI cdk2_shell_entry(void *image, void *system_table);

#endif
