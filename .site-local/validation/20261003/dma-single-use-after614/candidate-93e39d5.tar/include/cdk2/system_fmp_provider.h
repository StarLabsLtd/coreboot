/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_PROVIDER_H
#define CDK2_SYSTEM_FMP_PROVIDER_H

#include <cdk2/esrt_abi.h>
#include <cdk2/capsule_check_outcome.h>
#include <cdk2/system_fmp_session.h>

#include <stdint.h>

#define CDK2_SYSTEM_FMP_IMAGE_INDEX 1U
#define CDK2_SYSTEM_FMP_IMAGE_UPDATABLE BIT0
#define CDK2_SYSTEM_FMP_RESET_REQUIRED BIT1
#define CDK2_SYSTEM_FMP_AUTHENTICATION_REQUIRED BIT2

struct cdk2_system_fmp_provider {
	struct cdk2_fmp_protocol protocol;
	struct cdk2_system_fmp_session session;
	struct cdk2_capsule_check_outcome check_outcome;
	uint8_t busy;
};

EFI_STATUS cdk2_system_fmp_provider_initialize(
	struct cdk2_system_fmp_provider *provider,
	const struct cdk2_system_fmp_session_config *config);
EFI_STATUS cdk2_system_fmp_provider_close(
	struct cdk2_system_fmp_provider *provider);

extern const EFI_GUID cdk2_system_fmp_protocol_guid;
EFI_STATUS CDK2_MS_ABI cdk2_system_fmp_entry(void *image,
	struct cdk2_system_table_view *system);
EFI_STATUS CDK2_MS_ABI cdk2_system_fmp_unload(void *image);

#endif
