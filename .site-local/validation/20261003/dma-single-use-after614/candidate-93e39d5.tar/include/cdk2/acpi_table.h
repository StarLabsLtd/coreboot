/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_ACPI_TABLE_H_
#define CDK2_ACPI_TABLE_H_

#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

#define CDK2_ACPI_HEADER_SIZE 36U
#define CDK2_ACPI_RSDP_SIZE 36U
#define CDK2_ACPI_MAX_TABLE_SIZE SIZE_1MB

#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
#include <cdk2/diagnostic.h>
void cdk2_acpi_diagnostic(const char *message);
void cdk2_acpi_diagnostic_value(const char *label, uint64_t value);
#define CDK2_ACPI_DIAG(message) cdk2_acpi_diagnostic(message)
#define CDK2_ACPI_DIAG_VALUE(label, value) \
	cdk2_acpi_diagnostic_value((label), (value))
#else
#define CDK2_ACPI_DIAG(message) do { } while (0)
#define CDK2_ACPI_DIAG_VALUE(label, value) do { } while (0)
#endif

typedef uint64_t cdk2_acpi_allocator_allocate_fn(void *context, size_t size,
					 size_t alignment, void **buffer);
typedef void cdk2_acpi_allocator_free_fn(void *context, void *buffer);

struct cdk2_acpi_allocator {
	void *context;
	cdk2_acpi_allocator_allocate_fn *allocate;
	cdk2_acpi_allocator_free_fn *free;
};

struct cdk2_acpi_record {
	void *table;
	uint32_t length;
	uint64_t key;
	uint8_t owned;
};

struct cdk2_acpi_tables {
	struct cdk2_acpi_allocator allocator;
	struct cdk2_acpi_record *records;
	size_t capacity;
	size_t count;
	uint64_t next_key;
	size_t replacement_index;
	uint8_t replacement_pending;
	uint8_t *rsdp;
	uint32_t rsdp_length;
	uint8_t *rsdp10;
	uint8_t *rsdt;
	uint8_t *xsdt;
};

uint64_t
cdk2_acpi_tables_initialize(struct cdk2_acpi_tables *tables,
			    const struct cdk2_acpi_allocator *allocator,
			    struct cdk2_acpi_record *records, size_t capacity,
			    const void *source_rsdp);
void cdk2_acpi_tables_destroy(struct cdk2_acpi_tables *tables);
uint64_t cdk2_acpi_install(struct cdk2_acpi_tables *tables, const void *table,
			     size_t table_size, uint64_t *key);
uint64_t cdk2_acpi_uninstall(struct cdk2_acpi_tables *tables, uint64_t key);
const void *cdk2_acpi_rsdp(const struct cdk2_acpi_tables *tables);
uint8_t cdk2_acpi_checksum(const void *buffer, size_t size);

#endif
