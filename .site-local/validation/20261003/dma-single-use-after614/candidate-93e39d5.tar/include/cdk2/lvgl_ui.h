/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_LVGL_UI_H_
#define CDK2_LVGL_UI_H_

#include <uefi.h>
#include <cdk2/lvgl_renderer.h>

#define CDK2_LVGL_MENU_MAX_ITEMS 32U
#define CDK2_LVGL_STATUS_PROTOCOL_REVISION 1U
#define CDK2_LVGL_STATUS_PROTOCOL_GUID \
	{ 0x141f2235, 0x7e9f, 0x4af9, \
		{ 0x97, 0x76, 0xb4, 0xe3, 0x1b, 0xe0, 0xf0, 0xf1 } }

enum cdk2_lvgl_status_message {
	CDK2_LVGL_STATUS_PREPARING,
	CDK2_LVGL_STATUS_SELECTING_BOOT,
	CDK2_LVGL_STATUS_STARTING_OS,
	CDK2_LVGL_STATUS_BOOT_FAILED,
	CDK2_LVGL_STATUS_MESSAGE_COUNT,
};

struct cdk2_lvgl_status {
	UINT32 x;
	UINT32 y;
	UINT32 width;
	UINT32 height;
	enum cdk2_lvgl_status_message message;
};

struct cdk2_lvgl_menu_item {
	const CHAR16 *label;
	BOOLEAN disabled;
};

struct cdk2_lvgl_ui_protocol;
typedef EFI_STATUS CDK2_MS_ABI cdk2_lvgl_show_menu_fn(
	struct cdk2_lvgl_ui_protocol *, const CHAR16 *,
	const struct cdk2_lvgl_menu_item *, UINTN, UINTN *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_lvgl_show_form_fn(
	struct cdk2_lvgl_ui_protocol *, const struct cdk2_lvgl_form *, UINT16 *, INTN *);
typedef void CDK2_MS_ABI cdk2_lvgl_poll_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_lvgl_set_poll_fn(
	struct cdk2_lvgl_ui_protocol *, cdk2_lvgl_poll_fn *, void *, UINTN);

struct cdk2_lvgl_ui_protocol {
	cdk2_lvgl_show_menu_fn *show_menu;
	cdk2_lvgl_show_form_fn *show_form;
	cdk2_lvgl_set_poll_fn *set_poll;
};

struct cdk2_lvgl_status_protocol;
typedef EFI_STATUS CDK2_MS_ABI cdk2_lvgl_show_status_fn(
	struct cdk2_lvgl_status_protocol *, const struct cdk2_lvgl_status *);

struct cdk2_lvgl_status_protocol {
	cdk2_lvgl_show_status_fn *show_status;
	UINT32 revision;
	UINT32 size;
};

EFI_STATUS CDK2_MS_ABI cdk2_lvgl_ui_entry(void *image, void *system_table);

#endif
