/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_AUTHVAR_PRESENCE_LIFECYCLE_H
#define CDK2_AUTHVAR_PRESENCE_LIFECYCLE_H

#include <uefi.h>

typedef EFI_STATUS cdk2_authvar_presence_restrict_fn(void *context);

struct cdk2_authvar_presence_lifecycle_ops {
	cdk2_authvar_presence_restrict_fn *ready_to_boot;
	cdk2_authvar_presence_restrict_fn *enter_runtime;
	void *context;
};

/*
 * Install the boot-local authenticated-variable restriction owner. Future
 * integration binds these callbacks to the service's READY_TO_BOOT and
 * ENTER_RUNTIME operations. This plumbing is dormant until installation.
 */
EFI_STATUS cdk2_authvar_presence_lifecycle_install(
	const struct cdk2_authvar_presence_lifecycle_ops *ops);

/* Idempotent restrictions used before externally supplied code or callbacks. */
EFI_STATUS cdk2_authvar_presence_lifecycle_seal(void);
EFI_STATUS cdk2_authvar_presence_lifecycle_enter_runtime(void);

#ifdef CDK2_HOST_TEST
typedef void cdk2_authvar_presence_install_hook_fn(void *context);
void cdk2_authvar_presence_lifecycle_test_install_hook(
	cdk2_authvar_presence_install_hook_fn *hook, void *context);
void cdk2_authvar_presence_lifecycle_test_preclaim_hook(
	cdk2_authvar_presence_install_hook_fn *hook, void *context);
void cdk2_authvar_presence_lifecycle_test_reset(void);
#endif

#endif
