/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_FTW_PI_H
#define CDK2_FTW_PI_H
#include <cdk2/ftw.h>

struct cdk2_ftw_pi_work_header {
	EFI_GUID signature;
	UINT32 crc32;
	UINT8 working_block_valid, working_block_invalid, reserved[2];
	UINT64 write_queue_size;
};
struct cdk2_ftw_pi_write_header {
	EFI_GUID caller_id;
	UINT64 number_of_writes, private_data_size;
	UINT8 header_allocated, writes_allocated, complete, pad[5];
} __packed;
typedef char cdk2_ftw_pi_write_caller_offset[
	(offsetof(struct cdk2_ftw_pi_write_header, caller_id) == 0) ? 1 : -1];
typedef char cdk2_ftw_pi_write_count_offset[
	(offsetof(struct cdk2_ftw_pi_write_header, number_of_writes) == 16) ? 1 : -1];
typedef char cdk2_ftw_pi_write_state_offset[
	(offsetof(struct cdk2_ftw_pi_write_header, header_allocated) == 32 &&
	 offsetof(struct cdk2_ftw_pi_write_header, writes_allocated) == 33 &&
	 offsetof(struct cdk2_ftw_pi_write_header, complete) == 34) ? 1 : -1];
struct cdk2_ftw_pi_record {
	UINT64 lba, offset, length;
	INT64 relative_offset;
	UINT8 spare_complete, destination_complete, pad[6];
} __packed;
typedef char cdk2_ftw_pi_record_spare_offset[
	(offsetof(struct cdk2_ftw_pi_record, spare_complete) == 32) ? 1 : -1];
typedef char cdk2_ftw_pi_record_destination_offset[
	(offsetof(struct cdk2_ftw_pi_record, destination_complete) == 33) ? 1 : -1];
typedef char cdk2_ftw_pi_work_header_size[(sizeof(struct cdk2_ftw_pi_work_header) == 32) ? 1 : -1];
typedef char cdk2_ftw_pi_write_header_size[(sizeof(struct cdk2_ftw_pi_write_header) == 40) ? 1 :
						 -1];
typedef char cdk2_ftw_pi_record_size[(sizeof(struct cdk2_ftw_pi_record) == 40) ? 1 : -1];

EFI_STATUS cdk2_ftw_pi_initialize(UINT8 *workspace, UINTN size);
EFI_STATUS cdk2_ftw_pi_recover_clean_header(const UINT8 *workspace,
	UINTN size);
EFI_STATUS cdk2_ftw_pi_decode(const UINT8 *workspace, UINTN size,
			      struct cdk2_ftw_journal *journal);
EFI_STATUS cdk2_ftw_pi_encode(UINT8 *workspace, UINTN size,
			      const struct cdk2_ftw_journal *journal);
#endif
