/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_AUTHVAR_PRESENCE_COMPOSITION_H
#define CDK2_AUTHVAR_PRESENCE_COMPOSITION_H

#include <cdk2/authvar_presence_lifecycle.h>
#include <cdk2/payload_mm_authvar_presence.h>
#include <cdk2/payload_mm_authvar_presence_client.h>
#include <uefi.h>

struct cdk2_authvar_presence_bootstrap_io;

typedef EFI_STATUS cdk2_authvar_presence_close_fn(void *context);

struct cdk2_authvar_presence_close_port {
	void *context;
	cdk2_authvar_presence_close_fn *abort;
	cdk2_authvar_presence_close_fn *ready_to_boot;
	cdk2_authvar_presence_close_fn *enter_runtime;
};

/*
 * Compose a validated endpoint with the bootstrap, client and lifecycle owner.
 * The close port is mandatory and must restrict the protected coreboot
 * authority; locally forgetting the client is not a substitute.
 */
EFI_STATUS cdk2_authvar_presence_compose(
	const struct cdk2_authvar_presence_endpoint *endpoint,
	const struct cdk2_authvar_presence_bootstrap_io *io,
	const struct cdk2_authvar_presence_close_port *close_port);

enum cdk2_authvar_presence_client_status
cdk2_authvar_presence_compose_enter_setup_mode(void);

/*
 * Irrevocably retire the local setup capability without invoking a platform
 * lifecycle transition.  A later composition owns the external close proof;
 * this operation only removes the legacy local authority.
 */
EFI_STATUS cdk2_authvar_presence_compose_retire_local_authority(void);

#ifdef CDK2_HOST_TEST
typedef void cdk2_authvar_presence_compose_retire_hook_fn(
	struct cdk2_authvar_presence_close_port *close_port,
	struct cdk2_authvar_presence_close_port *sealed_close_port,
	void *context);

void cdk2_authvar_presence_compose_test_reset(void);
void cdk2_authvar_presence_compose_test_precommit_hook(
	void (*hook)(void *context), void *context);
void cdk2_authvar_presence_compose_test_setup_acquired_hook(
	void (*hook)(void *context), void *context);
void cdk2_authvar_presence_compose_test_retire_claimed_hook(
	void (*hook)(void *context), void *context);
void cdk2_authvar_presence_compose_test_retire_hook(
	cdk2_authvar_presence_compose_retire_hook_fn * hook, void *context);
BOOLEAN cdk2_authvar_presence_compose_test_terminal_scrubbed(void);
BOOLEAN cdk2_authvar_presence_compose_test_retired_scrubbed(void);
#endif

#endif
