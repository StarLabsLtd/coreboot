/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_EARLY_SPLASH_H
#define CDK2_EARLY_SPLASH_H

#include <coreboot_tables.h>
#include <uefi.h>

EFI_STATUS cdk2_early_splash_draw(const struct cb_framebuffer *framebuffer);

#endif
