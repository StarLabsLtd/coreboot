/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_CAPSULE_DISK_H
#define CDK2_CAPSULE_DISK_H

#include <uefi.h>
#include <cdk2/fat_binding.h>

#define CDK2_CAPSULE_FILE_DIRECTORY L"\\EFI\\UpdateCapsule"
#define CDK2_CAPSULE_PERSIST_ACROSS_RESET 0x00010000U
#define CDK2_CAPSULE_POPULATE_SYSTEM_TABLE 0x00020000U
#define CDK2_CAPSULE_INITIATE_RESET 0x00040000U
#define CDK2_CAPSULE_ALLOWED_FLAGS (CDK2_CAPSULE_PERSIST_ACROSS_RESET | \
	CDK2_CAPSULE_POPULATE_SYSTEM_TABLE | CDK2_CAPSULE_INITIATE_RESET)
#define CDK2_CAPSULE_FILE_SYSTEM 0x0000000000000004ULL
#define CDK2_CAPSULE_FILE_DIRECTORY_ATTRIBUTE 0x0000000000000010ULL
#define CDK2_CAPSULE_FILE_ARCHIVE 0x0000000000000020ULL
#define CDK2_CAPSULE_FILE_VALID_ATTRIBUTES 0x0000000000000037ULL

#ifndef CDK2_CAPSULE_HEADER_DEFINED
#define CDK2_CAPSULE_HEADER_DEFINED
struct cdk2_capsule_header {
	EFI_GUID guid;
	UINT32 header_size;
	UINT32 flags;
	UINT32 image_size;
};
#endif

_Static_assert(sizeof(struct cdk2_capsule_header) == 28U,
	"UEFI capsule header layout changed");

struct cdk2_capsule_image {
	void *data;
	UINTN size;
	EFI_GUID guid;
	UINT32 flags;
};

struct cdk2_capsule_list {
	/* The scanner replaces this array but preserves every existing entry.
	 * The input array remains caller-owned and is never released by a scan. */
	struct cdk2_capsule_image *images;
	UINTN count;
};

struct cdk2_capsule_disk_source {
	UINTN id;
	BOOLEAN preferred;
	BOOLEAN esp;
};

struct cdk2_capsule_disk_file {
	/* name is valid only until file() returns; name_bytes bounds the copy. */
	const CHAR16 *name;
	UINTN name_bytes;
	UINT64 size;
	UINT64 attributes;
};

enum cdk2_capsule_disk_event {
	CDK2_CAPSULE_DISK_SOURCE = 1,
	CDK2_CAPSULE_DISK_FILE,
	CDK2_CAPSULE_DISK_MALFORMED,
	CDK2_CAPSULE_DISK_IO_ERROR,
	CDK2_CAPSULE_DISK_DELETE_ERROR,
	CDK2_CAPSULE_DISK_COMPLETE,
};

typedef void *(*cdk2_capsule_disk_alloc_fn)(UINTN size, void *context);
typedef void (*cdk2_capsule_disk_free_fn)(void *buffer, void *context);
typedef EFI_STATUS cdk2_capsule_disk_source_fn(UINTN index,
	struct cdk2_capsule_disk_source *source, void *context);
typedef EFI_STATUS cdk2_capsule_disk_file_fn(UINTN source, UINTN index,
	struct cdk2_capsule_disk_file *file, void *context);
typedef EFI_STATUS cdk2_capsule_disk_read_fn(UINTN source, UINTN file,
	void *buffer, UINTN size, void *context);
typedef EFI_STATUS cdk2_capsule_disk_remove_fn(UINTN source,
	const CHAR16 *name, const void *expected, UINTN size, void *context);
typedef EFI_STATUS cdk2_capsule_disk_remove_unread_fn(UINTN source,
	const CHAR16 *name, UINT64 size, UINT64 attributes, void *context);
typedef EFI_STATUS cdk2_capsule_disk_validate_fn(const void *image,
	UINTN size, void *context);
typedef EFI_STATUS cdk2_capsule_disk_process_fn(
	const struct cdk2_capsule_image *images, UINTN count, void *context);
typedef EFI_STATUS cdk2_capsule_disk_finish_fn(void *context);
typedef void (*cdk2_capsule_disk_report_fn)(enum cdk2_capsule_disk_event event,
	UINTN source, UINTN file, UINT64 value, EFI_STATUS status, void *context);

struct cdk2_capsule_disk_ops {
	UINTN source_count;
	UINTN max_nonpopulate_size;
	UINTN max_populate_size;
	cdk2_capsule_disk_source_fn *source;
	cdk2_capsule_disk_file_fn *file;
	cdk2_capsule_disk_read_fn *read;
	cdk2_capsule_disk_remove_fn *remove;
	cdk2_capsule_disk_remove_unread_fn *remove_unread;
	cdk2_capsule_disk_validate_fn *validate_fmp;
	cdk2_capsule_disk_process_fn *process_fmp;
	cdk2_capsule_disk_finish_fn *finish;
	cdk2_capsule_disk_alloc_fn alloc;
	cdk2_capsule_disk_free_fn free;
	cdk2_capsule_disk_report_fn report;
	void *context;
	const void *source_identity;
};

struct cdk2_capsule_disk_result {
	UINTN source;
	UINTN candidates;
	UINTN loaded;
	UINTN malformed;
	UINTN deleted;
	BOOLEAN used_preferred;
	BOOLEAN cleanup_failed;
	BOOLEAN reset_required;
	/* Independent failure domains used by boot policy after completion. */
	EFI_STATUS scan_status;
	EFI_STATUS processing_status;
	EFI_STATUS completion_status;
	BOOLEAN processing_attempted;
	/* Opaque valid-file transaction, consumed by cdk2_capsule_disk_complete. */
	void *transaction;
	UINTN cleanup_failures;
	/* Name-order comparisons performed by bounded metadata selection. */
	UINTN metadata_work;
};

/*
 * A successfully appended image belongs to capsules even when source cleanup
 * later fails. Definitively malformed files are removed after the replacement
 * array is owned by the caller. After committing the replacement array, scan
 * invokes process_fmp exactly once with only its newly appended suffix. Valid
 * files remain on the source until the recorded batch application and source
 * cleanup are both successful. The caller must consume the resulting
 * transaction exactly once with cdk2_capsule_disk_complete() or its ESP
 * adapter. A reset is requested only after that completion. A scan can return
 * a live transaction together with a later directory or image error. The
 * returned images form an independently valid prefix, and completion leaves
 * the uncertain remainder on disk for a subsequent scan.
 */
EFI_STATUS cdk2_capsule_disk_scan(const struct cdk2_capsule_disk_ops *ops,
	struct cdk2_capsule_list *capsules,
	struct cdk2_capsule_disk_result *result);
EFI_STATUS cdk2_capsule_disk_scan_esp(
	struct cdk2_fat_simple_fs_protocol *filesystem,
	UINTN max_nonpopulate_size, UINTN max_populate_size,
	cdk2_capsule_disk_validate_fn *validate_fmp,
	cdk2_capsule_disk_process_fn *process_fmp,
	cdk2_capsule_disk_alloc_fn alloc, cdk2_capsule_disk_free_fn free,
	cdk2_capsule_disk_report_fn report, void *context,
	struct cdk2_capsule_list *capsules,
	struct cdk2_capsule_disk_result *result);
EFI_STATUS cdk2_capsule_disk_complete_esp(
	struct cdk2_fat_simple_fs_protocol *filesystem,
	cdk2_capsule_disk_alloc_fn alloc, cdk2_capsule_disk_free_fn free,
	cdk2_capsule_disk_report_fn report, void *context,
	struct cdk2_capsule_list *capsules,
	struct cdk2_capsule_disk_result *result);

/*
 * Complete one scan using its internally recorded batch result. A failed batch
 * releases the transaction while preserving valid source files for retry. The
 * source identity must match the scan, and a transaction is single-use.
 */
EFI_STATUS cdk2_capsule_disk_complete(const struct cdk2_capsule_disk_ops *ops,
	struct cdk2_capsule_list *capsules,
	struct cdk2_capsule_disk_result *result);

#endif
