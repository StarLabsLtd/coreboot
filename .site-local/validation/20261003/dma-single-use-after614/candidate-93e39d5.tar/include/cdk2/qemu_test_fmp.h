/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_QEMU_TEST_FMP_H
#define CDK2_QEMU_TEST_FMP_H

#include <stdint.h>
#include <cdk2/esrt_abi.h>

#define CDK2_QEMU_FMP_MAX_IMAGE           65536U
#define CDK2_QEMU_FMP_FACTORY_IMAGE_SIZE  1U
#define CDK2_QEMU_FMP_AUTH_HEADER_SIZE    344U
#define CDK2_QEMU_FMP_STATE_HEADER_SIZE   52U
#define CDK2_QEMU_FMP_STATE_LEGACY_FORMAT 1U
#define CDK2_QEMU_FMP_STATE_FORMAT        2U
#define CDK2_QEMU_FMP_STATE_COMMIT        0x434d4954U
#define CDK2_QEMU_FMP_VARIABLE_ATTRIBUTES (BIT0 | BIT1 | BIT2)
#define CDK2_QEMU_FMP_IMAGE_UPDATABLE     BIT0
#define CDK2_QEMU_FMP_RESET_REQUIRED      BIT1
#define CDK2_QEMU_FMP_IMAGE_VALID         CDK2_FMP_IMAGE_UPDATABLE_VALID
#define CDK2_QEMU_FMP_IMAGE_INVALID       CDK2_FMP_IMAGE_UPDATABLE_INVALID

#ifndef EFI_INCOMPATIBLE_VERSION
#define EFI_INCOMPATIBLE_VERSION EFIERR(25)
#endif

struct cdk2_qemu_fmp_auth {
	uint8_t magic[8];
	uint32_t header_size;
	uint32_t version;
	uint32_t image_size;
	uint32_t reserved0;
	uint8_t certificate_sha256[32];
	uint8_t payload_sha256[32];
	uint8_t signature[256];
	uint8_t payload[];
} __packed;

struct cdk2_qemu_fmp_state_header {
	uint32_t format;
	uint32_t generation;
	uint32_t version;
	uint32_t image_size;
	uint8_t payload_sha256[32];
	uint32_t crc32;
	uint8_t payload[];
} __packed;
typedef char cdk2_qemu_fmp_auth_size_check
	[(offsetof(struct cdk2_qemu_fmp_auth, payload) == 344) ? 1 : -1];
typedef char cdk2_qemu_fmp_state_size_check
	[(offsetof(struct cdk2_qemu_fmp_state_header, payload) == 52) ? 1 : -1];

typedef EFI_STATUS cdk2_qemu_fmp_read_fn(void *context, BOOLEAN slot,
				      UINTN *size, void *buffer);
typedef EFI_STATUS cdk2_qemu_fmp_write_fn(void *context, BOOLEAN slot,
				       UINTN size, const void *buffer);
typedef EFI_STATUS cdk2_qemu_fmp_crc32_fn(void *data, UINTN size, uint32_t *crc32);
typedef BOOLEAN cdk2_qemu_fmp_rsa_verify_fn(void *context, const uint8_t digest[32],
					 const uint8_t signature[256]);
typedef EFI_STATUS cdk2_qemu_fmp_alloc_fn(void *context, UINTN size, void **buffer);
typedef void cdk2_qemu_fmp_free_fn(void *context, void *buffer);

struct cdk2_qemu_fmp_ops {
	cdk2_qemu_fmp_read_fn *read;
	cdk2_qemu_fmp_write_fn *write;
	cdk2_qemu_fmp_crc32_fn *crc32;
	cdk2_qemu_fmp_rsa_verify_fn *rsa_verify;
	cdk2_qemu_fmp_alloc_fn *alloc;
	cdk2_qemu_fmp_free_fn *free;
};

struct cdk2_qemu_fmp {
	const struct cdk2_qemu_fmp_ops *ops;
	void *context;
	uint32_t generation;
	uint32_t version;
	uint32_t image_size;
	uint8_t *image;
	BOOLEAN active_slot;
};

void cdk2_qemu_fmp_sha256(const void *data, UINTN size, uint8_t digest[32]);
BOOLEAN cdk2_qemu_fmp_rsa2048_verify(const uint8_t digest[32], const uint8_t signature[256]);
EFI_STATUS cdk2_qemu_fmp_authenticate(struct cdk2_qemu_fmp *fmp, const void *buffer,
				      UINTN size, const uint8_t **payload, uint32_t *version);
EFI_STATUS cdk2_qemu_fmp_recover(struct cdk2_qemu_fmp *fmp);
EFI_STATUS cdk2_qemu_fmp_commit(struct cdk2_qemu_fmp *fmp, uint32_t version,
			      const void *image, uint32_t image_size);
void cdk2_qemu_fmp_release(struct cdk2_qemu_fmp *fmp);

struct cdk2_qemu_fmp_protocol {
	struct cdk2_fmp_protocol abi;
	struct cdk2_qemu_fmp *owner;
};
void cdk2_qemu_fmp_protocol_init(struct cdk2_qemu_fmp_protocol *protocol,
				 struct cdk2_qemu_fmp *owner);
BOOLEAN cdk2_qemu_fmp_configure_image_guid(const char *text);

extern const EFI_GUID cdk2_qemu_fmp_protocol_guid;
extern EFI_GUID cdk2_qemu_fmp_image_guid;
extern const EFI_GUID cdk2_qemu_fmp_variable_guid;
EFI_STATUS CDK2_MS_ABI cdk2_qemu_test_fmp_entry(void *image,
					    struct cdk2_system_table_view *system_table);
EFI_STATUS CDK2_MS_ABI cdk2_qemu_test_fmp_unload(void *image);

#endif
