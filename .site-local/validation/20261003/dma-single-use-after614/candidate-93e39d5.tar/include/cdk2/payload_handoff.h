/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_PAYLOAD_HANDOFF_H_
#define CDK2_PAYLOAD_HANDOFF_H_

#include <stdint.h>

#pragma pack(push, 1)
struct cdk2_payload_header {
	uint16_t revision, length;
};
#pragma pack(pop)

#endif
