/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_DEADLINE_H
#define CDK2_DEADLINE_H

#include <stdbool.h>
#include <stdint.h>

#include <guid/tsc_info.h>

#define CDK2_DEADLINE_REVISION 2U
#define CDK2_DEADLINE_ACTIVE 0x00000001U
#define CDK2_DEADLINE_FAILED 0x00000002U
#define CDK2_DEADLINE_CONSTANT_TSC 0x00000004U
#define CDK2_DEADLINE_MEASURED_TSC 0x00000008U
#define CDK2_DEADLINE_CLOCK_MASK \
	(CDK2_DEADLINE_CONSTANT_TSC | CDK2_DEADLINE_MEASURED_TSC)
#define CDK2_DEADLINE_FLAG_MASK \
	(CDK2_DEADLINE_ACTIVE | CDK2_DEADLINE_FAILED | \
	 CDK2_DEADLINE_CLOCK_MASK)
#define CDK2_DEADLINE_PROTOCOL_GUID \
	{ 0x9c97646b, 0x29be, 0x447c, \
	  { 0xa2, 0x56, 0x79, 0xba, 0x83, 0xaa, 0x0a, 0x87 } }

enum cdk2_deadline_start_result {
	CDK2_DEADLINE_START_SUCCESS,
	CDK2_DEADLINE_START_INVALID_ARGUMENT,
	CDK2_DEADLINE_START_INVALID_CLOCK,
	CDK2_DEADLINE_START_OVERFLOW,
};

/* Value-only state that can be copied between linear driver stages. */
struct cdk2_deadline {
	uint16_t revision;
	uint16_t length;
	uint32_t flags;
	uint64_t expires_at_ticks;
};

enum cdk2_deadline_start_result
cdk2_deadline_start(struct cdk2_deadline *deadline,
		    const struct cdk2_tsc_info *tsc_info, uint32_t seconds,
		    uint64_t now_tsc);
enum cdk2_deadline_start_result
cdk2_deadline_start_measured_tsc(struct cdk2_deadline *deadline,
				 const struct cdk2_tsc_info *tsc_info,
				 uint32_t seconds, uint64_t now_tsc);
bool cdk2_deadline_expired_at(const struct cdk2_deadline *deadline,
	uint64_t now_tsc);

#endif
