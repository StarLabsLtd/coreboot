/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_BDS_SETTINGS_H_
#define CDK2_BDS_SETTINGS_H_

#include <cdk2/lvgl_settings_form.h>
#include <cdk2/lvgl_ui.h>

UINT64 cdk2_bds_adjusted_setting_value(UINT64 value, UINT64 minimum,
	UINT64 maximum, UINT64 step, INTN adjustment);
EFI_STATUS cdk2_bds_browse_settings(struct cdk2_lvgl_ui_protocol *ui,
	struct cdk2_runtime_services_view *runtime);

#endif
