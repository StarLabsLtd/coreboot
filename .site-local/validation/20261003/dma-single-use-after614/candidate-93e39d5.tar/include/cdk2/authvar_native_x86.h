/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_AUTHVAR_NATIVE_X86_H
#define CDK2_AUTHVAR_NATIVE_X86_H

#include <cdk2/authvar_transport.h>

/*
 * Unselected native trigger callback. Port/value come from the validated
 * coreboot endpoint. RAX/RDX are fully zero-extended; RCX is zero so the
 * existing adapter's EAX/ECX packed value is precisely the command. No
 * register argument carries a mailbox pointer or request size. No private
 * context is accessed. A returning SMI is not itself a successful reply:
 * the existing client still validates the complete shared response.
 */
EFI_STATUS cdk2_authvar_native_x86_trigger(void *context, UINT16 port, UINT8 value);
EFI_STATUS cdk2_authvar_native_x86_cache(void *context, void *base, UINTN size);
void cdk2_authvar_native_x86_barrier(void *context);

#endif
