/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_AUTHVAR_RUNTIME_OWNER_H
#define CDK2_AUTHVAR_RUNTIME_OWNER_H

#include <stdbool.h>
#include <cdk2/authvar_runtime.h>

/* This owner publishes no runtime services or VariablePolicy protocol. */
struct cdk2_authvar_runtime_owner {
	struct cdk2_authvar_client client;
	struct cdk2_authvar_runtime runtime;
	bool failed;
	bool entered_runtime;
	bool converted;
};

typedef EFI_STATUS cdk2_authvar_allocate_runtime_fn(size_t size, void **buffer);
typedef void cdk2_authvar_release_runtime_fn(void *buffer);
typedef EFI_STATUS cdk2_authvar_convert_runtime_fn(void **pointer);

EFI_STATUS cdk2_authvar_endpoint_from_hob(const void *hob_list,
	struct cdk2_authvar_endpoint *endpoint);
EFI_STATUS cdk2_authvar_runtime_owner_prepare(const void *hob_list,
	cdk2_authvar_allocate_runtime_fn *allocate_runtime,
	cdk2_authvar_release_runtime_fn *release_runtime,
	cdk2_authvar_trigger_fn *trigger, cdk2_authvar_cache_fn *cache,
	cdk2_authvar_barrier_fn *barrier,
	struct cdk2_authvar_runtime_owner **owner);
/* Only before publication/EBS; the caller closes its events first. */
void cdk2_authvar_runtime_owner_destroy(struct cdk2_authvar_runtime_owner *owner,
	cdk2_authvar_release_runtime_fn *release_runtime);
EFI_STATUS cdk2_authvar_runtime_owner_enter_runtime(
	struct cdk2_authvar_runtime_owner *owner);
/*
 * Fresh coherent boot-policy bytes from a GENERAL-capable endpoint. This does
 * not establish origin or protect the caller's copy after return. The caller
 * owns the buffer and must serialize its authorization decision. Successful
 * output is copied; failures leave it unchanged except required size on
 * BUFFER_TOO_SMALL. Private BOOT delivery and closed owners refuse before SMI.
 */
EFI_STATUS cdk2_authvar_runtime_owner_image_policy_snapshot(
	struct cdk2_authvar_runtime_owner *owner, void *data, size_t capacity, size_t *size);
EFI_STATUS cdk2_authvar_runtime_owner_convert(
	struct cdk2_authvar_runtime_owner **owner,
	cdk2_authvar_convert_runtime_fn *convert_pointer);

#endif
