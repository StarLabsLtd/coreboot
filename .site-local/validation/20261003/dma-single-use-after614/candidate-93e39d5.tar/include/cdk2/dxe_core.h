/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_DXE_CORE_H_
#define CDK2_DXE_CORE_H_

#include <uefi.h>
#include <cdk2/direct_image_table.h>
#include <cdk2/dxe_image_transaction.h>

#ifndef EFI_NO_MEDIA
#define EFI_NO_MEDIA EFIERR(12)
#endif
#include <cdk2/dxe_core_abi.h>
#include <cdk2/linear_boot.h>
#include <cdk2/runtime_arch.h>

#define CDK2_DXE_ACCESS_DENIED EFIERR(15)

struct cdk2_fat_simple_fs_protocol;
#define CDK2_DXE_MAX_HANDLES 512U
#define CDK2_DXE_MAX_PROTOCOLS 2048U
#define CDK2_DXE_MAX_OPENS 4096U
#define CDK2_DXE_MAX_EVENTS 1024U
#define CDK2_DXE_MAX_IMAGES 256U
#define CDK2_DXE_MAX_DRIVERS 256U
#define CDK2_DXE_MAX_CONFIGURATION_TABLES 64U
#define CDK2_DXE_MAX_NOTIFICATIONS 256U
#define CDK2_DXE_MAX_GCD_RANGES 2048U

typedef void cdk2_dxe_notify_fn(void *event, void *context) CDK2_MS_ABI;
typedef void *cdk2_dxe_alloc_fn(UINTN size, void *context);
typedef EFI_STATUS cdk2_dxe_span_fn(const void *address, UINTN *size,
	UINT64 generation[], void *context);
typedef EFI_STATUS cdk2_dxe_pe_load_fn(const void *source, UINTN source_size,
	void *destination, UINTN destination_size, void **entry, UINTN *image_size,
	void *context);
typedef BOOLEAN cdk2_dxe_protocol_present_fn(const EFI_GUID *guid,
	void *context);
enum cdk2_dxe_driver_origin {
	CDK2_DXE_DRIVER_FIRMWARE_VOLUME = 0,
	CDK2_DXE_DRIVER_LINKED_PRIMARY,
};
typedef EFI_STATUS cdk2_dxe_driver_start_fn(const EFI_GUID *guid,
	const void *image, UINTN image_size, enum cdk2_dxe_driver_origin origin,
	void *context);
typedef EFI_STATUS cdk2_dxe_section_extract_fn(UINT8 type,
	const void *section, UINTN section_size, void **output, UINTN *output_size,
	void *context);
typedef void cdk2_dxe_section_release_fn(void *buffer, void *context);

EFI_STATUS cdk2_dxe_validate_guided_section(EFI_STATUS status,
	UINT32 authentication, const void *output, UINTN output_size);
EFI_STATUS cdk2_dxe_linear_unimplemented(
	const struct cdk2_linear_state *state, BOOLEAN *compatibility_allowed);
EFI_STATUS cdk2_dxe_linear_validate_platform_hobs(void *hob_list);
EFI_STATUS cdk2_dxe_linear_require_protocols(const EFI_GUID *guids,
	UINTN count, cdk2_dxe_protocol_present_fn *present, void *context);
EFI_STATUS cdk2_dxe_linear_ram_capsule_present(void *hob_list,
	BOOLEAN *present);
EFI_STATUS cdk2_dxe_record_connection(EFI_STATUS status, UINTN *connected);

struct cdk2_dxe_fv_protocol {
	EFI_STATUS (*get_attributes)(void *, UINT64 *) CDK2_MS_ABI;
	void *set_attributes;
	EFI_STATUS (*read_file)(void *, const EFI_GUID *, void **,
		UINTN *, UINT8 *, UINT32 *, UINT32 *) CDK2_MS_ABI;
	EFI_STATUS (*read_section)(void *, const EFI_GUID *,
		UINTN, UINTN, void **, UINTN *, UINT32 *) CDK2_MS_ABI;
	void *write_file;
	EFI_STATUS (*get_next_file)(void *, void *, UINT8 *,
		EFI_GUID *, UINT32 *, UINTN *) CDK2_MS_ABI;
	UINT32 key_size;
	void *parent;
	struct cdk2_dxe_core *owner;
	const UINT8 *volume;
	UINTN volume_size;
};

struct cdk2_dxe_event {
	UINT32 type;
	UINTN tpl;
	cdk2_dxe_notify_fn *notify;
	void *context;
	EFI_GUID group;
	BOOLEAN grouped;
	BOOLEAN signaled;
	BOOLEAN notify_pending;
	BOOLEAN closed;
	BOOLEAN timer_active;
	UINT64 trigger;
	UINT64 period;
	void *runtime_entry;
};

struct cdk2_dxe_events {
	struct cdk2_dxe_event events[CDK2_DXE_MAX_EVENTS];
	UINTN count;
	UINTN current_tpl;
	UINT64 time;
};

struct cdk2_dxe_protocol {
	void *handle;
	UINT64 registration;
	EFI_GUID guid;
	void *interface;
	UINTN interface_size;
	UINT64 interface_generation;
	BOOLEAN interface_dynamic;
	void *owner_image;
	UINT64 owner_generation;
};

struct cdk2_dxe_open {
	void *handle;
	EFI_GUID guid;
	void *agent;
	void *controller;
	UINT32 attributes;
	UINT32 count;
};

struct cdk2_dxe_database {
	void *handles[CDK2_DXE_MAX_HANDLES];
	struct cdk2_dxe_protocol protocols[CDK2_DXE_MAX_PROTOCOLS];
	struct cdk2_dxe_open opens[CDK2_DXE_MAX_OPENS];
	UINTN handle_count;
	UINTN protocol_count;
	UINTN open_count;
	UINTN next_handle;
	UINT64 next_registration;
	cdk2_dxe_alloc_fn *allocate;
	void *allocate_context;
	cdk2_dxe_span_fn *span;
	void *span_context;
};

struct cdk2_dxe_pool_record {
	void *base;
	UINTN size;
	UINT64 generation;
	BOOLEAN live;
};

struct cdk2_dxe_memory {
	UINT8 *base;
	UINTN pages;
	UINTN total_pages;
	UINTN map_key;
	UINT8 *allocated;
	UINT32 *type;
	struct cdk2_dxe_memory_descriptor *external;
	UINTN external_count;
	struct cdk2_dxe_pool_record *pools;
	UINTN pool_count, pool_capacity, pool_pages;
	UINT64 next_pool_generation;
};

struct cdk2_dxe_memory_descriptor {
	UINT32 type;
	UINT32 padding;
	UINT64 physical_start;
	UINT64 virtual_start;
	UINT64 number_of_pages;
	UINT64 attribute;
};

struct cdk2_dxe_image {
	void *handle;
	void *parent;
	void *base;
	UINTN pages;
	UINTN size;
	cdk2_dxe_image_entry_fn *entry;
	EFI_STATUS exit_status;
	UINTN exit_data_size;
	CHAR16 *exit_data;
	BOOLEAN started;
	BOOLEAN exited;
	BOOLEAN unloadable;
	BOOLEAN exit_active;
	UINT64 load_generation;
	UINTN protocol_pins;
	void *exit_jump[5];
	void *owned_file_path;
	void *owned_device_path;
	void *runtime_entry;
	void *runtime_relocation;
	struct cdk2_dxe_image_transaction *transaction;
	UINT64 transaction_allocation_generation;
	const struct cdk2_dxe_driver *linked_primary_driver;
	struct {
		UINT32 revision;
		UINT32 padding;
		void *parent_handle;
		void *system_table;
		void *device_handle;
		void *file_path;
		void *reserved;
		UINT32 load_options_size;
		UINT32 options_padding;
		void *load_options;
		void *image_base;
		UINT64 image_size;
		UINT32 image_code_type;
		UINT32 image_data_type;
		void *unload;
	} loaded_image;
};

struct cdk2_dxe_images {
	struct cdk2_dxe_image images[CDK2_DXE_MAX_IMAGES];
	struct cdk2_dxe_memory *memory;
	cdk2_dxe_pe_load_fn *load;
	void *load_context;
	void *system_table;
	UINTN count;
	UINTN next_handle;
	UINT64 next_transaction_generation;
};

enum cdk2_dxe_direct_disposition {
	CDK2_DXE_DIRECT_PENDING = 0,
	CDK2_DXE_DIRECT_STARTED,
	CDK2_DXE_DIRECT_SKIPPED_HARDWARE_ABSENT,
	CDK2_DXE_DIRECT_SKIPPED_BACKEND_UNSELECTED,
};

struct cdk2_dxe_driver {
	EFI_GUID guid;
	const void *volume;
	const void *image;
	UINTN image_size;
	const UINT8 *dependency;
	UINTN dependency_size;
	BOOLEAN started;
	BOOLEAN failed;
	EFI_STATUS failure_status;
	BOOLEAN scheduled;
	void *extracted[16];
	UINTN extracted_count;
	const UINT8 *encapsulated_file;
	UINTN encapsulated_file_size;
	BOOLEAN extraction_pending;
	BOOLEAN direct;
	enum cdk2_direct_image_role direct_role;
	enum cdk2_dxe_direct_disposition direct_disposition;
};

struct cdk2_dxe_dispatcher {
	struct cdk2_dxe_driver drivers[CDK2_DXE_MAX_DRIVERS];
	struct cdk2_direct_image_table_view direct_table;
	cdk2_dxe_protocol_present_fn *present;
	cdk2_dxe_driver_start_fn *start;
	cdk2_dxe_section_extract_fn *extract;
	cdk2_dxe_section_release_fn *release;
	void *context;
	void *extract_context;
	UINTN count;
	UINTN direct_count;
};

struct cdk2_dxe_gcd_range {
	UINT64 base;
	UINT64 length;
	UINT64 capabilities;
	UINT64 attributes;
	UINT32 type;
	BOOLEAN allocated;
	BOOLEAN io;
	void *image;
	void *device;
};

struct cdk2_dxe_core {
	struct cdk2_dxe_database database;
	struct cdk2_dxe_events events;
	struct cdk2_dxe_memory memory;
	struct cdk2_dxe_images images;
	struct cdk2_dxe_dispatcher dispatcher;
	struct cdk2_dxe_boot_services boot_services;
	struct cdk2_dxe_runtime_services runtime_services;
	struct cdk2_dxe_services dxe_services;
	struct cdk2_dxe_system_table system_table;
	struct cdk2_dxe_configuration_table
		configuration_tables[CDK2_DXE_MAX_CONFIGURATION_TABLES];
	struct {
		struct cdk2_dxe_system_table system_table;
		struct cdk2_dxe_runtime_services runtime_services;
		struct cdk2_dxe_configuration_table
			configuration_tables[CDK2_DXE_MAX_CONFIGURATION_TABLES];
		CHAR16 vendor[5];
	} *runtime_storage;
	void *runtime_unsupported_stub;
	struct {
		struct cdk2_runtime_list_entry link;
		void *image_base;
		UINT64 image_size;
		void *relocation_data;
		void *handle;
		void *runtime_node;
		BOOLEAN linked;
	} runtime_images[CDK2_DXE_MAX_IMAGES];
	struct {
		struct cdk2_runtime_list_entry link;
		UINT32 type;
		UINTN notify_tpl;
		cdk2_dxe_notify_fn *notify;
		void *context;
		void *event;
		void *runtime_node;
		BOOLEAN linked;
	} runtime_events[CDK2_DXE_MAX_EVENTS];
	struct {
		EFI_GUID guid;
		void *event;
		void *pending[CDK2_DXE_MAX_HANDLES];
		UINTN cursor, pending_count;
		UINT64 generation;
		BOOLEAN active;
	} notifications[CDK2_DXE_MAX_NOTIFICATIONS];
	UINT64 next_notification_generation;
	struct cdk2_dxe_gcd_range gcd_ranges[CDK2_DXE_MAX_GCD_RANGES];
	struct cdk2_dxe_memory_descriptor external_memory[128];
	UINTN external_memory_count;
	UINTN gcd_count;
	UINT64 monotonic_count;
	const UINT8 *firmware_volume;
	UINTN firmware_volume_size;
	void *firmware_volume_handle;
	struct cdk2_dxe_fv_protocol firmware_volume_protocol;
	UINT8 firmware_volume_path[24];
	struct {
		const UINT8 *volume;
		UINTN size;
		void *handle;
		struct cdk2_dxe_fv_protocol protocol;
		UINT8 path[24];
	} additional_firmware_volumes[15];
	UINTN additional_firmware_volume_count;
};

EFI_STATUS cdk2_dxe_database_initialize(struct cdk2_dxe_database *database);
EFI_STATUS cdk2_dxe_database_set_allocator(struct cdk2_dxe_database *database,
	cdk2_dxe_alloc_fn *allocate, void *context);
EFI_STATUS cdk2_dxe_database_set_span_resolver(struct cdk2_dxe_database *database,
	cdk2_dxe_span_fn *span, void *context);
EFI_STATUS cdk2_dxe_install(struct cdk2_dxe_database *database, void **handle,
	const EFI_GUID *guid, void *interface);
EFI_STATUS cdk2_dxe_restore(struct cdk2_dxe_database *database, void *handle,
	const EFI_GUID *guid, void *interface);
EFI_STATUS cdk2_dxe_connect_exact(void *controller, void *driver,
	void *remaining);
BOOLEAN cdk2_dxe_connection_present(void *controller, void *image);
EFI_STATUS cdk2_dxe_reinstall(struct cdk2_dxe_database *database, void *handle,
	const EFI_GUID *guid, void *old_interface, void *new_interface);
EFI_STATUS cdk2_dxe_uninstall(struct cdk2_dxe_database *database, void *handle,
	const EFI_GUID *guid, void *interface);
EFI_STATUS cdk2_dxe_fv_unmount(struct cdk2_dxe_core *core, void *handle);
EFI_STATUS cdk2_dxe_handle(struct cdk2_dxe_database *database, void *handle,
	const EFI_GUID *guid, void **interface);
EFI_STATUS cdk2_dxe_device_path_size(const void *path, UINTN path_bytes,
	UINTN *size);
EFI_STATUS cdk2_dxe_protocol_span_set(struct cdk2_dxe_database *database,
	void *handle, const EFI_GUID *guid, void *interface, UINTN size);
EFI_STATUS cdk2_dxe_protocol_span_set_owned(struct cdk2_dxe_database *database,
	void *handle, const EFI_GUID *guid, void *interface);
EFI_STATUS cdk2_dxe_protocol_span_shrink(struct cdk2_dxe_database *database,
	void *handle, const EFI_GUID *guid, void *interface, UINTN size);
EFI_STATUS cdk2_dxe_handle_span(struct cdk2_dxe_database *database,
	void *handle, const EFI_GUID *guid, void **interface, UINTN *size);
EFI_STATUS cdk2_dxe_locate(struct cdk2_dxe_database *database,
	const EFI_GUID *guid, void ***handles, UINTN *count);
EFI_STATUS cdk2_dxe_open(struct cdk2_dxe_database *database, void *handle,
	const EFI_GUID *guid, void **interface, void *agent, void *controller,
	UINT32 attributes);
EFI_STATUS cdk2_dxe_close(struct cdk2_dxe_database *database, void *handle,
	const EFI_GUID *guid, void *agent, void *controller);
EFI_STATUS cdk2_dxe_validate_nvme_children(struct cdk2_dxe_database *database,
	void *selected_controller, void *nvme_binding);
EFI_STATUS cdk2_dxe_device_esps(struct cdk2_dxe_database *database,
	void *device, void *partition_binding, void **esps, UINTN capacity,
	UINTN *count);
EFI_STATUS cdk2_dxe_validate_boot_file(
	struct cdk2_fat_simple_fs_protocol *filesystem, CHAR16 *path,
	UINT32 *file_size);
EFI_STATUS cdk2_dxe_read_boot_file(
	struct cdk2_fat_simple_fs_protocol *filesystem, CHAR16 *path,
	UINT32 expected_size, void *buffer);
EFI_STATUS cdk2_dxe_device_path_size(const void *path, UINTN path_bytes,
	UINTN *size);
EFI_STATUS cdk2_dxe_build_file_path(const void *device_path,
	UINTN device_path_bytes, const CHAR16 *file_path, void *buffer,
	UINTN capacity, UINTN *size);
EFI_STATUS cdk2_dxe_resolve_device_path(struct cdk2_dxe_database *database,
	const EFI_GUID *protocol, const void *path, UINTN path_size, void **handle);
typedef EFI_STATUS (CDK2_MS_ABI cdk2_dxe_unload_image_fn)(void *image);
EFI_STATUS cdk2_dxe_cleanup_returned_image(void *image,
	cdk2_dxe_unload_image_fn *unload, BOOLEAN start_returned,
	EFI_STATUS operation_status, EFI_STATUS exit_cleanup_status,
	EFI_STATUS *unload_status);
EFI_STATUS cdk2_dxe_events_initialize(struct cdk2_dxe_events *events);
EFI_STATUS cdk2_dxe_event_create(struct cdk2_dxe_events *events, UINT32 type,
	UINTN tpl, cdk2_dxe_notify_fn *notify, void *context,
	const EFI_GUID *group, void **event);
EFI_STATUS cdk2_dxe_event_signal(struct cdk2_dxe_events *events, void *event);
EFI_STATUS cdk2_dxe_event_check(struct cdk2_dxe_events *events, void *event);
EFI_STATUS cdk2_dxe_event_wait(struct cdk2_dxe_events *events, UINTN count,
	void **event, UINTN *index);
EFI_STATUS cdk2_dxe_event_close(struct cdk2_dxe_events *events, void *event);
EFI_STATUS cdk2_dxe_event_timer(struct cdk2_dxe_events *events, void *event,
	UINTN type, UINT64 trigger);
void cdk2_dxe_event_advance(struct cdk2_dxe_events *events, UINT64 elapsed);
void cdk2_dxe_event_dispatch_pending(struct cdk2_dxe_events *events);
EFI_STATUS cdk2_dxe_memory_initialize(struct cdk2_dxe_memory *memory,
	void *base, UINTN pages);
EFI_STATUS cdk2_dxe_allocate_pages(struct cdk2_dxe_memory *memory, UINT32 type,
	UINTN pages, void **address);
EFI_STATUS cdk2_dxe_allocate_pages_policy(struct cdk2_dxe_memory *memory,
	UINT32 type, UINTN pages, UINTN allocation, UINT64 *address);
EFI_STATUS cdk2_dxe_memory_set_external(struct cdk2_dxe_memory *memory,
	struct cdk2_dxe_memory_descriptor *descriptors, UINTN count);
EFI_STATUS cdk2_dxe_memory_refine_external_allocation(
	struct cdk2_dxe_memory_descriptor *descriptors, UINTN *count,
	UINT64 start, UINT64 length, UINT32 type);
EFI_STATUS cdk2_dxe_free_pages(struct cdk2_dxe_memory *memory, void *address,
	UINTN pages);
EFI_STATUS cdk2_dxe_allocate_pool(struct cdk2_dxe_memory *memory, UINT32 type,
	UINTN size, void **buffer);
EFI_STATUS cdk2_dxe_free_pool(struct cdk2_dxe_memory *memory, void *buffer);
EFI_STATUS cdk2_dxe_memory_readable_span(struct cdk2_dxe_memory *memory,
	const void *address, UINTN *size, UINT64 *generation);
EFI_STATUS cdk2_dxe_memory_allocation_generation(
	struct cdk2_dxe_memory *memory, const void *address, UINTN size,
	UINT64 *generation);
EFI_STATUS cdk2_dxe_get_memory_map(struct cdk2_dxe_memory *memory,
	UINTN *size, struct cdk2_dxe_memory_descriptor *map, UINTN *key,
	UINTN *descriptor_size, UINT32 *descriptor_version);
EFI_STATUS cdk2_dxe_images_initialize(struct cdk2_dxe_images *images,
	struct cdk2_dxe_memory *memory, cdk2_dxe_pe_load_fn *load,
	void *load_context, void *system_table);
EFI_STATUS cdk2_dxe_image_load(struct cdk2_dxe_images *images, void *parent,
	const void *source, UINTN source_size, void **handle);
EFI_STATUS cdk2_dxe_image_transaction_prepare(struct cdk2_dxe_images *images,
	const void *source, UINTN source_size, const void *path, UINTN path_size,
	struct cdk2_dxe_image_transaction **transaction,
	UINT64 *allocation_generation);
EFI_STATUS cdk2_dxe_image_transaction_validate_owned(
	struct cdk2_dxe_images *images,
	const struct cdk2_dxe_image_transaction *transaction,
	UINT64 allocation_generation);
EFI_STATUS cdk2_dxe_image_transaction_advance(
	struct cdk2_dxe_images *images,
	struct cdk2_dxe_image_transaction *transaction,
	UINT64 allocation_generation,
	enum cdk2_dxe_image_transaction_state state);
void cdk2_dxe_image_transaction_release(struct cdk2_dxe_images *images,
	struct cdk2_dxe_image_transaction *transaction,
	UINT64 allocation_generation);
EFI_STATUS cdk2_dxe_image_start(struct cdk2_dxe_images *images, void *handle,
	EFI_STATUS *exit_status);
EFI_STATUS cdk2_dxe_image_exit(struct cdk2_dxe_images *images, void *handle,
	EFI_STATUS status);
EFI_STATUS cdk2_dxe_image_unload(struct cdk2_dxe_images *images, void *handle);
EFI_STATUS cdk2_dxe_dispatcher_initialize(struct cdk2_dxe_dispatcher *dispatcher,
	cdk2_dxe_protocol_present_fn *present, cdk2_dxe_driver_start_fn *start,
	void *context);
EFI_STATUS cdk2_dxe_dispatcher_set_extractor(
	struct cdk2_dxe_dispatcher *dispatcher,
	cdk2_dxe_section_extract_fn *extract,
	cdk2_dxe_section_release_fn *release, void *context);
EFI_STATUS cdk2_dxe_dispatcher_scan(struct cdk2_dxe_dispatcher *dispatcher,
	const void *volume, UINTN volume_size);
EFI_STATUS cdk2_dxe_dispatcher_seed_direct(
	struct cdk2_dxe_dispatcher *dispatcher,
	const struct cdk2_direct_image_table_view *table);
EFI_STATUS cdk2_dxe_dispatcher_direct_complete(
	const struct cdk2_dxe_dispatcher *dispatcher);
EFI_STATUS cdk2_dxe_dispatcher_skip_direct(
	struct cdk2_dxe_dispatcher *dispatcher, const EFI_GUID *guid,
	enum cdk2_dxe_direct_disposition disposition);
EFI_STATUS cdk2_dxe_dispatcher_reset(struct cdk2_dxe_dispatcher *dispatcher);
EFI_STATUS cdk2_dxe_direct_images_from_hob(const void *hob_list,
	struct cdk2_direct_image_table_view *table);
EFI_STATUS cdk2_dxe_dispatch_one(struct cdk2_dxe_dispatcher *dispatcher,
	const EFI_GUID *guid);
EFI_STATUS cdk2_dxe_dispatch_compat_one(struct cdk2_dxe_dispatcher *dispatcher,
	const EFI_GUID *guid);
EFI_STATUS cdk2_dxe_core_initialize(struct cdk2_dxe_core *core, void *memory,
	UINTN pages);
EFI_STATUS cdk2_dxe_discard_failed_image(struct cdk2_dxe_core *core,
	void *handle);
EFI_STATUS cdk2_dxe_runtime_image_register(struct cdk2_dxe_core *core,
	struct cdk2_dxe_image *image);
void cdk2_dxe_runtime_image_unregister(struct cdk2_dxe_core *core,
	struct cdk2_dxe_image *image);
#ifdef CDK2_HOST_TEST
UINTN cdk2_dxe_test_runtime_image_register_calls(void);
UINTN cdk2_dxe_test_image_service_trace_depth(void);
#endif
EFI_STATUS cdk2_dxe_gcd_initialize(struct cdk2_dxe_core *core);
void cdk2_dxe_gcd_set_fv_ops(EFI_STATUS (*scan)(const void *, UINTN),
	EFI_STATUS (*mount)(const void *,
	UINTN, void **));
EFI_STATUS cdk2_dxe_fv_mount(struct cdk2_dxe_core *core, const void *volume,
	UINTN size);

#endif
