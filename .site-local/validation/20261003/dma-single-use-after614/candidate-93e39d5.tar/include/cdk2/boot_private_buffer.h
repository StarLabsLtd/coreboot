/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_BOOT_PRIVATE_BUFFER_H
#define CDK2_BOOT_PRIVATE_BUFFER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <coreboot_tables.h>

struct cdk2_boot_private_buffer {
	struct cb_payload_boot_private_buffer record;
	uint32_t state;
};

struct cdk2_boot_private_span {
	const uint8_t *bytes;
	size_t size;
};

/*
 * Dormant lifetime bookkeeping, not delivery authority. Bind a zero-initialized,
 * exclusively owned object once using the local result of the actual coreboot
 * importer/reservation helper. Allocation metadata cannot authenticate origin,
 * protect a resumed CPU copy interval, or revoke an already returned pointer.
 * The caller owns the reserved backing memory and must keep the owner immutable.
 * No allocator, loader hook, policy registration or S3 callback is supplied here.
 */
bool cdk2_boot_private_buffer_bind(struct cdk2_boot_private_buffer *owner,
	const struct cb_payload_boot_private_buffer *imported);
bool cdk2_boot_private_buffer_span(const struct cdk2_boot_private_buffer *owner,
	uint32_t slot, struct cdk2_boot_private_span *output);

/*
 * Terminally denies access before scrubbing all three slots. The trusted caller
 * must close before its first external LoadImage/StartImage, EBS or S3 boundary.
 * Neither return from an external image nor a second bind can reopen this owner.
 */
bool cdk2_boot_private_buffer_close(struct cdk2_boot_private_buffer *owner);

#ifdef CDK2_HOST_TEST
void cdk2_boot_private_buffer_scrub_observe(
	const struct cdk2_boot_private_buffer *owner, size_t scrubbed);
#endif

#endif
