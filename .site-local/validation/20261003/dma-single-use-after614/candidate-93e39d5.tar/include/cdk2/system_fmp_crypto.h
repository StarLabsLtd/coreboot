/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_CRYPTO_H
#define CDK2_SYSTEM_FMP_CRYPTO_H

#include <cdk2/system_fmp_auth.h>

#define CDK2_SYSTEM_FMP_SHA256_SIZE 32U

void cdk2_system_fmp_sha256(const void *data, size_t size,
	uint8_t digest[CDK2_SYSTEM_FMP_SHA256_SIZE]);

/*
 * Native RSA-2048/SHA-256 detached PKCS7 verifier.  The context is unused;
 * it exists only to match the authentication-envelope callback ABI.
 */
bool cdk2_system_fmp_pkcs7_verify(void *context,
	const uint8_t *signature, size_t signature_size,
	const uint8_t *certificate, size_t certificate_size,
	const struct cdk2_system_fmp_signed_span signed_data[2]);

#endif
