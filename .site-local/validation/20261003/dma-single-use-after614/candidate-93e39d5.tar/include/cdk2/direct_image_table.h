/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_DIRECT_IMAGE_TABLE_H_
#define CDK2_DIRECT_IMAGE_TABLE_H_

#include <uefi.h>

#define CDK2_DIRECT_IMAGE_TABLE_MAGIC 0x31474d49324b4443ULL
#define CDK2_DIRECT_IMAGE_TABLE_REVISION 1U
#define CDK2_DIRECT_IMAGE_TABLE_HEADER_SIZE 32U
#define CDK2_DIRECT_IMAGE_TABLE_RECORD_SIZE 40U
#define CDK2_DIRECT_IMAGE_TABLE_MAX_RECORDS 256U
#define CDK2_DIRECT_IMAGE_ALIGNMENT 8U

#define CDK2_DIRECT_IMAGE_HANDOFF_REVISION 1U
#define CDK2_DIRECT_IMAGE_HANDOFF_SIZE 56U

extern const EFI_GUID cdk2_direct_image_handoff_guid;

struct cdk2_direct_image_handoff {
	UINT16 revision;
	UINT16 size;
	UINT32 flags;
	UINT64 payload_base;
	UINT64 payload_size;
	UINT64 table_base;
	UINT64 table_size;
	UINT64 pe_base;
	UINT64 pe_size;
};

#define CDK2_DIRECT_IMAGE_HEADER_MAGIC_OFFSET 0U
#define CDK2_DIRECT_IMAGE_HEADER_REVISION_OFFSET 8U
#define CDK2_DIRECT_IMAGE_HEADER_SIZE_OFFSET 10U
#define CDK2_DIRECT_IMAGE_HEADER_RECORD_SIZE_OFFSET 12U
#define CDK2_DIRECT_IMAGE_HEADER_FLAGS_OFFSET 14U
#define CDK2_DIRECT_IMAGE_HEADER_RECORD_COUNT_OFFSET 16U
#define CDK2_DIRECT_IMAGE_HEADER_TABLE_SIZE_OFFSET 20U
#define CDK2_DIRECT_IMAGE_HEADER_PE_SIZE_OFFSET 24U

#define CDK2_DIRECT_IMAGE_RECORD_GUID_OFFSET 0U
#define CDK2_DIRECT_IMAGE_RECORD_ROLE_OFFSET 16U
#define CDK2_DIRECT_IMAGE_RECORD_SUBSYSTEM_OFFSET 18U
#define CDK2_DIRECT_IMAGE_RECORD_FLAGS_OFFSET 20U
#define CDK2_DIRECT_IMAGE_RECORD_SOURCE_OFFSET 24U
#define CDK2_DIRECT_IMAGE_RECORD_SOURCE_SIZE_OFFSET 32U

enum cdk2_direct_image_role {
	CDK2_DIRECT_IMAGE_ROLE_DXE_CORE = 1U,
	CDK2_DIRECT_IMAGE_ROLE_BOOT_SERVICE_DRIVER = 2U,
	CDK2_DIRECT_IMAGE_ROLE_RUNTIME_DRIVER = 3U,
	CDK2_DIRECT_IMAGE_ROLE_APPLICATION = 4U,
};

struct cdk2_direct_image_table_view {
	const UINT8 *table;
	UINTN table_size;
	const UINT8 *pe_span;
	UINTN pe_span_size;
	UINT32 record_count;
};

struct cdk2_direct_image_record {
	EFI_GUID guid;
	enum cdk2_direct_image_role role;
	UINT16 subsystem;
	const UINT8 *source;
	UINTN source_size;
	UINT64 source_offset;
};

EFI_STATUS cdk2_direct_image_table_open(const void *table, UINTN table_size,
	const void *pe_span, UINTN pe_span_size,
	struct cdk2_direct_image_table_view *view);
EFI_STATUS cdk2_direct_image_table_record(
	const struct cdk2_direct_image_table_view *view, UINT32 index,
	struct cdk2_direct_image_record *record);
EFI_STATUS cdk2_direct_image_table_dxe_core(
	const struct cdk2_direct_image_table_view *view,
	struct cdk2_direct_image_record *record);
EFI_STATUS cdk2_direct_image_handoff_open(
	const struct cdk2_direct_image_handoff *handoff,
	struct cdk2_direct_image_table_view *view);

#endif
