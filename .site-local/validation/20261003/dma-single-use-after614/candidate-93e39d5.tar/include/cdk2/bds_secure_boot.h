/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_BDS_SECURE_BOOT_H_
#define CDK2_BDS_SECURE_BOOT_H_

#include <cdk2/capsule_runtime_abi.h>
#include <cdk2/lvgl_ui.h>

enum cdk2_secure_boot_key_state {
	CDK2_SECURE_BOOT_KEYS_UNKNOWN,
	CDK2_SECURE_BOOT_KEYS_NONE,
	CDK2_SECURE_BOOT_KEYS_DEFAULT,
	CDK2_SECURE_BOOT_KEYS_CUSTOM,
};

enum cdk2_secure_boot_enforcement {
	CDK2_SECURE_BOOT_ENFORCEMENT_UNKNOWN,
	CDK2_SECURE_BOOT_DISABLED,
	CDK2_SECURE_BOOT_ENABLED,
};

EFI_STATUS cdk2_secure_boot_enforcement_state(
	struct cdk2_runtime_services_view *runtime,
	struct cdk2_boot_services_view *boot,
	enum cdk2_secure_boot_enforcement *state);
EFI_STATUS cdk2_secure_boot_publish_defaults(
	struct cdk2_runtime_services_view *runtime,
	struct cdk2_boot_services_view *boot);
EFI_STATUS cdk2_secure_boot_key_state(
	struct cdk2_runtime_services_view *runtime,
	struct cdk2_boot_services_view *boot,
	enum cdk2_secure_boot_key_state *state);
EFI_STATUS cdk2_secure_boot_browse(struct cdk2_lvgl_ui_protocol *ui,
	struct cdk2_runtime_services_view *runtime,
	struct cdk2_boot_services_view *boot);
typedef EFI_STATUS cdk2_setup_page_fn(struct cdk2_lvgl_ui_protocol *,
	struct cdk2_runtime_services_view *);
EFI_STATUS cdk2_secure_boot_setup_root(struct cdk2_lvgl_ui_protocol *ui,
	struct cdk2_runtime_services_view *runtime,
	struct cdk2_boot_services_view *boot, cdk2_setup_page_fn *display_page);

#endif
