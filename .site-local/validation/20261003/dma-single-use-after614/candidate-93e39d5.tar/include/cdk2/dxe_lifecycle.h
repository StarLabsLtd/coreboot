/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_DXE_LIFECYCLE_H
#define CDK2_DXE_LIFECYCLE_H

#include <uefi.h>

typedef EFI_STATUS CDK2_MS_ABI cdk2_dxe_lifecycle_load_image_fn(BOOLEAN,
	void *, void *, void *, UINTN, void **);

struct cdk2_dxe_lifecycle {
	BOOLEAN end_of_dxe_signaled;
	BOOLEAN end_of_dxe_completed;
	BOOLEAN ready_to_boot_signaled;
	EFI_STATUS ready_to_boot_cleanup_status;
};

struct cdk2_dxe_lifecycle_ops {
	EFI_STATUS (*create)(void *context, const EFI_GUID *group, void **event);
	EFI_STATUS (*signal)(void *context, void *event);
	EFI_STATUS (*close)(void *context, void *event);
	void *context;
};

EFI_STATUS cdk2_dxe_lifecycle_end_of_dxe(struct cdk2_dxe_lifecycle *state,
	const struct cdk2_dxe_lifecycle_ops *ops);
EFI_STATUS cdk2_dxe_lifecycle_ready_to_boot(struct cdk2_dxe_lifecycle *state,
	const struct cdk2_dxe_lifecycle_ops *ops);
EFI_STATUS cdk2_dxe_lifecycle_load_image(
	cdk2_dxe_lifecycle_load_image_fn load, BOOLEAN boot_policy, void *parent,
	void *path, void *source, UINTN source_size, void **owned_image);

#endif
