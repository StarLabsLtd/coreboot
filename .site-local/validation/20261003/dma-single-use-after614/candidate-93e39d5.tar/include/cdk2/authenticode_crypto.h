/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_AUTHENTICODE_CRYPTO_H
#define CDK2_AUTHENTICODE_CRYPTO_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

enum cdk2_authenticode_hash {
	CDK2_AUTHENTICODE_HASH_SHA256 = 1U,
	CDK2_AUTHENTICODE_HASH_SHA384 = 2U,
	CDK2_AUTHENTICODE_HASH_SHA512 = 4U,
};

struct cdk2_authenticode_tbs_digests {
	uint8_t sha256[32];
	uint8_t sha384[48];
	uint8_t sha512[64];
};

struct cdk2_authenticode_timestamp {
	/* Gregorian days since 0000-01-01 and seconds within the UTC day. */
	uint32_t days;
	uint32_t seconds;
};

/* Parse exactly 16 immutable wire bytes of canonical UTC whole-second EFI_TIME.
 * Zero, invalid calendars and unsupported metadata fail without changing output.
 * Output must not overlap the input. This does not establish timestamp trust.
 */
bool cdk2_authenticode_revocation_time(const uint8_t encoded[16],
	struct cdk2_authenticode_timestamp *timestamp);

/* Verify one RFC3161 token over the outer RSA signature using one explicit
 * trusted TSA anchor. Does not retrieve authoritative dbt or override dbx.
 * This does not independently authenticate/authorize the enclosing image.
 * The selected token signer requires a critical, sole timeStamping EKU.
 * Output is unchanged on failure and disjoint from all immutable inputs.
 */
bool cdk2_authenticode_timestamp_verify(const uint8_t *signature, size_t size,
	const uint8_t image_digest[32], const uint8_t *trust_anchor, size_t trust_size,
	struct cdk2_authenticode_timestamp *timestamp);

/* Requested algorithms only; unrequested fields are zero on success.
 * A zero mask still validates the certificate/unique signer but hashes nothing.
 * Output is atomic on failure and disjoint from all immutable inputs.
 * These are admission/digest operations, not signature authentication.
 */
bool cdk2_authenticode_signer_hashes(const uint8_t *signature, size_t size,
	const uint8_t image_digest[32], uint32_t requested,
	struct cdk2_authenticode_tbs_digests *digests);
bool cdk2_authenticode_certificate_hashes(const uint8_t *certificate, size_t size,
	uint32_t requested, struct cdk2_authenticode_tbs_digests *digests);

/* Admission only: these do not authenticate a signature or establish trust. */
bool cdk2_authenticode_certificate_supported(const uint8_t *certificate, size_t size);
bool cdk2_authenticode_pkcs7_supported(const uint8_t *signature, size_t size,
	const uint8_t image_digest[32]);

/* Hash the uniquely selected signer's complete TBSCertificate SEQUENCE TLV.
 * Admission only, not signature authentication. Output is unchanged on failure
 * and must not overlap the immutable signature/image-digest input snapshots.
 */
bool cdk2_authenticode_signer_sha256(const uint8_t *signature, size_t size,
	const uint8_t image_digest[32], uint8_t signer_digest[32]);

/* Hash a bounded DER certificate's complete TBSCertificate SEQUENCE TLV.
 * This does not authenticate the certificate or authorize a trust anchor.
 * Output is unchanged on failure and must not overlap the certificate.
 */
bool cdk2_authenticode_certificate_sha256(const uint8_t *certificate, size_t size,
	uint8_t certificate_digest[32]);

/*
 * Verify one RSA2048/SHA256 Authenticode SignedData against one supplied DER
 * trust anchor and expected image digest. All input bytes must remain immutable
 * for the complete call. This does not establish db/dbx or installed image policy.
 */
bool cdk2_authenticode_pkcs7_verify(const uint8_t *signature, size_t signature_size,
	const uint8_t *certificate, size_t certificate_size,
	const uint8_t image_digest[32]);

#endif
