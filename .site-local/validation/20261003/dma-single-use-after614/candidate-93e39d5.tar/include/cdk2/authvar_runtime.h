/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_AUTHVAR_RUNTIME_H
#define CDK2_AUTHVAR_RUNTIME_H

#include <cdk2/authvar_transport.h>

struct cdk2_authvar_runtime {
	struct cdk2_authvar_client *client;
	UINT8 *message;
	UINTN message_size;
	BOOLEAN busy;
	/* Optional enclosing allocations; descriptive caller-buffer exclusion only. */
	void *owner_base;
	size_t owner_size;
	void *entry_base;
	size_t entry_size;
};

struct cdk2_authvar_key_classification {
	uint32_t kind;
	uint32_t attributes;
	uint32_t flags;
};

/* Shape-checked protected metadata, not authenticated reply provenance. */
EFI_STATUS cdk2_authvar_runtime_classify(struct cdk2_authvar_runtime *runtime,
	const CHAR16 *name, const EFI_GUID *vendor,
	struct cdk2_authvar_key_classification *classification);

EFI_STATUS cdk2_authvar_runtime_init(struct cdk2_authvar_runtime *runtime,
	struct cdk2_authvar_client *client, void *message, UINTN message_size);
EFI_STATUS cdk2_authvar_runtime_get(struct cdk2_authvar_runtime *runtime,
	const CHAR16 *name, const EFI_GUID *vendor, UINT32 *attributes,
	UINTN *data_size, void *data);
EFI_STATUS cdk2_authvar_runtime_next(struct cdk2_authvar_runtime *runtime,
	UINTN *name_size, CHAR16 *name, EFI_GUID *vendor);
EFI_STATUS cdk2_authvar_runtime_set(struct cdk2_authvar_runtime *runtime,
	const CHAR16 *name, const EFI_GUID *vendor, UINT32 attributes,
	UINTN data_size, const void *data);
EFI_STATUS cdk2_authvar_runtime_query(struct cdk2_authvar_runtime *runtime,
	UINT32 attributes, UINT64 *maximum_storage, UINT64 *remaining_storage,
	UINT64 *maximum_variable);
EFI_STATUS cdk2_authvar_runtime_ready_to_boot(
	struct cdk2_authvar_runtime *runtime);
EFI_STATUS cdk2_authvar_runtime_register_policy(
	struct cdk2_authvar_runtime *runtime, const void *policy, UINTN policy_size);
EFI_STATUS cdk2_authvar_runtime_lock_policy(
	struct cdk2_authvar_runtime *runtime);
EFI_STATUS cdk2_authvar_runtime_enter_runtime(
	struct cdk2_authvar_runtime *runtime);

#endif
