/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_DXE_IMAGE_TRANSACTION_H
#define CDK2_DXE_IMAGE_TRANSACTION_H

#include <uefi.h>

typedef EFI_STATUS cdk2_dxe_image_entry_fn(void *image, void *system_table)
	CDK2_MS_ABI;

enum cdk2_dxe_image_transaction_state {
	CDK2_DXE_IMAGE_PREPARED = 1,
	CDK2_DXE_IMAGE_AUTHENTICATED,
	CDK2_DXE_IMAGE_LOADED_PRIVATE,
	CDK2_DXE_IMAGE_PUBLISHED,
};

struct cdk2_dxe_image_transaction {
	enum cdk2_dxe_image_transaction_state state;
	UINT64 generation;
	void *source;
	UINTN source_size;
	void *source_allocation;
	UINTN source_allocation_size;
	UINT64 source_generation;
	void *device_path;
	UINTN device_path_size;
	void *device_path_allocation;
	UINTN device_path_allocation_size;
	UINT64 device_path_generation;
};

#endif
