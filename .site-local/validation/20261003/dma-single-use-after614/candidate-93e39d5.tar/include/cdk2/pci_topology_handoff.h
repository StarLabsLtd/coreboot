/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_PCI_TOPOLOGY_HANDOFF_H_
#define CDK2_PCI_TOPOLOGY_HANDOFF_H_

#include <stddef.h>
#include <stdint.h>
#include <uefi.h>
#include <cdk2/payload_handoff.h>

#define CDK2_PCI_TOPOLOGY_HANDOFF_REVISION 2U
#define CDK2_PCI_TOPOLOGY_HANDOFF_MAX_FUNCTIONS 512U

#define CDK2_PCI_TOPOLOGY_PATH_ONLY       0x01U
#define CDK2_PCI_TOPOLOGY_PARENT_ROOT     0xffffU

#define CDK2_PCI_TOPOLOGY_HANDOFF_FRAMEBUFFER_OWNER_VALID 0x01U

#define CDK2_PCI_TOPOLOGY_HANDOFF_HOB_GUID                                      \
	{ 0x52006bfa, 0x62d9, 0x48e0,                                          \
	  { 0xbd, 0x8e, 0x41, 0xfe, 0xf5, 0xce, 0x1c, 0xf6 } }

extern const EFI_GUID cdk2_pci_topology_handoff_hob_guid;

#pragma pack(push, 1)
struct cdk2_pci_topology_function {
	uint16_t segment;
	uint8_t bus, device, function, header_type;
	uint16_t parent_index;
	uint16_t vendor_id, device_id, command;
	uint8_t class_code, subclass, programming_interface;
	uint8_t secondary_bus, subordinate_bus, flags;
	uint32_t reserved;
};

struct cdk2_pci_boot_controller {
	uint16_t topology_index, flags;
	uint32_t reserved;
};

struct cdk2_pci_topology_handoff {
	struct cdk2_payload_header header;
	uint64_t producer_generation;
	uint16_t function_count;
	uint16_t boot_controller_count;
	uint16_t framebuffer_topology_index;
	uint8_t framebuffer_bar;
	uint8_t flags;
	struct cdk2_pci_topology_function function[];
};
#pragma pack(pop)

static inline const struct cdk2_pci_boot_controller *
cdk2_pci_topology_boot_controllers(const struct cdk2_pci_topology_handoff *handoff)
{
	return (const struct cdk2_pci_boot_controller *)(const void *)
		(&handoff->function[handoff->function_count]);
}

_Static_assert(sizeof(struct cdk2_pci_topology_function) == 24U,
	"PCI topology function ABI size changed");
_Static_assert(offsetof(struct cdk2_pci_topology_function, parent_index) == 6U,
	"PCI topology parent offset changed");
_Static_assert(offsetof(struct cdk2_pci_topology_function, reserved) == 20U,
	"PCI topology reserved offset changed");
_Static_assert(sizeof(struct cdk2_pci_boot_controller) == 8U,
	"PCI boot-controller ABI size changed");
_Static_assert(offsetof(struct cdk2_pci_topology_handoff,
	producer_generation) == 4U,
	"PCI topology producer-generation offset changed");
_Static_assert(sizeof(struct cdk2_pci_topology_handoff) == 20U,
	"PCI topology HOB header size changed");

#endif
