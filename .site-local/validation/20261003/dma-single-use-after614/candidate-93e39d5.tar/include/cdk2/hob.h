/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_HOB_H
#define CDK2_HOB_H

#include <pi/hob.h>

static inline EFI_STATUS cdk2_hob_list_validate(const void *hob_list)
{
	const EFI_HOB_HANDOFF_INFO_TABLE *handoff = hob_list;
	const EFI_HOB_GENERIC_HEADER *hob;
	UINTN begin, end, memory_bottom, memory_top;
	UINTN free_bottom, free_top;

	if (handoff == NULL || ((UINTN)handoff & 7U) != 0U)
		return EFI_INVALID_PARAMETER;
	begin = (UINTN)handoff;
	if (handoff->header.hob_type != EFI_HOB_TYPE_HANDOFF ||
	    handoff->header.hob_length != sizeof(*handoff) ||
	    handoff->header.reserved != 0U ||
	    handoff->version != EFI_HOB_HANDOFF_TABLE_VERSION ||
	    handoff->efi_memory_bottom > MAX_UINTN ||
	    handoff->efi_memory_top > MAX_UINTN ||
	    handoff->efi_free_memory_bottom > MAX_UINTN ||
	    handoff->efi_free_memory_top > MAX_UINTN ||
	    handoff->efi_end_of_hob_list > MAX_UINTN)
		return EFI_COMPROMISED_DATA;
	memory_bottom = (UINTN)handoff->efi_memory_bottom;
	memory_top = (UINTN)handoff->efi_memory_top;
	free_bottom = (UINTN)handoff->efi_free_memory_bottom;
	free_top = (UINTN)handoff->efi_free_memory_top;
	end = (UINTN)handoff->efi_end_of_hob_list;
	if (memory_top < sizeof(*handoff) || free_top < sizeof(*hob) ||
	    begin > MAX_UINTN - sizeof(*handoff) ||
	    memory_bottom >= memory_top || begin < memory_bottom ||
	    begin > memory_top - sizeof(*handoff) ||
	    free_bottom < memory_bottom || free_bottom > free_top ||
	    free_top > memory_top || end < begin + sizeof(*handoff) ||
	    (end & 7U) != 0U || end > free_top - sizeof(*hob) ||
	    free_bottom != end + sizeof(*hob))
		return EFI_COMPROMISED_DATA;
	for (hob = hob_list; (UINTN)hob < end;
	     hob = (const void *)((const UINT8 *)hob + hob->hob_length)) {
		UINTN address = (UINTN)hob;

		if ((address & 7U) != 0U || hob->hob_length < sizeof(*hob) ||
		    (hob->hob_length & 7U) != 0U || hob->reserved != 0U ||
		    hob->hob_type == EFI_HOB_TYPE_END_OF_HOB_LIST ||
		    hob->hob_length > end - address)
			return EFI_COMPROMISED_DATA;
	}
	if ((UINTN)hob != end || hob->hob_type != EFI_HOB_TYPE_END_OF_HOB_LIST ||
	    hob->hob_length != sizeof(*hob) || hob->reserved != 0U)
		return EFI_COMPROMISED_DATA;
	return EFI_SUCCESS;
}

#endif
