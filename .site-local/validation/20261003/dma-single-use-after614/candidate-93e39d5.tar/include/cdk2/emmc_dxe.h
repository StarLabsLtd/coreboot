/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_EMMC_DXE_H
#define CDK2_EMMC_DXE_H

#include <cdk2/sd_dxe.h>
#include <cdk2/diagnostic.h>
#if defined(CDK2_DEBUG) || defined(CDK2_DIAGNOSTIC)
void cdk2_emmc_diagnostic(const char *message);
#define CDK2_EMMC_DIAG(message) cdk2_emmc_diagnostic(message)
#else
#define CDK2_EMMC_DIAG(message) do { } while (0)
#endif

#define CDK2_EMMC_PARTITIONS 8U
#define CDK2_EMMC_MAX_CONTROLLERS 8U
#define CDK2_EMMC_MAX_DEVICES 8U

enum cdk2_emmc_partition_type {
	CDK2_EMMC_USER,
	CDK2_EMMC_BOOT1,
	CDK2_EMMC_BOOT2,
	CDK2_EMMC_RPMB,
	CDK2_EMMC_GP1,
	CDK2_EMMC_GP2,
	CDK2_EMMC_GP3,
	CDK2_EMMC_GP4,
};

struct cdk2_emmc_partition {
	enum cdk2_emmc_partition_type type;
	UINT64 blocks;
	UINT32 erase_granularity;
	BOOLEAN enabled, block_io, security, read_only;
};

struct cdk2_emmc_block;
struct cdk2_emmc_device {
	UINT8 slot;
	UINT16 rca;
	UINT32 block_size;
	UINT8 csd[16], cid[16], ext_csd[512];
	struct cdk2_emmc_partition partition[CDK2_EMMC_PARTITIONS];
	void *active_block;
	BOOLEAN read_only, cache_enabled, sector_addressing;
	struct cdk2_emmc_block *published[CDK2_EMMC_PARTITIONS];
};

struct cdk2_emmc_transfer {
	UINT8 partition;
	UINT16 command;
	UINT32 argument, blocks, bytes;
	void *buffer;
	BOOLEAN write;
};

struct cdk2_emmc_block {
	struct cdk2_block_io block;
	struct cdk2_block_io2 block2;
	struct cdk2_block_media media;
	struct cdk2_sd_transport *transport;
	struct cdk2_emmc_device *device;
	UINT8 partition;
	struct cdk2_sd_async_services async_services;
	struct cdk2_sdmmc_command async_command;
	struct cdk2_sdmmc_status async_status;
	struct cdk2_sdmmc_packet async_packet;
	struct cdk2_block_io2_token *async_token;
	void *completion_event, *async_buffer;
	UINT64 async_lba;
	UINTN async_bytes, async_remaining;
	UINT32 async_blocks;
	UINT8 async_phase;
	BOOLEAN async_active, async_write;
};

struct cdk2_emmc_disk_info;
typedef EFI_STATUS CDK2_MS_ABI cdk2_emmc_info_data_fn(
	struct cdk2_emmc_disk_info *, void *, UINT32 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_emmc_info_sense_fn(
	struct cdk2_emmc_disk_info *, void *, UINT32 *, UINT8 *);
typedef EFI_STATUS CDK2_MS_ABI cdk2_emmc_info_ide_fn(
	struct cdk2_emmc_disk_info *, UINT32 *, UINT32 *);
struct cdk2_emmc_disk_info {
	EFI_GUID interface;
	cdk2_emmc_info_data_fn *inquiry, *identify;
	cdk2_emmc_info_sense_fn *sense;
	cdk2_emmc_info_ide_fn *which_ide;
	struct cdk2_emmc_device *device;
};

struct cdk2_emmc_bound_child {
	void *handle, *path;
	struct cdk2_emmc_block block;
	struct cdk2_emmc_disk_info info;
	UINT8 partition;
	BOOLEAN installed, linked, block2_installed;
};

struct cdk2_emmc_bound_device {
	struct cdk2_sd_transport transport;
	struct cdk2_emmc_device card;
	struct cdk2_emmc_bound_child *child[CDK2_EMMC_PARTITIONS];
	UINTN count;
};

struct cdk2_emmc_bound_controller {
	void *handle, *parent_path;
	struct cdk2_sdmmc_protocol *pass_thru;
	struct cdk2_emmc_bound_device *device[CDK2_EMMC_MAX_DEVICES];
	UINTN count;
	BOOLEAN parent_open, marker;
};

struct cdk2_emmc_target { UINT8 slot, partition; };
typedef EFI_STATUS cdk2_emmc_open_parent_fn(void *context, void *handle,
	struct cdk2_sdmmc_protocol **pass_thru, void **parent_path);
typedef EFI_STATUS cdk2_emmc_close_parent_fn(void *context, void *handle);
typedef EFI_STATUS cdk2_emmc_allocate_fn(void *context, UINTN size,
	void **buffer);
typedef void cdk2_emmc_release_fn(void *context, void *buffer);
typedef EFI_STATUS cdk2_emmc_marker_fn(void *context, void *handle,
	struct cdk2_emmc_bound_controller *controller);
typedef EFI_STATUS cdk2_emmc_append_path_fn(void *context, void *parent_path,
	void *slot_path, UINT8 partition, void **path);
typedef EFI_STATUS cdk2_emmc_child_protocol_fn(void *context,
	struct cdk2_emmc_bound_child *child);
typedef EFI_STATUS cdk2_emmc_child_link_fn(void *context, void *parent,
	void *child);
typedef EFI_STATUS cdk2_emmc_set_clock_fn(void *context,
	struct cdk2_sdmmc_protocol *protocol, UINT8 slot, UINT32 frequency);
struct cdk2_emmc_binding_services {
	void *context;
	cdk2_emmc_open_parent_fn *open_parent;
	cdk2_emmc_close_parent_fn *close_parent;
	cdk2_emmc_allocate_fn *allocate;
	cdk2_emmc_release_fn *release;
	cdk2_emmc_marker_fn *mark, *unmark;
	cdk2_emmc_append_path_fn *append_path;
	cdk2_emmc_child_protocol_fn *install_child, *uninstall_child;
	cdk2_emmc_child_link_fn *link_child, *unlink_child;
	cdk2_emmc_set_clock_fn *set_clock;
	void (*stall)(void *context, UINTN microseconds);
};
struct cdk2_emmc_binding {
	struct cdk2_emmc_binding_services services;
	struct cdk2_emmc_bound_controller *controller[CDK2_EMMC_MAX_CONTROLLERS];
	UINTN count;
};

EFI_STATUS cdk2_emmc_parse_partitions(const UINT8 csd[16],
	const UINT8 ext_csd[512], struct cdk2_emmc_device *device);
EFI_STATUS cdk2_emmc_discover(struct cdk2_sd_transport *transport, UINT16 rca,
	struct cdk2_emmc_device *device);
EFI_STATUS cdk2_emmc_build_transfer(const struct cdk2_emmc_device *device,
	UINT8 partition, UINT64 lba, UINTN bytes, void *buffer, BOOLEAN write,
	struct cdk2_emmc_transfer *transfer);
EFI_STATUS cdk2_emmc_transfer_sync(struct cdk2_sd_transport *transport,
	struct cdk2_emmc_device *device, UINT8 partition, UINT64 lba, UINTN bytes,
	void *buffer, BOOLEAN write);
EFI_STATUS cdk2_emmc_reidentify(struct cdk2_sd_transport *transport,
	struct cdk2_emmc_device *device);
EFI_STATUS cdk2_emmc_flush(struct cdk2_sd_transport *transport,
	struct cdk2_emmc_device *device);
EFI_STATUS cdk2_emmc_block_init(struct cdk2_emmc_block *block,
	struct cdk2_sd_transport *transport, struct cdk2_emmc_device *device,
	UINT8 partition, UINT32 io_align);
EFI_STATUS cdk2_emmc_block_enable_async(struct cdk2_emmc_block *block,
	const struct cdk2_sd_async_services *services);
EFI_STATUS cdk2_emmc_block_disable_async(struct cdk2_emmc_block *block);
EFI_STATUS cdk2_emmc_disk_info_init(struct cdk2_emmc_disk_info *info,
	struct cdk2_emmc_device *device);
EFI_STATUS cdk2_emmc_binding_init(struct cdk2_emmc_binding *binding,
	const struct cdk2_emmc_binding_services *services);
EFI_STATUS cdk2_emmc_binding_start(struct cdk2_emmc_binding *binding,
	void *controller, const struct cdk2_emmc_target *target);
EFI_STATUS cdk2_emmc_binding_stop(struct cdk2_emmc_binding *binding,
	void *controller, UINTN child_count, void **children);

#endif
