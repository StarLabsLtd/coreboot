/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_TPM2_ACPI_HOB_H
#define CDK2_TPM2_ACPI_HOB_H
#include <uefi.h>
struct cdk2_tpm2_config_table { EFI_GUID guid; void *table; };
EFI_STATUS cdk2_tpm2_acpi_hob_probe(const struct cdk2_tpm2_config_table *tables,
	UINTN table_count, UINT64 *base);
#endif
