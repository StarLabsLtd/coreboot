/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_BDS_H_
#define CDK2_BDS_H_

#include <uefi.h>

struct cdk2_bds_option {
	UINT32 attributes;
	const CHAR16 *description;
	const void *path;
	UINTN path_size;
	const void *optional_data;
	UINTN optional_data_size;
};

EFI_STATUS cdk2_bds_parse_option(const void *data, UINTN size,
	struct cdk2_bds_option *option);
typedef EFI_STATUS CDK2_MS_ABI cdk2_bds_input_poll_fn(void *context);
EFI_STATUS CDK2_MS_ABI cdk2_bds_enter_setup(UINTN timeout_seconds,
	cdk2_bds_input_poll_fn *poll_input, void *poll_context);
EFI_STATUS cdk2_bds_boot_once(void);
EFI_STATUS CDK2_MS_ABI cdk2_bds_entry(void *image, void *system_table);

#endif
