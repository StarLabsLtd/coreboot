/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_PE_AUTHENTICODE_H
#define CDK2_PE_AUTHENTICODE_H

#include <stddef.h>
#include <stdint.h>
#include <uefi.h>
#include <cdk2/authenticode_crypto.h>

#define CDK2_AUTHENTICODE_SHA256_SIZE 32U

struct cdk2_pe_authenticode_digests {
	uint8_t sha256[32];
	uint8_t sha384[48];
	uint8_t sha512[64];
};

struct cdk2_authenticode_certificate {
	const uint8_t *data;
	size_t size;
	uint16_t revision;
	uint16_t type;
};

typedef EFI_STATUS cdk2_authenticode_certificate_fn(void *context,
	const struct cdk2_authenticode_certificate *certificate);

/*
 * Both APIs borrow the image. The caller must keep all image bytes stable for
 * the complete call, and a certificate visitor must not modify those bytes.
 * Digest only: no signature, trust-database or revocation decision.
 */
EFI_STATUS cdk2_pe_authenticode_sha256(const void *image, size_t image_size,
	uint8_t digest[CDK2_AUTHENTICODE_SHA256_SIZE]);

/* Hash only requested algorithms in one traversal of the validated PE image. */
EFI_STATUS cdk2_pe_authenticode_hashes(const void *image, size_t image_size,
	uint32_t requested, struct cdk2_pe_authenticode_digests *digests);

/* Validate the complete table before exposing any WIN_CERTIFICATE payload. */
EFI_STATUS cdk2_pe_authenticode_certificates(const void *image, size_t image_size,
	cdk2_authenticode_certificate_fn *visit, void *context);

#endif
