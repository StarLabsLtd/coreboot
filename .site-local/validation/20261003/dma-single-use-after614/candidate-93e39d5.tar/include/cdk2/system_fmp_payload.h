/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_PAYLOAD_H
#define CDK2_SYSTEM_FMP_PAYLOAD_H

#include <stddef.h>
#include <stdint.h>
#include <cdk2/capsule_runtime_abi.h>
#include <uefi.h>

#define CDK2_FMP_MSS1_SIGNATURE 0x3153534dU
#define CDK2_FMP_MSS1_HEADER_SIZE 16U

#define CDK2_FMP_DEP_PUSH_GUID 0x00U
#define CDK2_FMP_DEP_PUSH_VERSION 0x01U
#define CDK2_FMP_DEP_VERSION_STRING 0x02U
#define CDK2_FMP_DEP_AND 0x03U
#define CDK2_FMP_DEP_OR 0x04U
#define CDK2_FMP_DEP_NOT 0x05U
#define CDK2_FMP_DEP_TRUE 0x06U
#define CDK2_FMP_DEP_FALSE 0x07U
#define CDK2_FMP_DEP_EQUAL 0x08U
#define CDK2_FMP_DEP_GREATER_THAN 0x09U
#define CDK2_FMP_DEP_GREATER_EQUAL 0x0aU
#define CDK2_FMP_DEP_LESS_THAN 0x0bU
#define CDK2_FMP_DEP_LESS_EQUAL 0x0cU
#define CDK2_FMP_DEP_END 0x0dU
#define CDK2_FMP_DEP_DECLARE_LENGTH 0x0eU

#define CDK2_FMP_LAST_ATTEMPT_SUCCESS 0x00000000U
#define CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL 0x00000001U
#define CDK2_FMP_LAST_ATTEMPT_GET_HEADER 0x00001000U
#define CDK2_FMP_LAST_ATTEMPT_GET_HEADER_SIZE 0x00001007U
#define CDK2_FMP_LAST_ATTEMPT_GET_HEADER_VERSION 0x00001009U
#define CDK2_FMP_LAST_ATTEMPT_INVALID_IMAGE_INDEX 0x0000100dU
#define CDK2_FMP_LAST_ATTEMPT_VERSION_TOO_LOW 0x00001010U
#define CDK2_FMP_LAST_ATTEMPT_DEP_GET_FAILURE 0x00001080U
#define CDK2_FMP_LAST_ATTEMPT_DEP_NO_END 0x00001081U
#define CDK2_FMP_LAST_ATTEMPT_DEP_UNKNOWN 0x00001082U
#define CDK2_FMP_LAST_ATTEMPT_DEP_GUID_TRUNCATED 0x00001083U
#define CDK2_FMP_LAST_ATTEMPT_DEP_VERSION_TRUNCATED 0x00001084U
#define CDK2_FMP_LAST_ATTEMPT_DEP_STRING_TRUNCATED 0x00001085U
#define CDK2_FMP_LAST_ATTEMPT_DEP_FMP_NOT_FOUND 0x00001086U
#define CDK2_FMP_LAST_ATTEMPT_DEP_PUSH_FAILURE 0x00001087U
#define CDK2_FMP_LAST_ATTEMPT_DEP_POP_FAILURE 0x00001088U
#define CDK2_FMP_LAST_ATTEMPT_DEP_LENGTH_NOT_FIRST 0x00001089U
#define CDK2_FMP_LAST_ATTEMPT_DEP_LENGTH_TRUNCATED 0x0000108aU
#define CDK2_FMP_LAST_ATTEMPT_DEP_LENGTH_INCORRECT 0x0000108bU
#define CDK2_FMP_LAST_ATTEMPT_UNSATISFIED_DEPENDENCIES 0x00000008U

enum cdk2_system_fmp_operation {
	CDK2_SYSTEM_FMP_OPERATION_CHECK = 1,
	CDK2_SYSTEM_FMP_OPERATION_SET = 2,
};

struct cdk2_system_fmp_dependency_version {
	EFI_GUID image_type;
	uint32_t version;
};

struct cdk2_system_fmp_payload_request {
	enum cdk2_system_fmp_operation operation;
	const EFI_GUID *image_type;
	const EFI_GUID *expected_image_type;
	uint8_t image_index;
	uint32_t lowest_supported_version;
	const struct cdk2_system_fmp_dependency_version *dependency_versions;
	size_t dependency_version_count;
	const uint8_t *payload;
	size_t payload_size;
};

struct cdk2_system_fmp_payload_view {
	const uint8_t *dependency;
	size_t dependency_size;
	const uint8_t *image;
	size_t image_size;
	uint32_t version;
	uint32_t lowest_supported_version;
	uint32_t image_updatable;
	uint32_t last_attempt_status;
};

/*
 * Check only the payload-layer gates represented by this model. A VALID result
 * is not overall capsule admission: authentication, device-specific checks,
 * durable policy, and the flash broker remain separate fail-closed gates.
 */
EFI_STATUS cdk2_system_fmp_payload_check(
	const struct cdk2_system_fmp_payload_request *request,
	struct cdk2_system_fmp_payload_view *view);

#endif
