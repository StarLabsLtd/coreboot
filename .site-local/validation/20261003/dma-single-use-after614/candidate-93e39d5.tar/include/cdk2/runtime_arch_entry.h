/* SPDX-License-Identifier: BSD-2-Clause-Patent */
#ifndef CDK2_RUNTIME_ARCH_ENTRY_H
#define CDK2_RUNTIME_ARCH_ENTRY_H

#include <cdk2/runtime_arch.h>

EFI_STATUS CDK2_MS_ABI cdk2_runtime_arch_entry(void *image, void *system);

#endif
