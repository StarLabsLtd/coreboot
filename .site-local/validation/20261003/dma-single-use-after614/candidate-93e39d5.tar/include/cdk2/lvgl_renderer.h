/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_LVGL_RENDERER_H_
#define CDK2_LVGL_RENDERER_H_

#include <uefi.h>

#define CDK2_LVGL_MAX_STATEMENTS 256U
#define CDK2_LVGL_MAX_ONE_OF_OPTIONS 16U

struct cdk2_lvgl_one_of_option {
	const CHAR16 *label;
	UINT64 value;
};

struct cdk2_lvgl_framebuffer {
	UINT32 *base;
	UINTN width;
	UINTN height;
	UINTN pixels_per_scanline;
};

struct cdk2_lvgl_pointer_sample {
	UINTN x;
	UINTN y;
	INT32 wheel;
	BOOLEAN pressed;
};

struct cdk2_lvgl_absolute_sample {
	UINT64 x;
	UINT64 y;
	INT64 wheel;
	UINT64 minimum_x;
	UINT64 maximum_x;
	UINT64 minimum_y;
	UINT64 maximum_y;
	BOOLEAN pressed;
};

enum cdk2_lvgl_statement_kind {
	CDK2_LVGL_SUBTITLE,
	CDK2_LVGL_TEXT,
	CDK2_LVGL_CHECKBOX,
	CDK2_LVGL_NUMERIC,
	CDK2_LVGL_ONE_OF,
	CDK2_LVGL_ORDERED_LIST,
	CDK2_LVGL_STRING,
	CDK2_LVGL_REFERENCE,
	CDK2_LVGL_ACTION,
	CDK2_LVGL_DATE,
	CDK2_LVGL_TIME,
};

struct cdk2_lvgl_statement {
	const CHAR16 *prompt;
	const CHAR16 *help;
	const void *value;
	UINTN value_size;
	UINT64 minimum;
	UINT64 maximum;
	UINT64 step;
	struct cdk2_lvgl_one_of_option options[CDK2_LVGL_MAX_ONE_OF_OPTIONS];
	UINTN option_count;
	UINT16 varstore_id;
	UINT16 varstore_offset;
	UINT16 question_id;
	UINT16 gray_question_id;
	UINT16 gray_value;
	UINT8 kind;
	BOOLEAN gray_when_equal;
	BOOLEAN disabled;
	BOOLEAN read_only;
};

struct cdk2_lvgl_form {
	const CHAR16 *title;
	const struct cdk2_lvgl_statement *statements;
	UINTN statement_count;
	UINT16 form_id;
	UINT16 varstore_id;
	UINTN varstore_size;
	EFI_GUID varstore_guid;
	const CHAR8 *varstore_name;
	BOOLEAN setting_changed;
};

typedef EFI_STATUS cdk2_lvgl_begin_form_fn(void *context,
	const struct cdk2_lvgl_form *form);
typedef EFI_STATUS cdk2_lvgl_add_widget_fn(void *context,
	const struct cdk2_lvgl_statement *statement, UINTN index);
typedef EFI_STATUS cdk2_lvgl_end_form_fn(void *context);
typedef void cdk2_lvgl_abort_form_fn(void *context);

struct cdk2_lvgl_backend {
	cdk2_lvgl_begin_form_fn *begin_form;
	cdk2_lvgl_add_widget_fn *add_widget;
	cdk2_lvgl_end_form_fn *end_form;
	cdk2_lvgl_abort_form_fn *abort_form;
};

EFI_STATUS cdk2_lvgl_render_form(const struct cdk2_lvgl_backend *backend,
	void *context, const struct cdk2_lvgl_form *form);

EFI_STATUS cdk2_lvgl_flush_bgra(const struct cdk2_lvgl_framebuffer *framebuffer,
	UINTN x1, UINTN y1, UINTN x2, UINTN y2, const UINT32 *pixels);
EFI_STATUS cdk2_lvgl_scale_pointer(const struct cdk2_lvgl_framebuffer *framebuffer,
	const struct cdk2_lvgl_absolute_sample *sample,
	struct cdk2_lvgl_pointer_sample *output);
#endif
