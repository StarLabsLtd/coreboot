/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_POLICY_H
#define CDK2_SYSTEM_FMP_POLICY_H

#include <cdk2/system_fmp_test_key.h>
#include <uefi.h>

#define CDK2_FMP_POLICY_VERSION 1U
#define CDK2_FMP_IMAGE_NAME_UNITS 16U

/* Missing evidence is a blocker, never a zero-valued policy default. */
#define CDK2_FMP_POLICY_STORAGE (1U << 0)
#define CDK2_FMP_POLICY_NAME (1U << 1)
#define CDK2_FMP_POLICY_LOWEST_VERSION (1U << 2)
#define CDK2_FMP_POLICY_PROGRESS (1U << 3)
#define CDK2_FMP_POLICY_WATCHDOG (1U << 4)
#define CDK2_FMP_POLICY_CERTIFICATES (1U << 5)
#define CDK2_FMP_POLICY_TEST_DIGEST (1U << 6)
#define CDK2_FMP_POLICY_IMAGE_FALLBACK (1U << 7)
#define CDK2_FMP_POLICY_LOCK_EVENT (1U << 8)
#define CDK2_FMP_POLICY_CALLER (1U << 9)
#define CDK2_FMP_POLICY_ALL ((1U << 10) - 1U)
#define CDK2_FMP_POLICY_ABI (1U << 31)

enum cdk2_fmp_storage_access {
	CDK2_FMP_STORAGE_UNRESOLVED,
	CDK2_FMP_STORAGE_DISABLED,
	CDK2_FMP_STORAGE_ENABLED,
};

enum cdk2_fmp_image_fallback {
	CDK2_FMP_IMAGE_UNRESOLVED,
	CDK2_FMP_IMAGE_CALLER,
	CDK2_FMP_IMAGE_OVERRIDE,
};

struct cdk2_fmp_const_span {
	const uint8_t *data;
	size_t size;
};

/*
 * Internal X64 phase ABI, not an EFI protocol or persistent/wire structure.
 * The phase supplies immutable policy and readable spans for the start call.
 * resolved_fields describes reviewed evidence; it is not a token accessor.
 */
struct cdk2_system_fmp_policy {
	uint32_t version;
	uint32_t size;
	uint32_t resolved_fields;
	uint32_t storage_access;
	EFI_GUID caller_guid;
	CHAR16 image_name[CDK2_FMP_IMAGE_NAME_UNITS];
	uint32_t build_lowest_version;
	uint32_t progress_color;
	uint32_t watchdog_seconds;
	uint32_t image_fallback;
	EFI_GUID image_override;
	EFI_GUID lock_event;
	struct cdk2_fmp_const_span certificates;
	struct cdk2_fmp_const_span test_digest;
};

/* Zero-initialize exactly once per boot. No reset/rebind API is provided. */
struct cdk2_system_fmp_owner {
	bool initialized;
	struct cdk2_fmp_test_key_state warning;
	enum cdk2_fmp_test_key_result detection;
	uint32_t policy_blockers;
};

/* Exact retained-image policy; deliberately not selected for any firmware. */
extern const struct cdk2_system_fmp_policy cdk2_system_fmp_retained_policy;

/* Structural/evidence checks only: no certificate or capsule authentication. */
uint32_t cdk2_system_fmp_policy_blockers(const struct cdk2_system_fmp_policy *policy);

/*
 * Consume once, including an incomplete policy, and preserve diagnostic output.
 * EFI_NOT_READY reports missing/malformed policy fields; warning hash failure
 * sets the sticky warning, not an authentication error. ABI failure does not
 * consume the owner. Reentry/reinitialization returns EFI_ALREADY_STARTED.
 * No policy, certificate or hash-context pointer is retained by the owner.
 */
EFI_STATUS cdk2_system_fmp_owner_start(struct cdk2_system_fmp_owner *owner,
	const struct cdk2_system_fmp_policy *policy,
	cdk2_fmp_key_sha256_fn *sha256, void *context);

#endif
