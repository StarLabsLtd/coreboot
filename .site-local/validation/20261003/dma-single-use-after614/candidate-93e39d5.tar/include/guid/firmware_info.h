/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_ABI_FIRMWARE_INFO_GUID_H_
#define CDK2_ABI_FIRMWARE_INFO_GUID_H_

#include <uefi.h>

#define CDK2_FIRMWARE_INFO_HOB_GUID \
	{ 0xe0653829, 0x274e, 0x4b1e, \
		{ 0x87, 0x2d, 0xa2, 0x20, 0xf5, 0xaf, 0x8f, 0x3d } }

typedef struct {
	EFI_GUID type;
	CHAR8 version_str[64];
	UINT32 version;
	UINT32 lowest_supported_version;
	UINT32 image_size;
} FIRMWARE_INFO;

#endif
