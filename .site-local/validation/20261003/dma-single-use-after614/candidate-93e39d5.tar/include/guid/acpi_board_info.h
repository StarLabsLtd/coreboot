/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_ABI_ACPI_BOARD_INFO_GUID_H_
#define CDK2_ABI_ACPI_BOARD_INFO_GUID_H_

#include <uefi.h>

typedef struct {
	UINT8 revision;
	UINT8 reserved0[2];
	UINT8 reset_value;
	UINT64 pm_evt_base;
	UINT64 pm_gpe_en_base;
	UINT64 pm_ctrl_reg_base;
	UINT64 pm_timer_reg_base;
	UINT64 reset_reg_address;
	UINT64 pcie_base_address;
	UINT64 pcie_base_size;
	UINT8 tpm20_present;
	UINT8 tpm12_present;
	UINT8 reset_reg_address_space;
	UINT8 s5_sleep_type;
	UINT8 s5_sleep_type_valid;
	UINT64 pm_ctrl_reg_base_b;
	UINT8 pm_ctrl_reg_address_space;
	UINT8 pm_gpe_en_length;
	UINT64 pm_gpe1_en_base;
	UINT8 pm_gpe1_en_length;
	UINT8 pm_ctrl_reg_b_address_space;
	UINT64 pm_evt_base_b;
	UINT8 pm_evt_address_space;
	UINT8 pm_evt_b_address_space;
	UINT8 pm_evt_length;
	UINT8 hardware_reduced_acpi;
	UINT64 sleep_control_reg;
	UINT8 sleep_control_address_space;
	UINT64 sleep_status_reg;
	UINT8 sleep_status_address_space;
	UINT8 s5_sleep_type_b;
	UINT8 pm_gpe_en_address_space;
	UINT8 pm_gpe1_en_address_space;
	UINT8 pm_gpe_address_spaces_valid;
	UINT8 s5_sleep_type_b_valid;
	UINT8 pcie_start_bus;
} ACPI_BOARD_INFO;

#endif
