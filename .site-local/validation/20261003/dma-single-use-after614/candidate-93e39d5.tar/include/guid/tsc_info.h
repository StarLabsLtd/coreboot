/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_GUID_TSC_INFO_H_
#define CDK2_GUID_TSC_INFO_H_

#include <uefi.h>

#define CDK2_TSC_INFO_REVISION 1U

/* coreboot measures this once before handing control to the payload. */
struct cdk2_tsc_info {
	UINT16 revision;
	UINT16 reserved;
	UINT64 frequency_hz;
} __packed;

#endif
