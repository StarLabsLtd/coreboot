/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#ifndef CDK2_ABI_VARIABLE_FLASH_INFO_H_
#define CDK2_ABI_VARIABLE_FLASH_INFO_H_

#include <uefi.h>

typedef struct {
	EFI_PHYSICAL_ADDRESS variable_base;
	UINT64 variable_length;
	EFI_PHYSICAL_ADDRESS working_base;
	UINT64 working_length;
	EFI_PHYSICAL_ADDRESS spare_base;
	UINT64 spare_length;
} __packed CDK2_VARIABLE_FLASH_INFO;

typedef char cdk2_variable_flash_working_offset_check[
	OFFSET_OF(CDK2_VARIABLE_FLASH_INFO, working_base) == 16U ? 1 : -1];
typedef char cdk2_variable_flash_spare_offset_check[
	OFFSET_OF(CDK2_VARIABLE_FLASH_INFO, spare_base) == 32U ? 1 : -1];

#endif
