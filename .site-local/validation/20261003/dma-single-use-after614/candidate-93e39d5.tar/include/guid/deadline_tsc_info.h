/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef CDK2_GUID_DEADLINE_TSC_INFO_H_
#define CDK2_GUID_DEADLINE_TSC_INFO_H_

#include <uefi.h>

#define CDK2_DEADLINE_TSC_INFO_REVISION 1U
#define CDK2_DEADLINE_TSC_INFO_GUID \
	{ 0xa5f21cf7, 0xb693, 0x4eeb, \
	  { 0x92, 0xf7, 0x25, 0x91, 0xa7, 0xf4, 0x2e, 0x31 } }

enum cdk2_deadline_tsc_source {
	CDK2_DEADLINE_TSC_SOURCE_COREBOOT_CONSTANT_TSC = 1U,
	CDK2_DEADLINE_TSC_SOURCE_COREBOOT_CBMEM_MEASURED_TSC = 2U,
};

/* Deadline-only TSC metadata.  The source is retained so a CBMEM measurement
 * can never be mistaken for coreboot's constant-rate TSC handoff. */
struct cdk2_deadline_tsc_info {
	UINT16 revision;
	UINT16 length;
	UINT32 source;
	UINT64 frequency_hz;
} __packed;

#endif
