/* SPDX-License-Identifier: GPL-2.0-only */
#include <cdk2/pci_host_bridge.h>
#include <cdk2/pci_enumerate.h>

#include <string.h>

static int same_bdf(const struct cdk2_pci_assignment_record *assignment,
	const struct cdk2_pci_enumerated_device *device)
{
	return assignment->segment == device->segment &&
		assignment->bus == device->bus &&
		assignment->device == device->device &&
		assignment->function == device->function;
}

static int read_config(cdk2_pci_enumerate_read_fn *read, void *context,
	const struct cdk2_pci_assignment_record *assignment, uint16_t offset,
	uint32_t *value)
{
	return read(context, assignment->segment, assignment->bus,
		assignment->device, assignment->function, offset, value);
}

static int validate_bar(const struct cdk2_pci_assignment_record *assignment,
	cdk2_pci_enumerate_read_fn *read, void *context)
{
	uint32_t low, high = 0;
	uint64_t base;
	uint16_t offset = (uint16_t)(0x10U + assignment->bar * 4U);

	if (read_config(read, context, assignment, offset, &low) != 0)
		return 2;
	if (assignment->resource_type == CDK2_PCI_RESOURCE_IO) {
		if ((low & 1U) == 0U || (assignment->flags & CDK2_PCI_ASSIGNMENT_64BIT))
			return 3;
		base = low & ~3ULL;
	} else {
		int authoritative_prefetch = assignment->resource_type == 4U ||
			assignment->resource_type == CDK2_PCI_RESOURCE_PREFETCH_MMIO64;

		if ((low & 1U) != 0U)
			return 4;
		if (!!(low & 8U) != authoritative_prefetch)
			return 5;
		if (assignment->flags & CDK2_PCI_ASSIGNMENT_64BIT) {
			if ((low & 6U) != 4U || assignment->bar == 5U ||
			    read_config(read, context, assignment,
				(uint16_t)(offset + 4U), &high) != 0)
				return 6;
		} else if ((low & 6U) == 4U) {
			return 7;
		}
		base = ((uint64_t)high << 32) | (low & ~15ULL);
	}
	return base == assignment->base ? 0 : 8;
}

int cdk2_pci_enumerate_assigned(
	const struct cdk2_pci_assignment_record *assignments,
	size_t assignment_count, cdk2_pci_enumerate_read_fn *read,
	void *context, struct cdk2_pci_enumeration *enumeration)
{
	size_t assignment, device, visible_assignment_count = 0U;

	if (assignments == NULL || assignment_count == 0U || read == NULL ||
	    enumeration == NULL)
		return -1;
	memset(enumeration, 0, sizeof(*enumeration));
	for (assignment = 0; assignment < assignment_count; assignment++) {
		const struct cdk2_pci_assignment_record *record = &assignments[assignment];
		uint32_t identity, class_revision, command_after;
		struct cdk2_pci_enumerated_device *found = NULL;
		int bar_status;

		if (record->device >= 32U || record->function >= 8U || record->bar >= 6U ||
		    record->length == 0U)
			return -(int)(0x200U + assignment * 0x10U + 1U);
		if (read_config(read, context, record, 0x00U, &identity) != 0)
			return -(int)(0x200U + assignment * 0x10U + 11U);
		/* A platform may hide a function during its final pre-payload lockdown,
		 * after constructing the coreboot resource table.  Such a function is
		 * no longer part of the payload-visible topology; retain strict BAR
		 * validation for every function that remains visible. */
		if ((identity & 0xffffU) == 0xffffU || (identity & 0xffffU) == 0U)
			continue;
		bar_status = validate_bar(record, read, context);
		if (bar_status != 0)
			return -(int)(0x200U + assignment * 0x10U +
				(unsigned int)bar_status);
		for (size_t prior = 0U; prior < assignment; prior++)
			if (assignments[prior].segment == record->segment &&
			    assignments[prior].bus == record->bus &&
			    assignments[prior].device == record->device &&
			    assignments[prior].function == record->function &&
			    assignments[prior].bar == record->bar)
				return -(int)(0x200U + assignment * 0x10U + 9U);
		for (device = 0; device < enumeration->count; device++)
			if (same_bdf(record, &enumeration->device[device])) {
				found = &enumeration->device[device];
				break;
			}
		if (found == NULL) {
			if (enumeration->count == CDK2_PCI_ENUMERATE_MAX_DEVICES)
				return -(int)(0x200U + assignment * 0x10U + 10U);
			if (read_config(read, context, record, 0x08U, &class_revision) != 0)
				return -(int)(0x200U + assignment * 0x10U + 12U);
			found = &enumeration->device[enumeration->count++];
			*found = (struct cdk2_pci_enumerated_device) {
				.segment = record->segment, .bus = record->bus,
				.device = record->device, .function = record->function,
				.vendor = (uint16_t)identity,
				.device_id = (uint16_t)(identity >> 16),
				.command = 0,
				.programming_interface = (uint8_t)(class_revision >> 8),
				.subclass = (uint8_t)(class_revision >> 16),
				.class_code = (uint8_t)(class_revision >> 24) };
			if (read_config(read, context, record, 0x04U, &command_after) != 0)
				return -(int)(0x200U + assignment * 0x10U + 14U);
			found->command = (uint16_t)command_after;
		}
		if (found->assignment_count == UINT8_MAX)
			return -(int)(0x200U + assignment * 0x10U + 15U);
		found->assignment_count++;
		visible_assignment_count++;
	}
	for (device = 0; device < enumeration->count; device++) {
		uint32_t command_after;
		const struct cdk2_pci_enumerated_device *entry =
			&enumeration->device[device];
		struct cdk2_pci_assignment_record key = { .segment = entry->segment,
			.bus = entry->bus, .device = entry->device,
			.function = entry->function };
		if (read_config(read, context, &key, 0x04U, &command_after) != 0 ||
		    (uint16_t)command_after != entry->command)
			return -(int)(0x600U + device);
	}
	enumeration->assignment_count = visible_assignment_count;
	return 0;
}
