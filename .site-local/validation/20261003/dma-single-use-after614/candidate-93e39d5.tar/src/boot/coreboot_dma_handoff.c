/* SPDX-License-Identifier: GPL-2.0-only */

#include "coreboot.h"
#include "coreboot_checksum.h"

#include <cdk2/dma_handoff.h>

#include <stddef.h>
#include <string.h>

static uint32_t handoff_crc32(const struct dma_handoff_header *header)
{
	const uint8_t *bytes = (const void *)header;
	const size_t crc_offset = OFFSET_OF(struct dma_handoff_header, crc32);
	uint32_t crc = 0U;

	for (size_t index = 0U; index < header->size; index++)
		crc = cdk2_coreboot_crc32_update(crc,
			index >= crc_offset && index < crc_offset + sizeof(header->crc32) ?
			0U : bytes[index]);
	return crc;
}

static uint8_t range_valid(uint64_t base, uint32_t pages, uint16_t granule_shift,
	uint64_t *end)
{
	uint64_t granule;
	uint64_t bytes;

	if (granule_shift >= 64U)
		return FALSE;
	granule = 1ULL << granule_shift;
	if (base == 0U || (base & (granule - 1U)) != 0U || pages == 0U ||
	    pages > (MAX_UINT64 >> granule_shift))
		return FALSE;
	bytes = (uint64_t)pages << granule_shift;
	if (base > MAX_UINT64 - bytes)
		return FALSE;
	*end = base + bytes;
	return TRUE;
}

static uint8_t range_overlaps_blob(uint64_t base, uint64_t end,
	const void *blob, uint32_t bytes)
{
	const uint64_t blob_base = (uintptr_t)blob;
	uint64_t blob_end;

	if (blob_base > MAX_UINT64 - bytes)
		return TRUE;
	blob_end = blob_base + bytes;
	return base < blob_end && blob_base < end;
}

static uint64_t unpack64(const struct cbuint64 *value)
{
	return (uint64_t)value->lo | ((uint64_t)value->hi << 32);
}

static uint64_t validate_requesters_against_boot_intent(
	const struct cdk2_coreboot_handoff *coreboot,
	const struct cdk2_dma_handoff_state *state)
{
	const struct cb_payload_resource_handoff *resource =
		coreboot->payload_resource_handoff;
	const struct cb_payload_resource_section *topology;
	const struct cb_payload_resource_section *boot_intent;
	uint64_t status;

	status = cdk2_coreboot_find_payload_resource_section(coreboot,
		CB_PRH_SECTION_PCI_TOPOLOGY, &topology);
	if (EFI_ERROR(status))
		return status == EFI_NOT_FOUND ? EFI_SECURITY_VIOLATION : status;
	status = cdk2_coreboot_find_payload_resource_section(coreboot,
		CB_PRH_SECTION_BOOT_INTENT, &boot_intent);
	if (EFI_ERROR(status))
		return status == EFI_NOT_FOUND ? EFI_SECURITY_VIOLATION : status;
	if (state->requester_count != boot_intent->entry_count)
		return EFI_SECURITY_VIOLATION;
	for (uint32_t requester_index = 0U;
	     requester_index < state->requester_count; requester_index++) {
		const struct dma_handoff_requester *requester =
			&state->requesters[requester_index];
		uint32_t matches = 0U;

		for (uint32_t boot_index = 0U;
		     boot_index < boot_intent->entry_count; boot_index++) {
			const struct cb_prh_boot_intent_entry *boot = (const void *)
				((const uint8_t *)resource + boot_intent->offset +
				 (size_t)boot_index * boot_intent->entry_size);
			const struct cb_prh_pci_topology_entry *function;
			uint16_t bdf;

			if (boot->topology_index >= topology->entry_count)
				return EFI_COMPROMISED_DATA;
			function = (const void *)((const uint8_t *)resource +
				topology->offset +
				(size_t)boot->topology_index * topology->entry_size);
			bdf = ((uint16_t)function->bus << 8) |
				((uint16_t)function->device << 3) | function->function;
			if (function->segment != requester->segment ||
			    bdf != requester->bdf)
				continue;
			if ((function->command & 4U) != 0U)
				return EFI_SECURITY_VIOLATION;
			matches++;
		}
		if (matches != 1U)
			return EFI_SECURITY_VIOLATION;
	}
	return EFI_SUCCESS;
}

uint64_t cdk2_dma_handoff_find_blob(
	const struct cdk2_coreboot_handoff *coreboot, uint32_t minimum_size,
	uint64_t *base, uint32_t *size)
{
	const struct cb_record *record;
	const struct cb_cbmem_entry *entry;
	const uint8_t *cursor;
	uint64_t found_base = 0U;
	uint32_t found_size = 0U;
	size_t remaining;
	size_t index;
	uint8_t found = FALSE;

	if (coreboot == NULL || coreboot->header == NULL || base == NULL ||
	    size == NULL)
		return EFI_INVALID_PARAMETER;
	if (coreboot->header->header_bytes > coreboot->table_size)
		return EFI_COMPROMISED_DATA;
	cursor = (const uint8_t *)coreboot->header + coreboot->header->header_bytes;
	remaining = coreboot->table_size - coreboot->header->header_bytes;
	for (index = 0U; index < coreboot->record_count; index++) {
		if (remaining < sizeof(*record))
			return EFI_COMPROMISED_DATA;
		record = (const struct cb_record *)(const void *)cursor;
		if (record->size < sizeof(*record) || record->size > remaining)
			return EFI_COMPROMISED_DATA;
		if (record->tag == CB_TAG_CBMEM_ENTRY) {
			if (record->size < sizeof(*entry))
				return EFI_COMPROMISED_DATA;
			entry = (const struct cb_cbmem_entry *)record;
			if (entry->id == CBMEM_ID_DMA_HANDOFF) {
				struct cbuint64 packed_address;

				if (found)
					return EFI_COMPROMISED_DATA;
				memcpy(&packed_address, &entry->address,
					sizeof(packed_address));
				found_base = unpack64(&packed_address);
				found_size = entry->entry_size;
				if (found_base == 0U || found_size < minimum_size ||
				    found_base > MAX_UINT64 - found_size)
					return EFI_COMPROMISED_DATA;
				found = TRUE;
			}
		}
		cursor += record->size;
		remaining -= record->size;
	}
	if (!found)
		return EFI_NOT_FOUND;
	*base = found_base;
	*size = found_size;
	return EFI_SUCCESS;
}

static uint64_t validate_blob(const void *blob, uint32_t bytes,
	struct cdk2_dma_handoff_state *state)
{
	const struct dma_handoff_header *header = blob;
	const struct dma_handoff_requester *requesters;
	size_t expected;
	uint32_t slot;

	if (blob == NULL || state == NULL || bytes < sizeof(*header))
		return EFI_INVALID_PARAMETER;
	if (header->revision != DMA_HANDOFF_REVISION ||
	    header->header_size != sizeof(*header) ||
	    header->requester_size != sizeof(*requesters) ||
	    header->granule_shift != DMA_HANDOFF_GRANULE_SHIFT ||
	    header->flags != DMA_HANDOFF_REQUIRED_FLAGS || header->generation == 0U ||
	    header->reserved[0] != 0U || header->reserved[1] != 0U ||
	    header->requester_count == 0U ||
	    header->requester_count > DMA_HANDOFF_MAX_REQUESTERS)
		return EFI_COMPROMISED_DATA;
	expected = sizeof(*header) +
		(size_t)header->requester_count * sizeof(*requesters);
	if (expected > MAX_UINT32 || header->size != expected || bytes != expected)
		return EFI_COMPROMISED_DATA;
	if (handoff_crc32(header) != header->crc32)
		return EFI_COMPROMISED_DATA;
	requesters = (const void *)((const uint8_t *)blob + header->header_size);
	for (slot = 0; slot < header->requester_count; slot++) {
		const struct dma_handoff_requester *requester = &requesters[slot];
		uint64_t cpu_end;
		uint64_t device_end;
		uint32_t other;

		if (requester->protection_domain == 0U ||
		    requester->flags != DMA_HANDOFF_REQUESTER_FLAGS ||
		    requester->arena_flags != DMA_HANDOFF_ARENA_FLAGS ||
		    !range_valid(requester->arena_cpu_base, requester->arena_pages,
			header->granule_shift, &cpu_end) ||
		    !range_valid(requester->arena_device_base, requester->arena_pages,
			header->granule_shift, &device_end) ||
		    range_overlaps_blob(requester->arena_cpu_base, cpu_end, blob,
			header->size))
			return EFI_COMPROMISED_DATA;
		for (other = 0; other < slot; other++) {
			uint64_t other_cpu_end = requesters[other].arena_cpu_base +
				((uint64_t)requesters[other].arena_pages <<
				 header->granule_shift);

			if ((requesters[other].segment == requester->segment &&
			     requesters[other].bdf == requester->bdf) ||
			    requesters[other].protection_domain ==
				requester->protection_domain ||
			    (requester->arena_cpu_base < other_cpu_end &&
			     requesters[other].arena_cpu_base < cpu_end))
				return EFI_COMPROMISED_DATA;
		}
	}
	state->valid = TRUE;
	state->generation = header->generation;
	state->requester_count = header->requester_count;
	memcpy(state->requesters, requesters,
		header->requester_count * sizeof(*requesters));
	return EFI_SUCCESS;
}

uint64_t cdk2_dma_handoff_consume(
	const struct cdk2_coreboot_handoff *coreboot,
	uint64_t cbmem_base, uint32_t cbmem_size,
	struct cdk2_dma_handoff_state *state)
{
	const struct cb_dma_handoff *reference;
	const void *record;
	struct cbuint64 packed_generation;
	uint64_t status;

	if (state == NULL)
		return EFI_INVALID_PARAMETER;
	*state = (struct cdk2_dma_handoff_state){0};
	if (coreboot == NULL || cbmem_base == 0U || cbmem_base > UINTPTR_MAX)
		return EFI_INVALID_PARAMETER;
	if (coreboot->payload_resource_handoff_status != EFI_SUCCESS ||
	    coreboot->payload_resource_handoff == NULL ||
	    coreboot->payload_resource_handoff->revision !=
		CB_PAYLOAD_RESOURCE_HANDOFF_REVISION_4)
		return EFI_SECURITY_VIOLATION;
	status = cdk2_coreboot_find_unique_record(coreboot, CB_TAG_DMA_HANDOFF,
		sizeof(*reference), &record);
	if (EFI_ERROR(status))
		return status == EFI_NOT_FOUND ? EFI_SECURITY_VIOLATION : status;
	reference = record;
	if (reference->size != sizeof(*reference) ||
	    reference->revision != DMA_HANDOFF_REVISION || reference->reserved != 0U ||
	    reference->address != cbmem_base || reference->bytes != cbmem_size ||
	    cbmem_size < sizeof(struct dma_handoff_header))
		return EFI_COMPROMISED_DATA;
	memcpy(&packed_generation,
		(const uint8_t *)coreboot->payload_resource_handoff +
		OFFSET_OF(struct cb_payload_resource_handoff, producer_generation),
		sizeof(packed_generation));
	status = validate_blob((const void *)(uintptr_t)cbmem_base, cbmem_size, state);
	if (EFI_ERROR(status))
		return status;
	if (state->generation != unpack64(&packed_generation)) {
		*state = (struct cdk2_dma_handoff_state){0};
		return EFI_SECURITY_VIOLATION;
	}
	status = validate_requesters_against_boot_intent(coreboot, state);
	if (EFI_ERROR(status)) {
		*state = (struct cdk2_dma_handoff_state){0};
		return status;
	}
	return EFI_SUCCESS;
}

uint64_t cdk2_dma_handoff_import(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_dma_handoff_state *state)
{
	uint64_t base;
	uint32_t size;
	uint64_t status;

	if (state == NULL)
		return EFI_INVALID_PARAMETER;
	*state = (struct cdk2_dma_handoff_state){0};
	status = cdk2_dma_handoff_find_blob(coreboot,
		sizeof(struct dma_handoff_header), &base, &size);
	if (EFI_ERROR(status))
		return status;
	return cdk2_dma_handoff_consume(coreboot, base, size, state);
}
