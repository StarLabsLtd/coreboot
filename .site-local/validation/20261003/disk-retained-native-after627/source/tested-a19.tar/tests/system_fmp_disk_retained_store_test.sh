#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

test "$#" -eq 2 || exit 2
media_path=$1
: "${COREBOOT_TREE:?actual producer codec source required}"
: "${CBFSTOOL:?actual matching producer cbfstool required}"
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
output=$(mktemp -d "$2/disk-retained-store.XXXXXX")
printf 'Actual codec artifacts: %s\n' "$output"
compiler=${HOSTCC:-cc}
sources=
for implementation in fv store record store_semantics writer default_store ftw; do
	sources="$sources $COREBOOT_TREE/src/lib/payload_mm_authvar_$implementation.c"
done
sources="$sources $COREBOOT_TREE/src/lib/uuid.c $COREBOOT_TREE/src/lib/hexstrtobin.c"
translation_units=1
# shellcheck disable=SC2086
for source in $sources; do translation_units=$((translation_units + 1)); done
set -- -std=gnu11 -Wall -Wextra -Werror -g -fno-builtin -fno-pie -no-pie \
	-fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer -DENV_TEST=1 \
	-Du8=uint8_t -Du16=uint16_t -Du32=uint32_t -Du64=uint64_t -Ds32=int32_t -Ds64=int64_t \
	-include "$COREBOOT_TREE/src/commonlib/bsd/include/commonlib/bsd/compiler.h" \
	-I"$COREBOOT_TREE/src/commonlib/include" -I"$COREBOOT_TREE/src/commonlib/bsd/include" \
	-idirafter "$COREBOOT_TREE/src/include"
# Capture actual compiler-reported transitive closure before compiling either
# variant. No persistent objects, source replacements, or guest writes exist.
for optimization in 0 2; do
	# shellcheck disable=SC2086
	"$compiler" "$@" -O"$optimization" -M -MT closure \
		"$root/tests/system_fmp_disk_retained_store.c" $sources \
		> "$output/dependencies-o$optimization.mk"
done
perl - "$((translation_units * 2))" "$output/dependencies-o0.mk" "$output/dependencies-o2.mk" <<-'PERL' > "$output/dependencies.list"
	use strict;
	use warnings;
	my $expected = shift @ARGV;
	my $targets = 0;
	my %paths;
	for my $file (@ARGV) {
		open my $input, '<', $file or die $!;
		local $/;
		my $body = <$input>;
		$body =~ s/\\\n/ /g;
		$targets += ($body =~ s/^closure:\s*//mg);
		for my $path (split /\s+/, $body) {
			next unless length $path;
			die "unsupported escaped/space dependency" if $path =~ /\\/;
			$paths{$path} = 1;
		}
	}
	die "dependency target cardinality $targets != $expected" unless $targets == $expected;
	print "$_\n" for sort keys %paths;
PERL
while IFS= read -r path; do
	sha256sum "$path"
done < "$output/dependencies.list" > "$output/closure-before.sha256"
sha256sum "$0" "$CBFSTOOL" "$(command -v "$compiler")" >> "$output/closure-before.sha256"
sha256sum "$root/src/modules/capsule_runtime/entry.c" "$(command -v python3)" \
	"$(command -v perl)" >> "$output/closure-before.sha256"
sha256sum "$media_path" >> "$output/closure-before.sha256"
# Bind the retirement namespace to the actual Runtime publisher, not a
# separately remembered GUID or a value learned from successful media.
python3 -B - "$root/src/modules/capsule_runtime/entry.c" "$root/tests/system_fmp_disk_retained_store.c" <<-'PY'
	import pathlib
	import re
	import struct
	import sys

	runtime_source = pathlib.Path(sys.argv[1]).read_text()
	oracle_source = pathlib.Path(sys.argv[2]).read_text()
	runtime = re.findall(r"static const EFI_GUID capsule_vendor_guid = \{(.*?)\};",
	                     runtime_source, re.S)
	oracle = re.findall(r"static const uint8_t request_guid\[16\] = \{(.*?)\};",
	                    oracle_source, re.S)
	if len(runtime) != 1 or len(oracle) != 1:
	    raise ValueError("request namespace declaration cardinality")
	number = r"(0x[0-9a-fA-F]+)"
	fields = re.fullmatch(r"\s*" + r"\s*,\s*".join([number] * 3) +
	                      r"\s*,\s*\{\s*" + r"\s*,\s*".join([number] * 8) +
	                      r"\s*\}\s*", runtime[0])
	values = re.fullmatch(r"\s*" + r"\s*,\s*".join([number] * 16) + r"\s*,?\s*",
	                      oracle[0])
	if fields is None or values is None:
	    raise ValueError("request namespace representation")
	fields = [int(value, 16) for value in fields.groups()]
	values = [int(value, 16) for value in values.groups()]
	if struct.pack("<IHH8B", *fields) != bytes(values):
	    raise ValueError("actual Runtime request namespace")
	names = re.findall(r'CHAR16 name\[32\] = L"([^"]+)";', runtime_source)
	prefix = re.findall(r"static const uint16_t request_prefix\[\] = \{(.*?)\};",
	                    oracle_source, re.S)
	if len(names) != 1 or len(prefix) != 1:
	    raise ValueError("request prefix declaration cardinality")
	if re.fullmatch(r"\s*'[A-Za-z]'\s*(?:,\s*'[A-Za-z]'\s*)*,?\s*", prefix[0]) is None:
	    raise ValueError("request prefix representation")
	if names[0] != "".join(re.findall(r"'([^'])'", prefix[0])):
	    raise ValueError("actual Runtime request prefix")
PY
"$CBFSTOOL" "$media_path" read -r SMMSTORE -f "$output/store.bin" > "$output/extract.log" 2>&1
"$CBFSTOOL" "$media_path" extract -n config -f "$output/producer.config" > "$output/config.log" 2>&1
grep -qx 'CONFIG_Q35_SMM_CAPSULE_BROKER=y' "$output/producer.config"
grep -qx 'CONFIG_PAYLOAD_MM_FMP_OWNER_AUTHVAR_BOOT=y' "$output/producer.config"
test "$(grep -c '^CONFIG_DRIVERS_EFI_MAIN_FW_GUID=' "$output/producer.config")" -eq 1
guid=$(sed -n 's/^CONFIG_DRIVERS_EFI_MAIN_FW_GUID="\(.*\)"$/\1/p' "$output/producer.config")
export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
for optimization in 0 2; do
	# shellcheck disable=SC2086
	"$compiler" "$@" -O"$optimization" "$root/tests/system_fmp_disk_retained_store.c" \
		$sources -o "$output/check-o$optimization" > "$output/build-o$optimization.log" 2>&1
	"$output/check-o$optimization" "$output/store.bin" "$guid" > "$output/check-o$optimization.log" 2>&1
done
sha256sum -c "$output/closure-before.sha256" > "$output/closure-check.log"
printf '%s\n' 'Actual producer DISK-to-RAM final media codec: PASS (HOST read-only)'
