# SPDX-License-Identifier: GPL-2.0-only
"""HOST-modeled opposition of the actual four-epoch observer predicates."""

import ast
import copy
import struct
import types
import unittest
from pathlib import Path

import system_fmp_disk_retained_native_test as observer
from qmp_cbmem_console import PhysicalReadError


def records(epoch):
    version = observer.TARGET_VERSION if epoch == 3 else observer.INITIAL_VERSION
    result = [(0x45, struct.pack("<II", 0x45, 36) + observer.IMAGE_GUID +
               struct.pack("<III", version, observer.INITIAL_VERSION, observer.IMAGE_SIZE)),
              (0x59, struct.pack("<IIHHIQQQ", 0x59, 40, 1, 40, 3, 16777216, 16777216, 0))]
    if epoch == 2:
        result.append((0x46, struct.pack("<IIQI", 0x46, 20, 0x200000, 64)))
    return result


def body(epoch):
    lines = [b"CDK2 | CAPSULE_RAM | begin | NOT_STARTED (0x8000000000000013) | 0 us"]
    if epoch == 2:
        lines += [b"CDK2 | module 0x02 | SystemFmp CHECK transport | 0x0000000000000000",
                  b"CDK2 | module 0x02 | SystemFmp SET transport | 0x0000000000000000"]
    else:
        lines += [b"CDK2 | CAPSULE_RAM | complete | SUCCESS (0x0000000000000000) | 1 us",
                  b"CDK2 | PCI_ROOTS | begin | NOT_STARTED (0x8000000000000013) | 0 us",
                  b"CDK2 | CAPSULE_DISK | begin | NOT_STARTED (0x8000000000000013) | 0 us"]
        if epoch != 1:
            lines += [b"CDK2 | CAPSULE_DISK | complete | SUCCESS (0x0000000000000000) | 1 us",
                      b"CDK2 | OS_HANDOFF | begin | NOT_STARTED (0x8000000000000013) | 0 us"]
    return b"\n".join(lines) + b"\n"


class RunnerTests(unittest.TestCase):
    def test_packaged_kconfig_exact_values(self):
        full = ['# generated full config', 'CONFIG_ROUTE=y', 'CONFIG_WIDTH=0x00800000',
                'CONFIG_PATH="/actual/Core.elf"', '# CONFIG_LEGACY is not set', 'CONFIG_DISABLED=n']
        packed = ['# savedefconfig + derivable values', 'CONFIG_PATH="/actual/Core.elf"',
                  'CONFIG_WIDTH=0x00800000', 'CONFIG_ROUTE=y']
        expected = observer.config_assignments(full)
        self.assertEqual(observer.config_assignments(packed), expected)
        for changed in (packed + ['CONFIG_UNKNOWN=y'], packed[:-1],
                        [line.replace('0x00800000', '0x00400000') for line in packed],
                        [line.replace('/actual/Core.elf', '/other/Core.elf') for line in packed],
                        [line.replace('CONFIG_ROUTE=y', 'CONFIG_ROUTE=m') for line in packed]):
            self.assertNotEqual(observer.config_assignments(changed), expected)
        for changed in (packed + ['CONFIG_ROUTE=y'], packed + ['CONFIG_ROUTE=n'],
                        packed + ['# CONFIG_ROUTE is not set'], ['CONFIG_X='],
                        ['CONFIG_X'], ['# CONFIG_X not set'], ['UNKNOWN=y']):
            with self.assertRaises(ValueError):
                observer.config_assignments(changed)

    def test_each_epoch_and_old_partial_tail(self):
        for epoch in range(4):
            observer.check_epoch(epoch, body(0) + body(epoch), records(epoch), 1073741824, b"c" * 64)

    def test_firmware_and_policy_identity(self):
        good = records(0)
        variants = [good + [good[0]], good[1:], [good[0]], good + [good[1]]]
        for offset in (8, 24, 28, 32):
            changed = bytearray(good[0][1])
            changed[offset] ^= 1
            variants.append([(0x45, bytes(changed)), good[1]])
        for offset in (8, 10, 12, 32):
            changed = bytearray(good[1][1])
            changed[offset] ^= 4
            variants.append([good[0], (0x59, bytes(changed))])
        too_small = bytearray(good[1][1])
        struct.pack_into("<Q", too_small, 16, 63)
        variants.append([good[0], (0x59, bytes(too_small))])
        for offset in (16, 24):
            overflow = bytearray(good[1][1])
            struct.pack_into("<Q", overflow, offset, 0x100000000)
            variants.append([good[0], (0x59, bytes(overflow))])
        for variant in variants:
            with self.subTest(variant=variant), self.assertRaises(ValueError):
                observer.check_epoch(0, body(0), variant, 1073741824, b"c" * 64)

    def test_retained_capsule_class_bounds(self):
        good = records(2)
        variants = [good[:2], good + [good[2]]]
        for address, size in ((0, 64), (1073741824, 64), (1073741800, 64), (0x200000, 63)):
            variants.append(good[:2] + [(0x46, struct.pack("<IIQI", 0x46, 20, address, size))])
        for variant in variants:
            with self.subTest(variant=variant), self.assertRaises(ValueError):
                observer.check_epoch(2, body(2), variant, 1073741824, b"c" * 64)
        with self.assertRaises(ValueError):
            observer.check_epoch(1, body(1), good, 1073741824, b"c" * 64)

    def test_late_writer_and_processing_phase(self):
        variants = [(1, body(1) + body(2).split(b"\n", 1)[1]),
                    (1, body(0)), (2, body(0)),
                    (2, body(2).replace(b"SET transport | 0x0000000000000000",
                                        b"SET transport | 0x0000000000000008")),
                    (2, body(2).replace(b"CHECK transport", b"SET transport")),
                    (2, body(2).replace(b"CHECK", b"TEMP").replace(b"SET", b"CHECK").replace(b"TEMP", b"SET")),
                    (2, body(2) + b"CDK2 | CAPSULE_DISK | complete | SUCCESS (0x0000000000000000) | 1 us\n"),
                    (0, body(0).replace(b"CAPSULE_RAM | complete", b"CAPSULE_RAM | ignored")),
                    (3, body(3).replace(b"CAPSULE_DISK | complete", b"CAPSULE_DISK | ignored"))]
        for epoch, variant in variants:
            with self.subTest(epoch=epoch, variant=variant), self.assertRaises(ValueError):
                observer.check_epoch(epoch, variant, records(epoch), 1073741824, b"c" * 64)
        for epoch in range(4):
            with self.assertRaises(ValueError):
                observer.check_epoch(epoch, body(epoch) +
                    b"CDK2 | PLATFORM_TABLES | failed | COMPROMISED_DATA\n",
                    records(epoch), 1073741824, b"c" * 64)

    def test_malformed_extra_transport_diagnostics(self):
        for epoch in range(4):
            for operation in (b"CHECK", b"SET"):
                for suffix in (b" | 0x000000000000000z", b" | success", b" | 0x0000000000000000 extra"):
                    changed = body(epoch) + b"CDK2 | module 0x02 | SystemFmp " + operation + \
                        b" transport" + suffix + b"\n"
                    with self.subTest(epoch=epoch, operation=operation, suffix=suffix), self.assertRaises(ValueError):
                        observer.check_epoch(epoch, changed, records(epoch), 1073741824, b"c" * 64)

    def test_markers_and_reset_cardinality(self):
        names = ("MAIN", "SETUP1_SECURE0", "REAL_FMP_ESRT_INFO", "SET_READBACK_RESET",
                 "MAIN", "SETUP1_SECURE0", "REAL_FMP_ESRT_INFO", "TARGET_A_NO_RESUBMIT_PASS")
        uart = b"".join(("CDK2_EFI_DISK_REQUEST_" + name + "\r\n").encode() for name in names)
        events = [{"event": "RESET", "data": {"guest": True}} for _ in range(3)]
        observer.check_markers(uart, events)
        for changed in (events[:-1], events + [events[0]],
                        [{"event": "RESET", "data": {"guest": False}}] + events[1:]):
            with self.assertRaises(ValueError):
                observer.check_markers(uart, changed)
        for name in set(names):
            marker = ("CDK2_EFI_DISK_REQUEST_" + name + "\r\n").encode()
            for changed in (uart.replace(marker, b"", 1), uart + marker):
                with self.assertRaises(ValueError):
                    observer.check_markers(changed, events)
        with self.assertRaises(ValueError):
            observer.check_markers(uart + b"CDK2_EFI_DISK_REQUEST_FAIL", events)

    def test_exact_media_and_allowed_real_store(self):
        initial = b"i" * observer.IMAGE_SIZE
        target = initial[:73728] + b"t" * (observer.IMAGE_SIZE - 73728)
        installed = b"s" * 65536 + target[65536:]
        regions = {"SMMSTORE": (0, 65536), "COREBOOT": (73728, observer.IMAGE_SIZE - 73728)}
        observer.check_media(installed, initial, target, regions)
        for changed in (installed[:-1], installed[:65536] + b"x" + installed[65537:],
                        installed[:-1] + b"x"):
            with self.assertRaises(ValueError):
                observer.check_media(changed, initial, target, regions)
        with self.assertRaises(ValueError):
            observer.check_media(installed, initial, target, dict(regions, SMMSTORE=(0, 1)))

    def test_actual_terminal_success_and_read_error_predicates(self):
        tree = ast.parse(Path(observer.__file__).read_text())
        terminal = [node for node in ast.walk(tree) if isinstance(node, ast.If) and
                    ast.unparse(node.test) == "process.poll() != 3 or time.monotonic() > deadline"]
        read = [node for node in ast.walk(tree) if isinstance(node, ast.If) and
                ast.unparse(node.test).startswith("process.poll() == 3 and reader.metadata is not None")]
        self.assertEqual((len(terminal), len(read)), (1, 1))
        for status, now, accepted in ((3, 179, True), (3, 181, False), (None, 179, False), (2, 179, False)):
            namespace = {"process": types.SimpleNamespace(poll=lambda: status),
                         "time": types.SimpleNamespace(monotonic=lambda: now), "deadline": 180}
            predicate = compile(ast.Expression(copy.deepcopy(terminal[0].test)), "actual-terminal", "eval")
            self.assertEqual(not eval(predicate, namespace), accepted)
        wrapped = PhysicalReadError("read failed")
        wrapped.__cause__ = OSError("transport closed")
        semantic = PhysicalReadError("malformed read")
        for status, metadata, error, accepted in ((3, {}, wrapped, True), (3, {}, OSError(), True),
                (3, {}, EOFError(), True), (3, {}, semantic, False), (3, {}, ValueError(), False),
                (None, {}, wrapped, False), (2, {}, wrapped, False), (3, None, wrapped, False)):
            namespace = {"process": types.SimpleNamespace(poll=lambda: status),
                         "reader": types.SimpleNamespace(metadata=metadata), "error": error,
                         "PhysicalReadError": PhysicalReadError}
            predicate = compile(ast.Expression(copy.deepcopy(read[0].test)), "actual-read", "eval")
            self.assertEqual(eval(predicate, namespace), accepted)


if __name__ == "__main__":
    unittest.main()
