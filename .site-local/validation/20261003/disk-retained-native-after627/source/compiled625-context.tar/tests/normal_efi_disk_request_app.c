/* SPDX-License-Identifier: GPL-2.0-only */

/* Normally admitted QEMU EFI app: real variable request, never MM authority. */
#include <cdk2/esrt.h>
#include <cdk2/esrt_abi.h>
#include <cdk2/reset_system.h>
#include <cdk2/system_fmp_provider.h>

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef EFI_STATUS CDK2_MS_ABI locate_protocol_fn(const EFI_GUID *, void *, void **);
typedef EFI_STATUS CDK2_MS_ABI get_variable_fn(CHAR16 *, const EFI_GUID *,
	UINT32 *, UINTN *, void *);
typedef EFI_STATUS CDK2_MS_ABI set_variable_fn(CHAR16 *, const EFI_GUID *,
	UINT32, UINTN, void *);
typedef EFI_STATUS CDK2_MS_ABI free_pool_fn(void *);

struct configuration_table {
	EFI_GUID guid;
	void *table;
};

static const EFI_GUID global_guid = {
	0x8be4df61, 0x93ca, 0x11d2,
	{ 0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c },
};
static const EFI_GUID fmp_guid = {
	0x86c77a67, 0x0b97, 0x4633,
	{ 0xa1, 0x87, 0x49, 0x10, 0x4d, 0x06, 0x85, 0xc7 },
};
static const EFI_GUID esrt_guid = {
	0xb122a263, 0x3661, 0x4f68,
	{ 0x99, 0x29, 0x78, 0xf8, 0xb0, 0xd6, 0x21, 0x80 },
};
static const EFI_GUID image_guid = {
	0x00112233, 0x4455, 0x6677,
	{ 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff },
};
static CHAR16 indications_name[] = L"OsIndications";
static CHAR16 supported_name[] = L"OsIndicationsSupported";
static CHAR16 setup_name[] = L"SetupMode";
static CHAR16 secure_name[] = L"SecureBoot";

static bool guid_equal(const EFI_GUID *a, const EFI_GUID *b)
{
	const uint8_t *first = (const uint8_t *)a;
	const uint8_t *second = (const uint8_t *)b;

	for (size_t index = 0; index < sizeof(*a); index++) {
		if (first[index] != second[index])
			return false;
	}
	return true;
}

static void marker(const char *text)
{
	while (*text != '\0') {
		__asm__ volatile("outb %0, %1" : :
			"a"((uint8_t)*text), "Nd"((uint16_t)0x3f8));
		text++;
	}
}

static void fail(const char *reason)
{
	marker("CDK2_EFI_DISK_REQUEST_FAIL ");
	marker(reason);
	marker("\r\n");
	__asm__ volatile("outl %0, %1" : : "a"(2U), "Nd"((uint16_t)0xf4));
	for (;;)
		__asm__ volatile("cli; hlt");
}

EFI_STATUS CDK2_MS_ABI normal_efi_disk_request_entry(void *image,
	struct cdk2_system_table_view *system)
{
	struct cdk2_fmp_descriptor descriptor;
	struct cdk2_fmp_protocol *fmp = NULL;
	const struct cdk2_esrt_table *esrt = NULL;
	const struct configuration_table *tables;
	locate_protocol_fn *locate;
	get_variable_fn *get;
	set_variable_fn *set;
	free_pool_fn *release;
	cdk2_reset_fn reset;
	UINTN info_size = sizeof(descriptor), descriptor_size = 0, size;
	UINT32 descriptor_version = 0, package_version = 0, attributes = 0;
	UINT8 count = 0;
	CHAR16 *package_name = NULL;
	uint8_t setup = 0, secure = 1;
	uint64_t indications = 0, supported = 0, requested, readback = 0;
	EFI_STATUS status;

	(void)image;
	marker("CDK2_EFI_DISK_REQUEST_MAIN\r\n");
	if (system == NULL || system->boot == NULL || system->runtime == NULL)
		fail("SYSTEM");
	locate = system->boot->locate_protocol;
	get = system->runtime->get_variable;
	set = system->runtime->set_variable;
	release = system->boot->free_pool;
	reset = system->runtime->reset_system;
	if (locate == NULL || get == NULL || set == NULL || release == NULL || reset == NULL)
		fail("SERVICES");
	size = sizeof(setup);
	if (get(setup_name, &global_guid, &attributes, &size, &setup) != EFI_SUCCESS ||
	    size != sizeof(setup) || attributes != 6 || setup != 1)
		fail("SETUP_MODE");
	size = sizeof(secure);
	if (get(secure_name, &global_guid, &attributes, &size, &secure) != EFI_SUCCESS ||
	    size != sizeof(secure) || attributes != 6 || secure != 0)
		fail("SECURE_BOOT");
	marker("CDK2_EFI_DISK_REQUEST_SETUP1_SECURE0\r\n");
	if (locate(&fmp_guid, NULL, (void **)&fmp) != EFI_SUCCESS ||
	    fmp == NULL || fmp->get_image_info == NULL)
		fail("FMP");
	status = fmp->get_image_info(fmp, &info_size, &descriptor, &descriptor_version,
		&count, &descriptor_size, &package_version, &package_name);
	if (status != EFI_SUCCESS || count != 1 || info_size != sizeof(descriptor) ||
	    descriptor_size != sizeof(descriptor) || descriptor.image_index != 1 ||
	    !guid_equal(&descriptor.image_type_id, &image_guid) ||
	    descriptor.lowest_supported_version != 0x001a0009 ||
	    descriptor.size != 8U * 1024U * 1024U ||
	    (descriptor.attributes_setting & CDK2_SYSTEM_FMP_AUTHENTICATION_REQUIRED) == 0)
		fail("FMP_INFO");
	if (package_name != NULL && release(package_name) != EFI_SUCCESS)
		fail("FREE_PACKAGE_NAME");
	tables = system->configuration_table;
	if (system->table_entries > 256 || tables == NULL ||
	    (uintptr_t)tables % _Alignof(struct configuration_table) != 0 ||
	    system->table_entries > (UINTPTR_MAX - (uintptr_t)tables) / sizeof(*tables))
		fail("CONFIGURATION_TABLE");
	for (size_t index = 0; index < system->table_entries; index++) {
		if (!guid_equal(&tables[index].guid, &esrt_guid))
			continue;
		if (esrt != NULL || tables[index].table == NULL)
			fail("ESRT_DUPLICATE");
		esrt = tables[index].table;
	}
	if (esrt == NULL || (uintptr_t)esrt % _Alignof(struct cdk2_esrt_table) != 0 ||
	    esrt->resource_count != 1 || esrt->resource_count_max < 1 ||
	    esrt->resource_version != 1 ||
	    !guid_equal(&esrt->entries[0].firmware_class, &image_guid) ||
	    esrt->entries[0].firmware_type != CDK2_ESRT_TYPE_SYSTEM ||
	    esrt->entries[0].firmware_version != descriptor.version ||
	    esrt->entries[0].lowest_supported_version != 0x001a0009 ||
	    esrt->entries[0].last_attempt_version != descriptor.last_attempt_version ||
	    esrt->entries[0].last_attempt_status != descriptor.last_attempt_status)
		fail("ESRT_INFO");
	marker("CDK2_EFI_DISK_REQUEST_REAL_FMP_ESRT_INFO\r\n");
	size = sizeof(indications);
	status = get(indications_name, &global_guid, &attributes, &size, &indications);
	if (status == EFI_NOT_FOUND)
		indications = 0;
	else if (status != EFI_SUCCESS || size != sizeof(indications) || attributes != 7)
		fail("GET_INDICATIONS");
	if (descriptor.version == 0x001a000a) {
		if ((indications & 4U) != 0 || descriptor.last_attempt_version != 0x001a000a ||
		    descriptor.last_attempt_status != 0)
			fail("TARGET_STATE");
		marker("CDK2_EFI_DISK_REQUEST_TARGET_A_NO_RESUBMIT_PASS\r\n");
		__asm__ volatile("outl %0, %1" : : "a"(1U), "Nd"((uint16_t)0xf4));
		for (;;)
			__asm__ volatile("cli; hlt");
	}
	if (descriptor.version != 0x001a0009)
		fail("RUNNING_VERSION");
	size = sizeof(supported);
	if (get(supported_name, &global_guid, &attributes, &size, &supported) != EFI_SUCCESS ||
	    size != sizeof(supported) || attributes != 6 || (supported & 4U) == 0)
		fail("DISK_NOT_SUPPORTED");
	requested = indications | 4U;
	if (set(indications_name, &global_guid, 7, sizeof(requested), &requested) != EFI_SUCCESS)
		fail("SET_INDICATIONS");
	size = sizeof(readback);
	if (get(indications_name, &global_guid, &attributes, &size, &readback) != EFI_SUCCESS ||
	    size != sizeof(readback) || attributes != 7 || readback != requested)
		fail("REQUEST_READBACK");
	marker("CDK2_EFI_DISK_REQUEST_SET_READBACK_RESET\r\n");
	reset(cdk2_reset_cold, EFI_SUCCESS, 0, NULL);
	fail("RESET_RETURNED");
	return EFI_DEVICE_ERROR;
}
