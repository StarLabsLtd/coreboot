#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
test "$#" -eq 2 || exit 2
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
header=$(realpath "$1")
output=$(realpath -m "$2")
compiler=${HOSTCC:-cc}
linker=${HOSTLD:-ld}
readelf=${HOSTREADELF:-readelf}
pe_link=${NATIVE_PE_LINK:?actual native PE linker required}
pe_audit=${NATIVE_PE_AUDIT:?actual native PE relocation audit required}
pe_marker=${NATIVE_PE_MARKER:?actual native PE relocation marker required}
for symbol in NATIVE_SYSTEM_FMP PROTECTED_VARIABLE_RUNTIME; do
	grep -qx "#define CONFIG_CDK2_$symbol 1" "$header"
done
for symbol in NATIVE_QEMU_TEST_FMP QEMU_ACCEPTANCE_PROFILE; do
	grep -qx "#define CONFIG_CDK2_$symbol 0" "$header"
done
mkdir -p "$output/include/cdk2"
cp -p "$header" "$output/include/cdk2/config.h"
sha256sum "$header" "$root/tests/normal_efi_disk_request_app.c" \
	"$root/tests/normal_efi_disk_request_app.ld" "$0" \
	> "$output/inputs-before.sha256"
set -- -std=gnu11 -Wall -Wextra -Werror -O2 -ffreestanding \
	-fno-stack-protector -fno-asynchronous-unwind-tables -fshort-wchar \
	-mno-red-zone -m64 -mcmodel=small -fpie -fno-ident \
	-fcf-protection=none -maccumulate-outgoing-args \
	-I"$output/include" -I"$root/include"
"$compiler" "$@" -M "$root/tests/normal_efi_disk_request_app.c" > "$output/entry.d"
sed 's/^[^:]*://; s/\\$//' "$output/entry.d" | tr ' \n\t' '\n' | \
	awk 'NF && !seen[$0]++' | while IFS= read -r dependency; do
		sha256sum "$dependency"
	done >> "$output/inputs-before.sha256"
sha256sum "$(command -v "$compiler")" "$(command -v "$linker")" \
	"$(command -v "$readelf")" "$pe_link" "$pe_audit" "$pe_marker" \
	> "$output/tools-before.sha256"
"$compiler" "$@" \
	-c "$root/tests/normal_efi_disk_request_app.c" -o "$output/entry.o"
"$pe_link" "$linker" "$pe_audit" "$pe_marker" "$readelf" \
	--subsystem 10 --entry normal_efi_disk_request_entry \
	--image-base 0 --section-alignment 0x1000 --file-alignment 0x1000 \
	--build-id=none --no-insert-timestamp -s --nxcompat \
	-T "$root/tests/normal_efi_disk_request_app.ld" \
	-o "$output/NormalEfiDiskRequest.efi" "$output/entry.o"
cmp "$header" "$output/include/cdk2/config.h"
sha256sum -c "$output/inputs-before.sha256"
sha256sum -c "$output/tools-before.sha256"
sha256sum "$output/NormalEfiDiskRequest.efi"
printf '%s\n' 'Normally admitted EFI disk request diagnostic compiled; no native run claim'
