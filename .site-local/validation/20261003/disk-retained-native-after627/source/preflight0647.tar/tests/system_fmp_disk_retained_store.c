/* SPDX-License-Identifier: GPL-2.0-only */

/* Read-only actual producer codecs; no guest writes or authority substitutes. */
#include <boot/payload_mm_authvar.h>
#include <boot/payload_mm_authvar_ftw.h>
#include <boot/payload_mm_authvar_record.h>
#include <boot/payload_mm_authvar_store.h>
#include <commonlib/helpers.h>
#include <uuid.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

#define REGION_SIZE (64U * 1024U)
#define ENTRY_CAPACITY 128U

static const uint16_t state_name[] = { 'F', 'm', 'p', 'S', 't', 'a', 't', 'e', 0 };
static const uint16_t indication_name[] = {
	'O', 's', 'I', 'n', 'd', 'i', 'c', 'a', 't', 'i', 'o', 'n', 's', 0,
};
static const uint16_t request_prefix[] = {
	'C', 'a', 'p', 's', 'u', 'l', 'e', 'U', 'p', 'd', 'a', 't', 'e', 'D', 'a', 't', 'a',
};
static const uint8_t global_guid[16] = {
	0x61, 0xdf, 0xe4, 0x8b, 0xca, 0x93, 0xd2, 0x11,
	0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c,
};
static const uint8_t request_guid[16] = {
	0x3f, 0x70, 0x1c, 0x71, 0x85, 0xc2, 0x10, 0x4b,
	0x93, 0xcf, 0xa8, 0x21, 0x59, 0xe7, 0x77, 0xc5,
};
static const uint8_t expected_state[20] = {
	1, 1, 1, 1, 0x0a, 0, 0x1a, 0, 9, 0, 0x1a, 0,
	0, 0, 0, 0, 0x0a, 0, 0x1a, 0,
};
static uint8_t media[REGION_SIZE], changed[REGION_SIZE];

static bool matches(const uint8_t *region, const uint8_t *guid,
	uint32_t *state_record, uint32_t *state_data, uint32_t *indication_data)
{
	struct payload_mm_authvar_fv_geometry geometry;
	struct payload_mm_authvar_ftw_plan plan;
	struct payload_mm_authvar_store_entry entries[ENTRY_CAPACITY];
	struct payload_mm_authvar_store_index index = {
		.entries = entries, .entry_capacity = ARRAY_SIZE(entries),
	};
	const struct payload_mm_authvar_store_limits limits = {
		.maximum_store_size = REGION_SIZE, .maximum_name_size = 4096U,
		.maximum_data_size = REGION_SIZE, .maximum_records = ENTRY_CAPACITY,
	};
	const struct payload_mm_authvar_store_entry *state, *indications;
	const uint8_t *data;

	_Static_assert(sizeof(expected_state) == PAYLOAD_MM_FMP_STATE_WIRE_SIZE,
		"actual producer state wire size");
	if (!payload_mm_authvar_fv_geometry(&geometry, REGION_SIZE, 4096U) ||
	    payload_mm_authvar_ftw_plan(region, REGION_SIZE, 4096U, &plan) != CB_SUCCESS ||
	    plan.action != PAYLOAD_MM_AUTHVAR_FTW_CLEAN ||
	    plan.workspace != PAYLOAD_MM_AUTHVAR_FTW_WORKSPACE_WORKING ||
	    plan.queue_entry_size != 0U ||
	    !((plan.queue_disposition == PAYLOAD_MM_AUTHVAR_FTW_QUEUE_EMPTY &&
	       plan.queue_offset == PAYLOAD_MM_AUTHVAR_FTW_WORK_HEADER_SIZE) ||
	      (plan.queue_disposition == PAYLOAD_MM_AUTHVAR_FTW_QUEUE_NONE &&
	       plan.queue_offset > PAYLOAD_MM_AUTHVAR_FTW_WORK_HEADER_SIZE &&
	       plan.queue_offset < geometry.working_size)))
		return false;
	if (payload_mm_authvar_store_scan(&index,
	    region + PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE,
	    geometry.variable_size - PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE, &limits) != CB_SUCCESS ||
	    index.dirty_tail_offset != 0U)
		return false;
	state = payload_mm_authvar_store_find(&index, guid, state_name, sizeof(state_name));
	if (state == NULL || state->attributes != PAYLOAD_MM_FMP_STATE_VARIABLE_ATTRIBUTES ||
	    state->data_size != sizeof(expected_state))
		return false;
	data = payload_mm_authvar_store_data(&index, state);
	if (data == NULL || memcmp(data, expected_state, sizeof(expected_state)))
		return false;
	indications = payload_mm_authvar_store_find(&index, global_guid,
		indication_name, sizeof(indication_name));
	if (indications == NULL || indications->attributes != 7U || indications->data_size != 8U)
		return false;
	data = payload_mm_authvar_store_data(&index, indications);
	if (data == NULL || (data[0] & 4U))
		return false;
	for (size_t item = 0; item < index.entry_count; item++) {
		const struct payload_mm_authvar_store_entry *entry = &index.entries[item];
		const void *name = payload_mm_authvar_store_name(&index, entry);

		if (name == NULL || (!memcmp(entry->vendor_guid, request_guid, sizeof(request_guid)) &&
		    entry->name_size >= sizeof(request_prefix) + sizeof(uint16_t) &&
		    !memcmp(name, request_prefix, sizeof(request_prefix))))
			return false;
	}
	if (state_record != NULL)
		*state_record = PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE + state->record_offset;
	if (state_data != NULL)
		*state_data = PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE + state->data_offset;
	if (indication_data != NULL)
		*indication_data = PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE + indications->data_offset;
	return true;
}

int main(int argc, char **argv)
{
	uint8_t guid[UUID_LEN], other[UUID_LEN];
	uint32_t record, state, indications;
	struct payload_mm_authvar_fv_geometry geometry;
	FILE *input;
	bool complete;

	if (argc != 3 || parse_uuid(guid, argv[2]))
		return 2;
	input = fopen(argv[1], "rb");
	if (input == NULL)
		return 2;
	complete = fread(media, 1, sizeof(media), input) == sizeof(media) &&
		fgetc(input) == EOF && !ferror(input);
	if (fclose(input) || !complete)
		return 2;
	if (!matches(media, guid, &record, &state, &indications))
		return 1;
	for (size_t byte = 0; byte < sizeof(expected_state); byte++) {
		memcpy(changed, media, sizeof(changed));
		changed[state + byte] ^= 1U;
		assert(!matches(changed, guid, NULL, NULL, NULL));
	}
	memcpy(changed, media, sizeof(changed));
	changed[record + 4U] |= 4U;
	assert(!matches(changed, guid, NULL, NULL, NULL));
	memcpy(changed, media, sizeof(changed));
	changed[indications] |= 4U;
	assert(!matches(changed, guid, NULL, NULL, NULL));
	for (size_t byte = 0; byte < sizeof(other); byte++) {
		memcpy(other, guid, sizeof(other));
		other[byte] ^= 1U;
		assert(!matches(media, other, NULL, NULL, NULL));
	}
	assert(payload_mm_authvar_fv_geometry(&geometry, REGION_SIZE, 4096U));
	for (size_t byte = 0; byte < PAYLOAD_MM_AUTHVAR_FTW_WORK_HEADER_SIZE; byte++) {
		memcpy(changed, media, sizeof(changed));
		changed[geometry.working_offset + byte] ^= 1U;
		assert(!matches(changed, guid, NULL, NULL, NULL));
	}
	/* A HOST-only canonical append proves absence is not learned from the
	 * successful guest. Neither this copy nor the encoded request is booted. */
	{
		uint16_t request_name[ARRAY_SIZE(request_prefix) + 1U] = { 0 };
		uint64_t pointer = 0x200000U;
		struct payload_mm_authvar_record_descriptor descriptor = {
			.name = request_name, .name_size = sizeof(request_name), .attributes = 7U,
		};
		const struct payload_mm_authvar_record_span span = {
			.data = &pointer, .size = sizeof(pointer),
		};
		struct payload_mm_authvar_store_entry entries[ENTRY_CAPACITY];
		struct payload_mm_authvar_store_index index = {
			.entries = entries, .entry_capacity = ARRAY_SIZE(entries),
		};
		const struct payload_mm_authvar_store_limits limits = {
			.maximum_store_size = REGION_SIZE, .maximum_name_size = 4096U,
			.maximum_data_size = REGION_SIZE, .maximum_records = ENTRY_CAPACITY,
		};
		uint32_t length;
		uint8_t *store;
		size_t capacity = geometry.variable_size - PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE;

		memcpy(request_name, request_prefix, sizeof(request_prefix));
		memcpy(descriptor.vendor_guid, request_guid, sizeof(request_guid));
		memcpy(changed, media, sizeof(changed));
		store = changed + PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE;
		assert(payload_mm_authvar_store_scan(&index, store, capacity, &limits) == CB_SUCCESS);
		assert(index.used_size <= capacity);
		assert(payload_mm_authvar_record_encode(&descriptor, &span, 1,
			PAYLOAD_MM_AUTHVAR_RECORD_TIMESTAMP_VALIDATED,
			store + index.used_size, capacity - index.used_size, &length));
		store[index.used_size + 2U] = PAYLOAD_MM_AUTHVAR_STATE_ADDED;
		assert(payload_mm_authvar_store_scan(&index, store, capacity, &limits) == CB_SUCCESS);
		assert(payload_mm_authvar_store_find(&index, request_guid, request_name,
			sizeof(request_name)) != NULL);
		assert(!matches(changed, guid, NULL, NULL, NULL));
	}
	puts("Actual producer codec: successful A history, cleared disk request, retired RAM request, clean FTW: PASS");
	return 0;
}
