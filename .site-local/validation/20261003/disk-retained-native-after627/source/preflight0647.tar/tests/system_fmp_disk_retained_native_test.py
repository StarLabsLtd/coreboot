# SPDX-License-Identifier: GPL-2.0-only
"""Read-only HOST observer of ordinary DISK-to-retained-RAM delivery."""

import argparse
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import time
import uuid
from pathlib import Path

from system_fmp_core_ram_native_test import Qmp, digest, loads, save
from system_fmp_core_ram_native_test import previous_table_during_reset
from system_fmp_core_ram_native_test import unpublished_reset_console_motion

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "util/qemu/bin"))
from qmp_cbmem_console import ConsoleReader, PhysicalReadError, TableNotReady
from qmp_cbmem_console import parse_table, validate_saved_console

IMAGE_GUID = uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le
INITIAL_VERSION = 0x001a0009
TARGET_VERSION = 0x001a000a
IMAGE_SIZE = 8388608


def check_epoch(index, body, records, physical_limit, capsule):
    """Independent DISK chronology; no RAM-fixture admission/oracle reuse."""
    if index not in range(4):
        raise ValueError("unexpected fourth reset or firmware epoch")
    firmware = [record for tag, record in records if tag == 0x45]
    expected = IMAGE_GUID + struct.pack("<III", TARGET_VERSION if index == 3 else
                                       INITIAL_VERSION, INITIAL_VERSION, IMAGE_SIZE)
    if len(firmware) != 1 or len(firmware[0]) != 36 or firmware[0][8:] != expected:
        raise ValueError("actual firmware identity differs from declared DISK epoch")
    policies = [record for tag, record in records if tag == 0x59]
    if len(policies) != 1 or len(policies[0]) != 40:
        raise ValueError("unique bounded delivery policy required")
    revision, width, transports, maximum, populate, reserved = \
        struct.unpack_from("<HHIQQQ", policies[0], 8)
    if revision != 1 or width != 40 or transports != 3 or maximum < len(capsule) or \
            maximum > 0xffffffff or populate > 0xffffffff or reserved:
        raise ValueError("actual RAM and DISK delivery capability required")
    retained = [record for tag, record in records if tag == 0x46]
    if len(retained) != int(index == 2):
        raise ValueError("retained capsule only belongs to the RAM-processing epoch")
    if retained:
        if len(retained[0]) != 20:
            raise ValueError("retained capsule record shape")
        address, size = struct.unpack_from("<QI", retained[0], 8)
        if not address or size != len(capsule) or address >= physical_limit or \
                size > physical_limit - address:
            raise ValueError("retained capsule extent outside actual guest RAM")
    # CBMEM can retain earlier boot text. The last real RAM begin anchors
    # this boot; subtracting an earlier incomplete snapshot is not an epoch.
    start = body.rfind(b"CDK2 | CAPSULE_RAM | begin")
    if start < 0:
        raise ValueError("actual current RAM phase boundary missing")
    current = body[start:]
    if re.search(rb"(?m)^CDK2 \| [A-Z][A-Z0-9_]* \| failed \|", current):
        raise ValueError("actual firmware reached a failed phase")
    ram = list(re.finditer(rb"(?m)^CDK2 \| CAPSULE_RAM \| complete \| "
                          rb"SUCCESS \(0x0000000000000000\) \| [0-9]+ us\r?$", current))
    pci = list(re.finditer(rb"(?m)^CDK2 \| PCI_ROOTS \| begin \| "
                          rb"NOT_STARTED \(0x8000000000000013\) \| [0-9]+ us\r?$", current))
    disk = list(re.finditer(rb"(?m)^CDK2 \| CAPSULE_DISK \| begin \| "
                           rb"NOT_STARTED \(0x8000000000000013\) \| [0-9]+ us\r?$", current))
    disk_end = list(re.finditer(rb"(?m)^CDK2 \| CAPSULE_DISK \| complete \| "
                               rb"SUCCESS \(0x0000000000000000\) \| [0-9]+ us\r?$", current))
    handoff = list(re.finditer(rb"(?m)^CDK2 \| OS_HANDOFF \| begin \| "
                              rb"NOT_STARTED \(0x8000000000000013\) \| [0-9]+ us\r?$", current))
    checks = list(re.finditer(rb"(?m)^CDK2 \| module 0x02 \| SystemFmp CHECK transport "
                             rb"\| 0x([0-9a-f]{16})\r?$", current))
    sets = list(re.finditer(rb"(?m)^CDK2 \| module 0x02 \| SystemFmp SET transport "
                           rb"\| 0x([0-9a-f]{16})\r?$", current))
    if current.count(b"CDK2 | module 0x02 | SystemFmp CHECK transport") != len(checks) or \
            current.count(b"CDK2 | module 0x02 | SystemFmp SET transport") != len(sets):
        raise ValueError("malformed or extra SystemFmp transport diagnostic")
    if index == 2:
        if ram or pci or disk or disk_end or handoff or len(checks) != 1 or len(sets) != 1 or \
                checks[0][1] != b"0000000000000000" or sets[0][1] != b"0000000000000000" or \
                checks[0].start() >= sets[0].start():
            raise ValueError("retained RAM requires real successful CHECK then SET before reset/PCI")
    else:
        if len(ram) != 1 or len(pci) != 1 or len(disk) != 1 or \
                not ram[0].start() < pci[0].start() < disk[0].start() or checks or sets:
            raise ValueError("DISK epoch must close normal RAM before PCI without late CHECK/SET")
        if index == 1:
            if disk_end or handoff:
                raise ValueError("successful retained staging must reset before DISK completion/MAIN")
        elif len(disk_end) != 1 or len(handoff) != 1 or \
                not disk[0].start() < disk_end[0].start() < handoff[0].start():
            raise ValueError("unrequested disk must complete before normal MAIN")
    return current


def check_markers(uart, events):
    resets = [event for event in events if event.get("event") == "RESET"]
    if len(resets) != 3 or any(event.get("data", {}).get("guest") is not True for event in resets):
        raise ValueError("exactly three real guest resets required")
    for suffix, count in (("MAIN", 2), ("SETUP1_SECURE0", 2), ("REAL_FMP_ESRT_INFO", 2),
                          ("SET_READBACK_RESET", 1), ("TARGET_A_NO_RESUBMIT_PASS", 1)):
        if uart.count(("CDK2_EFI_DISK_REQUEST_" + suffix + "\r\n").encode()) != count:
            raise ValueError("ordinary request MAIN marker cardinality: " + suffix)
    if b"CDK2_EFI_DISK_REQUEST_FAIL" in uart:
        raise ValueError("ordinary request MAIN failed")
    if uart.find(b"CDK2_EFI_DISK_REQUEST_SET_READBACK_RESET") >= \
            uart.find(b"CDK2_EFI_DISK_REQUEST_TARGET_A_NO_RESUBMIT_PASS"):
        raise ValueError("ordinary request/reset must precede target MAIN")


def check_saved(boots, capsule):
    if [path.name for path in boots] != [f"boot-{index}" for index in range(4)]:
        raise ValueError("exactly four independently accepted epochs required")
    for index, directory in enumerate(boots):
        body = validate_saved_console(directory)
        metadata = json.loads((directory / "cbmem-observer.json").read_text())
        leaf = len(metadata["tables"]) - 1
        records = parse_table((directory / f"cbmem-table-{leaf}.bin").read_bytes())
        check_epoch(index, body, records, metadata["physical_limit"], capsule)
    if (boots[2] / "retained-capsule.bin").read_bytes() != capsule:
        raise ValueError("actual retained RAM bytes differ from the original signed disk capsule")


def check_media(installed, initial, target, regions):
    if any(len(data) != IMAGE_SIZE for data in (installed, initial, target)) or \
            regions.get("SMMSTORE") != (0, 65536) or \
            regions.get("COREBOOT") != (73728, IMAGE_SIZE - 73728) or \
            installed[73728:] != target[73728:] or installed[65536:73728] != initial[65536:73728]:
        raise ValueError("exact signed COREBOOT target/excluded probe-gap equality required")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("initial", "target", "disk", "app", "output", "config", "header", "core",
                 "inventory", "capsule", "trust", "capsule-tools", "cbfstool", "compiler",
                 "pe-audit", "initial-config", "target-config"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--binding", type=Path, action="append", default=[])
    parser.add_argument("--qemu", default="qemu-system-x86_64")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    producer_root = args.capsule_tools.resolve().parents[1]
    inputs = [value.resolve() for value in vars(args).values() if isinstance(value, Path)
              and value != args.output and value.is_file()]
    inputs += args.binding + [Path(__file__), Path(__file__).with_name(
        "system_fmp_disk_retained_store.c"), Path(__file__).with_name(
        "system_fmp_disk_retained_store_test.sh")]
    for tool in (args.qemu, "mcopy", "mmd", "sh", "openssl"):
        resolved = shutil.which(tool)
        if resolved is None:
            raise ValueError("required real tool missing: " + tool)
        inputs.append(Path(resolved))
    for directory in (root, producer_root):
        names = subprocess.check_output(["git", "-C", str(directory), "ls-files", "-z",
                                         "src", "include", "tests", "util", "Makefile", "Kconfig"])
        inputs += [directory / os.fsdecode(name) for name in names.split(b"\0") if name
                   and (directory / os.fsdecode(name)).is_file()]
    before = {str(path.resolve()): digest(path) for path in inputs}
    (output / "inputs-before.json").write_text(json.dumps(before, indent=2) + "\n")
    config, header = args.config.read_text().splitlines(), args.header.read_text().splitlines()
    for symbol, value in (("NATIVE_SYSTEM_FMP", 1), ("PROTECTED_VARIABLE_RUNTIME", 1),
                          ("NATIVE_QEMU_TEST_FMP", 0), ("QEMU_ACCEPTANCE_PROFILE", 0), ("DIAGNOSTIC", 1)):
        if f"#define CONFIG_CDK2_{symbol} {value}" not in header or \
                (value == 1 and f"CONFIG_CDK2_{symbol}=y" not in config) or \
                (value == 0 and f"CONFIG_CDK2_{symbol}=y" in config):
            raise ValueError("genuine normal protected SystemFmp/diagnostic configuration required")
    inventory = args.inventory.read_text()
    if "975cd0e6-c540-4e2b-906c-72c0d0d1e40d" not in inventory or "QEMU_TEST_FMP" in inventory:
        raise ValueError("actual normal SystemFmp inventory required")
    der = subprocess.check_output(["openssl", "x509", "-in", str(args.trust), "-outform", "DER"])
    for label, image, expected_config, version in (("initial", args.initial, args.initial_config,
            INITIAL_VERSION), ("target", args.target, args.target_config, TARGET_VERSION)):
        extracted = output / f"{label}-core.elf"
        subprocess.run([str(args.cbfstool), str(image), "extract", "-n", "fallback/payload",
                        "-f", str(extracted), "-m", "x86"], check=True)
        if loads(extracted) != loads(args.core):
            raise ValueError("immutable pre-CMS producer image does not contain the actual full Core")
        certificate = output / f"{label}-trust.der"
        subprocess.run([str(args.cbfstool), str(image), "extract", "-n", "capsule/trust.der",
                        "-f", str(certificate)], check=True)
        if certificate.read_bytes() != der:
            raise ValueError("producer authority differs from the verified public trust")
        extracted_config = output / f"{label}-producer.config"
        subprocess.run([str(args.cbfstool), str(image), "extract", "-n", "config",
                        "-f", str(extracted_config)], check=True)
        producer = extracted_config.read_text().splitlines()
        if producer != expected_config.read_text().splitlines():
            raise ValueError("actual packaged producer config differs from its bound build input")
        for symbol in ("Q35_SMM_CAPSULE_BROKER", "PAYLOAD_MM_FMP_OWNER_AUTHVAR_BOOT",
                       "DRIVERS_EFI_CAPSULE_DELIVERY_POLICY", "DRIVERS_EFI_CAPSULE_ON_DISK_SUPPORT"):
            if f"CONFIG_{symbol}=y" not in producer:
                raise ValueError("actual selected typed producer delivery/owner capability required")
        for symbol in ("DRIVERS_EFI_UPDATE_CAPSULES", "SMMSTORE", "SMMSTORE_FULL_FLASH_ACCESS"):
            if f"CONFIG_{symbol}=y" in producer:
                raise ValueError("legacy flash authority forbidden in selected typed fixture")
        versions = [line.split("=", 1)[1] for line in producer
                    if line.startswith("CONFIG_DRIVERS_EFI_MAIN_FW_VERSION=")]
        if len(versions) != 1 or int(versions[0], 16) != version:
            raise ValueError("actual hex producer firmware version differs from declared epoch")
    subprocess.run([str(args.pe_audit), "--subsystem", "10", str(args.app)], check=True)
    subprocess.run([sys.executable, str(args.capsule_tools / "validate_capsule.py"),
                    "--capsule", str(args.capsule), "--guid", str(uuid.UUID(bytes_le=IMAGE_GUID)),
                    "--embedded-drivers", "0", "--fw-version", hex(TARGET_VERSION), "--lsv",
                    hex(INITIAL_VERSION), "--image", str(args.target), "--region", "COREBOOT",
                    "--trusted-public-cert", str(args.trust), "--initiate-reset", "--require-fmap"],
                   check=True)
    sys.path.insert(0, str(args.capsule_tools))
    from validate_capsule import parse_fmap_regions
    initial, target, capsule = args.initial.read_bytes(), args.target.read_bytes(), args.capsule.read_bytes()
    regions = parse_fmap_regions(initial)
    if regions != parse_fmap_regions(target) or initial[:65536] != b"\xff" * 65536 or \
            initial[:73728] != target[:73728]:
        raise ValueError("genuine virgin producer store and unchanged excluded ranges required")
    check_media(target, initial, target, regions)
    media, disk = output / "pflash.rom", output / "nvme.raw"
    shutil.copyfile(args.initial, media)
    shutil.copyfile(args.disk, disk)
    esp = str(disk) + "@@1048576"
    subprocess.run(["mmd", "-i", esp, "::/EFI/UpdateCapsule"], check=True)
    subprocess.run(["mcopy", "-i", esp, str(args.capsule), "::/EFI/UpdateCapsule/disk-a.cap"], check=True)
    subprocess.run(["mcopy", "-o", "-i", esp, str(args.app), "::/EFI/BOOT/BOOTX64.EFI"], check=True)
    disk_before = digest(disk)
    serial = output / "serial.log"
    command = [args.qemu, "-machine", "q35,smm=on,accel=tcg", "-m", "1024M", "-cpu", "max",
               "-smp", "1", "-nodefaults", "-device", "intel-iommu,pt=off", "-device",
               "VGA,bus=pcie.0,addr=01", "-drive", f"if=none,id=nvme0,format=raw,file={disk}",
               "-device", "nvme,drive=nvme0,serial=CDK2MMRESET,bus=pcie.0,addr=03", "-device",
               "qemu-xhci,bus=pcie.0,addr=04", "-device", "edu,dma_mask=0xffffffff,bus=pcie.0,addr=05",
               "-global", "driver=cfi.pflash01,property=secure,value=on", "-drive",
               f"if=pflash,format=raw,file={media},cache=writeback", "-display", "none",
               "-serial", f"file:{serial}", "-device", "isa-debug-exit,iobase=0xf4,iosize=0x04",
               "-qmp", f"unix:{output}/qmp.sock,server=on,wait=off"]
    (output / "command.json").write_text(json.dumps(command, indent=2) + "\n")
    started = time.monotonic()
    deadline = started + 180
    boots, reader, accepted_epoch, previous, publication_started, qmp = [], None, None, None, None, None
    failure = None
    qemu_seconds = None
    with (output / "qemu.log").open("wb") as log:
        process = subprocess.Popen(command, stdout=log, stderr=log)
        try:
            while process.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError("original four-epoch DISK 180 second budget expired")
                uart = serial.read_bytes() if serial.exists() else b""
                if b"CDK2_EFI_DISK_REQUEST_FAIL" in uart or \
                        uart.count(b"CDK2_EFI_DISK_REQUEST_SET_READBACK_RESET\r\n") > 1:
                    raise ValueError("ordinary request app failed or resubmitted")
                if qmp is None:
                    if not (output / "qmp.sock").exists():
                        time.sleep(0.05)
                        continue
                    qmp = Qmp(output / "qmp.sock")
                epoch = qmp.epoch()
                if epoch > 3:
                    raise ValueError("unexpected guest reset beyond fourth epoch")
                if reader is None or accepted_epoch != epoch:
                    if reader is not None:
                        previous = boots[-1] if boots else None
                        publication_started = time.monotonic()
                    reader = ConsoleReader(qmp, output / f"scratch-{epoch}")
                    accepted_epoch = epoch
                try:
                    body = reader.snapshot()
                except (ValueError, OSError, EOFError) as error:
                    if qmp.epoch() != accepted_epoch:
                        previous = boots[-1] if boots else None
                        publication_started = time.monotonic()
                        reader = None
                        continue
                    if isinstance(error, TableNotReady) or unpublished_reset_console_motion(
                            error, reader, previous, publication_started, time.monotonic()):
                        time.sleep(0.05)
                        continue
                    if process.poll() == 3 and reader.metadata is not None and \
                            (isinstance(error, (OSError, EOFError)) or
                             isinstance(error, PhysicalReadError) and isinstance(error.__cause__, OSError)):
                        break  # Saved strict oracles below remain mandatory.
                    raise
                if qmp.epoch() != accepted_epoch:
                    previous = boots[-1] if boots else None
                    publication_started = time.monotonic()
                    reader = None
                    continue
                if previous_table_during_reset(reader, previous, 0 if publication_started is None else
                                               time.monotonic() - publication_started):
                    reader = None
                    time.sleep(0.05)
                    continue
                previous = None
                directory = output / f"boot-{accepted_epoch}"
                records = parse_table(reader.table_snapshots[-1])
                retained_records = [record for tag, record in records if tag == 0x46]
                if retained_records and not (directory / "retained-capsule.bin").exists():
                    if accepted_epoch != 2 or len(retained_records) != 1 or len(retained_records[0]) != 20:
                        raise ValueError("retained capsule in unexpected epoch or malformed record")
                    address, size = struct.unpack_from("<QI", retained_records[0], 8)
                    if not address or size != len(capsule) or address >= reader.physical_limit or \
                            size > reader.physical_limit - address:
                        raise ValueError("retained capsule physical bounds")
                    try:
                        retained = b"".join(reader.read(address + offset, min(1024 * 1024, size - offset))
                                            for offset in range(0, size, 1024 * 1024))
                    except (ValueError, OSError, EOFError):
                        if qmp.epoch() == accepted_epoch:
                            raise
                        previous = boots[-1] if boots else None
                        publication_started = time.monotonic()
                        reader = None
                        continue
                    if qmp.epoch() != accepted_epoch:
                        previous = boots[-1] if boots else None
                        publication_started = time.monotonic()
                        reader = None
                        continue
                    if retained != capsule:
                        raise ValueError("actual retained capsule byte identity differs from signed disk file")
                    directory.mkdir(exist_ok=True)
                    (directory / "retained-capsule.bin").write_bytes(retained)
                save(reader, directory, body)
                if directory not in boots:
                    boots.append(directory)
                current = body[body.rfind(b"CDK2 | CAPSULE_RAM | begin"):]
                if re.search(rb"(?m)^CDK2 \| [A-Z][A-Z0-9_]* \| failed \|", current):
                    raise ValueError("actual current firmware phase failed")
                time.sleep(0.05)
            if process.poll() != 3 or time.monotonic() > deadline:
                raise ValueError("actual guest success exit 3 required within original 180 second budget")
            qemu_seconds = time.monotonic() - started
            check_markers(serial.read_bytes(), qmp.events if qmp else [])
            check_saved(boots, capsule)
            check_media(media.read_bytes(), initial, target, regions)
            if digest(disk) != disk_before:
                raise ValueError("source capsule/app disk changed after HOST staging baseline")
            disk_capsule = output / "retained-disk-a.cap"
            subprocess.run(["mcopy", "-i", esp, "::/EFI/UpdateCapsule/disk-a.cap", str(disk_capsule)], check=True)
            if disk_capsule.read_bytes() != capsule:
                raise ValueError("original disk capsule was deleted or changed")
            subprocess.run(["sh", str(root / "tests/system_fmp_disk_retained_store_test.sh"),
                            str(media), str(output)], check=True,
                           env=dict(os.environ, COREBOOT_TREE=str(producer_root),
                                    CBFSTOOL=str(args.cbfstool), HOSTCC=str(args.compiler)))
        except Exception as error:
            failure = repr(error)
        finally:
            if qemu_seconds is None:
                qemu_seconds = time.monotonic() - started
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
            after = {path: digest(Path(path)) for path in before}
            (output / "inputs-after.json").write_text(json.dumps(after, indent=2) + "\n")
            if before != after:
                failure = "immutable source/caller/config/tool inputs changed"
            (output / "result.json").write_text(json.dumps({
                "failure": failure, "qemu_status": process.returncode, "wall_seconds": qemu_seconds,
                "budget_seconds": 180, "events": qmp.events if qmp else [],
                "epochs": [path.name for path in boots], "installed_sha256": digest(media),
                "disk_sha256": digest(disk), "staged_disk_sha256": disk_before,
                "outcome": "guest success or failure; never HOST termination as success"}, indent=2) + "\n")
    if failure is not None:
        raise SystemExit(failure)
    print("Actual normal DISK-to-retained-RAM four-epoch update PASS (guest success)")


if __name__ == "__main__":
    main()
