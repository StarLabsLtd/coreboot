#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
temporary=$(mktemp -d "${TMPDIR:-/tmp}/cdk2-system-fmp-future-floor.XXXXXX")
printf 'Future-floor HOST artifacts: %s\n' "$temporary"
trap 'rm -f "$temporary/trusted.key" "$temporary/rogue.key"' EXIT HUP INT TERM
compiler=${HOSTCC:-cc}
crypto_sources=${FUTURE_FLOOR_CRYPTO_SOURCES:?actual CMS/BearSSL sources required}
crypto_flags=${FUTURE_FLOOR_CRYPTO_FLAGS:?actual CMS/BearSSL flags required}
common="-std=gnu11 -Wall -Wextra -Werror -fno-pie -no-pie -ffunction-sections -fdata-sections -I$root/include -I$root/src/boot"
sanitizers="-fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer"
export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1

sha256sum "$root/src/modules/system_fmp/transport.c" \
	"$root/include/cdk2/system_fmp_session.h" \
	"$root/include/cdk2/capsule_check_outcome.h" \
	"$root/src/modules/system_fmp/session.c" \
	"$root/src/modules/system_fmp/provider.c" \
	"$root/src/modules/system_fmp/auth.c" \
	"$root/src/modules/system_fmp/handoff.c" \
	"$root/src/modules/system_fmp/starlabs_trust.c" \
	"$root/src/modules/system_fmp/payload.c" \
	"$root/src/modules/system_fmp/board_binding.c" \
	"$root/src/boot/coreboot.h" "$root/src/boot/coreboot.c" \
	"$root/src/modules/qemu_test_fmp/sha256.c" \
	"$root/tests/system_fmp_future_floor_test.c" \
	"$root/tests/system_fmp_mm_route_test.c" \
	"$root/tests/system_fmp_transport_client_test.c" \
	"$root/tests/system_fmp_future_floor_test.sh" \
	$crypto_sources > "$temporary/source-before.sha256"

# Authenticated MSS1 images contain a real bounded FMAP/CBFS board identity.
perl - "$temporary" <<-'PERL'
	use strict;
	use warnings;
	my ($directory) = @ARGV;
	sub write_bytes {
		my ($name, $bytes) = @_;
		open my $file, '>:raw', "$directory/$name" or die $!;
		print {$file} $bytes or die $!;
		close $file or die $!;
	}
	my $rom = "\xff" x 65536;
	my $header = '__FMAP__' . pack('CCQ<V', 1, 1, 0, 65536) .
		pack('a32v', 'CDK2_TEST', 2);
	my $areas = pack('VVa32v', 128, 4096, 'FMAP', 0) .
		pack('VVa32v', 8192, 57344, 'COREBOOT', 0);
	substr($rom, 128, length($header . $areas)) = $header . $areas;
	my $offset = 8192;
	for my $file (
		['cbfs_master_header', 'header'],
		['build_info', "COREBOOT_VERSION: test\nMAINBOARD_VENDOR: Star Labs\nMAINBOARD_PART_NUMBER: Lite\n"]
	) {
		my ($name, $data) = @$file;
		my $data_offset = (24 + length($name) + 1 + 3) & ~3;
		my $metadata = 'LARCHIVE' . pack('N4', length($data), 0x50, 0, $data_offset) .
			pack('a' . ($data_offset - 24), $name);
		substr($rom, $offset, length($metadata . $data)) = $metadata . $data;
		$offset = ($offset + length($metadata . $data) + 63) & ~63;
	}
	my $empty = 'LARCHIVE' . pack('N4', 65536 - $offset - 64, 0xffffffff, 0, 32) .
		pack('a8', '(empty)');
	substr($rom, $offset, length($empty)) = $empty;
	for my $version (9, 10) {
		my $payload = pack('V4', 0x3153534d, 16, $version, 10) . $rom;
		write_bytes("payload-$version", $payload);
		write_bytes("signed-$version", $payload . pack('Q<', 7));
	}
PERL

for signer in trusted rogue; do
	openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days 2 \
		-subj "/CN=CDK2 future floor $signer/" \
		-addext basicConstraints=critical,CA:TRUE \
		-addext keyUsage=critical,digitalSignature,keyCertSign,cRLSign \
		-keyout "$temporary/$signer.key" -out "$temporary/$signer.pem" \
		>/dev/null 2>&1
	openssl x509 -in "$temporary/$signer.pem" -outform DER \
		-out "$temporary/$signer.der"
done
for version in 9 10; do
	openssl cms -sign -binary -in "$temporary/signed-$version" \
		-signer "$temporary/trusted.pem" -inkey "$temporary/trusted.key" \
		-outform DER -out "$temporary/signature-$version" -nosmimecap -md sha256
	openssl cms -verify -binary -inform DER -in "$temporary/signature-$version" \
		-content "$temporary/signed-$version" -CAfile "$temporary/trusted.pem" \
		-purpose any -out /dev/null > "$temporary/openssl-$version.log" 2>&1
done
openssl cms -sign -binary -in "$temporary/signed-10" \
	-signer "$temporary/rogue.pem" -inkey "$temporary/rogue.key" \
	-outform DER -out "$temporary/signature-rogue" -nosmimecap -md sha256

perl - "$temporary" <<-'PERL'
	use strict;
	use warnings;
	my ($directory) = @ARGV;
	sub read_bytes {
		my ($name) = @_;
		open my $file, '<:raw', "$directory/$name" or die $!;
		local $/;
		return <$file>;
	}
	my $certificate = read_bytes('trusted.der');
	open my $xdr, '>:raw', "$directory/trust.xdr" or die $!;
	print {$xdr} pack('N', length($certificate)), $certificate,
		"\0" x ((4 - (length($certificate) & 3)) & 3) or die $!;
	close $xdr or die $!;
	for my $name ('9', '10', 'rogue') {
		my $signature = read_bytes("signature-$name");
		my $payload = read_bytes('payload-' . ($name eq 'rogue' ? 10 : $name));
		open my $file, '>:raw', "$directory/image-$name" or die $!;
		print {$file} pack('Q<Vvv', 7, 24 + length($signature), 0x200, 0xef1),
			pack('H*', '9dd2af4adf68ee498aa9347d375665a7'), $signature, $payload or die $!;
		close $file or die $!;
	}
PERL

# Restore each removed runtime cap only; inverse transformation must match all bytes.
perl -0777 -pe 's/(\t    response\.image_size != client->endpoint\.image_size \|\|)/\t    response.lowest_supported_version > response.current_version ||\n$1/g == 1 or die "transport anchor"' \
	"$root/src/modules/system_fmp/transport.c" > "$temporary/transport-mutant.c"
perl -0777 -pe 's/\t    response\.lowest_supported_version > response\.current_version \|\|\n//g == 1 or die "transport inverse"' \
	"$temporary/transport-mutant.c" | cmp - "$root/src/modules/system_fmp/transport.c"
perl -0777 -pe 's/(\t\tinfo->image_size == endpoint->image_size &&)/\t\tinfo->lowest_supported_version <= info->current_version \&\&\n$1/g == 1 or die "session anchor"' \
	"$root/src/modules/system_fmp/session.c" > "$temporary/session-mutant.c"
perl -0777 -pe 's/\t\tinfo->lowest_supported_version <= info->current_version &&\n//g == 1 or die "session inverse"' \
	"$temporary/session-mutant.c" | cmp - "$root/src/modules/system_fmp/session.c"
# Relocated session includes remain the exact real boot header, not a stub.
mkdir -p "$temporary/src/modules/system_fmp" "$temporary/src/boot"
cp "$root/src/boot/coreboot.h" "$temporary/src/boot/coreboot.h"
cp "$temporary/session-mutant.c" "$temporary/src/modules/system_fmp/session.c"
cp "$temporary/transport-mutant.c" "$temporary/src/modules/system_fmp/transport.c"

expect_assertion()
{
	name=$1
	expression=$2
	shift 2
	status=0
	(ulimit -c 0; "$@") > "$temporary/$name.log" 2>&1 || status=$?
	test "$status" -eq 134
	grep -Fq 'Assertion' "$temporary/$name.log"
	grep -Fq "$expression" "$temporary/$name.log"
	if grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' \
		"$temporary/$name.log"; then
		echo "ERROR: sanitizer fault instead of causal assertion: $name" >&2
		exit 1
	fi
}

for optimization in 0 2; do
	objects=
	route_objects=
	index=0
	for source in "$root/tests/system_fmp_future_floor_test.c" \
		"$root/src/modules/system_fmp/auth.c" \
		"$root/src/modules/system_fmp/handoff.c" \
		"$root/src/modules/system_fmp/provider.c" \
		"$root/src/modules/system_fmp/payload.c" \
		"$root/src/modules/system_fmp/board_binding.c" $crypto_sources; do
		object="$temporary/support-$optimization-$index.o"
		# shellcheck disable=SC2086
		"$compiler" $common $sanitizers $crypto_flags -O"$optimization" \
			-c "$source" -o "$object"
		objects="$objects $object"
		if test "$index" -ne 0; then
			route_objects="$route_objects $object"
		fi
		index=$((index + 1))
	done
	for variant in positive mutant; do
		source="$root/src/modules/system_fmp/session.c"
		if test "$variant" = mutant; then
			source="$temporary/src/modules/system_fmp/session.c"
		fi
		# shellcheck disable=SC2086
		"$compiler" $common $sanitizers -O"$optimization" -c "$source" \
			-o "$temporary/session-$variant-$optimization.o"
		# shellcheck disable=SC2086
		"$compiler" $common $sanitizers -O"$optimization" -Wl,--gc-sections \
			$objects "$temporary/session-$variant-$optimization.o" \
			-o "$temporary/session-$variant-$optimization"
	done
	"$temporary/session-positive-$optimization" "$temporary/trust.xdr" \
		"$temporary/image-9" "$temporary/image-10" "$temporary/image-rogue" \
		> "$temporary/session-positive-$optimization.log" 2>&1
	# The spy calls the real CMS verifier inside the modeled MM handler.  No
	# verification-success callback or production certificate replacement.
	# shellcheck disable=SC2086
	"$compiler" $common $sanitizers $crypto_flags -O"$optimization" \
		-Wl,--gc-sections -Wl,--wrap=cdk2_system_fmp_authenticate \
		-Wl,--wrap=cdk2_system_fmp_payload_check \
		"$root/tests/system_fmp_mm_route_test.c" \
		"$root/src/modules/system_fmp/starlabs_trust.c" $route_objects \
		"$temporary/session-positive-$optimization.o" \
		-o "$temporary/mm-route-$optimization"
	"$temporary/mm-route-$optimization" "$temporary/trust.xdr" \
		"$temporary/image-9" "$temporary/image-10" "$temporary/image-rogue" \
		> "$temporary/mm-route-$optimization.log" 2>&1
	expect_assertion "session-mutant-$optimization" \
		'cdk2_system_fmp_session_initialize(&session, &config) == EFI_SUCCESS' \
		"$temporary/session-mutant-$optimization" "$temporary/trust.xdr" \
		"$temporary/image-9" "$temporary/image-10" "$temporary/image-rogue"

	for variant in positive mutant; do
		source="$root/src/modules/system_fmp/transport.c"
		if test "$variant" = mutant; then
			source="$temporary/src/modules/system_fmp/transport.c"
		fi
		# shellcheck disable=SC2086
		"$compiler" $common $sanitizers -O"$optimization" -Wl,--gc-sections \
			"$root/tests/system_fmp_transport_client_test.c" "$source" \
			"$root/src/modules/qemu_test_fmp/sha256.c" "$root/src/boot/coreboot.c" \
			-o "$temporary/transport-$variant-$optimization"
	done
	"$temporary/transport-positive-$optimization" \
		> "$temporary/transport-positive-$optimization.log" 2>&1
	expect_assertion "transport-mutant-$optimization" \
		'status == CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS' \
		"$temporary/transport-mutant-$optimization"
done
# These causes use uninstrumented actual translation units, not a parallel
# route implementation.  Reconstruct every original TU before running them.
perl - "$root" "$temporary" <<-'PERL'
	use strict;
	use warnings;
	my ($root, $directory) = @ARGV;
	my @cases = (
		['flags', 'handoff', "\t    record->flags != CB_CAPSULE_HANDOFF_REQUIRED_FLAGS ||\n", "\t    0 || /* removed handoff flag gate */\n"],
		['handoff-seal', 'session', 'memcmp(value, session->handoff_digest, sizeof(value)) == 0', 'true /* removed handoff seal */'],
		['endpoint-seal', 'session', 'memcmp(value, session->endpoint_digest, sizeof(value)) == 0', 'true /* removed endpoint seal */'],
		['provider-alias', 'provider', "\t\t.image_type = &image_type,", "\t\t.image_type = &provider->session.info.image_type + (image_type.data1 & 0U),"],
	);
	for my $case (@cases) {
		my ($name, $source, $before, $after) = @$case;
		open my $input, '<:raw', "$root/src/modules/system_fmp/$source.c" or die $!;
		local $/;
		my $original = <$input>;
		my $mutant = $original;
		$mutant =~ s/\Q$before\E/$after/g == 1 or die "$name forward count";
		my $restored = $mutant;
		$restored =~ s/\Q$after\E/$before/g == 1 or die "$name reverse count";
		$restored eq $original or die "$name inverse TU mismatch";
		open my $output, '>:raw', "$directory/src/modules/system_fmp/$name.c" or die $!;
		print {$output} $mutant or die $!;
		close $output or die $!;
	}
PERL
cause_objects=
index=0
for source in "$root/tests/system_fmp_mm_route_test.c" \
	"$root/src/modules/system_fmp/starlabs_trust.c" \
	"$root/src/modules/system_fmp/auth.c" \
	"$root/src/modules/system_fmp/payload.c" \
	"$root/src/modules/system_fmp/board_binding.c" $crypto_sources; do
	object="$temporary/cause-support-$index.o"
	# shellcheck disable=SC2086
	"$compiler" $common $crypto_flags -O2 -c "$source" -o "$object"
	cause_objects="$cause_objects $object"
	index=$((index + 1))
done
for cause in flags handoff-seal endpoint-seal provider-alias; do
	session_source="$root/src/modules/system_fmp/session.c"
	handoff_source="$root/src/modules/system_fmp/handoff.c"
	provider_source="$root/src/modules/system_fmp/provider.c"
	assertion='execute(&allowed, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) =='
	if test "$cause" = flags; then
		handoff_source="$temporary/src/modules/system_fmp/$cause.c"
		assertion='EFI_ERROR(initialize_mm())'
	elif test "$cause" = provider-alias; then
		provider_source="$temporary/src/modules/system_fmp/$cause.c"
		assertion='provider.protocol.check_image(&provider.protocol, 1U, allowed.data,'
	else
		session_source="$temporary/src/modules/system_fmp/$cause.c"
	fi
	# shellcheck disable=SC2086
	"$compiler" $common $crypto_flags -O2 -Wl,--gc-sections \
		-Wl,--wrap=cdk2_system_fmp_authenticate \
		-Wl,--wrap=cdk2_system_fmp_payload_check $cause_objects \
		"$session_source" "$handoff_source" "$provider_source" \
		-o "$temporary/mm-cause-$cause"
	expect_assertion "mm-cause-$cause" "$assertion" \
		"$temporary/mm-cause-$cause" "$temporary/trust.xdr" \
		"$temporary/image-9" "$temporary/image-10" "$temporary/image-rogue"
done
sha256sum -c "$temporary/source-before.sha256"
printf '%s\n' 'Future-floor legacy CMS + typed MM/provider HOST joins and eight exact causals: PASS'
