/* SPDX-License-Identifier: GPL-2.0-only */

/* HOST records/transport only; actual framing, handoff, CMS and session code. */
#include <cdk2/system_fmp_session.h>
#include <cdk2/system_fmp_provider.h>
#include <cdk2/system_fmp_payload.h>
#include <cdk2/system_fmp_trust.h>

#define main legacy_fixture_main
#define cdk2_coreboot_find_unique_record legacy_find_record
#define cdk2_system_fmp_transport_from_coreboot legacy_transport_import
#define cdk2_system_fmp_client_execute legacy_client_execute
#include "system_fmp_future_floor_test.c"
#undef main
#undef cdk2_coreboot_find_unique_record
#undef cdk2_system_fmp_transport_from_coreboot
#undef cdk2_system_fmp_client_execute

static struct bytes mm_certificate;
static unsigned int frontend_authentications;
static unsigned int mm_authentications;
static bool in_mm;
static bool mutate_input;
static bool mutate_handoff;
static bool mutate_endpoint;
static bool record_missing;
static bool record_duplicate;
static uint32_t endpoint_revision = CB_CAPSULE_BROKER_ENDPOINT_RAM_REVISION;
static struct cdk2_system_fmp_provider provider;
static struct cdk2_system_fmp_provider *provider_owner;
static struct cdk2_system_fmp_session *executing_session = &session;
static bool local_input_drift, local_session_drift;

EFI_STATUS __real_cdk2_system_fmp_payload_check(
	const struct cdk2_system_fmp_payload_request *request,
	struct cdk2_system_fmp_payload_view *view);

EFI_STATUS __wrap_cdk2_system_fmp_payload_check(
	const struct cdk2_system_fmp_payload_request *request,
	struct cdk2_system_fmp_payload_view *view)
{
	EFI_STATUS status = __real_cdk2_system_fmp_payload_check(request, view);

	/* Hostile callback boundary only: retain the real parser's decision. */
	if (local_input_drift)
		((uint8_t *)request->payload)[request->payload_size - 1] ^= 1;
	if (local_session_drift)
		executing_session->info.lowest_supported_version++;
	return status;
}

EFI_STATUS __real_cdk2_system_fmp_authenticate(const void *image, size_t size,
	const void *certificates, size_t certificates_size,
	cdk2_system_fmp_pkcs7_verify_fn verify, void *context,
	struct cdk2_system_fmp_auth_view *view);

EFI_STATUS __wrap_cdk2_system_fmp_authenticate(const void *image, size_t size,
	const void *certificates, size_t certificates_size,
	cdk2_system_fmp_pkcs7_verify_fn verify, void *context,
	struct cdk2_system_fmp_auth_view *view)
{
	if (in_mm)
		mm_authentications++;
	else
		frontend_authentications++;
	return __real_cdk2_system_fmp_authenticate(image, size, certificates,
		certificates_size, verify, context, view);
}

static struct lb_efi_fw_info *firmware_record(void)
{
	return (void *)(mainboard + 64U);
}

static struct cb_capsule_handoff *handoff_record(void)
{
	return (void *)(mainboard + 128U);
}

EFI_STATUS cdk2_coreboot_find_unique_record(
	const struct cdk2_coreboot_handoff *coreboot, UINT32 tag,
	UINT32 minimum_size, const void **record)
{
	assert(coreboot->header == (const void *)mainboard);
	if (tag == CB_TAG_MAINBOARD)
		return legacy_find_record(coreboot, tag, minimum_size, record);
	if (record_missing)
		return EFI_NOT_FOUND;
	if (record_duplicate)
		return EFI_COMPROMISED_DATA;
	if (tag == CB_TAG_FW_INFO) {
		assert(minimum_size == sizeof(struct lb_efi_fw_info));
		*record = firmware_record();
	} else {
		assert(tag == CB_TAG_CAPSULE_HANDOFF);
		assert(minimum_size == sizeof(struct cb_capsule_handoff));
		*record = handoff_record();
	}
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_transport_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_transport *endpoint)
{
	EFI_STATUS status = legacy_transport_import(coreboot, endpoint);

	endpoint->revision = endpoint_revision;
	return status;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_execute(
	struct cdk2_system_fmp_client *client,
	enum cdk2_system_fmp_transport_operation operation,
	const void *image, UINTN image_size, UINT32 attempted_version,
	struct cdk2_system_fmp_outcome *outcome)
{
	struct cdk2_system_fmp_auth_view view;
	EFI_STATUS status;

	assert(client == &executing_session->client && image != NULL && image_size > ROM_SIZE);
	assert(operation == CDK2_SYSTEM_FMP_CHECK || operation == CDK2_SYSTEM_FMP_SET);
	assert(attempted_version == FUTURE_FLOOR);
	executions++;
	in_mm = true;
	status = cdk2_system_fmp_authenticate(image, image_size,
		mm_certificate.data, mm_certificate.size,
		cdk2_system_fmp_pkcs7_verify, NULL, &view);
	in_mm = false;
	*outcome = (struct cdk2_system_fmp_outcome) {
		.transaction = 37U, .generation = client->endpoint.generation,
		.attempted_version = attempted_version,
		.last_attempt_status = EFI_ERROR(status) ?
			CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL : CDK2_FMP_LAST_ATTEMPT_SUCCESS,
		.broker_result = EFI_ERROR(status) ?
			CDK2_SYSTEM_FMP_RESULT_EXECUTION : CDK2_SYSTEM_FMP_RESULT_SUCCESS,
		.trigger_invoked = true, .response_authenticated = true,
	};
	if (operation == CDK2_SYSTEM_FMP_CHECK && status == EFI_SECURITY_VIOLATION)
		outcome->broker_result = CDK2_SYSTEM_FMP_RESULT_SIGNATURE_REFUSED;
	if (mutate_input)
		((uint8_t *)image)[image_size - 1U] ^= 1U;
	if (mutate_handoff)
		session.authenticated_handoff.regions[0].flags ^= 1U;
	if (mutate_endpoint) {
		session.endpoint.generation++;
		session.client.endpoint.generation++;
	}
	if (outcome->broker_result == CDK2_SYSTEM_FMP_RESULT_SIGNATURE_REFUSED)
		return CDK2_SYSTEM_FMP_TRANSPORT_SIGNATURE_REFUSED;
	return EFI_ERROR(status) ? CDK2_SYSTEM_FMP_TRANSPORT_EXECUTION_FAILED :
		CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

static void reset_records(void)
{
	struct cb_mainboard *board = (void *)mainboard;
	struct lb_efi_fw_info *firmware = firmware_record();
	struct cb_capsule_handoff *handoff = handoff_record();

	memset(mainboard, 0, sizeof(mainboard));
	board->tag = CB_TAG_MAINBOARD;
	board->size = 28U;
	board->part_number_index = sizeof("Star Labs");
	memcpy(board->strings, "Star Labs\0Lite\0", sizeof("Star Labs\0Lite\0"));
	*firmware = (struct lb_efi_fw_info) {
		.tag = CB_TAG_FW_INFO, .size = sizeof(*firmware),
		.version = RUNNING_VERSION, .lowest_supported_version = 7U,
		.fw_size = ROM_SIZE,
	};
	memcpy(firmware->guid, &image_type, sizeof(image_type));
	*handoff = (struct cb_capsule_handoff) {
		.tag = CB_TAG_CAPSULE_HANDOFF,
		.size = sizeof(*handoff) + sizeof(handoff->regions[0]),
		.revision = CB_CAPSULE_HANDOFF_REVISION, .header_size = sizeof(*handoff),
		.flags = CB_CAPSULE_HANDOFF_REQUIRED_FLAGS,
		.broker_type = CB_CAPSULE_BROKER_COREBOOT_UPDATE,
		.capsule_format = CB_CAPSULE_FORMAT_FMP_V3,
		.authentication_format = CB_CAPSULE_AUTH_EFI_PKCS7,
		.board_binding_format = CB_CAPSULE_BOARD_BINDING_CBFS_BUILD_INFO_V1,
		.payload_format = CB_CAPSULE_PAYLOAD_MSS1_V1,
		.broker_capabilities = CB_CAPSULE_BROKER_REQUIRED_CAPABILITIES,
		.version = RUNNING_VERSION, .lowest_supported_version = 7U,
		.capsule_flags = CB_CAPSULE_FLAGS_PERSIST_RESET,
		.block_size = 4096U, .erase_size = 4096U, .region_count = 1U,
		.image_size = { .lo = ROM_SIZE }, .boot_media_size = { .lo = ROM_SIZE },
		.smmstore_size = { .lo = 4096U },
	};
	memcpy(handoff->image_type_guid, &image_type, sizeof(image_type));
	handoff->regions[0] = (struct cb_capsule_update_region) {
		.image_offset = { .lo = 8192U }, .flash_offset = { .lo = 8192U },
		.size = { .lo = ROM_SIZE - 8192U }, .flags = CB_CAPSULE_REGION_BIOS,
	};
	record_missing = false;
	record_duplicate = false;
	endpoint_revision = CB_CAPSULE_BROKER_ENDPOINT_RAM_REVISION;
	mutate_input = false;
	mutate_handoff = false;
	mutate_endpoint = false;
}

static EFI_STATUS initialize_mm(void)
{
	struct bytes production_trust = {
		.data = (void *)cdk2_system_fmp_starlabs_certificates,
		.size = sizeof(cdk2_system_fmp_starlabs_certificates),
	};
	struct cdk2_coreboot_handoff coreboot = {
		.header = (const void *)mainboard, .table_size = sizeof(mainboard),
	};
	struct cdk2_system_fmp_session_config config = {
		.coreboot = &coreboot,
		.certificate_xdr = production_trust.data,
		.certificate_xdr_size = production_trust.size,
		.transport_port = {
			.sha256 = hash, .publish = cache, .acquire = cache,
			.barrier = barrier, .trigger_apm_io8 = trigger,
		},
	};

	memset(&session, 0, sizeof(session));
	if (provider_owner != NULL) {
		executing_session = &provider_owner->session;
		return cdk2_system_fmp_provider_initialize(provider_owner, &config);
	}
	executing_session = &session;
	return cdk2_system_fmp_session_initialize(&session, &config);
}

int main(int argc, char **argv)
{
	struct cdk2_system_fmp_session_result result;
	struct bytes allowed, below, rogue, corrupt;
	unsigned int before, prior;
	UINT32 updatable = CDK2_FMP_IMAGE_UPDATABLE_INVALID;

	assert(argc == 5);
	mm_certificate = read_file(argv[1]);
	below = read_file(argv[2]);
	allowed = read_file(argv[3]);
	rogue = read_file(argv[4]);
	corrupt = read_file(argv[3]);
	corrupt.data[corrupt.size - 1U] ^= 1U;
	reset_records();
	assert(initialize_mm() == EFI_SUCCESS);
	assert(session.info.lowest_supported_version > session.info.current_version);
	assert(execute(&below, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) == EFI_SUCCESS);
	assert(!result.transport_invoked && executions == 0U && result.local_floor_refused);
	/* This rejection is local version policy, not CMS or board verification. */
	below.data[below.size - 1] ^= 1;
	assert(execute(&below, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) == EFI_SUCCESS);
	assert(result.local_floor_refused && !result.signature_refused &&
		!result.transport_invoked && executions == 0U && mm_authentications == 0U);
	below.data[below.size - 1] ^= 1;
	assert(execute(&rogue, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) == EFI_DEVICE_ERROR);
	assert(result.transport_invoked && result.broker_response_authenticated);
	assert(result.last_attempt_status == CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL);
	assert(execute(&corrupt, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) == EFI_DEVICE_ERROR);
	assert(execute(&allowed, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) == EFI_SUCCESS);
	assert(execute(&allowed, CDK2_SYSTEM_FMP_SESSION_SET, &result) == EFI_SUCCESS);
	before = executions;
	assert(EFI_ERROR(execute(&allowed, CDK2_SYSTEM_FMP_SESSION_SET, &result)));
	assert(executions == before && frontend_authentications == 0U);
	assert(mm_authentications == 4U);
	assert(cdk2_system_fmp_session_close(&session) == EFI_SUCCESS);

	for (unsigned int mode = 0U; mode < 3U; mode++) {
		reset_records();
		assert(initialize_mm() == EFI_SUCCESS);
		mutate_input = mode == 0U;
		mutate_handoff = mode == 1U;
		mutate_endpoint = mode == 2U;
		assert(execute(&allowed, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
			EFI_COMPROMISED_DATA);
		if (mutate_input)
			allowed.data[allowed.size - 1U] ^= 1U;
	}
	for (unsigned int mode = 0U; mode < 9U; mode++) {
		reset_records();
		switch (mode) {
		case 0:
			handoff_record()->flags = 0U;
			break;
		case 1:
			handoff_record()->authentication_format = 0U;
			break;
		case 2:
			handoff_record()->payload_format = 0U;
			break;
		case 3:
			handoff_record()->image_type_guid[0] ^= 1U;
			break;
		case 4:
			handoff_record()->regions[0].flash_offset.lo = 0U;
			break;
		case 5:
			record_missing = true;
			break;
		case 6:
			record_duplicate = true;
			break;
		case 7:
			endpoint_revision++;
			break;
		case 8:
			firmware_record()->version++;
			break;
		}
		assert(EFI_ERROR(initialize_mm()));
	}
	assert(frontend_authentications == 0U);
	for (unsigned int drift = 0; drift < 2; drift++) {
		reset_records();
		assert(initialize_mm() == EFI_SUCCESS);
		prior = executions;
		local_input_drift = drift == 0;
		local_session_drift = drift == 1;
		assert(execute(&below, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
			EFI_COMPROMISED_DATA);
		assert(!result.local_floor_refused && !result.signature_refused &&
			!result.transport_invoked && executions == prior);
		if (local_input_drift)
			below.data[below.size - 1] ^= 1;
		local_input_drift = local_session_drift = false;
	}
	/* Actual provider callbacks joined to the actual session/parser/CMS.
	 * Only records and authenticated MM transport remain HOST-modeled. */
	reset_records();
	provider_owner = &provider;
	assert(initialize_mm() == EFI_SUCCESS);
	before = executions;
	assert(provider.protocol.check_image(&provider.protocol, 1U, allowed.data,
		allowed.size, &updatable) == EFI_SUCCESS);
	assert(updatable == CDK2_FMP_IMAGE_UPDATABLE_VALID && executions == before + 1U);
	assert(provider.protocol.check_image(&provider.protocol, 1U, rogue.data,
		rogue.size, &updatable) == EFI_DEVICE_ERROR);
	assert(updatable == CDK2_FMP_IMAGE_UPDATABLE_INVALID);
	assert(provider.check_outcome.signature_refused &&
		provider.check_outcome.image == rogue.data && provider.check_outcome.transaction == 37U);
	assert(provider.protocol.check_image(&provider.protocol, 1U, corrupt.data,
		corrupt.size, &updatable) == EFI_DEVICE_ERROR);
	assert(updatable == CDK2_FMP_IMAGE_UPDATABLE_INVALID);
	assert(provider.check_outcome.signature_refused && provider.check_outcome.image == corrupt.data);
	prior = executions;
	assert(provider.protocol.check_image(&provider.protocol, 1U, below.data,
		below.size, &updatable) == EFI_SUCCESS);
	assert(updatable != CDK2_FMP_IMAGE_UPDATABLE_VALID && executions == prior);
	assert(!provider.check_outcome.signature_refused);
	assert(provider.check_outcome.local_floor_refused &&
		provider.check_outcome.transaction == 0U &&
		provider.check_outcome.generation == provider.session.endpoint.generation &&
		provider.check_outcome.attempted_version == RUNNING_VERSION &&
		provider.check_outcome.sealed_floor == FUTURE_FLOOR &&
		provider.check_outcome.image == below.data);
	assert(provider.protocol.set_image(&provider.protocol, 1U, allowed.data,
		allowed.size, NULL, NULL, NULL) == EFI_SUCCESS);
	assert(executions == before + 4U && frontend_authentications == 0U);
	prior = executions;
	assert(EFI_ERROR(provider.protocol.set_image(&provider.protocol, 1U,
		allowed.data, allowed.size, NULL, NULL, NULL)));
	assert(executions == prior);
	assert(cdk2_system_fmp_provider_close(&provider) == EFI_SUCCESS);
	free(mm_certificate.data);
	free(below.data);
	free(allowed.data);
	free(rogue.data);
	free(corrupt.data);
	puts("HOST typed MM route: real parsers/CMS, modeled authenticated transport: PASS");
	return 0;
}
