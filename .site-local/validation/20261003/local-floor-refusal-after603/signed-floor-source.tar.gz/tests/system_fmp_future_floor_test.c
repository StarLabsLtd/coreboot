/* SPDX-License-Identifier: GPL-2.0-only */

/* HOST transport/record model; real session, CMS, payload and board parsers. */
#include <assert.h>
#include <cdk2/system_fmp_crypto.h>
#include <cdk2/system_fmp_session.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../src/boot/coreboot.h"

#define RUNNING_VERSION 9U
#define FUTURE_FLOOR 10U
#define ROM_SIZE 65536U

struct bytes {
	uint8_t *data;
	size_t size;
};

static struct cdk2_system_fmp_session session;
static const EFI_GUID image_type = { .data1 = 0x975cd0e6U };
static uint8_t mainboard[1024];
static uint32_t reported_version = RUNNING_VERSION;
static uint32_t reported_floor = FUTURE_FLOOR;
static unsigned int executions;

static struct bytes read_file(const char *path)
{
	FILE *file = fopen(path, "rb");
	struct bytes bytes = {0};
	long size;

	assert(file != NULL && fseek(file, 0, SEEK_END) == 0);
	size = ftell(file);
	assert(size > 0 && fseek(file, 0, SEEK_SET) == 0);
	bytes.size = (size_t)size;
	bytes.data = malloc(bytes.size);
	assert(bytes.data != NULL);
	assert(fread(bytes.data, 1U, bytes.size, file) == bytes.size);
	assert(fgetc(file) == EOF && fclose(file) == 0);
	return bytes;
}

EFI_STATUS cdk2_coreboot_find_unique_record(
	const struct cdk2_coreboot_handoff *coreboot, UINT32 tag,
	UINT32 minimum_size, const void **record)
{
	assert(coreboot->header == (const void *)mainboard);
	assert(tag == CB_TAG_MAINBOARD && minimum_size <= 28U);
	*record = mainboard;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_transport_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_transport *endpoint)
{
	assert(coreboot->header == (const void *)mainboard);
	*endpoint = (struct cdk2_system_fmp_transport) {
		.revision = CB_CAPSULE_BROKER_ENDPOINT_REVISION,
		.generation = 7U,
		.image_type = image_type,
		.current_version = RUNNING_VERSION,
		.lowest_supported_version = 7U,
		.image_size = ROM_SIZE,
		.capabilities = CB_CAPSULE_BROKER_REQUIRED_CAPABILITIES,
		.communication_base = 0x1000U,
		.communication_size = CDK2_SYSTEM_FMP_TRANSPORT_SIZE,
		.message_size = CDK2_SYSTEM_FMP_TRANSPORT_SIZE,
		.staging_base = 0x2000U,
		.staging_size = ROM_SIZE + 4096U,
		.trigger_port = 0xb2U,
		.trigger_value = 0xe8U,
		.valid = TRUE,
	};
	return EFI_SUCCESS;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_init(
	struct cdk2_system_fmp_client *client,
	const struct cdk2_system_fmp_transport *endpoint,
	const struct cdk2_system_fmp_transport_port *port)
{
	*client = (struct cdk2_system_fmp_client) {
		.endpoint = *endpoint, .port = *port, .initialized = TRUE,
	};
	return CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_read_info(
	struct cdk2_system_fmp_client *client, struct cdk2_system_fmp_info *info)
{
	*info = (struct cdk2_system_fmp_info) {
		.image_type = client->endpoint.image_type,
		.current_version = reported_version,
		.lowest_supported_version = reported_floor,
		.image_size = client->endpoint.image_size,
		.capabilities = client->endpoint.capabilities,
	};
	return CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_execute(
	struct cdk2_system_fmp_client *client,
	enum cdk2_system_fmp_transport_operation operation,
	const void *image, UINTN image_size, UINT32 attempted_version,
	struct cdk2_system_fmp_outcome *outcome)
{
	assert(client == &session.client && image != NULL && image_size > ROM_SIZE);
	assert(operation == CDK2_SYSTEM_FMP_SET && attempted_version == FUTURE_FLOOR);
	executions++;
	*outcome = (struct cdk2_system_fmp_outcome) {
		.attempted_version = attempted_version,
		.last_attempt_status = CDK2_FMP_LAST_ATTEMPT_SUCCESS,
		.broker_result = CDK2_SYSTEM_FMP_RESULT_SUCCESS,
		.trigger_invoked = true, .response_authenticated = true,
	};
	return CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_close(
	struct cdk2_system_fmp_client *client)
{
	memset(client, 0, sizeof(*client));
	return CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

static EFI_STATUS hash(void *context, const void *data, UINTN size, UINT8 out[32])
{
	(void)context;
	cdk2_system_fmp_sha256(data, size, out);
	return EFI_SUCCESS;
}

static EFI_STATUS cache(void *context, void *base, UINTN size)
{
	(void)context;
	(void)base;
	(void)size;
	return EFI_SUCCESS;
}

static void barrier(void *context)
{
	(void)context;
}

static EFI_STATUS trigger(void *context, UINT16 port, UINT8 value)
{
	(void)context;
	(void)port;
	(void)value;
	assert(false); /* Modeled client delegates instead of invoking hardware. */
	return EFI_DEVICE_ERROR;
}

static void initialize(const struct bytes *certificate)
{
	struct cdk2_coreboot_handoff coreboot = {
		.header = (const void *)mainboard, .table_size = sizeof(mainboard),
	};
	struct cdk2_system_fmp_session_config config = {
		.coreboot = &coreboot,
		.certificate_xdr = certificate->data,
		.certificate_xdr_size = certificate->size,
		.transport_port = {
			.sha256 = hash, .publish = cache, .acquire = cache,
			.barrier = barrier, .trigger_apm_io8 = trigger,
		},
	};

	memset(&session, 0, sizeof(session));
	assert(cdk2_system_fmp_session_initialize(&session, &config) == EFI_SUCCESS);
	assert(session.info.current_version == RUNNING_VERSION);
	assert(session.info.lowest_supported_version == FUTURE_FLOOR);
}

static EFI_STATUS execute(const struct bytes *image,
	enum cdk2_system_fmp_session_operation operation,
	struct cdk2_system_fmp_session_result *result)
{
	struct cdk2_system_fmp_session_request request = {
		.operation = operation, .image_type = &image_type, .image_index = 1U,
		.authenticated_image = image->data, .authenticated_image_size = image->size,
	};

	return cdk2_system_fmp_session_execute(&session, &request, result);
}

int main(int argc, char **argv)
{
	struct cdk2_system_fmp_session_result result;
	struct bytes certificate, below, allowed, rogue;
	struct cb_mainboard *board = (void *)mainboard;

	assert(argc == 5);
	certificate = read_file(argv[1]);
	below = read_file(argv[2]);
	allowed = read_file(argv[3]);
	rogue = read_file(argv[4]);
	board->tag = CB_TAG_MAINBOARD;
	board->size = 28U;
	board->vendor_index = 0U;
	board->part_number_index = sizeof("Star Labs");
	memcpy(board->strings, "Star Labs\0Lite\0", sizeof("Star Labs\0Lite\0"));

	initialize(&certificate);
	assert(execute(&below, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) == EFI_SUCCESS);
	assert(result.image_updatable == CDK2_FMP_IMAGE_UPDATABLE_INVALID_OLD);
	assert(result.last_attempt_status == CDK2_FMP_LAST_ATTEMPT_VERSION_TOO_LOW);
	assert(result.attempted_version == RUNNING_VERSION && !result.transport_invoked);
	assert(result.local_floor_refused && !result.signature_refused &&
		result.sealed_floor == FUTURE_FLOOR && result.broker_transaction == 0U);
	assert(executions == 0U);
	assert(execute(&below, CDK2_SYSTEM_FMP_SESSION_SET, &result) == EFI_ABORTED);
	assert(!result.transport_invoked && !result.local_floor_refused && executions == 0U);
	assert(cdk2_system_fmp_session_close(&session) == EFI_SUCCESS);

	initialize(&certificate);
	assert(execute(&rogue, CDK2_SYSTEM_FMP_SESSION_SET, &result) ==
		EFI_SECURITY_VIOLATION);
	assert(!result.transport_invoked && executions == 0U);
	assert(cdk2_system_fmp_session_close(&session) == EFI_SUCCESS);

	initialize(&certificate);
	assert(execute(&allowed, CDK2_SYSTEM_FMP_SESSION_SET, &result) == EFI_SUCCESS);
	assert(result.attempted_version == FUTURE_FLOOR && result.transport_invoked);
	assert(result.image_updatable == CDK2_FMP_IMAGE_UPDATABLE_VALID);
	assert(result.trigger_invoked && result.broker_response_authenticated);
	assert(executions == 1U && session.info.current_version == RUNNING_VERSION);
	assert(session.info.lowest_supported_version == FUTURE_FLOOR);
	assert(cdk2_system_fmp_session_close(&session) == EFI_SUCCESS);

	free(certificate.data);
	free(below.data);
	free(allowed.data);
	free(rogue.data);
	puts("HOST real session/CMS/payload/board future-floor gates: PASS (modeled transport)");
	return 0;
}
