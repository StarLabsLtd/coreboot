/* SPDX-License-Identifier: GPL-2.0-only */
/* Real Core validator, registry records, allocation ownership and SHA256.
 * Driver publication and Runtime/FMP outcomes are HOST models, not MM proof. */
#include <assert.h>
#include <stdlib.h>
#include <cdk2/pcat_rtc.h>
#ifdef CDK2_CERTIFIED_CORE_SOURCE
#include CDK2_CERTIFIED_CORE_SOURCE
#else
#include "../src/modules/dxe_core/entry.c"
#endif

static struct {
	struct cdk2_fmp_protocol fmp;
	struct cdk2_capsule_check_outcome check;
	uint8_t padding[16];
} resident;
static struct cdk2_capsule_boot_protocol runtime;
static struct {
	struct cdk2_capsule_header header;
	uint8_t image[32];
} input;
static const uint8_t source_image[64] = { 1, 2, 3 };
static struct cdk2_capsule_process_outcome model_process;
static uint8_t mailbox[CDK2_SYSTEM_FMP_TRANSPORT_SIZE] __aligned(8);
static uint8_t staging[64] __aligned(8);
static bool pointer_live, close_error, retire_error, close_drift, retire_drift;
static unsigned int close_calls, retire_calls;
static uint8_t report_data[72];
static CHAR16 report_last[11];
static bool report_live, last_live, report_error, report_drift, report_padding_drift;
static bool header_clock_drift, header_set_drift, header_close_drift, header_retire_drift;
static bool header_process_drift;

static EFI_STATUS CDK2_MS_ABI validate_model(
	struct cdk2_capsule_boot_protocol *protocol, const void *data, UINTN size)
{
	(void)protocol;
	(void)data;
	(void)size;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI process_model(
	struct cdk2_capsule_boot_protocol *protocol, const void *data, UINTN size)
{
	assert(data == &input && size == sizeof(input));
	if (header_process_drift)
		input.header.guid.data2++;
	memcpy(&protocol->outcome, &model_process, sizeof(model_process));
	return model_process.failure;
}

static EFI_STATUS CDK2_MS_ABI scatter_model(
	struct cdk2_capsule_boot_protocol *protocol, UINT64 scatter)
{
	(void)protocol;
	(void)scatter;
	return EFI_UNSUPPORTED;
}

static EFI_STATUS cache_model(void *context, void *base, UINTN size)
{
	(void)context;
	assert(base == mailbox && size == sizeof(mailbox));
	return EFI_SUCCESS;
}

static void barrier_model(void *context)
{
	(void)context;
}

static EFI_STATUS trigger_model(void *context, UINT16 port, UINT8 value)
{
	struct cdk2_system_fmp_request *request = (void *)mailbox;
	struct cdk2_system_fmp_result *result =
		(void *)(mailbox + CDK2_SYSTEM_FMP_RESULT_OFFSET);

	(void)context;
	assert(port == 0xb2 && value == 0xe8);
	assert(request->operation == CDK2_SYSTEM_FMP_TRANSPORT_CLOSE_RAM);
	close_calls++;
	memset(result, 0, sizeof(*result));
	result->revision = request->revision;
	result->size = sizeof(*result);
	result->generation = request->generation;
	result->transaction = request->transaction;
	result->result = close_error ? CDK2_SYSTEM_FMP_RESULT_EXECUTION :
		CDK2_SYSTEM_FMP_RESULT_SUCCESS;
	if (close_drift)
		resident.check.transaction++;
	if (header_close_drift)
		input.header.flags ^= CDK2_CAPSULE_PERSIST;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI get_model(CHAR16 *name, EFI_GUID *guid,
	UINT32 *attributes, UINTN *size, void *data)
{
	const UINT64 pointer = 0x1000;
	static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;

	if (memcmp(guid, &report_guid, sizeof(*guid)) == 0) {
		const void *bytes;
		UINTN length;
		UINT32 attrs = 7;

		if (memcmp(name, L"CapsuleMax", sizeof(L"CapsuleMax")) == 0) {
			bytes = L"Capsuleffff";
			length = 22;
			attrs = 6;
		} else if (memcmp(name, L"CapsuleLast", sizeof(L"CapsuleLast")) == 0) {
			if (!last_live)
				return EFI_NOT_FOUND;
			bytes = report_last;
			length = sizeof(report_last);
		} else {
			assert(memcmp(name, L"Capsule0000", sizeof(L"Capsule0000")) == 0);
			if (!report_live)
				return EFI_NOT_FOUND;
			bytes = report_data;
			length = sizeof(report_data);
		}
		assert(*size >= length && data != NULL);
		memcpy(data, bytes, length);
		*size = length;
		*attributes = attrs;
		return EFI_SUCCESS;
	}

	assert(memcmp(name, L"CapsuleUpdateData", sizeof(L"CapsuleUpdateData")) == 0);
	assert(memcmp(guid, &capsule_variable_guid, sizeof(*guid)) == 0);
	if (!pointer_live)
		return EFI_NOT_FOUND;
	assert(*size == sizeof(pointer));
	*attributes = 7;
	memcpy(data, &pointer, sizeof(pointer));
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI set_model(CHAR16 *name, EFI_GUID *guid,
	UINT32 attributes, UINTN size, void *data)
{
	static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;

	if (memcmp(guid, &report_guid, sizeof(*guid)) == 0) {
		assert(close_calls == 1 && attributes == 7);
		if (report_error)
			return EFI_DEVICE_ERROR;
		if (size == 72) {
			EFI_STATUS reported;
			memcpy(&reported, (uint8_t *)data + 40, sizeof(reported));
			assert(reported == model_process.failure);
			memcpy(report_data, data, size);
			report_live = true;
		} else {
			assert(size == 22 && memcmp(name, L"CapsuleLast", 22) == 0);
			memcpy(report_last, data, size);
			last_live = true;
		}
		if (report_drift)
			resident.check.transaction++;
		if (report_padding_drift && size == 72)
			((uint8_t *)&resident.check)[sizeof(resident.check) - 1] ^= 1;
		if (header_set_drift && size == 72)
			input.header.image_size++;
		return EFI_SUCCESS;
	}
	assert(memcmp(name, L"CapsuleUpdateData", sizeof(L"CapsuleUpdateData")) == 0);
	assert(memcmp(guid, &capsule_variable_guid, sizeof(*guid)) == 0);
	assert(attributes == 0 && size == 0 && data == NULL);
	assert(close_calls == 1);
	retire_calls++;
	if (retire_error)
		return EFI_DEVICE_ERROR;
	pointer_live = false;
	if (retire_drift)
		runtime.outcome.matching_checks++;
	if (header_retire_drift)
		input.header.header_size++;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI next_model(UINTN *size, CHAR16 *name, EFI_GUID *guid)
{
	(void)size;
	(void)name;
	(void)guid;
	assert(!pointer_live);
	return EFI_NOT_FOUND;
}

static EFI_STATUS CDK2_MS_ABI report_time_model(CDK2_EFI_TIME *time,
	CDK2_TIME_CAPABILITIES *capabilities)
{
	(void)time;
	(void)capabilities;
	if (header_clock_drift) {
		input.header.guid.data1++;
		return EFI_SUCCESS;
	}
	return EFI_DEVICE_ERROR;
}

static void initialize(struct dxe_services_context *context)
{
	static const EFI_GUID boot_guid = { 0x2890d42b, 0x7f9b, 0x4a66,
		{ 0x9a, 0x12, 0x54, 0x8d, 0x6b, 0x57, 0xd8, 0x20 } };
	static const EFI_GUID check_guid = CDK2_CAPSULE_CHECK_OUTCOME_GUID;
	struct cdk2_dxe_image_transaction *transaction;
	UINT64 allocation_generation;
	struct cdk2_software_hash hash;
	void *storage = aligned_alloc(4096, 16 * 4096);

	assert(storage != NULL);
	memset(&core, 0, sizeof(core));
	assert(cdk2_dxe_memory_initialize(&core.memory, storage, 16) == EFI_SUCCESS);
	core.images.memory = &core.memory;
	assert(cdk2_dxe_image_transaction_prepare(&core.images, source_image,
		sizeof(source_image), NULL, 0, &transaction, &allocation_generation) == EFI_SUCCESS);
	transaction->state = CDK2_DXE_IMAGE_PUBLISHED;
	memset(context, 0, sizeof(*context));
	context->capsule_runtime_owner = (void *)1;
	context->capsule_fmp_owner = (void *)2;
	context->capsule_fmp_generation = 19;
	context->capsule_fmp_transaction_generation = transaction->generation;
	context->capsule_fmp_source = &core.dispatcher.drivers[0];
	context->capsule_fmp_source_image = source_image;
	context->capsule_fmp_source_size = sizeof(source_image);
	const struct cdk2_system_fmp_transport endpoint = {
		.revision = CB_CAPSULE_BROKER_ENDPOINT_RAM_REVISION, .generation = 5,
		.image_type = { 1, 2, 3, {4, 5, 6, 7, 8, 9, 10, 11} },
		.current_version = 2, .lowest_supported_version = 1, .image_size = sizeof(staging),
		.capabilities = CB_CAPSULE_BROKER_REQUIRED_CAPABILITIES,
		.communication_base = (UINTN)mailbox, .communication_size = sizeof(mailbox),
		.message_size = sizeof(mailbox), .staging_base = (UINTN)staging,
		.staging_size = sizeof(staging), .trigger_port = 0xb2, .trigger_value = 0xe8,
		.valid = true,
	};
	const struct cdk2_system_fmp_transport_port port = {
		.publish = cache_model, .acquire = cache_model, .barrier = barrier_model,
		.trigger_apm_io8 = trigger_model,
	};

	assert(cdk2_system_fmp_client_init(&context->capsule_client, &endpoint, &port) ==
		CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS);
	core.dispatcher.count = 1;
	core.dispatcher.drivers[0] = (struct cdk2_dxe_driver) {
		.guid = capsule_disk_drivers[1].guid, .image = source_image,
		.image_size = sizeof(source_image), .started = true,
	};
	core.images.count = 2;
	core.images.images[0] = (struct cdk2_dxe_image) {
		.handle = (void *)1, .load_generation = 11, .protocol_pins = 1,
		.base = &runtime, .size = sizeof(runtime),
	};
	core.images.images[1] = (struct cdk2_dxe_image) {
		.handle = (void *)2, .load_generation = 19, .protocol_pins = 2,
		.base = &resident, .size = sizeof(resident), .started = true,
		.exited = true, .exit_status = EFI_SUCCESS, .transaction = transaction,
		.transaction_allocation_generation = allocation_generation,
	};
	core.database.protocol_count = 3;
	core.database.protocols[0] = (struct cdk2_dxe_protocol) {
		.handle = (void *)3, .guid = boot_guid, .interface = &runtime,
		.owner_image = (void *)1, .owner_generation = 11,
	};
	core.database.protocols[1] = (struct cdk2_dxe_protocol) {
		.handle = (void *)4, .guid = firmware_management_protocol_guid,
		.interface = &resident.fmp, .owner_image = (void *)2, .owner_generation = 19,
	};
	core.database.protocols[2] = (struct cdk2_dxe_protocol) {
		.handle = (void *)4, .guid = check_guid, .interface = &resident.check,
		.owner_image = (void *)2, .owner_generation = 19,
	};
	runtime = (struct cdk2_capsule_boot_protocol) {
		.validate_capsule = validate_model, .process_capsule = process_model,
		.process_scatter = scatter_model,
		.outcome = {
			.capsule = &input, .capsule_size = sizeof(input), .fmp_handle = (void *)4,
			.fmp_protocol = &resident.fmp, .check = &resident.check,
			.image = input.image, .image_size = sizeof(input.image), .image_index = 1,
			.matching_checks = 1, .failure = EFI_DEVICE_ERROR, .completed = true,
		},
	};
	resident.check = (struct cdk2_capsule_check_outcome) {
		.image_type = endpoint.image_type,
		.protocol = &resident.fmp, .image = input.image, .image_size = sizeof(input.image),
		.generation = 5, .transaction = 37, .image_index = 1, .signature_refused = true,
	};
	assert(cdk2_software_hash_init(&hash, TPM_ALG_SHA256) == EFI_SUCCESS);
	assert(cdk2_software_hash_update(&hash, input.image, sizeof(input.image)) == EFI_SUCCESS);
	assert(cdk2_software_hash_final(&hash, resident.check.digest, 32) == EFI_SUCCESS);
	/* Exercise native representation snapshots, including tail padding. */
	_Static_assert(sizeof(resident.check) >
		offsetof(struct cdk2_capsule_check_outcome, sealed_floor) + sizeof(uint32_t),
		"fixture needs real CHECK tail padding");
	memset((uint8_t *)&resident.check +
		offsetof(struct cdk2_capsule_check_outcome, sealed_floor) + sizeof(uint32_t),
		0xa5, sizeof(resident.check) -
		offsetof(struct cdk2_capsule_check_outcome, sealed_floor) - sizeof(uint32_t));
	memcpy(&model_process, &runtime.outcome, sizeof(model_process));
}

int main(void)
{
	struct dxe_services_context context;

	initialize(&context);
#define VALID() certified_ram_check_refusal(&context, &runtime, &input.header, \
	sizeof(input), EFI_DEVICE_ERROR)
	assert(VALID());
#define REFUSE(field, value) do { __typeof__(field) saved = (field); \
	(field) = (value); assert(!VALID()); (field) = saved; assert(VALID()); } while (0)
	REFUSE(runtime.outcome.active, true);
	REFUSE(runtime.outcome.completed, false);
	REFUSE(runtime.outcome.set_begun, true);
	REFUSE(runtime.outcome.unproved, true);
	REFUSE(runtime.outcome.matching_checks, 2);
	REFUSE(runtime.outcome.capsule_size, sizeof(input) - 1);
	REFUSE(runtime.outcome.image, (void *)((uintptr_t)&input + sizeof(input) + 1));
	REFUSE(runtime.outcome.image_size, sizeof(input));
	REFUSE(runtime.reset_required, true);
	REFUSE(core.database.protocols[2].owner_generation, 20);
	REFUSE(core.database.protocols[2].owner_image, (void *)1);
	REFUSE(core.database.protocols[2].handle, (void *)5);
	REFUSE(core.database.protocols[2].interface_dynamic, true);
	REFUSE(core.database.protocols[2].interface_size, 1);
	REFUSE(core.database.protocols[2].interface_generation, 1);
	REFUSE(core.database.protocols[1].interface, (void *)1);
	REFUSE(core.database.protocols[2].interface, (void *)1);
	REFUSE(core.database.protocols[2].guid.data1, 0);
	core.database.protocols[3] = core.database.protocols[2];
	REFUSE(core.database.protocol_count, 4);
	REFUSE(core.images.images[1].protocol_pins, 0);
	REFUSE(core.images.images[1].size, sizeof(resident.fmp));
	REFUSE(core.images.images[1].exit_status, EFI_DEVICE_ERROR);
	REFUSE(core.images.images[1].transaction->state, CDK2_DXE_IMAGE_PREPARED);
	REFUSE(core.images.images[1].transaction_allocation_generation, 0);
	REFUSE(core.dispatcher.drivers[0].image_size, 1);
	REFUSE(context.capsule_fmp_source, (void *)1);
	REFUSE(resident.check.generation, 6);
	REFUSE(resident.check.transaction, 0);
	REFUSE(resident.check.image_index, 2);
	REFUSE(resident.check.protocol, (void *)1);
	REFUSE(resident.check.image, (void *)1);
	REFUSE(resident.check.image_size, 1);
	REFUSE(resident.check.signature_refused, false);
	REFUSE(resident.check.local_floor_refused, true);
	REFUSE(resident.check.digest[0], resident.check.digest[0] ^ 1);
	REFUSE(core.database.protocol_count, CDK2_DXE_MAX_PROTOCOLS + 1);
	REFUSE(core.images.count, CDK2_DXE_MAX_IMAGES + 1);
	REFUSE(core.dispatcher.count, CDK2_DXE_MAX_DRIVERS + 1);
	{
		struct cdk2_capsule_check_outcome *unaligned =
			(void *)((uintptr_t)&resident.check + 1);
		const struct cdk2_capsule_check_outcome *saved = runtime.outcome.check;

		runtime.outcome.check = unaligned;
		core.database.protocols[2].interface = unaligned;
		assert(!VALID());
		runtime.outcome.check = saved;
		core.database.protocols[2].interface = (void *)saved;
		assert(VALID());
	}
	{
		struct cdk2_capsule_check_outcome saved;
		memcpy(&saved, &resident.check, sizeof(saved));
		runtime.outcome.failure = EFI_UNSUPPORTED;
		resident.check.signature_refused = false;
		resident.check.local_floor_refused = true;
		resident.check.transaction = 0;
		resident.check.attempted_version = 8;
		resident.check.sealed_floor = 9;
#define LOCAL_VALID() certified_ram_check_refusal(&context, &runtime, &input.header, \
	sizeof(input), EFI_UNSUPPORTED)
#define LOCAL_DENY(field, value) do { __typeof__(field) saved_field = (field); \
	(field) = (value); assert(!LOCAL_VALID()); (field) = saved_field; \
	assert(LOCAL_VALID()); } while (0)
		assert(LOCAL_VALID());
		LOCAL_DENY(resident.check.signature_refused, true);
		LOCAL_DENY(resident.check.local_floor_refused, false);
		LOCAL_DENY(resident.check.transaction, 1);
		LOCAL_DENY(resident.check.attempted_version, 9);
		LOCAL_DENY(resident.check.sealed_floor, 8);
		LOCAL_DENY(resident.check.sealed_floor, 0);
		LOCAL_DENY(context.capsule_client.endpoint.lowest_supported_version, 10);
		LOCAL_DENY(resident.check.generation, 6);
		LOCAL_DENY(resident.check.digest[0], resident.check.digest[0] ^ 1);
		LOCAL_DENY(runtime.outcome.set_begun, true);
		LOCAL_DENY(runtime.outcome.unproved, true);
		LOCAL_DENY(runtime.outcome.matching_checks, 2);
		memcpy(&resident.check, &saved, sizeof(saved));
		runtime.outcome.failure = EFI_DEVICE_ERROR;
	}
	{
		struct cdk2_linear_state state;
		struct cdk2_dxe_runtime_services services = {
			.get_time = (void *)report_time_model,
			.get_variable = get_model, .set_variable = set_model,
			.get_next_variable_name = next_model,
		};
		struct cdk2_dxe_system_table system = { .runtime_services = &services };

		for (unsigned int reason = 0; reason < 2; reason++) {
			EFI_STATUS rejected = reason ? EFI_UNSUPPORTED : EFI_DEVICE_ERROR;
			resident.check.signature_refused = !reason;
			resident.check.local_floor_refused = reason;
			resident.check.transaction = reason ? 0 : 37;
			resident.check.attempted_version = reason ? 8 : 0;
			resident.check.sealed_floor = reason ? 9 : 0;
			model_process.failure = rejected;
			for (unsigned int scenario = 0; scenario < 13; scenario++) {
				struct cdk2_system_fmp_client saved = context.capsule_client;
				uint64_t transaction = resident.check.transaction;
				struct cdk2_capsule_header header;

				memcpy(&header, &input.header, sizeof(header));

				cdk2_linear_state_init(&state);
				state.next_phase = CDK2_LINEAR_CAPSULE_RAM;
				state.completed_mask = (1U << state.next_phase) - 1U;
				state.flags |= CDK2_LINEAR_CAPSULE_RESULT_RAM <<
					CDK2_LINEAR_STATE_CAPSULE_SHIFT;
				context.linear_state = &state;
				context.capsule_outcome = CDK2_LINEAR_CAPSULE_RESULT_RAM;
				close_calls = retire_calls = 0;
				pointer_live = true;
				report_live = last_live = false;
				report_error = scenario == 5;
				report_drift = scenario == 6;
				report_padding_drift = scenario == 7;
				header_clock_drift = scenario == 8;
				header_set_drift = scenario == 9;
				header_close_drift = scenario == 10;
				header_retire_drift = scenario == 11;
				header_process_drift = scenario == 12;
				close_error = scenario == 1;
				close_drift = scenario == 2;
				retire_error = scenario == 3;
				retire_drift = scenario == 4;
				EFI_STATUS status = finish_ram_capsule(&system, &runtime, &input.header,
					sizeof(input), 0x1000, &context);

				assert(close_calls == (scenario == 12 ? 0U : 1U));
				assert((status == EFI_SUCCESS) == (scenario == 0));
				assert(retire_calls == (scenario == 1 || scenario == 2 ||
					scenario == 5 || scenario == 6 || scenario == 7 || scenario == 8 ||
					scenario == 9 || scenario == 10 || scenario == 12 ? 0U : 1U));
				if (scenario == 8)
					assert(memcmp(report_data + 8, &header.guid, sizeof(header.guid)) == 0);
				assert(runtime.outcome.failure == rejected);
				assert(!runtime.reset_required);
				if (scenario == 0)
					assert(context.capsule_outcome == CDK2_LINEAR_CAPSULE_RESULT_NONE);
				else
					assert(context.capsule_outcome == CDK2_LINEAR_CAPSULE_RESULT_RAM);
				assert(cdk2_linear_capsule_outcome(&state) == context.capsule_outcome);
				context.capsule_client = saved;
				resident.check.transaction = transaction;
				((uint8_t *)&resident.check)[sizeof(resident.check) - 1] = 0xa5;
				memcpy(&input.header, &header, sizeof(header));
				runtime.outcome = model_process;
			}
		}
	}
	free(core.memory.base);
	return 0;
}
