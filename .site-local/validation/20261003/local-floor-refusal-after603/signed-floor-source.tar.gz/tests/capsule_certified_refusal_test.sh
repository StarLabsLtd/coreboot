#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
config=${1:?actual selected config header required}
output=$(mktemp -d "${TMPDIR:-/tmp}/capsule-certified-refusal.XXXXXX")
printf 'Certified refusal HOST artifacts: %s\n' "$output"
mkdir -p "$output/cdk2"
cp "$config" "$output/cdk2/config.h"
grep -qx '#define CONFIG_CDK2_COREBOOT_CAPSULE_PROFILE 1' "$config"
grep -qx '#define CONFIG_CDK2_NATIVE_SYSTEM_FMP 1' "$config"
sha256sum "$root/src/modules/dxe_core/entry.c" \
	"$root/src/modules/system_fmp/provider.c" \
	"$root/src/modules/capsule_runtime/entry.c" \
	"$root/tests/capsule_certified_refusal_core_test.c" \
	"$root/tests/system_fmp_provider_test.c" \
	"$root/tests/capsule_runtime_entry_test.c" \
	"$root/tests/capsule_certified_refusal_test.sh" "$config" \
	"$root/include/cdk2/capsule_check_outcome.h" "$root/include/cdk2/capsule_boot.h" \
	"$root/include/cdk2/system_fmp_provider.h" "$root/include/cdk2/system_fmp_session.h" \
	"$root/include/cdk2/system_fmp_transport.h" \
	"$root/include/cdk2/dxe_core.h" "$root/include/cdk2/dxe_image_transaction.h" \
	"$root/include/cdk2/software_hash.h" \
	"$root/src/modules/dxe_core/image.c" "$root/src/modules/dxe_core/memory.c" \
	"$root/src/lib/tcg_hash/software_hash.c" \
	"$root/src/lib/tcg_hash/vendor/vboot/2sha1.c" \
	"$root/src/lib/tcg_hash/vendor/vboot/2sha256.c" \
	"$root/src/lib/tcg_hash/vendor/vboot/2sha512.c" \
	"$root/src/lib/tcg_hash/vendor/linux/lib/crypto/sm3.c" \
	"$root/src/modules/system_fmp/transport.c" \
	"$root/src/lib/diagnostic.c" "$root/src/lib/deadline.c" \
	"$root/src/lib/boot_logo.c" "$root/src/modules/authvar_transport/native_x86.c" \
	"$root/include/cdk2/linear_boot.h" "$root/src/lib/linear_boot.c" \
	"$root/include/cdk2/capsule_report.h" "$root/src/lib/capsule_report.c" \
	"$root/tests/capsule_report_test.c" \
	"$root/src/modules/capsule_runtime/capsule_runtime.c" \
	"$root/src/modules/capsule_runtime/capsule_runtime_abi.c" > "$output/inputs-before.sha256"
export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
ulimit -c 0
core_source=$root/src/modules/dxe_core/entry.c
sanitizers='-fsanitize=address,undefined -fno-sanitize-recover=all --param asan-globals=0'

compile_core()
{
	# Keep actual heap/stack instrumentation; unrelated boot callback tables
	# must not become GC roots solely through ASan's global registration.
	"${HOSTCC:-cc}" "$optimization" -g -std=gnu11 -fshort-wchar \
		-Wall -Wextra -Werror -ffunction-sections -fdata-sections -fno-merge-constants \
		-fno-pie -no-pie $sanitizers \
		-DCDK2_HOST_TEST -I"$output" -I"$root/include" -I"$root/src/modules/dxe_core" \
		-DCDK2_CERTIFIED_CORE_SOURCE=\""$core_source"\" \
		-I"$root/src/lib/tcg_hash/vendor/vboot" \
		-I"$root/src/lib/tcg_hash/vendor/linux/include" \
		"$root/tests/capsule_certified_refusal_core_test.c" \
		"$root/src/modules/dxe_core/image.c" "$root/src/modules/dxe_core/memory.c" \
		"$root/src/lib/tcg_hash/software_hash.c" \
		"$root/src/lib/tcg_hash/vendor/vboot/2sha1.c" \
		"$root/src/lib/tcg_hash/vendor/vboot/2sha256.c" \
		"$root/src/lib/tcg_hash/vendor/vboot/2sha512.c" \
		"$root/src/lib/tcg_hash/vendor/linux/lib/crypto/sm3.c" \
		"$root/src/modules/system_fmp/transport.c" \
		"$root/src/lib/diagnostic.c" "$root/src/lib/deadline.c" \
		"$root/src/lib/boot_logo.c" "$root/src/modules/authvar_transport/native_x86.c" \
		"$root/src/lib/linear_boot.c" \
		"$root/src/lib/capsule_report.c" \
		-Wl,--gc-sections -o "$output/core"
}

for optimization in -O0 -O2; do
	"${HOSTCC:-cc}" "$optimization" -g -fshort-wchar -Wall -Wextra -Werror \
		-fno-pie -no-pie -fsanitize=address,undefined -fno-sanitize-recover=all \
		-I"$root/include" "$root/tests/capsule_report_test.c" \
		"$root/src/lib/capsule_report.c" -o "$output/report"
	"$output/report"
	compile_core
	"$output/core"
	"${HOSTCC:-cc}" "$optimization" -g -fshort-wchar -Wall -Wextra -Werror \
		-fno-pie -no-pie -fsanitize=address,undefined -fno-sanitize-recover=all \
		-I"$output" -I"$root/include" "$root/tests/system_fmp_provider_test.c" \
		"$root/src/modules/system_fmp/provider.c" -o "$output/provider"
	"$output/provider"
	"${HOSTCC:-cc}" "$optimization" -g -fshort-wchar -Wall -Wextra -Werror \
		-fno-pie -no-pie -fsanitize=address,undefined -fno-sanitize-recover=all \
		-D_GNU_SOURCE -DCDK2_CAPSULE_ENTRY_TEST -DCDK2_DEBUG -DCDK2_DIAGNOSTIC \
		-DCDK2_DIAG_RUNTIME_TRANSITION_TEST -I"$output" -I"$root/include" \
		"$root/tests/capsule_runtime_entry_test.c" \
		"$root/src/modules/capsule_runtime/entry.c" \
		"$root/src/modules/capsule_runtime/capsule_runtime.c" \
		"$root/src/modules/capsule_runtime/capsule_runtime_abi.c" \
		"$root/src/lib/diagnostic.c" -o "$output/runtime"
	"$output/runtime"
done
optimization=-O2
sanitizers=
for cause in aggregate generation signature digest completion header \
	localreason localtransaction localfloor; do
	assertion='!VALID()'
	case "$cause" in
	aggregate)
		needle='process.unproved || '
		replacement='(process.unproved && false) || '
		expected='REFUSE(runtime.outcome.unproved, true);'
		;;
	generation)
		needle='check.generation != context->capsule_client.endpoint.generation'
		replacement='(check.generation != context->capsule_client.endpoint.generation && false)'
		expected='REFUSE(resident.check.generation, 6);'
		;;
	signature)
		needle='!check.signature_refused || '
		replacement='(!check.signature_refused && false) || '
		expected='REFUSE(resident.check.signature_refused, false);'
		;;
	digest)
		needle='memcmp(digest, check.digest, sizeof(digest)) != 0'
		replacement='(memcmp(digest, check.digest, sizeof(digest)) != 0 && false)'
		expected='REFUSE(resident.check.digest[0], resident.check.digest[0] ^ 1);'
		;;
	completion)
		needle='status = cdk2_linear_capsule_finalize_ram(context->linear_state,
			&context->capsule_outcome);'
		replacement='status = (EFI_STATUS)0 /* RAM completion discarded */;'
		expected='assert(context.capsule_outcome == CDK2_LINEAR_CAPSULE_RESULT_NONE);'
		assertion='context.capsule_outcome == CDK2_LINEAR_CAPSULE_RESULT_NONE'
		;;
	header)
		needle='memcmp(&header, capsule, sizeof(header)) == 0'
		replacement='(memcmp(&header, capsule, sizeof(header)) == 0 || true)'
		expected='assert(close_calls == (scenario == 12 ? 0U : 1U));'
		assertion='close_calls == (scenario == 12 ? 0U : 1U)'
		;;
	localreason)
		needle='!check.local_floor_refused'
		replacement='(!check.local_floor_refused && false)'
		expected='LOCAL_DENY(resident.check.local_floor_refused, false);'
		assertion='!LOCAL_VALID()'
		;;
	localtransaction)
		needle='check.transaction != 0U'
		replacement='(check.transaction != 0U && false)'
		expected='LOCAL_DENY(resident.check.transaction, 1);'
		assertion='!LOCAL_VALID()'
		;;
	localfloor)
		needle='check.attempted_version >= check.sealed_floor'
		replacement='(check.attempted_version >= check.sealed_floor && false)'
		expected='LOCAL_DENY(resident.check.attempted_version, 9);'
		assertion='!LOCAL_VALID()'
		;;
	esac
	core_source=$output/$cause.c
	NEEDLE="$needle" REPLACEMENT="$replacement" perl -0pe '
		BEGIN { $needle=$ENV{NEEDLE}; $replacement=$ENV{REPLACEMENT}; }
		$count=s/\Q$needle\E/$replacement/g;
		END { die "guard count must equal one\n" unless $count == 1; }
	' "$root/src/modules/dxe_core/entry.c" > "$core_source"
	NEEDLE="$replacement" REPLACEMENT="$needle" perl -0pe '
		BEGIN { $needle=$ENV{NEEDLE}; $replacement=$ENV{REPLACEMENT}; }
		$count=s/\Q$needle\E/$replacement/g;
		END { die "inverse count must equal one\n" unless $count == 1; }
	' "$core_source" > "$output/restored.c"
	cmp "$root/src/modules/dxe_core/entry.c" "$output/restored.c"
	compile_core
	status=0
	"$output/core" > "$output/$cause.log" 2>&1 || status=$?
	test "$status" = 134
	line=$(awk -v expected="$expected" 'index($0, expected) { count++; line=NR }
		END { if (count != 1) exit 1; print line }' \
		"$root/tests/capsule_certified_refusal_core_test.c")
	grep -F "capsule_certified_refusal_core_test.c:$line: main: Assertion \`$assertion' failed" \
		"$output/$cause.log"
	! grep -Eq 'AddressSanitizer|LeakSanitizer|runtime error:' "$output/$cause.log"
done
sha256sum -c "$output/inputs-before.sha256"
