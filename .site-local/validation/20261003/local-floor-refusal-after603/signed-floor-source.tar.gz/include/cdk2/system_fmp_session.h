/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef CDK2_SYSTEM_FMP_SESSION_H
#define CDK2_SYSTEM_FMP_SESSION_H

#include <cdk2/system_fmp_board_binding.h>
#include <cdk2/system_fmp_handoff.h>
#include <cdk2/system_fmp_payload.h>
#include <cdk2/system_fmp_transport.h>

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <uefi.h>

struct cdk2_coreboot_handoff;
/* Keep this ABI bound aligned with coreboot Payload-MM trust-XDR policy. */
#define CDK2_SYSTEM_FMP_CERTIFICATE_MAX_SIZE (256U * 1024U)
#define CDK2_SYSTEM_FMP_DEPENDENCY_MAX_COUNT 32U

enum cdk2_system_fmp_session_operation {
	CDK2_SYSTEM_FMP_SESSION_CHECK = 1,
	CDK2_SYSTEM_FMP_SESSION_SET = 2,
};

struct cdk2_system_fmp_session_config {
	const struct cdk2_coreboot_handoff *coreboot;
	const void *certificate_xdr;
	size_t certificate_xdr_size;
	const struct cdk2_system_fmp_dependency_version *dependency_versions;
	size_t dependency_version_count;
	struct cdk2_system_fmp_transport_port transport_port;
};

struct cdk2_system_fmp_session {
	struct cdk2_system_fmp_client client;
	struct cdk2_system_fmp_transport endpoint;
	struct cdk2_system_fmp_info info;
	struct cdk2_system_fmp_info sealed_info;
	struct cdk2_system_fmp_board_identity board_identity;
	struct cdk2_system_fmp_handoff authenticated_handoff;
	uint8_t certificate_xdr[CDK2_SYSTEM_FMP_CERTIFICATE_MAX_SIZE];
	struct cdk2_system_fmp_dependency_version
		dependency_versions[CDK2_SYSTEM_FMP_DEPENDENCY_MAX_COUNT];
	uint8_t certificate_digest[CDK2_SYSTEM_FMP_DIGEST_SIZE];
	uint8_t dependency_digest[CDK2_SYSTEM_FMP_DIGEST_SIZE];
	uint8_t board_identity_digest[CDK2_SYSTEM_FMP_DIGEST_SIZE];
	uint8_t endpoint_digest[CDK2_SYSTEM_FMP_DIGEST_SIZE];
	uint8_t handoff_digest[CDK2_SYSTEM_FMP_DIGEST_SIZE];
	struct cdk2_system_fmp_transport_port sealed_transport_port;
	size_t certificate_xdr_size;
	size_t dependency_version_count;
	bool initialized;
	bool ready;
	bool active;
	bool set_attempted;
};

struct cdk2_system_fmp_session_request {
	enum cdk2_system_fmp_session_operation operation;
	const EFI_GUID *image_type;
	uint8_t image_index;
	const void *authenticated_image;
	size_t authenticated_image_size;
};

struct cdk2_system_fmp_session_result {
	uint32_t image_updatable;
	uint32_t last_attempt_status;
	uint32_t attempted_version;
	enum cdk2_system_fmp_transport_status transport_status;
	bool transport_invoked;
	bool trigger_invoked;
	bool broker_response_authenticated;
	uint64_t broker_transaction;
	uint64_t broker_generation;
	uint8_t input_digest[CDK2_SYSTEM_FMP_DIGEST_SIZE];
	bool signature_refused;
	/* Local policy decision, not a CMS or MM authentication result. */
	bool local_floor_refused;
	uint32_t sealed_floor;
};

/*
 * Initialize one zero-initialized dormant source-neutral owner in persistent,
 * non-stack storage. The endpoint comes only from CBTABLES; READ_INFO provides
 * authoritative live confirmation and broker-owned state.
 */
EFI_STATUS cdk2_system_fmp_session_initialize(
	struct cdk2_system_fmp_session *session,
	const struct cdk2_system_fmp_session_config *config);

/*
 * CHECK is repeatable. The first structurally valid SET attempt is terminal.
 * A safely separate result is initialized on every call. If session, request,
 * result or input spans are invalid or alias, result is deliberately untouched.
 */
EFI_STATUS cdk2_system_fmp_session_execute(
	struct cdk2_system_fmp_session *session,
	const struct cdk2_system_fmp_session_request *request,
	struct cdk2_system_fmp_session_result *result);

/* A failed scrub may be retried; success closes and clears the whole owner. */
EFI_STATUS cdk2_system_fmp_session_close(
	struct cdk2_system_fmp_session *session);

#endif
