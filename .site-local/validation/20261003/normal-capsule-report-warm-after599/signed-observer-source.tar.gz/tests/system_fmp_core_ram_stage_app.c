/* SPDX-License-Identifier: GPL-2.0-only */

/* Late, normally loaded EFI diagnostic; never a provider or MM authority. */
#include <cdk2/capsule_runtime_entry.h>
#include <cdk2/capsule_runtime.h>
#include <cdk2/reset_system.h>
#include <cdk2/system_fmp_provider.h>
#if defined(CDK2_CORE_RAM_CERTIFIED_REFUSAL)
#include <cdk2/coreboot_hob.h>
#include "../src/boot/coreboot.h"
#include <string.h>
#endif
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#if defined(CDK2_CORE_RAM_CAPSULE_REPORT)
#include <cdk2/capsule_report.h>
#include <cdk2/esrt.h>
#if !defined(CDK2_CORE_RAM_CERTIFIED_REFUSAL)
#error "capsule result observer requires certified refusal continuation"
#endif
#endif

#ifndef CDK2_CORE_RAM_ATTEMPT
#define CDK2_CORE_RAM_ATTEMPT 0x001a000aU
#endif
#ifndef CDK2_CORE_RAM_TARGET_RUNNING
#define CDK2_CORE_RAM_TARGET_RUNNING 0x001a000aU
#endif
#ifndef CDK2_CORE_RAM_PRIOR_RUNNING
#define CDK2_CORE_RAM_PRIOR_RUNNING 0x001a0009U
#endif
#ifndef CDK2_CORE_RAM_PRIOR_HISTORY
#define CDK2_CORE_RAM_PRIOR_HISTORY 0U
#endif

extern const uint8_t _binary_signed_capsule_bin_start[];
extern const uint8_t _binary_signed_capsule_bin_end[];

typedef EFI_STATUS CDK2_MS_ABI allocate_pages_fn(UINT32, UINT32, UINTN, UINT64 *);
typedef EFI_STATUS CDK2_MS_ABI free_pages_fn(UINT64, UINTN);
typedef EFI_STATUS CDK2_MS_ABI locate_protocol_fn(const EFI_GUID *, void *, void **);
typedef EFI_STATUS CDK2_MS_ABI get_variable_fn(CHAR16 *, const EFI_GUID *,
	UINT32 *, UINTN *, void *);
#if defined(CDK2_CORE_RAM_CAPSULE_REPORT)
typedef EFI_STATUS CDK2_MS_ABI set_variable_fn(CHAR16 *, const EFI_GUID *,
	UINT32, UINTN, void *);
#endif
typedef EFI_STATUS CDK2_MS_ABI query_capsule_fn(
	const struct cdk2_capsule_header *const *, UINTN, UINT64 *, UINT32 *);
typedef EFI_STATUS CDK2_MS_ABI update_capsule_fn(
	const struct cdk2_capsule_header *const *, UINTN, UINT64);

struct scatter {
	uint64_t length;
	uint64_t address;
};

static const EFI_GUID global_guid = {
	0x8be4df61, 0x93ca, 0x11d2,
	{ 0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c },
};
static const EFI_GUID fmp_guid = {
	0x86c77a67, 0x0b97, 0x4633,
	{ 0xa1, 0x87, 0x49, 0x10, 0x4d, 0x06, 0x85, 0xc7 },
};
static CHAR16 setup_name[] = { 'S', 'e', 't', 'u', 'p', 'M', 'o', 'd', 'e', 0 };
static CHAR16 secure_name[] = { 'S', 'e', 'c', 'u', 'r', 'e', 'B', 'o', 'o', 't', 0 };
static CHAR16 state_name[] = { 'F', 'm', 'p', 'S', 't', 'a', 't', 'e', 0 };

static void marker(const char *text)
{
	while (*text != '\0') {
		__asm__ volatile("outb %0, %1" : : "a"((uint8_t)*text), "Nd"((uint16_t)0x3f8U));
		text++;
	}
}

static void fail(void)
{
	marker("CDK2_CORE_RAM_STAGE_FAIL\r\n");
	__asm__ volatile("outl %0, %1" : : "a"(2U), "Nd"((uint16_t)0xf4U));
	for (;;)
		__asm__ volatile("cli; hlt");
}

static bool state_matches(const struct cdk2_fmp_descriptor *descriptor,
	const uint32_t state[5], uint32_t running, uint32_t history)
{
	if (descriptor->version != running ||
	    descriptor->lowest_supported_version != 0x001a0009U ||
	    descriptor->last_attempt_version != history ||
	    descriptor->last_attempt_status != 0U)
		return false;
	if (history == 0U) {
		for (size_t index = 0; index < 5; index++)
			if (state[index] != 0U)
				return false;
		return true;
	}
	return state[0] == 0x01010101U && state[1] == history &&
		state[2] == 0x001a0009U && state[3] == 0U && state[4] == history;
}

EFI_STATUS CDK2_MS_ABI system_fmp_core_ram_stage_entry(void *image,
	struct cdk2_system_table_view *system)
{
	const struct cdk2_capsule_header *capsules[1];
	const struct cdk2_capsule_header *embedded;
	struct cdk2_fmp_descriptor descriptor;
	struct cdk2_fmp_protocol *fmp = NULL;
	struct scatter *scatter;
	allocate_pages_fn *allocate;
	free_pages_fn *release;
	locate_protocol_fn *locate;
	get_variable_fn *get;
	query_capsule_fn *query;
	update_capsule_fn *update;
	uint8_t *payload;
	uint8_t setup = 0U, secure = 1U, count = 0U;
	uint32_t state[5] = {0};
	UINT32 attributes = 0U, descriptor_version = 0U, package_version = 0U;
	UINT32 reset_type = UINT32_MAX;
	UINTN variable_size = 1U, info_size = sizeof(descriptor), descriptor_size = 0U;
	CHAR16 *package_name = NULL;
	UINT64 address = 0U, maximum = 0U;
	uintptr_t start, end;
	size_t size, pages;
	EFI_STATUS status;

	(void)image;
	marker("CDK2_CORE_RAM_STAGE_MAIN_ENTRY\r\n");
	if (system == NULL || system->boot == NULL || system->runtime == NULL)
		fail();
	allocate = system->boot->allocate_pages;
	release = system->boot->free_pages;
	locate = system->boot->locate_protocol;
	get = system->runtime->get_variable;
	query = system->runtime->query_capsule;
	update = system->runtime->update_capsule;
	if (allocate == NULL || release == NULL || locate == NULL || get == NULL ||
	    query == NULL || update == NULL)
		fail();
	if (get(setup_name, &global_guid, &attributes, &variable_size, &setup) != EFI_SUCCESS ||
	    variable_size != 1U || setup != 1U)
		fail();
	variable_size = 1U;
	if (get(secure_name, &global_guid, &attributes, &variable_size, &secure) != EFI_SUCCESS ||
	    variable_size != 1U || secure != 0U)
		fail();
	marker("CDK2_CORE_RAM_STAGE_SETUP1_SECURE0\r\n");
	if (locate(&fmp_guid, NULL, (void **)&fmp) != EFI_SUCCESS ||
	    fmp == NULL || fmp->get_image_info == NULL)
		fail();
	status = fmp->get_image_info(fmp, &info_size, &descriptor, &descriptor_version,
		&count, &descriptor_size, &package_version, &package_name);
	if (status != EFI_SUCCESS || count != 1U || descriptor_size != sizeof(descriptor) ||
	    descriptor.lowest_supported_version !=
		0x001a0009U || descriptor.size != 8U * 1024U * 1024U ||
	    (descriptor.attributes_setting & CDK2_SYSTEM_FMP_AUTHENTICATION_REQUIRED) == 0U)
		fail();
	marker("CDK2_CORE_RAM_STAGE_REAL_SYSTEM_FMP_INFO\r\n");
	variable_size = sizeof(state);
	if (get(state_name, &descriptor.image_type_id, &attributes, &variable_size,
	    state) != EFI_SUCCESS || attributes != 3U || variable_size != sizeof(state))
		fail();
	if (descriptor.version == CDK2_CORE_RAM_TARGET_RUNNING) {
		if (!state_matches(&descriptor, state, CDK2_CORE_RAM_TARGET_RUNNING,
		    CDK2_CORE_RAM_ATTEMPT))
			fail();
		marker("CDK2_CORE_RAM_ACTUAL_NORMAL_CORE_COLD_RUNNING_AND_HISTORY_PASS\r\n");
		__asm__ volatile("outl %0, %1" : : "a"(1U), "Nd"((uint16_t)0xf4U));
		for (;;)
			__asm__ volatile("cli; hlt");
	}
	if (!state_matches(&descriptor, state, CDK2_CORE_RAM_PRIOR_RUNNING,
	    CDK2_CORE_RAM_PRIOR_HISTORY))
		fail();
#if defined(CDK2_CORE_RAM_CAPSULE_REPORT)
	{
		static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
		CHAR16 maximum[11];
		set_variable_fn *set = system->runtime->set_variable;

		variable_size = sizeof(maximum);
		if (set == NULL || get(L"CapsuleMax", &report_guid, &attributes,
		    &variable_size, maximum) != EFI_SUCCESS || attributes != 6 ||
		    variable_size != sizeof(maximum) || memcmp(maximum, L"Capsuleffff", 22) ||
		    set(L"CapsuleMax", &report_guid, 6, sizeof(maximum), maximum) !=
			EFI_WRITE_PROTECTED)
			fail();
	}
#endif
#if defined(CDK2_CORE_RAM_CERTIFIED_REFUSAL)
	{
		static const EFI_GUID hob_guid = { 0x7739f24c, 0x93d7, 0x11d4,
			{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
		static const EFI_GUID capsule_guid = { 0x711c703f, 0xc285, 0x4b10,
			{ 0xa3, 0xb0, 0x36, 0xec, 0xbd, 0x3c, 0x8b, 0xe2 } };
		static CHAR16 request_name[] = L"CapsuleUpdateData";
		struct configuration_table { EFI_GUID guid; void *table; };
		const struct configuration_table *tables = system->configuration_table;
		const void *hob_list = NULL, *record = NULL;
		struct cdk2_coreboot_handoff handoff;
		uint64_t request;

		if (system->table_entries > 256 || tables == NULL ||
		    (uintptr_t)tables % _Alignof(*tables) ||
		    (uintptr_t)tables > UINTPTR_MAX - system->table_entries * sizeof(*tables))
			fail();
		for (size_t index = 0; index < system->table_entries; index++) {
			if (memcmp(&tables[index].guid, &hob_guid, sizeof(hob_guid)))
				continue;
			if (hob_list != NULL || tables[index].table == NULL)
				fail();
			hob_list = tables[index].table;
		}
		if (EFI_ERROR(cdk2_coreboot_handoff_from_hobs(hob_list, &handoff)))
			fail();
		status = cdk2_coreboot_find_unique_record(&handoff, CB_TAG_CAPSULE,
			sizeof(struct cb_range), &record);
		if (status == EFI_SUCCESS) {
			const struct cb_range *capsule = record;
			uintptr_t address = capsule->range_start;
			size_t retained_size = capsule->range_size;
			bool mapped = false;

			start = (uintptr_t)_binary_signed_capsule_bin_start;
			end = (uintptr_t)_binary_signed_capsule_bin_end;
			if (capsule->size != sizeof(*capsule) || end <= start ||
			    retained_size != end - start || address == 0 ||
			    capsule->range_start > UINTPTR_MAX || address > UINTPTR_MAX - retained_size)
				fail();
			for (size_t index = 0; index < handoff.memory_range_count; index++) {
				const struct cdk2_coreboot_memory_range *range = &handoff.memory_ranges[index];

				if ((range->type == CB_MEM_RAM || range->type == CB_MEM_RESERVED) &&
				    address >= range->base && address - range->base <= range->size &&
				    retained_size <= range->size - (address - range->base))
					mapped = true;
			}
			if (!mapped || memcmp((const void *)address, (const void *)start, retained_size))
				fail();
			variable_size = sizeof(request);
			if (get(request_name, &capsule_guid, &attributes, &variable_size, &request) != EFI_NOT_FOUND)
				fail();
#if defined(CDK2_CORE_RAM_CAPSULE_REPORT)
			{
				static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
				CHAR16 last[12] = { 0 };
				uint8_t report[CDK2_CAPSULE_REPORT_FMP_SIZE];
				uint32_t total, reserved;
				uint64_t failure;

				variable_size = 22;
				if (get(L"CapsuleLast", &report_guid, &attributes, &variable_size,
				    last) != EFI_SUCCESS || attributes != 7 || variable_size != 22 ||
				    memcmp(last, L"Capsule0000", 22))
					fail();
				variable_size = sizeof(report);
				if (get(last, &report_guid, &attributes, &variable_size, report) !=
				    EFI_SUCCESS || attributes != 7 || variable_size != sizeof(report))
					fail();
				memcpy(&total, report, sizeof(total));
				memcpy(&reserved, report + 4, sizeof(reserved));
				memcpy(&failure, report + 40, sizeof(failure));
				if (total != sizeof(report) || reserved != 0 ||
				    memcmp(report + 8, &_binary_signed_capsule_bin_start[0], 16) ||
				    failure != EFI_DEVICE_ERROR || report[48] != 1 || report[49] != 0 ||
				    report[50] != 0 || report[51] != descriptor.image_index ||
				    memcmp(report + 52, &descriptor.image_type_id, 16) ||
				    memcmp(report + 68, "\0\0\0\0", 4))
					fail();
				marker("CDK2_CORE_RAM_STANDARD_CAPSULE_REPORT_MAIN_PASS\r\n");
			}
#endif
			marker("CDK2_CORE_RAM_CERTIFIED_REFUSAL_CONTINUED_MAIN_PASS\r\n");
			__asm__ volatile("outl %0, %1" : : "a"(1U), "Nd"((uint16_t)0xf4U));
			for (;;)
				__asm__ volatile("cli; hlt");
		} else if (status != EFI_NOT_FOUND) {
			fail();
		}
	}
#endif
#if defined(CDK2_CORE_RAM_CAPSULE_REPORT)
	{
		static const EFI_GUID report_guid = CDK2_CAPSULE_REPORT_GUID;
		CHAR16 last[12];

		variable_size = sizeof(last);
		if (get(L"CapsuleLast", &report_guid, &attributes, &variable_size, last) !=
		    EFI_NOT_FOUND)
			fail();
	}
#endif
	if (CDK2_CORE_RAM_PRIOR_HISTORY == 0U)
		marker("CDK2_CORE_RAM_STAGE_ACTUAL_INITIAL_ZERO_STATE\r\n");
	else
		marker("CDK2_CORE_RAM_STAGE_ACTUAL_PRIOR_SUCCESS_STATE\r\n");
	start = (uintptr_t)_binary_signed_capsule_bin_start;
	end = (uintptr_t)_binary_signed_capsule_bin_end;
	if (end <= start)
		fail();
	size = end - start;
	if (size <= sizeof(struct cdk2_capsule_header) ||
	    size > SIZE_MAX - sizeof(struct scatter) * 2U - 4095U)
		fail();
	embedded = (const void *)start;
	if (embedded->header_size != sizeof(*embedded) ||
	    embedded->image_size != size ||
	    embedded->flags != (CDK2_CAPSULE_PERSIST | CDK2_CAPSULE_RESET))
		fail();
	pages = (size + sizeof(struct scatter) * 2U + 4095U) / 4096U;
	status = allocate(0U, 0U, pages, &address); /* AnyPages, ReservedMemory. */
	if (status != EFI_SUCCESS || address == 0U ||
	    address > UINTPTR_MAX - pages * 4096U)
		fail();
	scatter = (void *)(uintptr_t)address;
	payload = (void *)(scatter + 2U);
	for (size_t index = 0U; index < size; index++)
		payload[index] = _binary_signed_capsule_bin_start[index];
	scatter[0] = (struct scatter) { .length = size, .address = (uintptr_t)payload };
	scatter[1] = (struct scatter) {0};
	capsules[0] = (const void *)payload;
	status = query(capsules, 1U, &maximum, &reset_type);
	if (status != EFI_SUCCESS || maximum < size || reset_type != cdk2_reset_warm) {
		(void)release(address, pages);
		fail();
	}
	marker("CDK2_CORE_RAM_STAGE_QUERY_STRUCTURAL_ONLY\r\n");
	marker("CDK2_CORE_RAM_STAGE_UPDATE_CAPSULE_RESET\r\n");
	/* INITIATE_RESET must transition through the real installed runtime service.
	 * Returning is not success; do not substitute a direct reset or free retained
	 * pages after a successful call.
	 */
	status = update(capsules, 1U, address);
	if (EFI_ERROR(status))
		(void)release(address, pages);
	fail();
	return EFI_ABORTED;
}
