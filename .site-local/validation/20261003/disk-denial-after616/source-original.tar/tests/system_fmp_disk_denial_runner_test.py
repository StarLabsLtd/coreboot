# SPDX-License-Identifier: GPL-2.0-only
"""Modeled HOST disk observation boundaries; no guest authority."""

import struct
import unittest
import uuid

from system_fmp_disk_denial_native_test import observation
from qmp_cbmem_console import checksum


def table(disk=2, version=0x001a0009, reserved=0, capsule=False):
    firmware = struct.pack("<II", 0x45, 36) + \
        uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le + \
        struct.pack("<III", version, 0x001a0009, 8388608)
    policy = struct.pack("<IIHHIQQQ", 0x59, 40, 1, 40, disk, 0x4000000, 0, reserved)
    body = firmware + policy
    if capsule:
        body += struct.pack("<IIQI", 0x46, 20, 0x100000, 8192)
    header = struct.pack("<4sIIIII", b"LBIO", 24, 0, len(body), checksum(body),
                         3 if capsule else 2)
    header = header[:8] + struct.pack("<I", checksum(header)) + header[12:]
    return header + body


BODY = b"\n".join((b"CDK2 | CAPSULE_RAM | end SUCCESS", b"CDK2 | PCI_ROOTS | begin",
                   b"CDK2 | CAPSULE_DISK | begin",
                   b"CDK2 | module 0x02 | SystemFmp CHECK transport | 0x0000000000000008",
                   b"CDK2 | CAPSULE_DISK | end SUCCESS"))


class DiskObservation(unittest.TestCase):
    def test_actual_enum_not_assumed_closed(self):
        result = observation(BODY, [table()])
        self.assertEqual(result["transport"], 8)
        self.assertEqual(result["transport_name"], "BAD_RESPONSE")

    def test_failed_phase_is_recorded_not_success_inferred(self):
        body = BODY.replace(b"end SUCCESS", b"failed COMPROMISED_DATA", 2)
        # Keep the actual successful RAM completion, change disk only.
        body = body.replace(b"CAPSULE_RAM | failed COMPROMISED_DATA",
                            b"CAPSULE_RAM | end SUCCESS")
        self.assertIn("failed", observation(body, [table()])["phase_result"])

    def test_single_known_denied_check_only(self):
        for body in (BODY.replace(b"0000000000000008", b"0000000000000000"),
                     BODY.replace(b"0000000000000008", b"ffffffffffffffff"),
                     BODY + b"\nSystemFmp SET transport", BODY + b"\n" + BODY,
                     BODY.replace(b"CHECK", b"SET")):
            with self.assertRaises(ValueError):
                observation(body, [table()])

    def test_ram_completion_before_pci_before_disk(self):
        for body in (BODY.replace(b"CAPSULE_RAM | end SUCCESS", b"CAPSULE_RAM | begin"),
                     BODY.replace(b"PCI_ROOTS | begin", b"PCI_ROOTS | absent"),
                     BODY.replace(b"CAPSULE_DISK | begin", b"CAPSULE_DISK | absent")):
            with self.assertRaises(ValueError):
                observation(body, [table()])

    def test_exact_current_firmware_and_delivery_table(self):
        for data in (table(disk=0), table(disk=6), table(version=0x001a000a),
                     table(reserved=1), table(capsule=True), table()[:-1]):
            with self.assertRaises(ValueError):
                observation(BODY, [data])

    def test_phase_completion_required(self):
        with self.assertRaises(ValueError):
            observation(BODY.rsplit(b"\n", 1)[0], [table()])


if __name__ == "__main__":
    unittest.main()
