# SPDX-License-Identifier: GPL-2.0-only
"""HOST observation of the missing late DISK writer; never guest authority."""

import argparse
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import time
import uuid
from pathlib import Path

from system_fmp_core_ram_native_test import Qmp, digest, loads, save, check_refusal_media

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "util/qemu/bin"))
from qmp_cbmem_console import ConsoleReader, TableNotReady, console_bytes, parse_table
from qmp_cbmem_console import validate_saved_console

TRANSPORT = ("SUCCESS", "INVALID", "CLOSED", "BUSY", "CAPACITY", "HASH_FAILED",
             "CACHE_FAILED", "TRIGGER_FAILED", "BAD_RESPONSE", "EXECUTION_FAILED",
             "SIGNATURE_REFUSED")
CHECK = rb"CDK2 \| module 0x02 \| SystemFmp CHECK transport \| 0x([0-9a-f]{16})"


def observation(body, tables):
    """A current ordinary storage epoch and exactly one actual denied CHECK."""
    records = parse_table(tables[-1])
    firmware = [record for tag, record in records if tag == 0x45]
    policies = [record for tag, record in records if tag == 0x59]
    if len(firmware) != 1 or len(firmware[0]) != 36 or \
            firmware[0][8:24] != uuid.UUID("00112233-4455-6677-8899-aabbccddeeff").bytes_le or \
            struct.unpack_from("<III", firmware[0], 24) != (0x001a0009, 0x001a0009, 8388608):
        raise ValueError("actual firmware identity differs from pristine9")
    if len(policies) != 1 or len(policies[0]) != 40:
        raise ValueError("unique actual delivery policy required")
    revision, width, transports, maximum, populate, reserved = \
        struct.unpack_from("<HHIQQQ", policies[0], 8)
    if revision != 1 or width != 40 or not transports & 2 or transports & ~3 or \
            maximum < 8388608 or reserved:
        raise ValueError("actual disk-delivery capability absent or malformed")
    if any(tag == 0x46 for tag, record in records):
        raise ValueError("DISK fixture must not use retained RAM delivery")
    ram = body.find(b"CDK2 | CAPSULE_RAM | end SUCCESS")
    pci = body.find(b"CDK2 | PCI_ROOTS | begin")
    disk = body.find(b"CDK2 | CAPSULE_DISK | begin")
    checks = list(re.finditer(CHECK, body))
    if len(checks) != 1 or not 0 <= ram < pci < disk < checks[0].start() or \
            b"SystemFmp SET transport" in body:
        raise ValueError("ordinary late single-CHECK/no-SET ordering rejected")
    result = int(checks[0][1], 16)
    if not 0 < result < len(TRANSPORT):
        raise ValueError("actual transport result is not a known denial")
    endings = [line for line in body[checks[0].end():].splitlines()
               if line.startswith(b"CDK2 | CAPSULE_DISK | ") and
               (b"end " in line or b"failed" in line)]
    if len(endings) != 1:
        raise ValueError("actual disk phase completion not yet uniquely observed")
    return {"transport": result, "transport_name": TRANSPORT[result],
            "phase_result": endings[0].decode("ascii"),
            "authority": "observed late CHECK denial; positive DISK admission not demonstrated"}


def ecam(qmp, output, name):
    """Bounded known-Q35 reads only; these command bits are not a drain proof."""
    sample = {}
    for device, label in ((3, "nvme"), (4, "xhci"), (5, "edu")):
        address = 0xb0000000 + (device << 15)
        path = output / f"{name}-{label}-config.bin"
        reply = qmp({"execute": "pmemsave", "arguments": {
            "val": address, "size": 8, "filename": str(path)}})
        if "error" in reply:
            raise ValueError("known-Q35 ECAM observation failed")
        data = path.read_bytes()
        if len(data) != 8 or data[:2] == b"\xff\xff":
            raise ValueError("known-Q35 device missing at bounded ECAM address")
        command = struct.unpack_from("<H", data, 4)[0]
        sample[label] = {"address": address, "vendor": int.from_bytes(data[:2], "little"),
                         "device": int.from_bytes(data[2:4], "little"),
                         "command": command, "bus_master": bool(command & 4)}
    return sample


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("initial", "target", "capsule", "trust", "capsule-tools", "cbfstool",
                 "core", "config", "header", "inventory", "producer-config", "disk", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--qemu", default="qemu-system-x86_64")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parents[1]
    inputs = [value.resolve() for value in vars(args).values() if isinstance(value, Path)
              and value != args.output]
    inputs += [Path(shutil.which(tool)) for tool in (args.qemu, "mcopy", "mmd", "cc", "sh", "openssl")]
    for directory in (root, args.capsule_tools.resolve().parents[1]):
        names = subprocess.check_output(["git", "-C", str(directory), "ls-files", "-z",
                                         "src", "include", "tests", "util", "Makefile", "Kconfig"])
        inputs += [directory / os.fsdecode(name) for name in names.split(b"\0") if name]
    inputs = sorted(set(path for path in inputs if path.is_file()))
    before = {str(path): digest(path) for path in inputs}
    (output / "inputs-before.json").write_text(json.dumps(before, indent=2) + "\n")
    header = args.header.read_text()
    for macro in ("NATIVE_SYSTEM_FMP 1", "NATIVE_QEMU_TEST_FMP 0", "QEMU_ACCEPTANCE_PROFILE 0",
                  "PROTECTED_VARIABLE_RUNTIME 1", "DIAGNOSTIC 1"):
        if "#define CONFIG_CDK2_" + macro not in header:
            raise ValueError("genuine normal production configuration required")
    inventory = args.inventory.read_text()
    if "975cd0e6-c540-4e2b-906c-72c0d0d1e40d" not in inventory or "QEMU_TEST_FMP" in inventory:
        raise ValueError("real SystemFmp inventory required")
    producer = args.producer_config.read_text().splitlines()
    for line in ("CONFIG_ECAM_MMCONF_BASE_ADDRESS=0xb0000000",
                 "CONFIG_DRIVERS_EFI_CAPSULE_DELIVERY_POLICY=y",
                 "CONFIG_DRIVERS_EFI_CAPSULE_ON_DISK_SUPPORT=y"):
        if line not in producer:
            raise ValueError("actual selected Q35 disk capability/ECAM configuration required")
    for symbol in ("DRIVERS_EFI_UPDATE_CAPSULES", "SMMSTORE", "SMMSTORE_FULL_FLASH_ACCESS"):
        if f"CONFIG_{symbol}=y" in producer:
            raise ValueError("legacy flash grant is forbidden in this selected fixture")
    der = subprocess.check_output(["openssl", "x509", "-in", str(args.trust), "-outform", "DER"])
    for label, image in (("initial", args.initial), ("target", args.target)):
        extracted = output / f"{label}-core.elf"
        subprocess.run([str(args.cbfstool), str(image), "extract", "-n", "fallback/payload",
                        "-f", str(extracted), "-m", "x86"], check=True)
        if loads(extracted) != loads(args.core):
            raise ValueError("immutable firmware does not contain actual normal Core")
        certificate = output / f"{label}-trust.der"
        subprocess.run([str(args.cbfstool), str(image), "extract", "-n", "capsule/trust.der",
                        "-f", str(certificate)], check=True)
        if certificate.read_bytes() != der:
            raise ValueError("actual producer public trust differs from verified fixture")
    subprocess.run([sys.executable, str(args.capsule_tools / "validate_capsule.py"),
                    "--capsule", str(args.capsule), "--guid",
                    "00112233-4455-6677-8899-aabbccddeeff", "--embedded-drivers", "0",
                    "--fw-version", "0x001a000a", "--lsv", "0x001a0009", "--image",
                    str(args.target), "--region", "COREBOOT", "--trusted-public-cert",
                    str(args.trust), "--initiate-reset", "--require-fmap"], check=True)
    media, disk = output / "pflash.rom", output / "nvme.raw"
    shutil.copyfile(args.initial, media)
    shutil.copyfile(args.disk, disk)
    esp = str(disk) + "@@1048576"
    subprocess.run(["mmd", "-i", esp, "::/EFI/UpdateCapsule"], check=True)
    subprocess.run(["mcopy", "-i", esp, str(args.capsule), "::/EFI/UpdateCapsule/disk-a.cap"],
                   check=True)
    disk_before = digest(disk)
    serial = output / "serial.log"
    command = [args.qemu, "-machine", "q35,smm=on,accel=tcg", "-m", "1024M", "-cpu", "max",
               "-smp", "1", "-nodefaults", "-device", "intel-iommu,pt=off",
               "-device", "VGA,bus=pcie.0,addr=01", "-drive",
               f"if=none,id=nvme0,format=raw,file={disk}", "-device",
               "nvme,drive=nvme0,serial=CDK2MMRESET,bus=pcie.0,addr=03", "-device",
               "qemu-xhci,bus=pcie.0,addr=04", "-device", "edu,dma_mask=0xffffffff,bus=pcie.0,addr=05",
               "-global", "driver=cfi.pflash01,property=secure,value=on", "-drive",
               f"if=pflash,format=raw,file={media},cache=writeback", "-display", "none",
               "-serial", f"file:{serial}", "-qmp", f"unix:{output}/qmp.sock,server=on,wait=off"]
    (output / "command.json").write_text(json.dumps(command, indent=2) + "\n")
    result, failure, reader, qmp = None, None, None, None
    started = time.monotonic()
    deadline = started + 180
    with (output / "qemu.log").open("wb") as log:
        process = subprocess.Popen(command, stdout=log, stderr=log)
        try:
            while process.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError("predeclared single-boot DISK 180s budget expired")
                if qmp is None:
                    if not (output / "qmp.sock").exists():
                        time.sleep(0.05)
                        continue
                    qmp = Qmp(output / "qmp.sock")
                    reader = ConsoleReader(qmp, output)
                try:
                    body = reader.snapshot()
                except TableNotReady:
                    time.sleep(0.05)
                    continue
                if qmp.epoch():
                    raise ValueError("unexpected guest RESET in single DISK attempt")
                if not (output / "ecam-first-accepted.json").exists():
                    (output / "ecam-first-accepted.json").write_text(
                        json.dumps(ecam(qmp, output, "first-accepted")))
                if re.search(CHECK, body) and any(line.startswith(b"CDK2 | CAPSULE_DISK | ") and
                        (b"end " in line or b"failed" in line) for line in body.splitlines()):
                    result = observation(body, reader.table_snapshots)
                    save(reader, output, body)
                    (output / "ecam-denial.json").write_text(json.dumps(ecam(qmp, output, "denial")))
                    break
                time.sleep(0.05)
            if result is None:
                raise ValueError("guest exited before actual denied disk CHECK completion")
        except Exception as error:
            failure = repr(error)
            if reader is not None and reader.metadata is not None:
                save(reader, output, console_bytes(reader.last_snapshot))
        finally:
            qemu_seconds = time.monotonic() - started
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)
            (output / "qmp-events.json").write_text(json.dumps(qmp.events if qmp else [], indent=2))
    if failure is None:
        try:
            body, tables = validate_saved_console(output)
            observation(body, tables)
            sys.path.insert(0, str(args.capsule_tools))
            from validate_capsule import parse_fmap_regions
            check_refusal_media(media.read_bytes(), args.initial.read_bytes(),
                                parse_fmap_regions(args.initial.read_bytes()))
            subprocess.run(["sh", str(root / "tests/system_fmp_core_ram_refusal_store_test.sh"),
                            str(media), str(output)], check=True,
                           env=dict(os.environ, COREBOOT_TREE=str(args.capsule_tools.resolve().parents[1]),
                                    CBFSTOOL=str(args.cbfstool)))
            retained = output / "retained-disk-a.cap"
            subprocess.run(["mcopy", "-i", esp, "::/EFI/UpdateCapsule/disk-a.cap", str(retained)],
                           check=True)
            if retained.read_bytes() != args.capsule.read_bytes() or digest(disk) != disk_before:
                raise ValueError("denied capsule file or staged disk changed")
        except Exception as error:
            failure = repr(error)
    after = {str(path): digest(path) for path in inputs}
    (output / "inputs-after.json").write_text(json.dumps(after, indent=2) + "\n")
    if before != after:
        failure = failure or "immutable source/tool/config/input drift"
    (output / "result.json").write_text(json.dumps({"failure": failure, "observation": result,
        "qemu_seconds": qemu_seconds, "deadline_seconds": 180, "qemu_status": process.returncode,
        "termination": "HOST after bounded denial, not guest boot success"}, indent=2) + "\n")
    if failure:
        raise SystemExit(failure)
    print("Actual ESP denied CHECK/file retained/no SET; no late writer/OS/drain proof: PASS")


if __name__ == "__main__":
    main()
