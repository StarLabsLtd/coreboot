/* SPDX-License-Identifier: BSD-2-Clause-Patent */

#include <cdk2/capsule_runtime.h>
#include <cdk2/capsule_runtime_entry.h>
#include <cdk2/capsule_boot.h>
#include <cdk2/dxe_core_abi.h>
#include <cdk2/config.h>
#include <cdk2/diagnostic.h>

#include <string.h>

#define EVT_NOTIFY_SIGNAL 0x200U
#define TPL_NOTIFY 16U

__weak void cdk2_diag_runtime_transition(void)
{
}
#ifdef CDK2_DIAG_RUNTIME_TRANSITION_TEST
void cdk2_diag_runtime_transition_test_after(void);
#endif

typedef EFI_STATUS CDK2_MS_ABI install_multiple_fn(void **, ...);
typedef EFI_STATUS CDK2_MS_ABI uninstall_multiple_fn(void *, ...);
typedef EFI_STATUS CDK2_MS_ABI close_event_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI allocate_pool_fn(UINT32, UINTN, void **);
typedef EFI_STATUS CDK2_MS_ABI free_pool_fn(void *);
typedef EFI_STATUS CDK2_MS_ABI get_memory_map_fn(UINTN *, void *, UINTN *,
	UINTN *, UINT32 *);
typedef EFI_STATUS CDK2_MS_ABI install_configuration_table_fn(
	const EFI_GUID *, void *);
typedef EFI_STATUS CDK2_MS_ABI locate_handles_fn(UINT32, const EFI_GUID *, void *,
	UINTN *, void ***);
typedef EFI_STATUS CDK2_MS_ABI handle_protocol_fn(void *, const EFI_GUID *, void **);
typedef EFI_STATUS CDK2_MS_ABI create_event_ex_fn(UINT32, UINTN,
	void (CDK2_MS_ABI *)(void *, void *), void *, const EFI_GUID *, void **);
typedef EFI_STATUS CDK2_MS_ABI convert_pointer_fn(UINTN, void **);
typedef EFI_STATUS CDK2_MS_ABI set_variable_fn(CHAR16 *, EFI_GUID *, UINT32,
	UINTN, void *);
typedef void CDK2_MS_ABI reset_system_fn(UINT32, EFI_STATUS, UINTN, void *);

static const EFI_GUID capsule_arch_guid = { 0x5053697e, 0x2cbc, 0x4819,
	{ 0x90, 0xd9, 0x05, 0x80, 0xde, 0xee, 0x57, 0x54 } };
static const EFI_GUID capsule_boot_guid = { 0x2890d42b, 0x7f9b, 0x4a66,
	{ 0x9a, 0x12, 0x54, 0x8d, 0x6b, 0x57, 0xd8, 0x20 } };
static const EFI_GUID va_change_guid = { 0x13fa7698, 0xc831, 0x49c7,
	{ 0x87, 0xea, 0x8f, 0x43, 0xfc, 0xc2, 0x51, 0x96 } };
static const EFI_GUID ebs_guid = { 0x27abf055, 0xb1b8, 0x4c26,
	{ 0x80, 0x48, 0x74, 0x8f, 0x37, 0xba, 0xa2, 0xdf } };
static const EFI_GUID capsule_vendor_guid = { 0x711c703f, 0xc285, 0x4b10,
	{ 0xa3, 0xb0, 0x36, 0xec, 0xbd, 0x3c, 0x8b, 0xe2 } };
static const EFI_GUID fmp_capsule_guid = { 0x6dcbd5ed, 0xe82d, 0x4c44,
	{ 0xbd, 0xa1, 0x71, 0x94, 0x19, 0x9a, 0xd9, 0x2a } };
static const EFI_GUID fmp_protocol_guid = { 0x86c77a67, 0x0b97, 0x4633,
	{ 0xa1, 0x87, 0x49, 0x10, 0x4d, 0x06, 0x85, 0xc7 } };
static const EFI_GUID check_outcome_guid = CDK2_CAPSULE_CHECK_OUTCOME_GUID;
static struct cdk2_runtime_services_view *runtime_services;
static struct cdk2_capsule_runtime runtime;
static void *capsule_handle;
static void *va_event;
static void *ebs_event;
static BOOLEAN runtime_active;
static BOOLEAN virtual_mode;
static EFI_STATUS convert(void **pointer, void *context);
static struct cdk2_boot_services_view *boot_services;
static struct cdk2_capsule_boot_protocol boot_protocol;

static void release_fmp_pool(free_pool_fn *free_pool, void *pool)
{
	if (EFI_ERROR(free_pool(pool)))
		boot_protocol.outcome.unproved = true;
}

struct memory_descriptor {
	UINT32 type, padding;
	UINT64 physical_start, virtual_start, pages, attributes;
};
struct capsule_table {
	UINT32 count, reserved;
	const struct cdk2_capsule_header *capsules[];
};

static BOOLEAN ram_range(const void *map, UINTN map_size, UINTN descriptor_size,
	UINT64 address, UINT64 length)
{
	UINT64 end;

	if (length == 0U || address > MAX_UINT64 - length)
		return FALSE;
	if (descriptor_size < sizeof(struct memory_descriptor) ||
	    map_size < descriptor_size)
		return FALSE;
	end = address + length;
	for (UINTN offset = 0U; offset <= map_size - descriptor_size;
	    offset += descriptor_size) {
		const struct memory_descriptor *descriptor =
			(const void *)((const UINT8 *)map + offset);
		UINT64 bytes;

		if (descriptor->pages > MAX_UINT64 / 4096U)
			continue;
		bytes = descriptor->pages * 4096U;
		if (descriptor->physical_start > MAX_UINT64 - bytes)
			continue;
		if ((descriptor->type >= 1U && descriptor->type <= 7U) ||
		    descriptor->type == 9U || descriptor->type == 10U ||
		    descriptor->type == 14U)
			if (address >= descriptor->physical_start &&
			    end <= descriptor->physical_start + bytes)
				return TRUE;
	}
	return FALSE;
}

static EFI_STATUS memory_map_snapshot(void **map, UINTN *map_size,
	UINTN *descriptor_size)
{
	get_memory_map_fn *get_memory_map = (void *)boot_services->get_memory_map;
	allocate_pool_fn *allocate_pool = (void *)boot_services->allocate_pool;
	free_pool_fn *free_pool = (void *)boot_services->free_pool;
	UINTN key = 0U;
	UINT32 version = 0U;
	EFI_STATUS status;

	*map = NULL;
	*map_size = 0U;
	if (get_memory_map == NULL || allocate_pool == NULL || free_pool == NULL)
		return EFI_UNSUPPORTED;
	status = get_memory_map(map_size, NULL, &key, descriptor_size, &version);
	if (status != EFI_BUFFER_TOO_SMALL || *map_size > MAX_UINTN -
	    2U * *descriptor_size)
		return EFI_COMPROMISED_DATA;
	*map_size += 2U * *descriptor_size;
	status = allocate_pool(4U, *map_size, map);
	if (EFI_ERROR(status))
		return status;
	status = get_memory_map(map_size, *map, &key, descriptor_size, &version);
	if (EFI_ERROR(status)) {
		(void)free_pool(*map);
		*map = NULL;
	}
	return status;
}
#ifdef CDK2_CAPSULE_ENTRY_TEST
struct cdk2_capsule_boot_protocol *cdk2_capsule_test_boot_protocol(void)
{
	return &boot_protocol;
}
#endif

struct fmp_capsule_header { UINT32 version; UINT16 embedded_count, payload_count; }
	__packed;
struct fmp_image_header {
	UINT32 version;
	EFI_GUID image_type;
	UINT8 image_index, reserved[3];
	UINT32 image_size, vendor_size;
	UINT64 hardware_instance, capsule_support;
} __packed;
struct fmp_image_descriptor {
	UINT8 image_index;
	EFI_GUID image_type;
	UINT64 image_id;
	CHAR16 *image_id_name;
	UINT32 version;
	CHAR16 *version_name;
	UINTN size;
	UINT64 attributes_supported, attributes_setting;
	UINT64 compatibilities;
	UINT32 lowest_supported_version, last_attempt_version,
		last_attempt_status;
	UINT64 hardware_instance;
	void *dependencies;
};
struct fmp_protocol {
	EFI_STATUS(CDK2_MS_ABI *get_image_info)(void *, UINTN *, void *, UINT32 *,
		UINT8 *, UINTN *, UINT32 *, CHAR16 **);
	void *get_image;
	EFI_STATUS(CDK2_MS_ABI *set_image)(void *, UINT8, const void *, UINTN,
		const void *, void *, CHAR16 **);
	EFI_STATUS(CDK2_MS_ABI *check_image)(void *, UINT8, const void *, UINTN,
		UINT32 *);
	void *get_package_info, *set_package_info;
};

#define FMP_IMAGE_RESET_REQUIRED BIT1
#define FMP_DESCRIPTOR_V1_SIZE \
	offsetof(struct fmp_image_descriptor, lowest_supported_version)

static BOOLEAN valid_fmp_descriptor_layout(UINT32 version, UINTN size)
{
	return version >= 1U && size >= FMP_DESCRIPTOR_V1_SIZE;
}

static void *boot_slot(UINTN offset)
{
	struct cdk2_system_table_view *system = runtime.context;

	return system == NULL ? NULL : *(void **)((UINT8 *)system->boot + offset);
}

static BOOLEAN guid_equal(const EFI_GUID *a, const EFI_GUID *b)
{
	const UINT8 *left = (const void *)a, *right = (const void *)b;
	UINTN index;
	for (index = 0; index < sizeof(*a); index++)
		if (left[index] != right[index])
			return FALSE;
	return TRUE;
}

static UINT64 read_u64(const void *source)
{
	const UINT8 *bytes = source;
	UINT64 value = 0;
	UINTN index;
	for (index = 0; index < sizeof(value); index++)
		value |= (UINT64)bytes[index] << (index * 8U);
	return value;
}

static UINT32 read_u32(const void *source)
{
	const UINT8 *bytes = source;
	return bytes[0] | (UINT32)bytes[1] << 8 | (UINT32)bytes[2] << 16 |
		(UINT32)bytes[3] << 24;
}

static EFI_STATUS installed_version(const EFI_GUID *type, void **handles, UINTN count,
	handle_protocol_fn *handle_protocol, allocate_pool_fn *allocate_pool,
	free_pool_fn *free_pool, UINT32 *version)
{
	UINTN handle_index;
	EFI_STATUS failure = EFI_NOT_FOUND;

	for (handle_index = 0; handle_index < count; handle_index++) {
		struct fmp_protocol *fmp;
		struct fmp_image_descriptor *descriptors = NULL;
		UINTN size = 0, descriptor_size = 0, index = 0;
		UINT32 descriptor_version = 0, package_version = 0;
		UINT8 descriptor_count = 0;
		CHAR16 *package_name = NULL;
		EFI_STATUS status = handle_protocol(handles[handle_index], &fmp_protocol_guid,
			(void **)&fmp);

		if (EFI_ERROR(status)) {
			boot_protocol.outcome.unproved = true;
			if (status != EFI_NOT_FOUND && failure == EFI_NOT_FOUND)
				failure = status;
			continue;
		}
		if (fmp == NULL || fmp->get_image_info == NULL) {
			boot_protocol.outcome.unproved = true;
			continue;
		}
		status = fmp->get_image_info(fmp, &size, NULL, &descriptor_version,
			&descriptor_count, &descriptor_size, &package_version, &package_name);
		if (package_name != NULL)
			release_fmp_pool(free_pool, package_name);
		if (EFI_ERROR(status) && status != EFI_BUFFER_TOO_SMALL &&
		    failure == EFI_NOT_FOUND)
			failure = status;
		if (status != EFI_BUFFER_TOO_SMALL || size == 0U || descriptor_size <
		    offsetof(struct fmp_image_descriptor, version) + sizeof(UINT32) ||
		    descriptor_count > size / descriptor_size) {
			boot_protocol.outcome.unproved = true;
			continue;
		}
		for (UINTN attempt = 0U; attempt < 3U; attempt++) {
			if (EFI_ERROR(allocate_pool(4U, size, (void **)&descriptors)))
				return EFI_OUT_OF_RESOURCES;
			package_name = NULL;
			status = fmp->get_image_info(fmp, &size, descriptors,
				&descriptor_version, &descriptor_count, &descriptor_size,
				&package_version, &package_name);
			if (status != EFI_BUFFER_TOO_SMALL)
				break;
			if (package_name != NULL) {
				release_fmp_pool(free_pool, package_name);
				package_name = NULL;
			}
			release_fmp_pool(free_pool, descriptors);
			descriptors = NULL;
			if (size == 0U || descriptor_size <
			    offsetof(struct fmp_image_descriptor, version) + sizeof(UINT32) ||
			    descriptor_count > size / descriptor_size) {
				status = EFI_COMPROMISED_DATA;
				break;
			}
		}
		if (!EFI_ERROR(status)) {
			for (index = 0; index < descriptor_count; index++) {
				struct fmp_image_descriptor *descriptor = (void *)
					((UINT8 *)descriptors + index * descriptor_size);
				if (guid_equal(&descriptor->image_type, type)) {
					*version = descriptor->version;
					status = EFI_SUCCESS;
					break;
				}
			}
		} else if (failure == EFI_NOT_FOUND)
			failure = status;
		if (EFI_ERROR(status))
			boot_protocol.outcome.unproved = true;
		if (package_name != NULL)
			release_fmp_pool(free_pool, package_name);
		if (descriptors != NULL)
			release_fmp_pool(free_pool, descriptors);
		if (!EFI_ERROR(status) && index < descriptor_count)
			return EFI_SUCCESS;
	}
	return failure;
}

static EFI_STATUS dependency_image(const UINT8 *data, UINTN size, void **handles,
	UINTN handle_count, handle_protocol_fn *handle_protocol,
	allocate_pool_fn *allocate_pool, free_pool_fn *free_pool,
	const UINT8 **image, UINTN *image_size)
{
	UINT64 *stack;
	UINTN expression_size = size;
	UINTN capacity, scan = 0;
	UINTN depth = 0, offset = 0;
	BOOLEAN declared = FALSE;
	EFI_STATUS result = EFI_INVALID_PARAMETER;

	if (size >= 5U && data[0] == 0x0eU) {
		declared = TRUE;
		expression_size = read_u32(data + 1U);
		if (expression_size < 6U || expression_size > size)
			return EFI_INVALID_PARAMETER;
	}
	while (scan < expression_size) {
		UINT8 opcode = data[scan++];

		if (opcode == 0x00U) {
			if (expression_size - scan < sizeof(EFI_GUID))
				return EFI_INVALID_PARAMETER;
			scan += sizeof(EFI_GUID);
		} else if (opcode == 0x01U) {
			if (expression_size - scan < sizeof(UINT32))
				return EFI_INVALID_PARAMETER;
			scan += sizeof(UINT32);
		} else if (opcode == 0x02U) {
			while (scan < expression_size && data[scan++] != 0U)
				;
			if (scan == expression_size && data[scan - 1U] != 0U)
				return EFI_INVALID_PARAMETER;
		} else if (opcode == 0x0eU && scan == 1U) {
			if (expression_size - scan < sizeof(UINT32))
				return EFI_INVALID_PARAMETER;
			scan += sizeof(UINT32);
		} else if (opcode == 0x0dU) {
			break;
		}
	}
	if (scan == 0U || (declared && scan != expression_size) ||
	    data[scan - 1U] != 0x0dU ||
	    scan > MAX_UINTN / sizeof(*stack))
		return EFI_INVALID_PARAMETER;
	capacity = scan;
	if (EFI_ERROR(allocate_pool(4U, capacity * sizeof(*stack), (void **)&stack)))
		return EFI_OUT_OF_RESOURCES;

	while (offset < expression_size) {
		UINT8 opcode = data[offset++];
		UINT64 left, right;

		if (opcode == 0x0eU && offset == 1U) {
			offset += sizeof(UINT32);
			continue;
		}

		if (opcode == 0x00U) {
			UINT32 version = 0;
			EFI_GUID guid;
			EFI_STATUS status;
			if (expression_size - offset < sizeof(guid) || depth == capacity)
				goto out;
			__builtin_memcpy(&guid, data + offset, sizeof(guid));
			offset += sizeof(guid);
			status = installed_version(&guid, handles, handle_count,
				handle_protocol, allocate_pool, free_pool, &version);
			if (EFI_ERROR(status)) {
				result = status == EFI_NOT_FOUND ? EFI_UNSUPPORTED : status;
				goto out;
			}
			stack[depth++] = version;
			continue;
		}
		if (opcode == 0x01U) {
			if (expression_size - offset < sizeof(UINT32) || depth == capacity)
				goto out;
			stack[depth++] = read_u32(data + offset);
			offset += sizeof(UINT32);
			continue;
		}
		if (opcode == 0x02U) {
			while (offset < expression_size && data[offset++] != 0U)
				;
			if (offset == expression_size && data[offset - 1U] != 0U)
				goto out;
			continue;
		}
		if (opcode == 0x06U || opcode == 0x07U) {
			if (depth == capacity)
				goto out;
			stack[depth++] = opcode == 0x06U;
			continue;
		}
		if (opcode == 0x05U) {
			if (depth == 0U)
				goto out;
			stack[depth - 1U] = !stack[depth - 1U];
			continue;
		}
		if (opcode == 0x0dU) {
			if (depth != 1U || stack[0] == 0U) {
				result = depth == 1U ? EFI_UNSUPPORTED : EFI_INVALID_PARAMETER;
				goto out;
			}
			*image = data + (declared ? expression_size : offset);
			*image_size = size - (declared ? expression_size : offset);
			result = *image_size != 0U ? EFI_SUCCESS : EFI_INVALID_PARAMETER;
			goto out;
		}
		if (opcode < 0x03U || opcode > 0x0cU || depth < 2U)
			goto out;
		right = stack[--depth];
		left = stack[depth - 1U];
		switch (opcode) {
		case 0x03U:
			stack[depth - 1U] = left && right;
			break;
		case 0x04U:
			stack[depth - 1U] = left || right;
			break;
		case 0x08U:
			stack[depth - 1U] = left == right;
			break;
		case 0x09U:
			stack[depth - 1U] = left > right;
			break;
		case 0x0aU:
			stack[depth - 1U] = left >= right;
			break;
		case 0x0bU:
			stack[depth - 1U] = left < right;
			break;
		case 0x0cU:
			stack[depth - 1U] = left <= right;
			break;
		default:
			goto out;
		}
	}
out:
	release_fmp_pool(free_pool, stack);
	return result;
}

EFI_STATUS __weak cdk2_capsule_cache_writeback_range_all_cpus(UINT64 address,
	UINT64 length)
{
	UINT64 line, end;
	if (length == 0U || address > MAX_UINT64 - length)
		return EFI_INVALID_PARAMETER;
	line = address & ~63ULL;
	end = address + length;
	for (;;) {
		__asm__ volatile("clflush (%0)" : : "r"((UINTN)line) : "memory");
		if (end - line <= 64U)
			break;
		line += 64U;
	}
	__asm__ volatile("mfence" : : : "memory");
	return EFI_SUCCESS;
}

static struct cdk2_capsule_policy policy;

static EFI_STATUS fmp_payload(const struct fmp_image_header *image, UINTN available,
	BOOLEAN apply, BOOLEAN *reset_required)
{
	locate_handles_fn *locate_handles;
	handle_protocol_fn *handle_protocol;
	allocate_pool_fn *allocate_pool;
	free_pool_fn *free_pool;
	void **handles = NULL;
	UINTN count = 0, handle_index;
	EFI_STATUS result = EFI_SUCCESS;
	BOOLEAN matched = FALSE;
	BOOLEAN target_all;
	UINTN header_size = image->version >= 3U ? sizeof(*image) :
		image->version == 2U ? offsetof(struct fmp_image_header, capsule_support) :
		offsetof(struct fmp_image_header, hardware_instance);
	if (image->version < 1U || image->version > 3U || available < header_size ||
	    image->reserved[0] != 0U || image->reserved[1] != 0U ||
	    image->reserved[2] != 0U ||
	    (image->version >= 3U && (image->capsule_support & ~3ULL) != 0U) ||
	    image->image_size > available - header_size ||
	    image->vendor_size > available - header_size - image->image_size)
		return EFI_INVALID_PARAMETER;
	/* QueryCapsuleCapabilities and UpdateCapsule preflight only establish that
	 * this is a structurally valid FMP capsule.  EDK2's SupportCapsuleImage()
	 * deliberately does not locate an FMP instance or call CheckImage here;
	 * doing so can perform platform flash work repeatedly while fwupd is merely
	 * probing capabilities.  Defer target matching and CheckImage to the single
	 * processing pass. */
	if (!apply)
		return EFI_SUCCESS;
	target_all = image->version == 1U || image->hardware_instance == 0U;
	/* FMP discovery and dispatch use boot services and cannot apply after EBS. */
	if (runtime.exited_boot_services)
		return apply ? EFI_UNSUPPORTED : EFI_SUCCESS;
	locate_handles = (void *)boot_slot(312U);
	handle_protocol = (void *)boot_slot(152U);
	allocate_pool = (void *)boot_slot(64U);
	free_pool = (void *)boot_slot(72U);
	if (!locate_handles || !handle_protocol || !allocate_pool || !free_pool)
		return EFI_INVALID_PARAMETER;
	result = locate_handles(2U, &fmp_protocol_guid, NULL, &count, &handles);
	if (EFI_ERROR(result)) {
		boot_protocol.outcome.unproved = true;
		return result == EFI_NOT_FOUND ? EFI_UNSUPPORTED : result;
	}
	for (handle_index = 0; handle_index < count; handle_index++) {
		struct fmp_protocol *fmp;
		struct fmp_image_descriptor *descriptors = NULL;
		UINTN info_size = 0, descriptor_size = 0, descriptor_index;
		UINT32 descriptor_version = 0, package_version = 0;
		UINT8 descriptor_count = 0;
		CHAR16 *package_name = NULL;
		EFI_STATUS status = handle_protocol(handles[handle_index], &fmp_protocol_guid,
			(void **)&fmp);
		if (EFI_ERROR(status)) {
			boot_protocol.outcome.unproved = true;
			if (!matched || !EFI_ERROR(result))
				result = status;
			continue;
		}
		if (fmp == NULL || fmp->get_image_info == NULL) {
			boot_protocol.outcome.unproved = true;
			continue;
		}
		status = fmp->get_image_info(fmp, &info_size, NULL, &descriptor_version,
			&descriptor_count, &descriptor_size, &package_version, &package_name);
		if (status != EFI_BUFFER_TOO_SMALL || !info_size) {
			boot_protocol.outcome.unproved = true;
			if (EFI_ERROR(status) && status != EFI_BUFFER_TOO_SMALL &&
			    (!matched || !EFI_ERROR(result)))
				result = status;
			continue;
		}
		if (package_name != NULL) {
			release_fmp_pool(free_pool, package_name);
			package_name = NULL;
		}
		if (!valid_fmp_descriptor_layout(descriptor_version, descriptor_size) ||
		    descriptor_count > info_size / descriptor_size) {
			boot_protocol.outcome.unproved = true;
			result = EFI_COMPROMISED_DATA;
			continue;
		}
		status = allocate_pool(4U, info_size, (void **)&descriptors);
		if (EFI_ERROR(status)) {
			boot_protocol.outcome.unproved = true;
			if (!matched || !EFI_ERROR(result))
				result = status;
			break;
		}
		for (UINTN attempt = 0U; attempt < 3U; attempt++) {
			status = fmp->get_image_info(fmp, &info_size, descriptors,
				&descriptor_version, &descriptor_count, &descriptor_size,
				&package_version, &package_name);
			if (status != EFI_BUFFER_TOO_SMALL)
				break;
			if (package_name != NULL) {
				release_fmp_pool(free_pool, package_name);
				package_name = NULL;
			}
			release_fmp_pool(free_pool, descriptors);
			descriptors = NULL;
			if (info_size == 0U ||
			    !valid_fmp_descriptor_layout(descriptor_version, descriptor_size) ||
			    descriptor_count > info_size / descriptor_size) {
				status = EFI_COMPROMISED_DATA;
				boot_protocol.outcome.unproved = true;
				break;
			}
			status = allocate_pool(4U, info_size, (void **)&descriptors);
			if (EFI_ERROR(status))
				break;
			if (attempt == 2U)
				status = EFI_BUFFER_TOO_SMALL;
		}
		if (!EFI_ERROR(status) &&
		    (!valid_fmp_descriptor_layout(descriptor_version, descriptor_size) ||
		     descriptor_count > info_size / descriptor_size))
			status = EFI_COMPROMISED_DATA;
		if (EFI_ERROR(status) && (!matched || !EFI_ERROR(result)))
			result = status;
		if (EFI_ERROR(status))
			boot_protocol.outcome.unproved = true;
		if (!EFI_ERROR(status)) {
			for (descriptor_index = 0; descriptor_index < descriptor_count;
			     descriptor_index++) {
				struct fmp_image_descriptor *descriptor = (void *)
					((UINT8 *)descriptors + descriptor_index * descriptor_size);
				const EFI_GUID *image_type = (const void *)((const UINT8 *)image +
					offsetof(struct fmp_image_header, image_type));
				UINT64 hardware = descriptor->size != 0U &&
					descriptor_version >= 3U &&
					descriptor_size >= offsetof(struct fmp_image_descriptor,
					hardware_instance) + sizeof(descriptor->hardware_instance) ?
					descriptor->hardware_instance : 0;
				UINT32 updatable = 0;
				const UINT8 *update_image = (const UINT8 *)image + header_size;
				UINTN update_size = image->image_size;
				UINTN authentication_size = 0U;
				if (descriptor->image_index != image->image_index ||
			    !guid_equal(&descriptor->image_type, image_type) ||
			    (image->version >= 2U && image->hardware_instance != 0U &&
			     hardware != image->hardware_instance)) {
					continue;
				}
				matched = TRUE;
				boot_protocol.outcome.matching_checks++;
				if (boot_protocol.outcome.matching_checks != 1U)
					boot_protocol.outcome.unproved = true;
				if (!target_all)
					result = EFI_SUCCESS;
				if (image->version >= 3U && (image->capsule_support & 1U) != 0U) {
					UINT32 certificate_size;

					if (update_size < 32U)
						status = EFI_INVALID_PARAMETER;
					else {
						certificate_size = read_u32(update_image + 8U);
						authentication_size = (UINTN)certificate_size + 8U;
						status = certificate_size >= 24U &&
							authentication_size <= update_size ?
							EFI_SUCCESS : EFI_INVALID_PARAMETER;
					}
					if (EFI_ERROR(status)) {
						boot_protocol.outcome.unproved = true;
						result = EFI_ERROR(result) ? result : status;
						continue;
					}
				}
				if (image->version >= 3U && (image->capsule_support & 2U) != 0U) {
					const UINT8 *firmware_image;
					UINTN firmware_size;

					status = dependency_image(update_image + authentication_size,
						update_size - authentication_size, handles, count,
						handle_protocol, allocate_pool, free_pool,
						&firmware_image, &firmware_size);
					if (EFI_ERROR(status)) {
						boot_protocol.outcome.unproved = true;
						result = EFI_ERROR(result) ? result : status;
						continue;
					}
					/* Validate the dependency expression, but preserve the exact
					 * authenticated bytes passed to CheckImage and SetImage. */
				}
				if (fmp->set_image == NULL) {
					boot_protocol.outcome.unproved = true;
					if (!EFI_ERROR(result))
						result = EFI_UNSUPPORTED;
					continue;
				}
				if (fmp->check_image != NULL)
					status = fmp->check_image(fmp, image->image_index,
						update_image, update_size,
						&updatable);
				else
					status = EFI_SUCCESS;
				if (EFI_ERROR(status)) {
					if (boot_protocol.outcome.active &&
					    boot_protocol.outcome.matching_checks == 1U &&
					    fmp->check_image != NULL) {
						void *check = NULL;

						if (EFI_ERROR(handle_protocol(handles[handle_index],
							&check_outcome_guid, &check)) || check == NULL)
							boot_protocol.outcome.unproved = true;
						boot_protocol.outcome.fmp_handle = handles[handle_index];
						boot_protocol.outcome.fmp_protocol = fmp;
						boot_protocol.outcome.check = check;
						boot_protocol.outcome.image = update_image;
						boot_protocol.outcome.image_size = update_size;
						boot_protocol.outcome.image_index = image->image_index;
					} else {
						boot_protocol.outcome.unproved = true;
					}
					if (!EFI_ERROR(result))
						result = status;
					continue;
				}
				if ((fmp->check_image != NULL &&
				    updatable != CDK2_FMP_IMAGE_UPDATABLE_VALID &&
				    updatable != CDK2_FMP_IMAGE_UPDATABLE_VALID_WITH_VENDOR_CODE) ||
				    (updatable == CDK2_FMP_IMAGE_UPDATABLE_VALID_WITH_VENDOR_CODE &&
				     image->vendor_size == 0U)) {
					if (!EFI_ERROR(result))
						result = EFI_UNSUPPORTED;
					boot_protocol.outcome.unproved = true;
					continue;
				}
				status = EFI_SUCCESS;
				if (apply) {
					CHAR16 *abort_reason = NULL;

					boot_protocol.outcome.set_begun = true;
					status = fmp->set_image(fmp, image->image_index,
							update_image, update_size,
							image->vendor_size != 0U ? (const UINT8 *)image +
								header_size + image->image_size : NULL,
							NULL, &abort_reason);
					if (abort_reason != NULL)
						release_fmp_pool(free_pool, abort_reason);
				}
				if (EFI_ERROR(status)) {
					if (!EFI_ERROR(result))
						result = status;
				} else {
					if (status != EFI_SUCCESS && result == EFI_SUCCESS)
						result = status;
					if (reset_required != NULL && descriptor->size != 0U &&
					    (descriptor->attributes_supported &
					     FMP_IMAGE_RESET_REQUIRED) != 0U &&
					    (descriptor->attributes_setting &
					     FMP_IMAGE_RESET_REQUIRED) != 0U)
						*reset_required = TRUE;
				}
				if (!target_all)
					break;
			}
		}
		if (package_name != NULL)
			release_fmp_pool(free_pool, package_name);
		if (descriptors != NULL)
			release_fmp_pool(free_pool, descriptors);
		if (matched && !target_all)
			break;
	}
	if (handles != NULL)
		release_fmp_pool(free_pool, handles);
	return matched || EFI_ERROR(result) ? result : EFI_UNSUPPORTED;
}

static EFI_STATUS fmp_capsule(const struct cdk2_capsule_header *capsule, BOOLEAN apply,
	BOOLEAN *reset_required)
{
	const UINT8 *base = (const UINT8 *)capsule + capsule->header_size;
	const struct fmp_capsule_header *header = (const void *)base;
	const UINT8 *offsets;
	UINTN body_size, items, index;
	EFI_STATUS result = EFI_SUCCESS, status;
	BOOLEAN provider_reset = FALSE;

	if (!guid_equal(&capsule->guid, &fmp_capsule_guid))
		return EFI_UNSUPPORTED;
	if (capsule->image_size < capsule->header_size + sizeof(*header))
		return EFI_INVALID_PARAMETER;
	body_size = capsule->image_size - capsule->header_size;
	items = (UINTN)header->embedded_count + header->payload_count;
	if (header->version != 1U || !header->payload_count ||
	    header->embedded_count != 0U || items > (body_size - sizeof(*header)) / sizeof(UINT64))
		return EFI_UNSUPPORTED;
	offsets = (const void *)(header + 1);
	for (index = 0; index < items; index++)
		if (read_u64(offsets + index * sizeof(UINT64)) <
		    sizeof(*header) + items * sizeof(UINT64) ||
		    read_u64(offsets + index * sizeof(UINT64)) > body_size ||
		    (index != 0U && read_u64(offsets + index * sizeof(UINT64)) <=
		     read_u64(offsets + (index - 1U) * sizeof(UINT64))))
			return EFI_INVALID_PARAMETER;
	for (index = header->embedded_count; index < items; index++) {
		UINTN offset = (UINTN)read_u64(offsets + index * sizeof(UINT64));
		UINTN end = index + 1U < items ? (UINTN)read_u64(offsets +
			(index + 1U) * sizeof(UINT64)) : body_size;
		if (end - offset < offsetof(struct fmp_image_header, hardware_instance))
			return EFI_INVALID_PARAMETER;
		status = fmp_payload((const void *)(base + offset), end - offset, apply,
			&provider_reset);
		if (EFI_ERROR(status))
			return status;
		if (status != EFI_SUCCESS && result == EFI_SUCCESS)
			result = status;
	}
	if (reset_required != NULL)
		*reset_required = provider_reset;
	return result;
}

static EFI_STATUS support(const struct cdk2_capsule_header *capsule, void *context)
{
	(void)context;
	return fmp_capsule(capsule, FALSE, NULL);
}

static EFI_STATUS process(const struct cdk2_capsule_header *capsule, void *context)
{
	(void)context;
	return fmp_capsule(capsule, TRUE, NULL);
}

static EFI_STATUS process_boot_capsule(const struct cdk2_capsule_header *capsule,
	BOOLEAN *reset_required)
{
	return fmp_capsule(capsule, TRUE, reset_required);
}

static EFI_STATUS CDK2_MS_ABI validate_capsule(
	struct cdk2_capsule_boot_protocol *protocol, const void *data, UINTN size)
{
	const struct cdk2_capsule_header *capsule = data;
	UINTN limit;

	if (protocol != &boot_protocol || capsule == NULL ||
	    size < sizeof(*capsule) || capsule->header_size < sizeof(*capsule) ||
	    capsule->header_size > size ||
	    capsule->image_size != size ||
	    (capsule->flags & ~CDK2_CAPSULE_FLAGS) != 0U ||
	    ((capsule->flags & (CDK2_CAPSULE_POPULATE | CDK2_CAPSULE_RESET)) != 0U &&
	     (capsule->flags & CDK2_CAPSULE_PERSIST) == 0U))
		return EFI_INVALID_PARAMETER;
	limit = (capsule->flags & CDK2_CAPSULE_POPULATE) != 0U ?
		policy.max_populate : policy.max_nonpopulate;
	if (size > limit)
		return EFI_INVALID_PARAMETER;
	return (capsule->flags & CDK2_CAPSULE_POPULATE) != 0U ?
		EFI_SUCCESS : support(capsule, NULL);
}

static EFI_STATUS CDK2_MS_ABI process_scatter(
	struct cdk2_capsule_boot_protocol *protocol, UINT64 scatter_gather);

static EFI_STATUS CDK2_MS_ABI process_capsule(
	struct cdk2_capsule_boot_protocol *protocol, const void *data, UINTN size)
{
	const struct cdk2_capsule_header *capsule = data;
	EFI_STATUS status;
	struct { UINT64 length, address; } scatter[2];
	BOOLEAN provider_reset = FALSE;

	if (boot_protocol.outcome.active) {
		boot_protocol.outcome.unproved = true;
		return EFI_ACCESS_DENIED;
	}
	boot_protocol.outcome = (struct cdk2_capsule_process_outcome) {
		.capsule = data,
		.capsule_size = size,
		.active = true,
	};
	status = validate_capsule(protocol, data, size);

	if (!EFI_ERROR(status) && (capsule->flags & CDK2_CAPSULE_POPULATE) != 0U) {
		scatter[0].length = size;
		scatter[0].address = (UINT64)(UINTN)data;
		scatter[1].length = 0U;
		scatter[1].address = 0U;
		boot_protocol.outcome.unproved = true;
		status = process_scatter(protocol, (UINT64)(UINTN)scatter);
		goto out;
	}
	if (!EFI_ERROR(status))
		status = process_boot_capsule(capsule, &provider_reset);
	if (!EFI_ERROR(status) && (provider_reset ||
	    (capsule->flags & CDK2_CAPSULE_RESET) != 0U))
		protocol->reset_required = TRUE;
out:
	boot_protocol.outcome.failure = status;
	boot_protocol.outcome.completed = true;
	boot_protocol.outcome.active = false;
	return status;
}

static EFI_STATUS CDK2_MS_ABI process_scatter(
	struct cdk2_capsule_boot_protocol *protocol, UINT64 scatter_gather)
{
	struct capsule_block { UINT64 length, address; };
	const struct capsule_block *block = (const void *)(UINTN)scatter_gather;
	allocate_pool_fn *allocate_pool = (void *)boot_services->allocate_pool;
	free_pool_fn *free_pool = (void *)boot_services->free_pool;
	UINT8 *buffer;
	void *memory_map = NULL;
	UINTN memory_map_size = 0U, descriptor_size = 0U;
	UINTN total = 0U, offset = 0U, walked = 0U;
	struct cdk2_capsule_policy boot_policy = policy;
	struct published_table { EFI_GUID guid; struct capsule_table *table; };
	struct published_table *published = NULL;
	UINTN published_count = 0U, reserved_count = 0U, published_capacity = 0U;
	BOOLEAN retain_buffer = FALSE;
	BOOLEAN update_reset = FALSE;
	EFI_STATUS status;

	/* Boot-owned staging is in RAM even when the capsule arrived from disk. */
	boot_policy.in_ram = boot_protocol.delivery_policy.allowed_transports != 0U;
	if (protocol != &boot_protocol || block == NULL || allocate_pool == NULL ||
	    free_pool == NULL)
		return EFI_INVALID_PARAMETER;
	status = memory_map_snapshot(&memory_map, &memory_map_size, &descriptor_size);
	if (EFI_ERROR(status))
		return status;
	while (block != NULL && walked++ < SIZE_1MB / sizeof(*block)) {
		if (!ram_range(memory_map, memory_map_size, descriptor_size,
		    (UINT64)(UINTN)block, sizeof(*block))) {
			status = EFI_INVALID_PARAMETER;
			goto done;
		}
		if (block->length == 0U) {
			block = block->address == 0U ? NULL :
				(const void *)(UINTN)block->address;
			continue;
		}
		if (block->address == 0U || block->length > MAX_UINTN - total ||
		    !ram_range(memory_map, memory_map_size, descriptor_size,
		    block->address, block->length)) {
			status = EFI_INVALID_PARAMETER;
			goto done;
		}
		total += (UINTN)block->length;
		block++;
	}
	if (block != NULL || total < sizeof(struct cdk2_capsule_header)) {
		status = EFI_INVALID_PARAMETER;
		goto done;
	}
	status = allocate_pool(6U, total, (void **)&buffer);
	if (EFI_ERROR(status))
		goto done;
	block = (const void *)(UINTN)scatter_gather;
	while (block != NULL && offset < total) {
		if (block->length == 0U) {
			block = block->address == 0U ? NULL :
				(const void *)(UINTN)block->address;
			continue;
		}
		memcpy(buffer + offset, (const void *)(UINTN)block->address,
			(UINTN)block->length);
		offset += (UINTN)block->length;
		block++;
	}
	for (offset = 0U; offset < total;) {
		const struct cdk2_capsule_header *capsule = (const void *)(buffer + offset);
		const struct cdk2_capsule_header *one;
		BOOLEAN initiate_reset, needs_reset;
		UINT64 limit;

		if (total - offset < sizeof(*capsule) ||
		    capsule->header_size < sizeof(*capsule) ||
		    capsule->image_size < capsule->header_size ||
		    capsule->image_size > total - offset) {
			status = EFI_INVALID_PARAMETER;
			break;
		}
		limit = (capsule->flags & CDK2_CAPSULE_POPULATE) != 0U ?
			policy.max_populate : policy.max_nonpopulate;
		if (capsule->image_size > limit) {
			status = EFI_INVALID_PARAMETER;
			break;
		}
		one = capsule;
		status = cdk2_capsule_preflight(&one, 1U, scatter_gather, FALSE,
			&boot_policy, support, NULL, &needs_reset, &initiate_reset);
		if (EFI_ERROR(status))
			break;
		offset += capsule->image_size;
	}
	/* Reserve publication bookkeeping before applying any FMP payload.  A
	 * failed reservation leaves the caller's update intact for a retry instead
	 * of reporting an allocation failure after a non-populate update ran. */
	if (!EFI_ERROR(status)) {
		published_capacity = total / sizeof(struct cdk2_capsule_header);
		if (published_capacity > MAX_UINTN / sizeof(*published))
			status = EFI_OUT_OF_RESOURCES;
		else
			status = allocate_pool(6U, published_capacity * sizeof(*published),
					       (void **)&published);
	}
	/* Validate and allocate every populate table before an FMP image can be
	 * changed.  This keeps a mixed scatter list retryable when publication
	 * bookkeeping runs out of memory. */
	for (offset = 0U; !EFI_ERROR(status) && offset < total;) {
		const struct cdk2_capsule_header *capsule = (const void *)(buffer + offset);

		if ((capsule->flags & CDK2_CAPSULE_POPULATE) != 0U) {
			install_configuration_table_fn *install =
				(void *)boot_services->install_configuration_table;
			struct capsule_table *table;
			UINTN scan, count = 0U, item = 0U;
			BOOLEAN first = TRUE;

			for (scan = 0U; scan < offset;) {
				const struct cdk2_capsule_header *prior =
					(const void *)(buffer + scan);
				if ((prior->flags & CDK2_CAPSULE_POPULATE) != 0U &&
				    guid_equal(&prior->guid, &capsule->guid))
					first = FALSE;
				scan += prior->image_size;
			}
			if (first) {
				for (scan = 0U; scan < total;) {
					const struct cdk2_capsule_header *candidate =
						(const void *)(buffer + scan);
					if ((candidate->flags & CDK2_CAPSULE_POPULATE) != 0U &&
					    guid_equal(&candidate->guid, &capsule->guid))
						count++;
					scan += candidate->image_size;
				}
				if (install == NULL || count > MAX_UINT32 ||
				    count > (MAX_UINTN - sizeof(*table)) /
				    sizeof(table->capsules[0])) {
					status = EFI_UNSUPPORTED;
					break;
				}
				status = allocate_pool(6U, sizeof(*table) + count *
					sizeof(table->capsules[0]), (void **)&table);
				if (EFI_ERROR(status))
					break;
				table->count = (UINT32)count;
				table->reserved = 0U;
				for (scan = 0U; scan < total;) {
					const struct cdk2_capsule_header *candidate =
						(const void *)(buffer + scan);
					if ((candidate->flags & CDK2_CAPSULE_POPULATE) != 0U &&
					    guid_equal(&candidate->guid, &capsule->guid))
						table->capsules[item++] = candidate;
					scan += candidate->image_size;
				}
				published[reserved_count++] = (struct published_table) {
					.guid = capsule->guid, .table = table
				};
			}
		}
		offset += capsule->image_size;
	}
	/* Installing tables is fallible too, so complete publication before a
	 * non-populate FMP update.  Later FMP failure can remove these tables. */
	for (offset = 0U; !EFI_ERROR(status) && offset < reserved_count; offset++) {
		install_configuration_table_fn *install =
			(void *)boot_services->install_configuration_table;

		status = install(&published[offset].guid, published[offset].table);
		if (!EFI_ERROR(status)) {
			published_count++;
			retain_buffer = TRUE;
		}
	}
	for (offset = 0U; !EFI_ERROR(status) && offset < total;) {
		const struct cdk2_capsule_header *capsule = (const void *)(buffer + offset);
		BOOLEAN provider_reset = FALSE;

		/* Every fallible publication step completed above, so FMP failure can
		 * now leave the scatter update intact for a retry. */
		if ((capsule->flags & CDK2_CAPSULE_POPULATE) == 0U)
			status = process_boot_capsule(capsule, &provider_reset);
		if (!EFI_ERROR(status) &&
		    (provider_reset || (capsule->flags & CDK2_CAPSULE_RESET) != 0U))
			update_reset = TRUE;
		offset += capsule->image_size;
	}
	if (!EFI_ERROR(status) && update_reset)
		protocol->reset_required = TRUE;
	if (EFI_ERROR(status)) {
		UINTN installed_count = published_count;

		while (reserved_count > installed_count)
			(void)free_pool(published[--reserved_count].table);
		if (published_count != 0U) {
			EFI_STATUS rollback = EFI_SUCCESS;
			install_configuration_table_fn *install =
				(void *)boot_services->install_configuration_table;

			while (published_count != 0U) {
				struct published_table *item = &published[--published_count];
				EFI_STATUS cleanup = install == NULL ? EFI_UNSUPPORTED :
					install(&item->guid, NULL);

				if (EFI_ERROR(cleanup)) {
					rollback = cleanup;
					retain_buffer = TRUE;
				} else {
					(void)free_pool(item->table);
				}
			}
			if (EFI_ERROR(rollback))
				status = rollback;
			else
				retain_buffer = FALSE;
		}
	}
	if (published != NULL)
		(void)free_pool(published);
	if (!retain_buffer)
		(void)free_pool(buffer);
done:
	if (memory_map != NULL)
		(void)free_pool(memory_map);
	return status;
}

static EFI_STATUS persist(UINTN sequence, UINT64 scatter_gather, void *context)
{
	set_variable_fn *set_variable = (void *)runtime_services->set_variable;
	CHAR16 name[32] = L"CapsuleUpdateData";
	UINTN value = sequence, digits = 0, index = 17;
	EFI_STATUS status;

	(void)context;
	CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] persist begin\n");
	if (set_variable == NULL)
		return EFI_OUT_OF_RESOURCES;
	if (sequence != 0U) {
		do {
			digits++;
			value /= 10U;
		} while (value != 0U);
		if (index + digits >= ARRAY_SIZE(name))
			return EFI_OUT_OF_RESOURCES;
		value = sequence;
		index += digits;
		name[index] = 0;
		while (digits-- != 0U) {
			name[--index] = (CHAR16)(L'0' + value % 10U);
			value /= 10U;
		}
	}
	status = set_variable(name, (EFI_GUID *)&capsule_vendor_guid, 7U,
		sizeof(scatter_gather), &scatter_gather);
	if (EFI_ERROR(status))
		CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][error] persist failed\n");
	else
		CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] persist complete\n");
	return status;
}

static BOOLEAN capsule_covered(UINT64 scatter_gather, UINT64 start, UINT64 size,
	UINT64 limit)
{
	struct capsule_block { UINT64 length, address; };
	const struct capsule_block *block;
	UINT64 cursor = start;
	UINT64 end;
	UINTN walked = 0U;

	if (start > MAX_UINT64 - size)
		return FALSE;
	block = (const void *)(UINTN)scatter_gather;
	if (virtual_mode && EFI_ERROR(convert((void **)&block, NULL)))
		return FALSE;
	end = start + size;
	while (block != NULL && walked++ <= limit) {
		UINT64 block_end;
		if (block->length == 0U) {
			if (block->address == 0U)
				break;
			block = (const void *)(UINTN)block->address;
			if (virtual_mode && EFI_ERROR(convert((void **)&block, NULL)))
				return FALSE;
			continue;
		}
		if (block->address > MAX_UINT64 - block->length)
			return FALSE;
		{
			const void *mapped = (const void *)(UINTN)block->address;
			UINT64 mapped_start;
			if (virtual_mode && EFI_ERROR(convert((void **)&mapped, NULL)))
				return FALSE;
			mapped_start = (UINT64)(UINTN)mapped;
			if (mapped_start > MAX_UINT64 - block->length)
				return FALSE;
			block_end = mapped_start + block->length;
			if (mapped_start <= cursor && block_end > cursor)
				cursor = block_end < end ? block_end : end;
		}
		if (cursor == end)
			return TRUE;
		block++;
	}
	return FALSE;
}

static EFI_STATUS writeback(UINT64 scatter_gather,
	const struct cdk2_capsule_header *const *capsules, UINTN count, void *context)
{
	struct capsule_block { UINT64 length, address; };
	const struct capsule_block *block = (const void *)(UINTN)scatter_gather;
	UINTN walked = 0;
	UINT64 limit = policy.max_populate > policy.max_nonpopulate ?
		policy.max_populate : policy.max_nonpopulate;
	EFI_STATUS status;
	UINTN index;
	(void)context;
	CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] writeback begin\n");
	/* Scatter/gather addresses remain physical at runtime and may describe ACPI
	 * NVS, which is deliberately absent from the virtual-address map.  The OS
	 * has completed these writes before entering the runtime service, so do not
	 * dereference or ConvertPointer such physical storage after the transition. */
	if (virtual_mode)
		return EFI_SUCCESS;
	for (index = 0; index < count; index++)
		if ((capsules[index]->flags & CDK2_CAPSULE_PERSIST) != 0U &&
		    !capsule_covered(scatter_gather, (UINT64)(UINTN)capsules[index],
		    capsules[index]->image_size, limit))
			return EFI_INVALID_PARAMETER;
	while (block != NULL && walked++ <= limit) {
		status = cdk2_capsule_cache_writeback_range_all_cpus((UINT64)(UINTN)block,
			sizeof(*block));
		if (EFI_ERROR(status))
			return status;
		if (block->length == 0U) {
			if (block->address == 0U) {
				CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] writeback complete\n");
				return EFI_SUCCESS;
			}
			block = (const void *)(UINTN)block->address;
			if (virtual_mode && EFI_ERROR(convert((void **)&block, NULL)))
				return EFI_INVALID_PARAMETER;
			continue;
		}
		if (block->address > MAX_UINT64 - block->length)
			return EFI_INVALID_PARAMETER;
		{
			void *payload = (void *)(UINTN)block->address;
			if (virtual_mode && EFI_ERROR(convert(&payload, NULL)))
				return EFI_INVALID_PARAMETER;

			status = cdk2_capsule_cache_writeback_range_all_cpus(
				(UINT64)(UINTN)payload, block->length);
		}
		if (EFI_ERROR(status))
			return status;
		block++;
	}
	return EFI_INVALID_PARAMETER;
}

static void warm_reset(void *context)
{
	reset_system_fn *reset = (void *)runtime_services->reset_system;

	(void)context;
	CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] warm reset\n");
	if (reset != NULL)
		reset(1U, EFI_SUCCESS, 0, NULL);
}

static EFI_STATUS CDK2_MS_ABI update_capsule(
	const struct cdk2_capsule_header *const *capsules, UINTN count, UINT64 scatter_gather)
{
	UINT64 total = 0U;
	UINT64 limit = policy.max_populate > policy.max_nonpopulate ?
		policy.max_populate : policy.max_nonpopulate;
	EFI_STATUS status;

	CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] UpdateCapsule begin\n");
	if (capsules == NULL || count == 0U)
		return EFI_INVALID_PARAMETER;
	if (!policy.in_ram)
		return EFI_UNSUPPORTED;
	for (UINTN index = 0U; index < count; index++) {
		if (capsules[index] == NULL ||
		    capsules[index]->image_size > MAX_UINT64 - total)
			return EFI_INVALID_PARAMETER;
		total += capsules[index]->image_size;
	}
	if (total > limit)
		return EFI_OUT_OF_RESOURCES;
	CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] UpdateCapsule preflight\n");
	status = cdk2_capsule_update(&runtime, capsules, count, scatter_gather, &policy,
		support);
	if (EFI_ERROR(status))
		CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][error] UpdateCapsule failed\n");
	else
		CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] UpdateCapsule complete\n");
	return status;
}

static EFI_STATUS CDK2_MS_ABI query_capsule(
	const struct cdk2_capsule_header *const *capsules, UINTN count,
	cdk2_uint64_ptr maximum_size, cdk2_uint32_ptr reset_type)
{
	UINTN index;
	EFI_STATUS status;

	if (capsules == NULL || count == 0U || maximum_size == NULL || reset_type == NULL)
		return EFI_INVALID_PARAMETER;
	if (!policy.in_ram)
		return EFI_UNSUPPORTED;
	if (runtime.exited_boot_services) {
		for (index = 0; index < count; index++)
			if (capsules[index] != NULL &&
			    (capsules[index]->flags & CDK2_CAPSULE_PERSIST) == 0U)
				return EFI_OUT_OF_RESOURCES;
	}
	status = cdk2_capsule_query(capsules, count, &policy, support, NULL,
		maximum_size, reset_type);
	if (EFI_ERROR(status))
		CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][error] QueryCapsuleCapabilities failed\n");
	return status;
}

static EFI_STATUS convert(void **pointer, void *context)
{
	convert_pointer_fn *convert_pointer = (void *)runtime_services->convert_pointer;

	(void)context;
	return convert_pointer == NULL ? EFI_UNSUPPORTED : convert_pointer(0, pointer);
}

static void CDK2_MS_ABI virtual_address_change(void *event, void *context)
{
	EFI_STATUS status;
	(void)event;
	(void)context;
	if (!runtime_active)
		return;
	cdk2_diag_runtime_transition();
#ifdef CDK2_DIAG_RUNTIME_TRANSITION_TEST
	cdk2_diag_runtime_transition_test_after();
#endif
	status = convert((void **)&runtime_services, NULL);
	if (!EFI_ERROR(status))
		status = cdk2_capsule_convert_runtime(&runtime, convert, NULL);
	if (!EFI_ERROR(status))
		virtual_mode = TRUE;
}

static void CDK2_MS_ABI exit_boot_services(void *event, void *context)
{
	(void)event;
	(void)context;
	if (!runtime_active)
		return;
	runtime.exited_boot_services = TRUE;
}

static void restore_slots(struct cdk2_runtime_services_view *rt, void *old_update,
	void *old_query, UINT32 old_crc)
{
	rt->update_capsule = old_update;
	rt->query_capsule = old_query;
	rt->header.crc32 = old_crc;
}

EFI_STATUS CDK2_MS_ABI cdk2_capsule_runtime_entry(void *image,
	struct cdk2_system_table_view *system)
{
	create_event_ex_fn *create_event_ex;
	install_multiple_fn *install_multiple;
	uninstall_multiple_fn *uninstall_multiple;
	void *old_update, *old_query;
	UINT32 old_crc;
	EFI_STATUS status, uninstall_status;
	const struct cdk2_dxe_configuration_table *tables;
	const void *hob_list = NULL;
	BOOLEAN duplicate_hob_list = FALSE;

	(void)image;
	if (system == NULL || system->boot == NULL || system->runtime == NULL)
		return EFI_INVALID_PARAMETER;
	CDK2_DIAG_CONFIGURE_OPTIONAL_SYSTEM_TABLE(system);
	boot_protocol.delivery_policy = (struct cdk2_capsule_delivery_policy) { 0 };
	if (system->table_entries <= 256U &&
	    (system->table_entries == 0U || (system->configuration_table != NULL &&
	     ((UINTN)system->configuration_table & 7U) == 0U &&
	     (UINTN)system->configuration_table <= MAX_UINTN -
		(system->table_entries * sizeof(*tables))))) {
		const EFI_GUID hob_list_guid = { 0x7739f24c, 0x93d7, 0x11d4,
			{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };

		tables = system->configuration_table;
		for (UINTN index = 0; index < system->table_entries; index++) {
			if (memcmp(&tables[index].guid, &hob_list_guid, sizeof(hob_list_guid)))
				continue;
			if (hob_list != NULL || tables[index].table == NULL)
				duplicate_hob_list = TRUE;
			hob_list = tables[index].table;
		}
		if (!duplicate_hob_list)
			(void)cdk2_capsule_delivery_policy_from_hobs(hob_list,
				&boot_protocol.delivery_policy);
	}
	policy = (struct cdk2_capsule_policy) {
		.max_nonpopulate = boot_protocol.delivery_policy.max_nonpopulate,
		.max_populate = boot_protocol.delivery_policy.max_populate,
		.in_ram = (boot_protocol.delivery_policy.allowed_transports &
			CB_CAPSULE_DELIVERY_RAM) != 0U,
		.persist = boot_protocol.delivery_policy.allowed_transports != 0U,
	};
	runtime_services = system->runtime;
	boot_services = system->boot;
	boot_protocol.process_scatter = process_scatter;
	boot_protocol.validate_capsule = validate_capsule;
	boot_protocol.process_capsule = process_capsule;
	boot_protocol.reset_required = FALSE;
	runtime_active = TRUE;
	old_update = system->runtime->update_capsule;
	old_query = system->runtime->query_capsule;
	old_crc = system->runtime->header.crc32;
	runtime = (struct cdk2_capsule_runtime) {
		.context = system,
		.process = process,
		.persist = persist,
		.writeback = writeback,
		.warm_reset = warm_reset,
	};
	status = cdk2_capsule_install_runtime_slots(system->runtime, system->boot,
		update_capsule, query_capsule);
	if (EFI_ERROR(status)) {
		CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][error] runtime service installation failed\n");
		return status;
	}
	CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] runtime context sized and installed\n");
	install_multiple = system->boot->install_multiple;
	if (install_multiple == NULL) {
		status = EFI_UNSUPPORTED;
		goto restore;
	}
	capsule_handle = NULL;
	status = install_multiple(&capsule_handle, &capsule_arch_guid, NULL,
		&capsule_boot_guid, &boot_protocol, NULL);
	if (EFI_ERROR(status))
		goto restore;
	create_event_ex = (void *)system->boot->create_event_ex;
	if (create_event_ex == NULL) {
		status = EFI_UNSUPPORTED;
		goto uninstall;
	}
	if (boot_slot(112U) == NULL) {
		status = EFI_UNSUPPORTED;
		goto uninstall;
	}
	va_event = NULL;
	status = create_event_ex(EVT_NOTIFY_SIGNAL, TPL_NOTIFY, virtual_address_change,
		NULL, &va_change_guid, &va_event);
	if (EFI_ERROR(status))
		goto uninstall;
	ebs_event = NULL;
	status = create_event_ex(EVT_NOTIFY_SIGNAL, TPL_NOTIFY, exit_boot_services,
		NULL, &ebs_guid, &ebs_event);
	if (!EFI_ERROR(status)) {
		CDK2_DIAG_LITERAL("[CDK2][capsule-runtime][info] runtime policy and events ready\n");
		return EFI_SUCCESS;
	}
uninstall:
	uninstall_multiple = system->boot->uninstall_multiple;
	if (uninstall_multiple == NULL) {
		close_event_fn *close_event = (void *)boot_slot(112U);
		if (close_event != NULL && va_event != NULL)
			(void)close_event(va_event);
		if (close_event != NULL && ebs_event != NULL)
			(void)close_event(ebs_event);
		va_event = NULL;
		ebs_event = NULL;
		runtime_active = FALSE;
		restore_slots(system->runtime, old_update, old_query, old_crc);
		return EFI_UNSUPPORTED;
	}
	uninstall_status = uninstall_multiple(capsule_handle, &capsule_arch_guid, NULL,
		&capsule_boot_guid, &boot_protocol, NULL);
	if (EFI_ERROR(uninstall_status)) {
		close_event_fn *close_event = (void *)boot_slot(112U);
		if (close_event != NULL && va_event != NULL)
			(void)close_event(va_event);
		if (close_event != NULL && ebs_event != NULL)
			(void)close_event(ebs_event);
		va_event = NULL;
		ebs_event = NULL;
		runtime_active = FALSE;
		restore_slots(system->runtime, old_update, old_query, old_crc);
		return uninstall_status;
	}
	runtime_active = FALSE;
	{
		close_event_fn *close_event = (void *)boot_slot(112U);
		if (close_event != NULL && va_event != NULL)
			(void)close_event(va_event);
		if (close_event != NULL && ebs_event != NULL)
			(void)close_event(ebs_event);
		va_event = NULL;
		ebs_event = NULL;
	}
	capsule_handle = NULL;
restore:
	runtime_active = FALSE;
	restore_slots(system->runtime, old_update, old_query, old_crc);
	return status;
}
