/* SPDX-License-Identifier: GPL-2.0-only */

#include <cdk2/system_fmp_crypto.h>
#include <cdk2/system_fmp_provider.h>
#include <cdk2/system_fmp_trust.h>
#include <cdk2/coreboot_hob.h>
#include <pi/hob.h>

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "../../boot/coreboot.h"

#define MAX_CONFIGURATION_TABLES 256U

typedef EFI_STATUS CDK2_MS_ABI install_fn(void **, ...);
typedef EFI_STATUS CDK2_MS_ABI uninstall_fn(void *, ...);
typedef EFI_STATUS CDK2_MS_ABI handle_protocol_fn(void *, EFI_GUID *, void **);
typedef EFI_STATUS CDK2_MS_ABI unload_fn(void *);

struct configuration_table_view {
	EFI_GUID guid;
	void *table;
};

struct loaded_image_protocol {
	UINT32 revision;
	void *parent_handle;
	void *system_table;
	void *device_handle;
	void *file_path;
	void *reserved;
	UINT32 load_options_size;
	void *load_options;
	void *image_base;
	UINT64 image_size;
	UINT32 image_code_type;
	UINT32 image_data_type;
	unload_fn *unload;
};

static const EFI_GUID hob_list_guid = {
	0x7739f24c, 0x93d7, 0x11d4,
	{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d }
};
static const EFI_GUID loaded_image_guid = {
	0x5b1b31a1, 0x9562, 0x11d2,
	{ 0x8e, 0x3f, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b }
};
static const EFI_GUID check_outcome_guid = CDK2_CAPSULE_CHECK_OUTCOME_GUID;

static struct cdk2_system_table_view *system_table;
static struct cdk2_coreboot_handoff coreboot;
static struct cdk2_system_fmp_provider provider;
static struct loaded_image_protocol *loaded_image;
static unload_fn *prior_unload;
static void *image_handle;
static void *protocol_handle;
static bool protocol_installed;
static bool provider_initialized;

static bool object_valid(const void *object, size_t size)
{
	return object != NULL && size != 0U &&
		(uintptr_t)object <= UINTPTR_MAX - (size - 1U);
}

static EFI_STATUS coreboot_handoff_from_system(
	const struct cdk2_system_table_view *system,
	struct cdk2_coreboot_handoff *handoff)
{
	const struct configuration_table_view *tables;
	const EFI_HOB_HANDOFF_INFO_TABLE *list = NULL;
	size_t index;
	EFI_STATUS status;

	if (!object_valid(system, sizeof(*system)) ||
	    !object_valid(handoff, sizeof(*handoff)) ||
	    system->table_entries > MAX_CONFIGURATION_TABLES ||
	    (system->table_entries != 0U &&
	     (system->configuration_table == NULL ||
	      ((uintptr_t)system->configuration_table &
	       (_Alignof(struct configuration_table_view) - 1U)) != 0U ||
	      (uintptr_t)system->configuration_table > UINTPTR_MAX -
		(system->table_entries * sizeof(*tables)))))
		return EFI_INVALID_PARAMETER;
	tables = system->configuration_table;
	for (index = 0U; index < system->table_entries; index++) {
		if (memcmp(&tables[index].guid, &hob_list_guid,
			   sizeof(hob_list_guid)) != 0)
			continue;
		if (list != NULL || tables[index].table == NULL)
			return EFI_COMPROMISED_DATA;
		list = tables[index].table;
	}
	if (list == NULL)
		return EFI_NOT_FOUND;
	status = cdk2_coreboot_handoff_from_hobs(list, handoff);
	return status == EFI_NOT_FOUND ? EFI_COMPROMISED_DATA : status;
}

static EFI_STATUS hash(void *context, const void *data, UINTN size,
	UINT8 output[CDK2_SYSTEM_FMP_DIGEST_SIZE])
{
	(void)context;
	if (data == NULL || size == 0U || output == NULL)
		return EFI_INVALID_PARAMETER;
	cdk2_system_fmp_sha256(data, size, output);
	return EFI_SUCCESS;
}

static EFI_STATUS cache_bounds(void *base, size_t size, uintptr_t *first,
	uintptr_t *last)
{
	uintptr_t end;

	if (base == NULL || size == 0U || first == NULL || last == NULL ||
	    (uintptr_t)base > UINTPTR_MAX - size)
		return EFI_INVALID_PARAMETER;
	end = (uintptr_t)base + size;
	*first = (uintptr_t)base & ~(uintptr_t)63U;
	*last = (end - 1U) & ~(uintptr_t)63U;
	return EFI_SUCCESS;
}

static EFI_STATUS cache_range(void *context, void *base, UINTN size)
{
	uintptr_t address;
	uintptr_t last;
	EFI_STATUS status;

	(void)context;
	status = cache_bounds(base, size, &address, &last);
	if (EFI_ERROR(status))
		return status;
	for (;;) {
		__asm__ volatile("clflush (%0)" : : "r"((void *)address) : "memory");
		if (address == last)
			break;
		address += 64U;
	}
	__asm__ volatile("mfence" : : : "memory");
	return EFI_SUCCESS;
}

#ifdef CDK2_SYSTEM_FMP_ENTRY_TEST
EFI_STATUS cdk2_system_fmp_test_cache_bounds(void *base, size_t size,
	uintptr_t *first, uintptr_t *last)
{
	return cache_bounds(base, size, first, last);
}

EFI_STATUS cdk2_system_fmp_test_coreboot_handoff(
	const struct cdk2_system_table_view *system,
	struct cdk2_coreboot_handoff *handoff)
{
	return coreboot_handoff_from_system(system, handoff);
}
#endif

static void barrier(void *context)
{
	(void)context;
	__asm__ volatile("mfence" : : : "memory");
}

static EFI_STATUS trigger(void *context, UINT16 port, UINT8 value)
{
	(void)context;
	__asm__ volatile("outb %0, %1" : : "a"(value), "d"(port) : "memory");
	return EFI_SUCCESS;
}

static const struct cdk2_system_fmp_transport_port transport_port = {
	.sha256 = hash,
	.publish = cache_range,
	.acquire = cache_range,
	.barrier = barrier,
	.trigger_apm_io8 = trigger,
};

EFI_STATUS CDK2_MS_ABI cdk2_system_fmp_entry(void *image,
	struct cdk2_system_table_view *system)
{
	struct cdk2_system_fmp_session_config config;
	handle_protocol_fn *handle_protocol;
	install_fn *install;
	EFI_STATUS status;

	if (image == NULL || !object_valid(system, sizeof(*system)) ||
	    !object_valid(system->boot, sizeof(*system->boot)))
		return EFI_INVALID_PARAMETER;
	if (system_table != NULL || protocol_handle != NULL)
		return EFI_ALREADY_STARTED;
	if (provider_initialized) {
		status = cdk2_system_fmp_provider_close(&provider);
		if (EFI_ERROR(status))
			return status;
		provider_initialized = false;
	}
	status = coreboot_handoff_from_system(system, &coreboot);
	if (EFI_ERROR(status))
		return status;
	config = (struct cdk2_system_fmp_session_config) {
		.coreboot = &coreboot,
		.certificate_xdr = cdk2_system_fmp_starlabs_certificates,
		.certificate_xdr_size =
			CDK2_SYSTEM_FMP_STARLABS_CERTIFICATES_SIZE,
		.dependency_versions = NULL,
		.dependency_version_count = 0U,
		.transport_port = transport_port,
	};
	status = cdk2_system_fmp_provider_initialize(&provider, &config);
	if (EFI_ERROR(status))
		return status;
	provider_initialized = true;
	handle_protocol = (void *)system->boot->handle_protocol;
	install = (void *)system->boot->install_multiple;
	if (handle_protocol == NULL || install == NULL) {
		status = EFI_UNSUPPORTED;
		goto fail;
	}
	status = handle_protocol(image, (EFI_GUID *)&loaded_image_guid,
		(void **)&loaded_image);
	if (EFI_ERROR(status) || loaded_image == NULL) {
		if (!EFI_ERROR(status))
			status = EFI_NOT_FOUND;
		goto fail;
	}
	image_handle = image;
	prior_unload = loaded_image->unload;
	system_table = system;
	status = install(&protocol_handle,
		(EFI_GUID *)&cdk2_system_fmp_protocol_guid, &provider.protocol,
		(EFI_GUID *)&check_outcome_guid, &provider.check_outcome, NULL);
	if (EFI_ERROR(status))
		goto fail;
	protocol_installed = true;
	loaded_image->unload = cdk2_system_fmp_unload;
	return EFI_SUCCESS;

fail:
	{
		EFI_STATUS close_status = cdk2_system_fmp_provider_close(&provider);

		if (!EFI_ERROR(close_status))
			provider_initialized = false;
		else
			status = close_status;
	}
	loaded_image = NULL;
	prior_unload = NULL;
	image_handle = NULL;
	protocol_handle = NULL;
	protocol_installed = false;
	system_table = NULL;
	return status;
}

EFI_STATUS CDK2_MS_ABI cdk2_system_fmp_unload(void *image)
{
	uninstall_fn *uninstall;
	EFI_STATUS status;

	if (system_table == NULL || protocol_handle == NULL)
		return EFI_NOT_STARTED;
	if (image != image_handle)
		return EFI_INVALID_PARAMETER;
	if (provider.busy)
		return EFI_ACCESS_DENIED;
	uninstall = (void *)system_table->boot->uninstall_multiple;
	if (uninstall == NULL)
		return EFI_UNSUPPORTED;
	if (protocol_installed) {
		status = uninstall(protocol_handle,
			(EFI_GUID *)&cdk2_system_fmp_protocol_guid,
			&provider.protocol,
			(EFI_GUID *)&check_outcome_guid, &provider.check_outcome, NULL);
		if (EFI_ERROR(status))
			return status;
		protocol_installed = false;
	}
	status = cdk2_system_fmp_provider_close(&provider);
	if (EFI_ERROR(status))
		return status;
	provider_initialized = false;
	loaded_image->unload = prior_unload;
	loaded_image = NULL;
	prior_unload = NULL;
	image_handle = NULL;
	protocol_handle = NULL;
	protocol_installed = false;
	system_table = NULL;
	return EFI_SUCCESS;
}
