#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
config=${1:?actual resolved config header required}
temporary=$(mktemp -d "${TMPDIR:-/tmp}/capsule-window-core.XXXXXX")
trap 'rm -rf "$temporary"' EXIT HUP INT TERM
mkdir -p "$temporary/cdk2"
cp "$config" "$temporary/cdk2/config.h"
grep -qx '#define CONFIG_CDK2_LINEAR_BOOT 1' "$temporary/cdk2/config.h"
export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
entry=$root/src/modules/dxe_core/entry.c

compile()
{
	"${HOSTCC:-cc}" -std=c11 "$optimization" -Wall -Wextra -Werror -fshort-wchar \
		-ffunction-sections -fdata-sections -fno-pie -no-pie \
		-fsanitize=address,undefined -fno-sanitize-recover=all \
		-DCDK2_HOST_TEST -DCDK2_DXE_CAPSULE_DISK_SOURCE="\"$1\"" \
		-I"$temporary" -I"$root/include" -I"$root/src/modules/dxe_core" \
		-I"$root/src/lib/tcg_hash/vendor/linux/include" \
		-o "$2" "$root/tests/capsule_ram_window_core_test.c" \
		"$root/src/modules/dxe_core/database.c" \
		"$root/src/modules/dxe_core/lifecycle.c" \
		"$root/src/modules/dxe_core/presence_lifecycle.c" \
		"$root/src/modules/dxe_core/memory.c" \
		"$root/src/modules/dxe_core/image.c" \
		"$root/src/lib/tcg_hash/software_hash.c" \
		"$root/src/lib/tcg_hash/vendor/vboot/2sha1.c" \
		"$root/src/lib/tcg_hash/vendor/vboot/2sha256.c" \
		"$root/src/lib/tcg_hash/vendor/vboot/2sha512.c" \
		"$root/src/lib/tcg_hash/vendor/linux/lib/crypto/sm3.c" \
		"$root/src/lib/linear_boot.c" "$root/src/lib/capsule_disk.c" \
		"$root/src/lib/diagnostic.c" "$root/src/lib/deadline.c" \
		"$root/src/modules/system_fmp/transport.c" -Wl,--gc-sections
}

for optimization in -O0 -O2; do
	compile "$entry" "$temporary/positive"
	"$temporary/positive"
	for mutation in gate reset; do
		case "$mutation" in
		gate)
			needle='EFI_STATUS closed = close_ram_window(context);'
			replacement='EFI_STATUS closed = EFI_SUCCESS;'
			expected='close_calls == 1 && context.capsule_client.ram_closed'
			;;
		reset)
			needle='status = close_ram_window(context);'
			replacement='status = EFI_SUCCESS; /* reset close removed */'
			expected='close_calls == 1 && !close_refused && !pointer_live'
			;;
		esac
		awk -v needle="$needle" -v replacement="$replacement" -v mutation="$mutation" '
			index($0, needle) && (mutation != "reset" || previous ~ /if \(context != NULL\)/) {
				matches++; position=index($0, needle);
				$0=substr($0,1,position-1) replacement substr($0,position+length(needle))
			}
			{ print; previous=$0 }
			END { if (matches != 1) exit 1 }
		' "$entry" > "$temporary/mutant.c"
		# Fixed-string reconstruction avoids treating the call as a regex.
		awk -v needle="$replacement" -v replacement="$needle" '
			index($0, needle) {
				matches++; position=index($0, needle);
				$0=substr($0,1,position-1) replacement substr($0,position+length(needle))
			}
			{ print }
			END { if (matches != 1) exit 1 }
		' "$temporary/mutant.c" > "$temporary/restored.c"
		cmp "$entry" "$temporary/restored.c"
		compile "$temporary/mutant.c" "$temporary/mutant"
		status=0
		"$temporary/mutant" > "$temporary/mutant.log" 2>&1 || status=$?
		test "$status" -eq 134
		grep -F "FAIL: $expected" "$temporary/mutant.log"
		! grep -Eq 'AddressSanitizer|LeakSanitizer|UndefinedBehaviorSanitizer|runtime error:' "$temporary/mutant.log"
		printf '%s\n' "Core RAM window $mutation causal $optimization: PASS"
	done
done
