#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
test "$#" -gt 1
configuration=$1
shift
temporary=$(mktemp -d)
trap 'rm -rf "$temporary"' EXIT HUP INT TERM
ulimit -c 0
mkdir -p "$temporary/include/cdk2"
awk -v guard="$temporary/guard.txt" '
	$0 == "EFI_STATUS CDK2_MS_ABI cdk2_dxe_core_entry(void *hob_list)" {
		inside_entry = 1; entries++
	}
	inside_entry && /^#if CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME && / {
		count++; removing = 1
	}
	removing {
		print > guard
		if ($0 == "#endif") removing = 0
		next
	}
	!removing { print }
	END { if (entries != 1 || count != 1 || removing) exit 1 }
' "$root/src/modules/dxe_core/entry.c" > "$temporary/no-gate.c"
! cmp -s "$temporary/no-gate.c" "$root/src/modules/dxe_core/entry.c"
# Verify reversal of the one scoped removal against the full actual TU.
awk -v guard="$temporary/guard.txt" '
	$0 == "\t/* Absence or rejection preserves the allocation-free COM1 fallback. */" {
		insertions++
		while ((getline line < guard) > 0) print line
		close(guard)
	}
	{ print }
	END { if (insertions != 1) exit 1 }
' "$temporary/no-gate.c" | cmp - "$root/src/modules/dxe_core/entry.c"
for profile in legacy supported missing-security; do
	selected=1 security=1
	case $profile in legacy) selected=0 ;; missing-security) security=0 ;; esac
	awk -v selected="$selected" -v security="$security" '
		$1 == "#define" {
			key = $2
			if (key == "CONFIG_CDK2_PROTECTED_VARIABLE_RUNTIME") {
				protected_count++; $3 = selected
			} else if (key == "CONFIG_CDK2_NATIVE_SECURITY_STUB") {
				security_count++; $3 = security
			} else if (key == "CONFIG_CDK2_LINEAR_BOOT" ||
				key == "CONFIG_CDK2_STRICT_DIRECT_RUNTIME" ||
				key == "CONFIG_CDK2_NATIVE_VARIABLE_RUNTIME") {
				prerequisites[key]++; $3 = 1
			}
		}
		{ print }
		END {
			if (protected_count != 1 || security_count != 1 ||
			    prerequisites["CONFIG_CDK2_LINEAR_BOOT"] != 1 ||
			    prerequisites["CONFIG_CDK2_STRICT_DIRECT_RUNTIME"] != 1 ||
			    prerequisites["CONFIG_CDK2_NATIVE_VARIABLE_RUNTIME"] != 1) exit 1
		}
	' "$configuration" > "$temporary/include/cdk2/config.h"
	# Local caller-component profiles are not source/Kconfig admission proofs.
	# Both call the real linear native entry, including non-linear base headers.
	for optimization in 0 2; do
		for variant in original no-gate; do
			if test "$variant:$profile:$optimization" != no-gate:missing-security:2 &&
			   test "$variant" = no-gate; then
				continue
			fi
			entry="$root/src/modules/dxe_core/entry.c"
			if test "$variant" = no-gate; then entry="$temporary/no-gate.c"; fi
			"${HOSTCC:-cc}" -std=c11 -O"$optimization" -Wall -Wextra -Werror \
				-fshort-wchar -ffunction-sections -fdata-sections \
				-fsanitize=address,undefined -fno-sanitize-recover=all \
				-fno-pie -no-pie -DCDK2_HOST_TEST -UNDEBUG \
				-I"$temporary/include" -I"$root/include" \
				-I"$root/src/lib/tcg_hash/vendor/linux/include" \
				-I"$root/src/modules/dxe_core" \
				"$root/tests/protected_variable_boot_gate_test.c" "$entry" "$@" \
				-Wl,--gc-sections -Wl,--wrap=cdk2_linear_run \
				-Wl,--wrap=cdk2_authvar_native_x86_trigger \
				-Wl,--wrap=cdk2_authvar_native_x86_cache \
				-Wl,--wrap=cdk2_authvar_native_x86_barrier \
				-o "$temporary/entry"
			status=0
			ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 \
				"$temporary/entry" > "$temporary/$variant.log" 2>&1 || status=$?
			if test "$variant" = original; then
				cat "$temporary/$variant.log"
				test "$status" = 0
			else
				test "$status" = 134
				grep -Fq 'phase_calls == 0' "$temporary/$variant.log"
				! grep -Eq 'Sanitizer|runtime error:' "$temporary/$variant.log"
			fi
		done
	done
done
echo 'HOST actual boot-entry: supported/legacy dispatch sentinels and partial-shape refusal O0/O2; scoped guard-deletion causal assertion: PASS'
