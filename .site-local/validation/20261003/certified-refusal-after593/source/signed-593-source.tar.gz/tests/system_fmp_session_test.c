/* SPDX-License-Identifier: GPL-2.0-only */

#include <assert.h>
#include <cdk2/system_fmp_auth.h>
#include <cdk2/system_fmp_board_binding.h>
#include <cdk2/system_fmp_crypto.h>
#include <cdk2/system_fmp_payload.h>
#include <cdk2/system_fmp_session.h>
#include <stdio.h>
#include <string.h>

#include "../src/boot/coreboot.h"

void cdk2_qemu_fmp_sha256(const void *data, UINTN size, UINT8 out[32]);

struct fixture {
	struct cdk2_system_fmp_session session;
	struct cdk2_system_fmp_session_request request;
	struct cdk2_system_fmp_dependency_version dependency;
	struct cdk2_coreboot_handoff coreboot;
	uint8_t coreboot_table[256];
	uint8_t certificate[8];
	uint8_t envelope[256];
	char trace[64];
	size_t trace_size;
	unsigned int executes;
	unsigned int closes;
	bool auth_fail;
	bool board_fail;
	bool board_unbound_success;
	bool mutate_during_board;
	bool mutate_during_broker;
	bool mutate_request;
	bool reenter;
	bool close_fail;
	bool payload_reject;
	enum cdk2_system_fmp_transport_status execute_status;
	unsigned int mutation_event;
	unsigned int mutation_target;
	bool policy_mutated;
};

static struct fixture *active;
static const EFI_GUID image_type = { .data1 = 0x975cd0e6U };

void cdk2_system_fmp_sha256(const void *data, size_t size, uint8_t out[32])
{
	cdk2_qemu_fmp_sha256(data, size, out);
}

static void mutate_policy(unsigned int event);

static void trace(char event)
{
	assert(active->trace_size + 1U < sizeof(active->trace));
	active->trace[active->trace_size++] = event;
	active->trace[active->trace_size] = '\0';
}

static EFI_STATUS hash(void *context, const void *data, UINTN size,
	UINT8 digest[CDK2_SYSTEM_FMP_DIGEST_SIZE])
{
	(void)context;
	mutate_policy(5U);
	cdk2_qemu_fmp_sha256(data, size, digest);
	return EFI_SUCCESS;
}

static void mutate_policy(unsigned int event)
{
	if (active->policy_mutated || active->mutation_event != event)
		return;
	active->policy_mutated = true;
	switch (active->mutation_target) {
	case 1U:
		active->session.certificate_xdr[0] ^= 1U;
		break;
	case 2U:
		active->session.dependency_versions[0].version++;
		break;
	case 3U:
		active->session.info.current_version++;
		break;
	case 4U:
		active->session.client.endpoint.image_size++;
		break;
	case 5U:
		active->session.certificate_xdr_size--;
		break;
	case 6U:
		active->session.dependency_version_count = 0U;
		break;
	case 7U:
		active->session.board_identity.vendor[0] ^= 1U;
		break;
	case 8U:
		active->session.client.port.publish = NULL;
		break;
	default:
		assert(false);
	}
}

static EFI_STATUS cache(void *context, void *base, UINTN size)
{
	(void)context;
	(void)base;
	(void)size;
	return EFI_SUCCESS;
}

static void barrier(void *context)
{
	(void)context;
}

static EFI_STATUS trigger(void *context, UINT16 port, UINT8 value)
{
	(void)context;
	(void)port;
	(void)value;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_transport_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_transport *transport)
{
	assert(coreboot == &active->coreboot);
	trace('T');
	memset(transport, 0, sizeof(*transport));
	transport->revision = CB_CAPSULE_BROKER_ENDPOINT_REVISION;
	transport->generation = 7U;
	transport->image_type = image_type;
	transport->current_version = 9U;
	transport->lowest_supported_version = 7U;
	transport->image_size = 64U;
	transport->capabilities = CB_CAPSULE_BROKER_REQUIRED_CAPABILITIES;
	transport->communication_base = 0x1000U;
	transport->communication_size = CDK2_SYSTEM_FMP_TRANSPORT_SIZE;
	transport->message_size = CDK2_SYSTEM_FMP_TRANSPORT_SIZE;
	transport->staging_base = 0x2000U;
	transport->staging_size = sizeof(active->envelope);
	transport->trigger_port = 0xb2U;
	transport->trigger_value = 0x77U;
	transport->valid = TRUE;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_board_identity_from_coreboot(
	const struct cdk2_coreboot_handoff *coreboot,
	struct cdk2_system_fmp_board_identity *identity)
{
	assert(coreboot == &active->coreboot);
	memset(identity, 0, sizeof(*identity));
	memcpy(identity->vendor, "Star Labs", 9U);
	identity->vendor_size = 9U;
	memcpy(identity->part, "Lite", 4U);
	identity->part_size = 4U;
	return EFI_SUCCESS;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_init(
	struct cdk2_system_fmp_client *client,
	const struct cdk2_system_fmp_transport *endpoint,
	const struct cdk2_system_fmp_transport_port *port)
{
	trace('I');
	memset(client, 0, sizeof(*client));
	client->endpoint = *endpoint;
	client->port = *port;
	client->initialized = TRUE;
	return CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_read_info(
	struct cdk2_system_fmp_client *client, struct cdk2_system_fmp_info *info)
{
	trace('R');
	*info = (struct cdk2_system_fmp_info) {
		.image_type = client->endpoint.image_type,
		.hardware_instance = 0x1234U,
		.current_version = client->endpoint.current_version,
		.lowest_supported_version = 8U,
		.image_size = client->endpoint.image_size,
		.capabilities = client->endpoint.capabilities,
	};
	return CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_execute(
	struct cdk2_system_fmp_client *client,
	enum cdk2_system_fmp_transport_operation operation, const void *image,
	UINTN image_size, UINT32 attempted_version,
	struct cdk2_system_fmp_outcome *outcome)
{
	struct cdk2_system_fmp_session_result ignored;

	(void)client;
	assert(operation == CDK2_SYSTEM_FMP_CHECK ||
		operation == CDK2_SYSTEM_FMP_SET);
	assert(image == active->envelope && image_size == sizeof(active->envelope));
	assert(attempted_version == 42U);
	trace('K');
	mutate_policy(4U);
	active->executes++;
	if (active->reenter)
		assert(cdk2_system_fmp_session_execute(&active->session,
			&active->request, &ignored) == EFI_ACCESS_DENIED);
	if (active->mutate_during_broker)
		active->envelope[255] ^= 1U;
	*outcome = (struct cdk2_system_fmp_outcome) {
		.transaction = 37U,
		.generation = 19U,
		.attempted_version = attempted_version,
		.last_attempt_status = CDK2_FMP_LAST_ATTEMPT_SUCCESS,
		.broker_result = CDK2_SYSTEM_FMP_RESULT_SUCCESS,
		.trigger_invoked = active->execute_status !=
			CDK2_SYSTEM_FMP_TRANSPORT_CAPACITY &&
			active->execute_status != CDK2_SYSTEM_FMP_TRANSPORT_HASH_FAILED &&
			active->execute_status != CDK2_SYSTEM_FMP_TRANSPORT_CACHE_FAILED,
		.response_authenticated = active->execute_status ==
			CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS ||
			active->execute_status ==
				CDK2_SYSTEM_FMP_TRANSPORT_EXECUTION_FAILED ||
			active->execute_status ==
				CDK2_SYSTEM_FMP_TRANSPORT_SIGNATURE_REFUSED,
	};
	if (active->execute_status == CDK2_SYSTEM_FMP_TRANSPORT_EXECUTION_FAILED) {
		outcome->last_attempt_status = CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL;
		outcome->broker_result = CDK2_SYSTEM_FMP_RESULT_EXECUTION;
	}
	if (active->execute_status == CDK2_SYSTEM_FMP_TRANSPORT_SIGNATURE_REFUSED) {
		outcome->last_attempt_status = CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL;
		outcome->broker_result = CDK2_SYSTEM_FMP_RESULT_SIGNATURE_REFUSED;
	}
	return active->execute_status;
}

enum cdk2_system_fmp_transport_status cdk2_system_fmp_client_close(
	struct cdk2_system_fmp_client *client)
{
	trace('C');
	active->closes++;
	if (active->close_fail)
		return CDK2_SYSTEM_FMP_TRANSPORT_CACHE_FAILED;
	memset(client, 0, sizeof(*client));
	return CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
}

bool cdk2_system_fmp_pkcs7_verify(void *context, const uint8_t *signature,
	size_t signature_size, const uint8_t *certificate, size_t certificate_size,
	const struct cdk2_system_fmp_signed_span signed_data[2])
{
	(void)context;
	(void)signature;
	(void)signature_size;
	(void)certificate;
	(void)certificate_size;
	(void)signed_data;
	return true;
}

/* Existing legacy authentication model; the genuine parser TU is also linked. */
EFI_STATUS __wrap_cdk2_system_fmp_authenticate(const void *image, size_t image_size,
	const void *certificate_xdr, size_t certificate_xdr_size,
	cdk2_system_fmp_pkcs7_verify_fn *verify, void *context,
	struct cdk2_system_fmp_auth_view *view)
{
	(void)context;
	assert(image == active->envelope && image_size == sizeof(active->envelope));
	assert(certificate_xdr == active->session.certificate_xdr &&
		certificate_xdr_size == sizeof(active->certificate));
	assert(verify == cdk2_system_fmp_pkcs7_verify);
	trace('A');
	mutate_policy(1U);
	if (active->mutate_request) {
		active->request.operation = 99;
		active->request.image_type = NULL;
	}
	if (active->auth_fail)
		return EFI_SECURITY_VIOLATION;
	*view = (struct cdk2_system_fmp_auth_view) {
		.payload = active->envelope + 16U,
		.payload_size = 200U,
	};
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_payload_check(
	const struct cdk2_system_fmp_payload_request *request,
	struct cdk2_system_fmp_payload_view *view)
{
	trace('P');
	mutate_policy(2U);
	assert(request->lowest_supported_version == 8U);
	assert(request->dependency_versions == active->session.dependency_versions &&
		request->dependency_version_count == 1U);
	assert(!memcmp(request->image_type, &image_type, sizeof(image_type)) &&
		!memcmp(request->expected_image_type, &image_type,
			sizeof(image_type)));
	assert(request->image_index == 1U);
	*view = (struct cdk2_system_fmp_payload_view) {
		.image = active->envelope + 80U,
		.image_size = 64U,
		.version = 42U,
		.lowest_supported_version = 8U,
		.image_updatable = CDK2_FMP_IMAGE_UPDATABLE_VALID,
		.last_attempt_status = CDK2_FMP_LAST_ATTEMPT_SUCCESS,
	};
	if (active->payload_reject) {
		view->image_updatable = CDK2_FMP_IMAGE_UPDATABLE_INVALID_OLD;
		view->last_attempt_status =
			CDK2_FMP_LAST_ATTEMPT_VERSION_TOO_LOW;
		return EFI_ABORTED;
	}
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_board_bind_identity(
	const struct cdk2_system_fmp_board_identity *identity, const void *image,
	size_t image_size, struct cdk2_system_fmp_board_binding_result *result)
{
	struct cdk2_system_fmp_session_result ignored;

	assert(identity == &active->session.board_identity);
	assert(image == active->envelope + 80U && image_size == 64U);
	trace('B');
	mutate_policy(3U);
	if (active->reenter)
		assert(cdk2_system_fmp_session_execute(&active->session,
			&active->request, &ignored) == EFI_ACCESS_DENIED);
	if (active->mutate_during_board)
		active->envelope[255] ^= 1U;
	result->fact = active->board_fail || active->board_unbound_success ?
		CDK2_SYSTEM_FMP_BOARD_UNBOUND :
		CDK2_SYSTEM_FMP_BOARD_BOUND;
	return active->board_fail ? EFI_SECURITY_VIOLATION : EFI_SUCCESS;
}

static void initialize(struct fixture *fixture)
{
	struct cdk2_system_fmp_session_config config;

	memset(fixture, 0, sizeof(*fixture));
	active = fixture;
	fixture->dependency.image_type = image_type;
	fixture->dependency.version = 9U;
	fixture->execute_status = CDK2_SYSTEM_FMP_TRANSPORT_SUCCESS;
	fixture->coreboot.header = (const void *)fixture->coreboot_table;
	fixture->coreboot.table_size = sizeof(fixture->coreboot_table);
	for (size_t index = 0U; index < sizeof(fixture->envelope); index++)
		fixture->envelope[index] = (uint8_t)index;
	fixture->request = (struct cdk2_system_fmp_session_request) {
		.operation = CDK2_SYSTEM_FMP_SESSION_CHECK,
		.image_type = &image_type,
		.image_index = 1U,
		.authenticated_image = fixture->envelope,
		.authenticated_image_size = sizeof(fixture->envelope),
	};
	config = (struct cdk2_system_fmp_session_config) {
		.coreboot = &fixture->coreboot,
		.certificate_xdr = fixture->certificate,
		.certificate_xdr_size = sizeof(fixture->certificate),
		.dependency_versions = &fixture->dependency,
		.dependency_version_count = 1U,
		.transport_port = {
			.context = NULL,
			.sha256 = hash,
			.publish = cache,
			.acquire = cache,
			.barrier = barrier,
			.trigger_apm_io8 = trigger,
		},
	};
	assert(cdk2_system_fmp_session_initialize(&fixture->session, &config) ==
		EFI_SUCCESS);
	assert(!strcmp(fixture->trace, "TIR"));
	fixture->trace_size = 0U;
	fixture->trace[0] = '\0';
}

static EFI_STATUS execute(struct fixture *fixture,
	enum cdk2_system_fmp_session_operation operation,
	struct cdk2_system_fmp_session_result *result)
{
	active = fixture;
	fixture->request.operation = operation;
	fixture->request.image_type = &image_type;
	return cdk2_system_fmp_session_execute(&fixture->session,
		&fixture->request, result);
}

static void check_repeatable_request(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;
	char transcript[64];

	initialize(&fixture);
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_SUCCESS);
	assert(!strcmp(fixture.trace, "APBK"));
	assert(result.transport_invoked && result.trigger_invoked &&
		result.broker_response_authenticated &&
		result.attempted_version == 42U &&
		result.image_updatable == CDK2_FMP_IMAGE_UPDATABLE_VALID);
	strcpy(transcript, fixture.trace);
	fixture.trace_size = 0U;
	fixture.trace[0] = '\0';
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_SUCCESS);
	assert(!strcmp(fixture.trace, transcript) && fixture.executes == 2U);
}

static void immutable_inputs_and_reentry(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;

	initialize(&fixture);
	fixture.mutate_request = true;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_SUCCESS);
	assert(fixture.executes == 1U);

	initialize(&fixture);
	fixture.reenter = true;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_SUCCESS);

	initialize(&fixture);
	fixture.mutate_during_board = true;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_COMPROMISED_DATA);
	assert(!result.transport_invoked && fixture.executes == 0U);

	initialize(&fixture);
	fixture.mutate_during_broker = true;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_COMPROMISED_DATA);
	assert(result.transport_invoked && fixture.executes == 1U);
}

static void initialization_owns_policy(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;

	initialize(&fixture);
	fixture.certificate[0] ^= 1U;
	fixture.dependency.version++;
	fixture.coreboot.record_count++;
	fixture.coreboot_table[0] ^= 1U;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_SUCCESS);
}

static void initialization_rejects_aliases(void)
{
	struct cdk2_system_fmp_session_config config;
	struct fixture fixture;

	memset(&fixture, 0, sizeof(fixture));
	active = &fixture;
	fixture.coreboot.header = (const void *)fixture.coreboot_table;
	fixture.coreboot.table_size = sizeof(fixture.coreboot_table);
	config = (struct cdk2_system_fmp_session_config) {
		.coreboot = &fixture.coreboot,
		.certificate_xdr = fixture.certificate,
		.certificate_xdr_size = sizeof(fixture.certificate),
		.dependency_versions = &fixture.dependency,
		.dependency_version_count = 1U,
		.transport_port = {
			.context = &fixture.session,
			.sha256 = hash,
			.publish = cache,
			.acquire = cache,
			.barrier = barrier,
			.trigger_apm_io8 = trigger,
		},
	};
	assert(cdk2_system_fmp_session_initialize(&fixture.session, &config) ==
		EFI_INVALID_PARAMETER);
	assert(!fixture.session.initialized);

	config.transport_port.context = NULL;
	fixture.session.ready = true;
	assert(cdk2_system_fmp_session_initialize(&fixture.session, &config) ==
		EFI_INVALID_PARAMETER);
	assert(fixture.session.ready);
	memset(&fixture.session, 0, sizeof(fixture.session));
	config.certificate_xdr = fixture.coreboot_table;
	assert(cdk2_system_fmp_session_initialize(&fixture.session, &config) ==
		EFI_INVALID_PARAMETER);
	assert(!fixture.session.initialized);
}

static void transport_failures_fail_closed(void)
{
	static const struct {
		enum cdk2_system_fmp_transport_status transport;
		EFI_STATUS status;
		bool trigger;
		bool response;
	} cases[] = {
		{ CDK2_SYSTEM_FMP_TRANSPORT_CAPACITY, EFI_BAD_BUFFER_SIZE,
			false, false },
		{ CDK2_SYSTEM_FMP_TRANSPORT_HASH_FAILED, EFI_COMPROMISED_DATA,
			false, false },
		{ CDK2_SYSTEM_FMP_TRANSPORT_CACHE_FAILED, EFI_COMPROMISED_DATA,
			false, false },
		{ CDK2_SYSTEM_FMP_TRANSPORT_TRIGGER_FAILED, EFI_COMPROMISED_DATA,
			true, false },
		{ CDK2_SYSTEM_FMP_TRANSPORT_BAD_RESPONSE, EFI_COMPROMISED_DATA,
			true, false },
		{ CDK2_SYSTEM_FMP_TRANSPORT_EXECUTION_FAILED, EFI_DEVICE_ERROR,
			true, true },
		{ CDK2_SYSTEM_FMP_TRANSPORT_SIGNATURE_REFUSED, EFI_DEVICE_ERROR,
			true, true },
	};

	for (size_t index = 0U; index < ARRAY_SIZE(cases); index++) {
		struct cdk2_system_fmp_session_result result;
		struct fixture fixture;

		initialize(&fixture);
		fixture.execute_status = cases[index].transport;
		assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
			cases[index].status);
		assert(result.transport_invoked &&
			result.transport_status == cases[index].transport &&
			result.trigger_invoked == cases[index].trigger &&
			result.broker_response_authenticated == cases[index].response);
		assert(result.signature_refused ==
			(cases[index].transport == CDK2_SYSTEM_FMP_TRANSPORT_SIGNATURE_REFUSED));
		if (result.signature_refused) {
			uint8_t digest[32];

			cdk2_system_fmp_sha256(fixture.request.authenticated_image,
				fixture.request.authenticated_image_size, digest);
			assert(result.broker_transaction == 37U && result.broker_generation == 19U);
			assert(memcmp(result.input_digest, digest, sizeof(digest)) == 0);
		}
		if (cases[index].response) {
			assert(result.image_updatable ==
				CDK2_FMP_IMAGE_UPDATABLE_INVALID);
			assert(result.attempted_version == 42U &&
				result.last_attempt_status ==
				CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL);
		} else {
			assert(result.image_updatable ==
				CDK2_FMP_IMAGE_UPDATABLE_INVALID &&
				result.last_attempt_status ==
				CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL);
		}
	}
}

static void local_admission_diagnostics_are_preserved(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;

	initialize(&fixture);
	fixture.payload_reject = true;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_ABORTED);
	assert(!result.transport_invoked &&
		result.image_updatable == CDK2_FMP_IMAGE_UPDATABLE_INVALID_OLD &&
		result.last_attempt_status ==
		CDK2_FMP_LAST_ATTEMPT_VERSION_TOO_LOW &&
		result.attempted_version == 42U);
}

static void impossible_board_success_fails_closed(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;

	initialize(&fixture);
	fixture.board_unbound_success = true;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK, &result) ==
		EFI_SECURITY_VIOLATION);
	assert(!result.transport_invoked &&
		result.image_updatable == CDK2_FMP_IMAGE_UPDATABLE_INVALID &&
		result.last_attempt_status == CDK2_FMP_LAST_ATTEMPT_UNSUCCESSFUL);
}

static void immutable_policy_at_every_stage(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;

	for (unsigned int event = 1U; event <= 4U; event++) {
		for (unsigned int target = 1U; target <= 8U; target++) {
			EFI_STATUS status;

			initialize(&fixture);
			fixture.mutation_event = event;
			fixture.mutation_target = target;
			status = execute(&fixture, CDK2_SYSTEM_FMP_SESSION_CHECK,
				&result);
			if (status != EFI_COMPROMISED_DATA)
				fprintf(stderr, "policy mutation event=%u target=%u status=%zu\n",
					event, target, (size_t)status);
			assert(status == EFI_COMPROMISED_DATA);
			assert(fixture.policy_mutated);
			assert(result.transport_invoked == (event == 4U));
		}
	}
}

static void output_contract(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;

	initialize(&fixture);
	memset(&result, 0xa5, sizeof(result));
	fixture.request.image_type = NULL;
	assert(cdk2_system_fmp_session_execute(&fixture.session,
		&fixture.request, &result) == EFI_INVALID_PARAMETER);
	for (size_t index = 0U; index < sizeof(result); index++)
		assert(((const uint8_t *)&result)[index] == 0xa5U);
	fixture.request.image_type = &image_type;
	fixture.request.operation = 99;
	assert(cdk2_system_fmp_session_execute(&fixture.session,
		&fixture.request, &result) == EFI_UNSUPPORTED);
	assert(result.image_updatable == CDK2_FMP_IMAGE_UPDATABLE_INVALID &&
		!result.transport_invoked);

	/* Aliases are rejected without corrupting the owner. */
	assert(cdk2_system_fmp_session_execute(&fixture.session,
		&fixture.request, (void *)&fixture.session) ==
		EFI_INVALID_PARAMETER);
	assert(fixture.session.initialized && fixture.session.ready);
}

static void set_and_close_are_terminal(void)
{
	struct cdk2_system_fmp_session_result result;
	struct fixture fixture;

	initialize(&fixture);
	fixture.auth_fail = true;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_SET, &result) ==
		EFI_SECURITY_VIOLATION);
	fixture.auth_fail = false;
	assert(execute(&fixture, CDK2_SYSTEM_FMP_SESSION_SET, &result) ==
		EFI_ACCESS_DENIED);
	fixture.close_fail = true;
	assert(cdk2_system_fmp_session_close(&fixture.session) ==
		EFI_COMPROMISED_DATA);
	assert(fixture.session.initialized);
	fixture.close_fail = false;
	assert(cdk2_system_fmp_session_close(&fixture.session) == EFI_SUCCESS);
	assert(!fixture.session.initialized && fixture.closes == 2U);
	assert(cdk2_system_fmp_session_close(&fixture.session) == EFI_NOT_STARTED);
}

int main(void)
{
	check_repeatable_request();
	immutable_inputs_and_reentry();
	initialization_owns_policy();
	initialization_rejects_aliases();
	immutable_policy_at_every_stage();
	transport_failures_fail_closed();
	local_admission_diagnostics_are_preserved();
	impossible_board_success_fails_closed();
	output_contract();
	set_and_close_are_terminal();
	puts("SystemFmp source-neutral session hostile tests: PASS");
	return 0;
}
