#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
config=${1:?generated config header is required}
compiler=${2:-cc}
flags=${3:--std=c11 -O2 -Wall -Wextra -Werror -fshort-wchar}
hash_sources="$root/src/lib/tcg_hash/software_hash.c $root/src/lib/tcg_hash/vendor/vboot/2sha1.c $root/src/lib/tcg_hash/vendor/vboot/2sha256.c $root/src/lib/tcg_hash/vendor/vboot/2sha512.c $root/src/lib/tcg_hash/vendor/linux/lib/crypto/sm3.c"
if grep -qx '#define CONFIG_CDK2_STRICT_DIRECT_RUNTIME 0' "$config"; then
	echo 'strict direct entry phase tests: skipped for compatibility route'
	exit 0
fi
grep -qx '#define CONFIG_CDK2_STRICT_DIRECT_RUNTIME 1' "$config" || {
	echo 'strict direct runtime identity is missing or malformed' >&2
	exit 1
}
temporary=$(mktemp -d "${TMPDIR:-/tmp}/cdk2-direct-phase.XXXXXX")
trap 'rm -rf "$temporary"' EXIT HUP INT TERM
mkdir -p "$temporary/cdk2"
sed 's/^#define CONFIG_CDK2_NATIVE_USB_KEYBOARD 0$/#define CONFIG_CDK2_NATIVE_USB_KEYBOARD 1/' \
	"$config" > "$temporary/cdk2/config.h"
grep -qx '#define CONFIG_CDK2_NATIVE_USB_KEYBOARD 1' \
	"$temporary/cdk2/config.h"
mkdir -p "$temporary/mixed/cdk2"
sed 's/^#define CONFIG_CDK2_NATIVE_TCG2 1$/#define CONFIG_CDK2_NATIVE_TCG2 0/' \
	"$temporary/cdk2/config.h" > "$temporary/mixed/cdk2/config.h"

# Compile the real entry source under the strict profile with the optional
# keyboard enabled. The entry test drives linked-primary dispatch and the
# actual OS-handoff completion gate, not a duplicate policy implementation.
# Flags deliberately undergo normal compiler argument splitting.
# shellcheck disable=SC2086
"$compiler" $flags -DCDK2_HOST_TEST -fsanitize=address,undefined \
	-fno-sanitize-recover=all -I"$temporary" -I"$root/include" \
	-I"$root/src/lib/tcg_hash/vendor/linux/include" \
	-o "$temporary/entry" \
	"$root/tests/dxe_core_entry_test.c" \
	"$root/tests/direct_phase_presence_fixture.c" \
	"$root/src/modules/dxe_core/entry.c" \
	"$root/src/lib/coreboot_hob.c" "$root/src/boot/coreboot.c" \
	"$root/src/boot/coreboot_checksum.c" "$root/src/boot/coreboot_resource.c" \
	"$root/src/modules/system_fmp/transport.c" \
	"$root/src/modules/authvar_transport/native_x86.c" \
	"$root/src/modules/dxe_core/lifecycle.c" \
	"$root/src/modules/dxe_core/presence_lifecycle.c" \
	"$root/src/modules/dxe_core/core.c" \
	"$root/src/modules/dxe_core/linked_primary.c" \
	"$root/src/modules/dxe_core/database.c" \
	"$root/src/modules/dxe_core/event.c" \
	"$root/src/modules/dxe_core/memory.c" \
	"$root/src/modules/dxe_core/image.c" \
	"$root/src/modules/dxe_core/gcd.c" \
	"$root/src/modules/dxe_core/direct_dispatch.c" \
	"$root/src/lib/linear_boot.c" "$root/src/lib/boot_logo.c" \
	"$root/src/lib/capsule_disk.c" \
	"$root/src/modules/graphics_output/graphics_output.c" \
	"$root/src/modules/graphics_output/driver.c" \
	"$root/src/lib/tpm2_acpi_hob.c" \
	"$root/src/lib/direct_image_table.c" \
	"$root/src/lib/diagnostic.c" "$root/src/lib/deadline.c" \
	"$root/src/boot/pe.c" "$root/src/lib/pe_image_view.c" $hash_sources
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
	UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 "$temporary/entry"

# The include-entry fixture drives the real XHCI -> UsbBus -> UsbKb binding
# and connect path with the strict keyboard option enabled.
# shellcheck disable=SC2086
"$compiler" $flags -DCDK2_HOST_TEST -DCDK2_DIRECT_PHASE_TEST_ONLY \
	-DCDK2_DIRECT_DISPATCH_EXTERNAL_ONE_TEST \
	-DCDK2_DXE_ENTRY_SOURCE=\"$root/src/modules/dxe_core/entry.c\" \
	-fsanitize=address,undefined -fno-sanitize-recover=all \
	-ffunction-sections -fdata-sections \
	-I"$temporary/mixed" -I"$root/include" -I"$root/src/modules/dxe_core" \
	-I"$root/src/lib/tcg_hash/vendor/linux/include" \
	-o "$temporary/mixed-entry" \
	"$root/tests/dxe_core_entry_mixed_partition_test.c" \
	"$root/tests/direct_phase_presence_fixture.c" \
	"$root/src/modules/dxe_core/database.c" \
	"$root/src/lib/linear_boot.c" \
	"$root/src/modules/dxe_core/direct_dispatch.c" \
	"$root/src/lib/direct_image_table.c" "$root/src/lib/pe_image_view.c" \
	"$root/src/modules/dxe_core/lifecycle.c" \
	"$root/src/modules/dxe_core/presence_lifecycle.c" \
	"$root/src/lib/diagnostic.c" "$root/src/lib/deadline.c" \
	$hash_sources -Wl,--gc-sections
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
	UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 "$temporary/mixed-entry"

compile_entry_mutant()
{
	source=$1
	output=$2
	# shellcheck disable=SC2086
	"$compiler" $flags -DCDK2_HOST_TEST -fsanitize=address,undefined \
		-fno-sanitize-recover=all -I"$temporary" -I"$root/include" \
		-I"$root/src/lib/tcg_hash/vendor/linux/include" \
		-I"$root/src/modules/dxe_core" \
		-o "$output" "$root/tests/dxe_core_entry_test.c" "$source" \
		"$root/src/lib/coreboot_hob.c" "$root/src/boot/coreboot.c" \
		"$root/src/boot/coreboot_checksum.c" "$root/src/boot/coreboot_resource.c" \
		"$root/src/modules/system_fmp/transport.c" \
		"$root/src/modules/authvar_transport/native_x86.c" \
		"$root/tests/direct_phase_presence_fixture.c" \
		"$root/src/modules/dxe_core/lifecycle.c" \
		"$root/src/modules/dxe_core/presence_lifecycle.c" \
		"$root/src/modules/dxe_core/core.c" \
		"$root/src/modules/dxe_core/linked_primary.c" \
		"$root/src/modules/dxe_core/database.c" \
		"$root/src/modules/dxe_core/event.c" \
		"$root/src/modules/dxe_core/memory.c" \
		"$root/src/modules/dxe_core/image.c" \
		"$root/src/modules/dxe_core/gcd.c" \
		"$root/src/modules/dxe_core/direct_dispatch.c" \
		"$root/src/lib/linear_boot.c" "$root/src/lib/boot_logo.c" \
		"$root/src/lib/capsule_disk.c" \
		"$root/src/modules/graphics_output/graphics_output.c" \
		"$root/src/modules/graphics_output/driver.c" \
		"$root/src/lib/tpm2_acpi_hob.c" \
		"$root/src/lib/direct_image_table.c" \
		"$root/src/lib/diagnostic.c" "$root/src/lib/deadline.c" \
		"$root/src/boot/pe.c" "$root/src/lib/pe_image_view.c" $hash_sources
}

compile_mixed_mutant()
{
	source=$1
	output=$2
	# shellcheck disable=SC2086
	"$compiler" $flags -DCDK2_HOST_TEST -DCDK2_DIRECT_PHASE_TEST_ONLY \
		-DCDK2_DIRECT_DISPATCH_EXTERNAL_ONE_TEST \
		-DCDK2_DXE_ENTRY_SOURCE=\"$source\" \
		-fsanitize=address,undefined -fno-sanitize-recover=all \
		-ffunction-sections -fdata-sections -I"$temporary/mixed" \
		-I"$root/include" -I"$root/src/modules/dxe_core" -o "$output" \
		-I"$root/src/lib/tcg_hash/vendor/linux/include" \
		"$root/tests/dxe_core_entry_mixed_partition_test.c" \
		"$root/tests/direct_phase_presence_fixture.c" \
		"$root/src/modules/dxe_core/database.c" \
		"$root/src/lib/linear_boot.c" \
		"$root/src/modules/dxe_core/direct_dispatch.c" \
		"$root/src/lib/direct_image_table.c" "$root/src/lib/pe_image_view.c" \
		"$root/src/modules/dxe_core/lifecycle.c" \
		"$root/src/modules/dxe_core/presence_lifecycle.c" \
		"$root/src/lib/diagnostic.c" "$root/src/lib/deadline.c" \
		$hash_sources -Wl,--gc-sections
}

expect_executable_failure()
{
	executable=$1
	label=$2
	if ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
		UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
		"$executable" > "$temporary/$label.log" 2>&1; then
		echo "direct phase $label executable mutant survived" >&2
		exit 1
	fi
}

for mutation in storage tcg complete late; do
	mutant="$temporary/$mutation-entry.c"
	cp "$root/src/modules/dxe_core/entry.c" "$mutant"
	case "$mutation" in
	storage)
		perl -0pi -e 's/status = disposition_storage_route\(&core\.dispatcher,\n\s*selected_storage_backend\);/status = EFI_SUCCESS;/' "$mutant" ;;
	tcg)
		perl -0pi -e 's/status = skip_direct_required\(&core\.dispatcher,\n\s*measured_boot_drivers,\n\s*ARRAY_SIZE\(measured_boot_drivers\),\n\s*CDK2_DXE_DIRECT_SKIPPED_HARDWARE_ABSENT,\n\s*"hardware absent"\);/status = EFI_SUCCESS;/' "$mutant" ;;
	complete|late)
		perl -0pi -e 's/status = cdk2_dxe_dispatcher_direct_complete\(&core\.dispatcher\);\n\s*if \(EFI_ERROR\(status\)\)\n\s*return status;/status = EFI_SUCCESS;/' "$mutant"
		if test "$mutation" = late; then
			perl -0pi -e 's/(status = cdk2_dxe_lifecycle_load_image\([\s\S]*?&image\);)/$1\n\tstatus = cdk2_dxe_dispatcher_direct_complete\(&core.dispatcher\);\n\tif (EFI_ERROR(status))\n\t\treturn status;/' "$mutant"
		fi ;;
	esac
	compile_entry_mutant "$mutant" "$temporary/$mutation-mutant"
	expect_executable_failure "$temporary/$mutation-mutant" "$mutation"
done

input_mutant="$temporary/input-entry.c"
cp "$root/src/modules/dxe_core/entry.c" "$input_mutant"
perl -0pi -e 's/status = disposition_usb_route\(&core\.dispatcher,\n\s*selected_storage_backend,\n\s*CONFIG_CDK2_NATIVE_USB_KEYBOARD != 0\);/status = EFI_SUCCESS;/' \
	"$input_mutant"
compile_mixed_mutant "$input_mutant" "$temporary/input-mutant"
expect_executable_failure "$temporary/input-mutant" input

phase_oracle()
{
	source=$1
	sed -n '/static EFI_STATUS initialize_block_discovery(/,/static EFI_STATUS initialize_filesystems(/p' \
		"$source" | grep -Fq 'disposition_storage_route(&core.dispatcher,' || return 1
	sed -n '/static EFI_STATUS initialize_input_ui(/,/static EFI_STATUS CDK2_MS_ABI poll_linear_input/p' \
		"$source" | grep -Fq 'disposition_usb_route(&core.dispatcher,' || return 1
	variables=$(sed -n '/static EFI_STATUS initialize_minimal_variables(/,/static BOOLEAN configuration_table_present/p' \
		"$source")
	printf '%s\n' "$variables" | grep -Fq \
		'skip_direct_required(&core.dispatcher,' || return 1
	printf '%s\n' "$variables" | grep -Fq 'measured_boot_drivers' || return 1
	direct_line=$(grep -n 'cdk2_dxe_dispatcher_direct_complete(&core.dispatcher)' \
		"$source" | cut -d: -f1)
	load_line=$(grep -n 'status = cdk2_dxe_lifecycle_load_image' "$source" |
		cut -d: -f1)
	test -n "$direct_line" && test -n "$load_line" && test "$direct_line" -lt "$load_line"
}

phase_oracle "$root/src/modules/dxe_core/entry.c"
for mutation in storage input tcg complete late; do
	mutant="$temporary/$mutation.c"
	cp "$root/src/modules/dxe_core/entry.c" "$mutant"
	case "$mutation" in
	storage)
		sed -i 's/status = disposition_storage_route(&core.dispatcher,/status = EFI_SUCCESS; \/\* removed storage disposition \*\//' \
			"$mutant" ;;
	input)
		sed -i 's/status = disposition_usb_route(&core.dispatcher,/status = EFI_SUCCESS; \/\* removed USB disposition \*\//' \
			"$mutant" ;;
	tcg)
		sed -i '/status = skip_direct_required(&core.dispatcher,/d' "$mutant" ;;
	complete)
		sed -i '/status = cdk2_dxe_dispatcher_direct_complete(&core.dispatcher);/d' \
			"$mutant" ;;
	late)
		sed -i '/status = cdk2_dxe_dispatcher_direct_complete(&core.dispatcher);/d' \
			"$mutant"
		sed -i '/status = cdk2_dxe_lifecycle_load_image/a\
\tstatus = cdk2_dxe_dispatcher_direct_complete(&core.dispatcher);' "$mutant" ;;
	esac
	if phase_oracle "$mutant"; then
		echo "direct phase $mutation mutation survived" >&2
		exit 1
	fi
done

echo 'strict direct entry phase and ordering mutations: PASS'
