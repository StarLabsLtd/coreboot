/* SPDX-License-Identifier: GPL-2.0-only */

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <cdk2/capsule_runtime_entry.h>
#include <cdk2/capsule_runtime.h>
#include <cdk2/capsule_boot.h>
#include <cdk2/diagnostic.h>

#include "diagnostic_runtime_guard.h"
#include "capsule_delivery_policy_fixture.h"
#include <cdk2/dxe_core_abi.h>

struct cdk2_capsule_boot_protocol *cdk2_capsule_test_boot_protocol(void);

typedef EFI_STATUS CDK2_MS_ABI install_multiple_fn(void **, ...);
typedef EFI_STATUS CDK2_MS_ABI uninstall_multiple_fn(void *, ...);
typedef EFI_STATUS CDK2_MS_ABI create_event_ex_fn(UINT32, UINTN,
	void (CDK2_MS_ABI *)(void *, void *), void *, const EFI_GUID *, void **);

static EFI_STATUS install_status, uninstall_status, event_status[2];
static EFI_STATUS flush_status;
static UINTN installs, uninstalls, converts, events, closes;
static UINTN table_installs;
static UINT32 last_table_count;
static UINTN checks, sets, flushes, variables, package_names_freed;
static UINT32 updatable_result;
static EFI_STATUS check_image_status;
static EFI_STATUS set_image_status;
static EFI_STATUS set_image_status_second;
static EFI_STATUS locate_status;
static EFI_STATUS first_handle_status;
static bool free_pool_failure;
static unsigned int free_calls, free_failure_at, handle_calls, handle_failure_at;
static struct cdk2_capsule_check_outcome modeled_check;
static const void *last_vendor;
static BOOLEAN runtime_pointer_converted;
static void (CDK2_MS_ABI *notification[2])(void *, void *);
static CHAR16 last_name[32];
static void *expected_runtime;

struct test_memory_descriptor {
	UINT32 type, padding;
	UINT64 physical, virtual, pages, attributes;
};

static EFI_STATUS CDK2_MS_ABI get_memory_map(UINTN *size, void *map,
	UINTN *key, UINTN *descriptor_size, UINT32 *version)
{
	struct test_memory_descriptor *descriptor = map;

	*descriptor_size = sizeof(*descriptor);
	*key = 1U;
	*version = 1U;
	if (map == NULL) {
		*size = 2U * sizeof(*descriptor);
		return EFI_BUFFER_TOO_SMALL;
	}
	assert(*size >= sizeof(*descriptor));
	memset(descriptor, 0, sizeof(*descriptor));
	descriptor->type = 4U;
	descriptor->pages = MAX_UINT64 / 4096U;
	*size = sizeof(*descriptor);
	return EFI_SUCCESS;
}

struct fmp_image_descriptor {
	UINT8 image_index;
	EFI_GUID image_type;
	UINT64 image_id;
	CHAR16 *image_id_name;
	UINT32 version;
	CHAR16 *version_name;
	UINTN size;
	UINT64 attributes_supported, attributes_setting;
	UINT64 compatibilities;
	UINT32 lowest_supported_version, last_attempt_version,
		last_attempt_status;
	UINT64 hardware_instance;
	void *dependencies;
};
struct fmp_protocol {
	EFI_STATUS(CDK2_MS_ABI *get_image_info)(void *, UINTN *, void *, UINT32 *,
		UINT8 *, UINTN *, UINT32 *, CHAR16 **);
	void *get_image;
	EFI_STATUS(CDK2_MS_ABI *set_image)(void *, UINT8, const void *, UINTN,
		const void *, void *, CHAR16 **);
	EFI_STATUS(CDK2_MS_ABI *check_image)(void *, UINT8, const void *, UINTN,
		UINT32 *);
	void *get_package_info, *set_package_info;
};
struct fmp_test_body {
	UINT32 version;
	UINT16 embedded_count, payload_count;
	UINT64 offset;
	UINT32 image_version;
	EFI_GUID image_type;
	UINT8 image_index, reserved[3];
	UINT32 image_size, vendor_size;
	UINT64 hardware_instance, capsule_support;
	UINT8 image[80];
} __packed;
struct fmp_test_capsule {
	struct cdk2_capsule_header outer;
	struct fmp_test_body body;
};
static struct fmp_protocol fmp;
static void *fmp_handles[2] = { (void *)9, (void *)10 };
static UINTN fmp_handle_count = 1U;
static struct fmp_image_descriptor descriptor;
static UINT32 fmp_descriptor_version = 3U;
static UINTN fmp_descriptor_size = sizeof(descriptor);
static UINT64 pool_storage[64][256];
static UINTN pool_allocations;
static UINTN pool_failure = MAX_UINTN;

#define TEST_FMP_RESET_REQUIRED BIT1
#define TEST_FMP_DESCRIPTOR_V1_SIZE \
	offsetof(struct fmp_image_descriptor, lowest_supported_version)

EFI_STATUS cdk2_capsule_cache_writeback_range_all_cpus(UINT64 address, UINT64 length)
{
	assert(address != 0U && length != 0U);
	flushes++;
	return flush_status;
}

static EFI_STATUS CDK2_MS_ABI allocate_pool(UINT32 type, UINTN size, void **buffer)
{
	(void)type;
	assert(size == sizeof(descriptor) || size <= sizeof(pool_storage[0]));
	if (size != sizeof(descriptor) && pool_allocations == pool_failure)
		return EFI_OUT_OF_RESOURCES;
	assert(size == sizeof(descriptor) || pool_allocations < 64U);
	*buffer = size == sizeof(descriptor) ? (void *)&descriptor :
		(void *)pool_storage[pool_allocations++];
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI free_pool(void *buffer)
{
	assert(buffer != NULL);
	free_calls++;
	if (buffer == (void *)0x1234U)
		package_names_freed++;
	return free_pool_failure || (free_failure_at && free_calls == free_failure_at) ?
		EFI_DEVICE_ERROR : EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI locate_handles(UINT32 type, const EFI_GUID *guid,
	void *key, UINTN *count, void ***buffer)
{
	(void)guid;
	(void)key;
	assert(type == 2U);
	if (EFI_ERROR(locate_status))
		return locate_status;
	*count = fmp_handle_count;
	*buffer = fmp_handles;
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI handle_protocol(void *handle, const EFI_GUID *guid,
	void **protocol)
{
	static const EFI_GUID check_guid = CDK2_CAPSULE_CHECK_OUTCOME_GUID;

	assert(handle == fmp_handles[0] || handle == fmp_handles[1]);
	if (memcmp(guid, &check_guid, sizeof(*guid)) != 0) {
		handle_calls++;
		if (handle_failure_at && handle_calls == handle_failure_at)
			return EFI_DEVICE_ERROR;
	}
	if (handle == fmp_handles[0] && EFI_ERROR(first_handle_status))
		return first_handle_status;
	*protocol = memcmp(guid, &check_guid, sizeof(*guid)) == 0 ?
		(void *)&modeled_check : (void *)&fmp;
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI get_image_info(void *self, UINTN *size, void *buffer,
	UINT32 *version, UINT8 *count, UINTN *descriptor_size, UINT32 *package,
	CHAR16 **package_name)
{
	(void)self;
	assert(fmp_descriptor_size <= sizeof(descriptor));
	*version = fmp_descriptor_version;
	*count = 1U;
	*descriptor_size = fmp_descriptor_size;
	*package = 0U;
	if (buffer == NULL) {
		*package_name = (CHAR16 *)(UINTN)0x1234U;
		*size = fmp_descriptor_size;
		return EFI_BUFFER_TOO_SMALL;
	}
	assert(*size >= fmp_descriptor_size);
	memcpy(buffer, &descriptor, fmp_descriptor_size);
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI check_image(void *self, UINT8 index,
	const void *image, UINTN size, UINT32 *updatable)
{
	(void)self;
	assert(index == 1U && image != NULL && (size == 4U ||
		(size == 19U && ((const UINT8 *)image)[18] == 0xa5U) ||
		(size == 1U && *(const UINT8 *)image == 0xa5U) ||
		(size == 67U && ((const UINT8 *)image)[66] == 0xa5U) ||
		(size == 8U && ((const UINT8 *)image)[7] == 0xa5U) ||
		(size == 40U && ((const UINT8 *)image)[39] == 0xa5U)));
	checks++;
	if (EFI_ERROR(check_image_status))
		return check_image_status;
	*updatable = updatable_result;
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI set_image(void *self, UINT8 index,
	const void *image, UINTN size, const void *vendor, void *progress,
	CHAR16 **abort_reason)
{
	(void)self;
	(void)progress;
	assert(index == 1U && image != NULL && (size == 4U ||
		(size == 1U && *(const UINT8 *)image == 0xa5U) ||
		(size == 67U && ((const UINT8 *)image)[66] == 0xa5U) ||
		(size == 8U && ((const UINT8 *)image)[7] == 0xa5U) ||
		(size == 40U && ((const UINT8 *)image)[39] == 0xa5U)));
	*abort_reason = NULL;
	last_vendor = vendor;
	sets++;
	return sets > 1U && set_image_status_second != EFI_SUCCESS ?
		set_image_status_second : set_image_status;
}
static EFI_STATUS CDK2_MS_ABI set_variable(CHAR16 *name, EFI_GUID *guid,
	UINT32 attributes, UINTN size, void *data)
{
	UINTN index = 0;

	(void)guid;
	assert(attributes == 7U && size == 8U && data != NULL);
	do {
		last_name[index] = name[index];
	} while (name[index++] != 0);
	variables++;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI crc32(void *table, UINTN size, cdk2_uint32_ptr crc)
{
	(void)table;
	(void)size;
	*crc = 0xabcdef01U;
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI install(void **handle, ...)
{
	installs++;
	*handle = (void *)1;
	return install_status;
}
static EFI_STATUS CDK2_MS_ABI uninstall(void *handle, ...)
{
	assert(handle == (void *)1);
	uninstalls++;
	return uninstall_status;
}
static EFI_STATUS CDK2_MS_ABI install_table(const EFI_GUID *guid, void *table)
{
	struct test_capsule_table { UINT32 count, reserved; const void *capsules[]; };
	const struct test_capsule_table *capsule_table = table;

	assert(guid != NULL && table != NULL);
	table_installs++;
	last_table_count = capsule_table->count;
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI create_event(UINT32 type, UINTN tpl,
	void (CDK2_MS_ABI *notify)(void *, void *), void *context,
	cdk2_const_guid_ptr group, cdk2_void_ptr_ptr event)
{
	(void)context;
	assert(type == 0x200U && tpl == 16U && group != NULL);
	assert(events < ARRAY_SIZE(event_status));
	EFI_STATUS status = event_status[events];

	if (!EFI_ERROR(status)) {
		notification[events] = notify;
		*event = (void *)(events + 2U);
	}
	events++;
	return status;
}
static EFI_STATUS CDK2_MS_ABI close_event(void *event)
{
	assert(event != NULL);
	closes++;
	return EFI_SUCCESS;
}
static EFI_STATUS CDK2_MS_ABI convert_pointer(UINTN disposition, void **pointer)
{
	(void)disposition;
	assert(pointer != NULL);
	diagnostic_runtime_guard_conversion();
	if (*pointer == expected_runtime)
		runtime_pointer_converted = TRUE;
	converts++;
	return EFI_SUCCESS;
}

int main(void)
{
	struct cdk2_boot_services_view boot = { 0 };
	struct cdk2_runtime_services_view runtime = { 0 };
	struct {
		struct cdk2_system_table_view view;
	} system = { 0 };
	struct test_capsule_delivery_hobs delivery_hobs;
	struct cdk2_dxe_configuration_table hob_table = {
		.guid = { 0x7739f24c, 0x93d7, 0x11d4,
			{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } },
		.table = &delivery_hobs,
	};
	void *old_update = (void *)3, *old_query = (void *)4;
	struct fmp_test_capsule capsule = { 0 };
	struct { UINT64 length, address; } blocks[3];
	const struct cdk2_capsule_header *capsules[1] = { &capsule.outer };
	typedef EFI_STATUS CDK2_MS_ABI update_fn(
		const struct cdk2_capsule_header *const *, UINTN, UINT64);
	typedef EFI_STATUS CDK2_MS_ABI query_fn(
		const struct cdk2_capsule_header *const *, UINTN, UINT64 *, UINT32 *);
	UINTN checks_before_runtime, sets_before_runtime;

	boot.calculate_crc32 = crc32;
	boot.create_event_ex = create_event;
	boot.install_multiple = install;
	boot.uninstall_multiple = uninstall;
	boot.allocate_pool = allocate_pool;
	boot.free_pool = free_pool;
	boot.get_memory_map = get_memory_map;
	boot.install_configuration_table = install_table;
	boot.handle_protocol = handle_protocol;
	boot.locate_handle_buffer = locate_handles;
	runtime.header.size = sizeof(runtime);
	runtime.header.crc32 = 7U;
	runtime.update_capsule = old_update;
	runtime.query_capsule = old_query;
	runtime.convert_pointer = convert_pointer;
	runtime.set_variable = set_variable;
	system.view.boot = &boot;
	system.view.runtime = &runtime;
	test_capsule_delivery_hobs_init(&delivery_hobs,
		CB_CAPSULE_DELIVERY_RAM | CB_CAPSULE_DELIVERY_DISK, 0x123400, 0x567800);
	system.view.table_entries = 1;
	system.view.configuration_table = &hob_table;
	expected_runtime = &runtime;
	/* The same actual PE entry must not substitute build defaults for a bad
	 * handoff. Disk-only delivery enables boot processing, not OS RAM submit. */
	for (unsigned int scenario = 0; scenario < 4; scenario++) {
		struct cdk2_dxe_configuration_table duplicate[] = { hob_table, hob_table };
		struct cdk2_capsule_header delivery_capsule = {
			.header_size = sizeof(delivery_capsule),
			.image_size = sizeof(delivery_capsule),
			.flags = CDK2_CAPSULE_PERSIST | CDK2_CAPSULE_POPULATE,
		};
		const struct cdk2_capsule_header *delivery_capsules[] = { &delivery_capsule };
		struct cdk2_capsule_boot_protocol *processor;
		UINTN previous_sets = sets, previous_variables = variables, previous_flushes = flushes;

		boot.close_event = close_event;
		events = 0;
		test_capsule_delivery_hobs_init(&delivery_hobs, CB_CAPSULE_DELIVERY_DISK,
			0x123400, 0x567800);
		system.view.table_entries = scenario == 0 ? 0 : scenario == 2 ? 2 : 1;
		system.view.configuration_table = scenario == 2 ? duplicate : &hob_table;
		if (scenario == 1)
			delivery_hobs.policy.reserved[0] = 1;
		assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_SUCCESS);
		processor = cdk2_capsule_test_boot_protocol();
		assert(processor->delivery_policy.allowed_transports ==
			(scenario == 3 ? CB_CAPSULE_DELIVERY_DISK : 0));
		assert(processor->delivery_policy.max_nonpopulate == (scenario == 3 ? 0x123400 : 0));
		assert(processor->delivery_policy.max_populate == (scenario == 3 ? 0x567800 : 0));
		assert(((query_fn *)runtime.query_capsule)(delivery_capsules, 1,
			&(UINT64) { 0 }, &(UINT32) { 0 }) == EFI_UNSUPPORTED);
		assert(((update_fn *)runtime.update_capsule)(delivery_capsules, 1, 0) ==
			EFI_UNSUPPORTED);
		assert(sets == previous_sets && variables == previous_variables &&
			flushes == previous_flushes);
		assert(processor->validate_capsule(processor, &delivery_capsule,
			sizeof(delivery_capsule)) == (scenario == 3 ? EFI_SUCCESS : EFI_INVALID_PARAMETER));
		if (scenario == 3)
			assert(processor->process_capsule(processor, &delivery_capsule,
				sizeof(delivery_capsule)) == EFI_SUCCESS);
		notification[1]((void *)3, NULL);
		delivery_capsule.flags = 0;
		assert(((query_fn *)runtime.query_capsule)(delivery_capsules, 1,
			&(UINT64) { 0 }, &(UINT32) { 0 }) == EFI_UNSUPPORTED);
		assert(((update_fn *)runtime.update_capsule)(delivery_capsules, 1, 0) ==
			EFI_UNSUPPORTED);
		assert(sets == previous_sets && variables == previous_variables &&
			flushes == previous_flushes);
		runtime.update_capsule = old_update;
		runtime.query_capsule = old_query;
		runtime.header.crc32 = 7U;
	}
	installs = uninstalls = closes = events = table_installs = 0;
	boot.close_event = NULL;
	test_capsule_delivery_hobs_init(&delivery_hobs,
		CB_CAPSULE_DELIVERY_RAM | CB_CAPSULE_DELIVERY_DISK, 0x123400, 0x567800);
	system.view.table_entries = 1;
	system.view.configuration_table = &hob_table;
	assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_UNSUPPORTED);
	assert(events == 0U && uninstalls == 1U && runtime.update_capsule == old_update &&
		runtime.query_capsule == old_query);
	installs = uninstalls = closes = events = 0U;
	boot.close_event = close_event;
	event_status[0] = EFI_DEVICE_ERROR;
	assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_DEVICE_ERROR);
	assert(runtime.update_capsule == old_update && runtime.query_capsule == old_query &&
		runtime.header.crc32 == 7U && installs == 1U && uninstalls == 1U);
	boot.uninstall_multiple = NULL;
	events = 0;
	assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_UNSUPPORTED);
	assert(runtime.update_capsule == old_update && runtime.query_capsule == old_query &&
		runtime.header.crc32 == 7U);
	boot.uninstall_multiple = uninstall;
	event_status[0] = EFI_SUCCESS;
	install_status = EFI_DEVICE_ERROR;
	assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_DEVICE_ERROR);
	assert(uninstalls == 1U && runtime.update_capsule == old_update &&
		runtime.query_capsule == old_query && runtime.header.crc32 == 7U);
	install_status = EFI_SUCCESS;
	events = 0;
	event_status[1] = EFI_DEVICE_ERROR;
	uninstall_status = EFI_DEVICE_ERROR;
	assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_DEVICE_ERROR);
	assert(runtime.update_capsule == old_update && runtime.query_capsule == old_query &&
		runtime.header.crc32 == 7U && uninstalls == 2U && closes == 1U);
	/* A coherent retry starts from the original table fixture. */
	runtime.update_capsule = old_update;
	runtime.query_capsule = old_query;
	runtime.header.crc32 = 7U;
	events = 0;
	uninstall_status = EFI_SUCCESS;
	event_status[1] = EFI_SUCCESS;
	assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_SUCCESS);
	assert(installs == 5U && runtime.update_capsule != old_update &&
		runtime.query_capsule != old_query && runtime.header.crc32 == 0xabcdef01U);
	fmp.get_image_info = get_image_info;
	fmp.check_image = check_image;
	fmp.set_image = set_image;
	descriptor.image_index = 1U;
	descriptor.image_type = (EFI_GUID) { .data1 = 0x12345678U };
	descriptor.hardware_instance = 7U;
	descriptor.size = 4U;
	capsule.outer.guid = (EFI_GUID) { 0x6dcbd5ed, 0xe82d, 0x4c44,
		{ 0xbd, 0xa1, 0x71, 0x94, 0x19, 0x9a, 0xd9, 0x2a } };
	capsule.outer.header_size = sizeof(capsule.outer);
	capsule.outer.image_size = sizeof(capsule);
	capsule.body.version = 1U;
	capsule.body.payload_count = 1U;
	capsule.body.offset = 16U;
	capsule.body.image_version = 3U;
	memcpy(&capsule.body.image_type, &descriptor.image_type,
		sizeof(descriptor.image_type));
	capsule.body.image_index = 1U;
	capsule.body.image_size = 4U;
	capsule.body.hardware_instance = 7U;
	updatable_result = CDK2_FMP_IMAGE_UPDATABLE_VALID;
	{
		struct { UINT64 length, address; } deferred[2] = {
			{ sizeof(capsule), (UINT64)(UINTN)&capsule }, { 0U, 0U }
		};
		struct cdk2_capsule_boot_protocol *protocol =
			cdk2_capsule_test_boot_protocol();
		assert(protocol->validate_capsule != NULL);
		assert(protocol->process_capsule != NULL);
		assert(protocol->validate_capsule(protocol, &capsule,
			sizeof(capsule)) == EFI_SUCCESS);
		/* Capability validation is structural.  It must not ask the platform
		 * FMP to inspect flash before an update is actually processed. */
		assert(checks == 0U && sets == 0U);
		checks = 0U;
		capsule.outer.header_size = UINT32_MAX;
		assert(protocol->validate_capsule(protocol, &capsule,
			sizeof(capsule)) == EFI_INVALID_PARAMETER);
		assert(checks == 0U && sets == 0U);
		capsule.outer.header_size = sizeof(capsule.outer);
		checks = 0U;
		capsule.outer.guid = (EFI_GUID) { .data1 = 0x87654321U };
		capsule.outer.flags = CDK2_CAPSULE_PERSIST | CDK2_CAPSULE_POPULATE;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_SUCCESS && table_installs == 1U);
		{
			struct fmp_test_capsule grouped[2] = { capsule, capsule };
			struct { UINT64 length, address; } grouped_scatter[3] = {
				{ sizeof(grouped[0]), (UINT64)(UINTN)&grouped[0] },
				{ sizeof(grouped[1]), (UINT64)(UINTN)&grouped[1] },
				{ 0U, 0U },
			};

			assert(protocol->process_scatter(protocol,
				(UINT64)(UINTN)grouped_scatter) == EFI_SUCCESS);
			assert(table_installs == 2U && last_table_count == 2U);
		}
		capsule.outer.guid = (EFI_GUID) { 0x6dcbd5ed, 0xe82d, 0x4c44,
			{ 0xbd, 0xa1, 0x71, 0x94, 0x19, 0x9a, 0xd9, 0x2a } };
		capsule.outer.flags = 0U;
		{
			struct fmp_test_capsule retry_capsules[2] = { capsule, capsule };
			struct { UINT64 length, address; } retry_scatter[3] = {
				{ sizeof(retry_capsules[0]), (UINT64)(UINTN)&retry_capsules[0] },
				{ sizeof(retry_capsules[1]), (UINT64)(UINTN)&retry_capsules[1] },
				{ 0U, 0U },
			};
			EFI_STATUS retry_status;

			/* A mixed FMP/populate list must allocate the latter's table before
			 * applying the former.  Fail that third scatter allocation, then
			 * prove the same request can be retried without an FMP update. */
			retry_capsules[0].outer.flags = CDK2_CAPSULE_PERSIST;
			retry_capsules[1].outer.guid = (EFI_GUID) { .data1 = 0x87654321U };
			retry_capsules[1].outer.flags = CDK2_CAPSULE_PERSIST |
				CDK2_CAPSULE_POPULATE;
			pool_failure = pool_allocations + 2U;
			retry_status = protocol->process_scatter(protocol,
				(UINT64)(UINTN)retry_scatter);
			assert(retry_status == EFI_OUT_OF_RESOURCES);
			assert(sets == 0U);
			pool_failure = MAX_UINTN;
			retry_status = protocol->process_scatter(protocol,
				(UINT64)(UINTN)retry_scatter);
			if (retry_status != EFI_SUCCESS)
				fprintf(stderr, "capsule scatter retry returned %#llx\n",
					(unsigned long long)retry_status);
			assert(retry_status == EFI_SUCCESS);
			assert(sets == 1U);
		}
		sets = 0U;
		checks = 0U;

		capsule.outer.flags = CDK2_CAPSULE_RESET;
		assert(protocol->validate_capsule(protocol, &capsule,
			sizeof(capsule)) == EFI_INVALID_PARAMETER);
		assert(checks == 0U && sets == 0U);
		capsule.outer.flags = 0U;
		capsule.outer.flags |= CDK2_CAPSULE_PERSIST | CDK2_CAPSULE_RESET;
		assert(protocol->process_scatter(protocol,
			(UINT64)(UINTN)deferred) == EFI_SUCCESS);
		assert(protocol->reset_required);
		events = 0U;
		assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_SUCCESS);
		assert(!protocol->reset_required);
		capsule.outer.flags = CDK2_CAPSULE_PERSIST;
		descriptor.attributes_supported = TEST_FMP_RESET_REQUIRED;
		descriptor.attributes_setting = TEST_FMP_RESET_REQUIRED;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_SUCCESS);
		assert(protocol->reset_required);
		events = 0U;
		assert(cdk2_capsule_runtime_entry((void *)5, &system.view) == EFI_SUCCESS);
		assert(!protocol->reset_required);
		descriptor.attributes_setting = 0U;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_SUCCESS);
		assert(!protocol->reset_required);
		descriptor.attributes_setting = TEST_FMP_RESET_REQUIRED;
		fmp_descriptor_version = 0U;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_COMPROMISED_DATA);
		assert(!protocol->reset_required);
		fmp_descriptor_version = 1U;
		fmp_descriptor_size = TEST_FMP_DESCRIPTOR_V1_SIZE - 1U;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_COMPROMISED_DATA);
		assert(!protocol->reset_required);
		fmp_descriptor_version = 3U;
		fmp_descriptor_size = sizeof(descriptor);
		descriptor.size = 0U;
		capsule.body.hardware_instance = 0U;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_SUCCESS);
		assert(!protocol->reset_required);
		descriptor.size = 4U;
		capsule.body.hardware_instance = 7U;
		check_image_status = EFI_SECURITY_VIOLATION;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_SECURITY_VIOLATION);
		assert(!protocol->reset_required);
		check_image_status = EFI_SUCCESS;
		check_image_status = EFI_DEVICE_ERROR;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) == EFI_DEVICE_ERROR);
		assert(protocol->outcome.completed && !protocol->outcome.active &&
			!protocol->outcome.set_begun && !protocol->outcome.unproved &&
			protocol->outcome.matching_checks == 1U &&
			protocol->outcome.capsule == &capsule &&
			protocol->outcome.check == &modeled_check &&
			protocol->outcome.fmp_protocol == &fmp);
		free_pool_failure = true;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) == EFI_DEVICE_ERROR);
		assert(protocol->outcome.unproved);
		free_pool_failure = false;
		{
			uint8_t saved_image[sizeof(capsule.body.image)];
			UINT32 saved_version = descriptor.version;

			memcpy(saved_image, capsule.body.image, sizeof(saved_image));
			capsule.body.capsule_support = 2;
			capsule.body.image_size = 19;
			capsule.body.image[0] = 0; /* PUSH_GUID */
			memcpy(capsule.body.image + 1, &descriptor.image_type, sizeof(EFI_GUID));
			capsule.body.image[17] = 0x0d; /* END */
			capsule.body.image[18] = 0xa5;
			descriptor.version = 1;
			fmp_handle_count = 2;
			handle_calls = 0;
			handle_failure_at = 2; /* dependency discovery fails, then another handle succeeds */
			assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) == EFI_DEVICE_ERROR);
			assert(protocol->outcome.unproved && protocol->outcome.matching_checks == 1);
			handle_failure_at = 0;
			fmp_handle_count = 1;
			for (unsigned int failure = 2; failure <= 4; failure++) {
				free_calls = 0;
				free_failure_at = failure; /* dependency package, descriptor, then stack */
				assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) == EFI_DEVICE_ERROR);
				assert(protocol->outcome.unproved && free_calls >= failure);
			}
			free_failure_at = 0;
			descriptor.version = saved_version;
			capsule.body.capsule_support = 0;
			capsule.body.image_size = 4;
			memcpy(capsule.body.image, saved_image, sizeof(saved_image));
		}
		fmp_handle_count = 2U;
		capsule.body.hardware_instance = 0U;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) == EFI_DEVICE_ERROR);
		assert(protocol->outcome.unproved && protocol->outcome.matching_checks == 2U);
		check_image_status = EFI_SUCCESS;
		sets = 0U;
		fmp_handle_count = 2U;
		capsule.body.hardware_instance = 0U;
		set_image_status_second = EFI_DEVICE_ERROR;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_DEVICE_ERROR);
		assert(sets == 2U && !protocol->reset_required);
		{
			struct fmp_test_capsule transaction[2] = { capsule, capsule };
			struct { UINT64 length, address; } transaction_scatter[3] = {
				{ sizeof(transaction[0]), (UINT64)(UINTN)&transaction[0] },
				{ sizeof(transaction[1]), (UINT64)(UINTN)&transaction[1] },
				{ 0U, 0U },
			};

			sets = 0U;
			fmp_handle_count = 1U;
			transaction[0].body.hardware_instance = 7U;
			transaction[1].body.hardware_instance = 7U;
			assert(protocol->process_scatter(protocol,
				(UINT64)(UINTN)transaction_scatter) == EFI_DEVICE_ERROR);
			assert(sets == 2U && !protocol->reset_required);
		}
		set_image_status_second = EFI_SUCCESS;
		capsule.body.hardware_instance = 7U;
		descriptor.attributes_setting = TEST_FMP_RESET_REQUIRED;
		set_image_status = EFI_DEVICE_ERROR;
		assert(protocol->process_capsule(protocol, &capsule, sizeof(capsule)) ==
			EFI_DEVICE_ERROR);
		assert(!protocol->reset_required);
		set_image_status = EFI_SUCCESS;
		descriptor.attributes_supported = 0U;
		descriptor.attributes_setting = 0U;
		capsule.outer.flags &= ~(CDK2_CAPSULE_PERSIST | CDK2_CAPSULE_RESET);
		sets = 0U;
		checks = 0U;
		package_names_freed = 0U;
	}
	blocks[0].length = sizeof(capsule);
	blocks[0].address = (UINT64)(UINTN)&capsule;
	blocks[1].length = 0U;
	blocks[1].address = 0U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) == EFI_SUCCESS &&
		checks == 1U && sets == 1U && last_vendor == NULL && package_names_freed == 1U);
	capsule.body.hardware_instance = 0U;
	fmp_handle_count = 2U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) == EFI_SUCCESS &&
		sets == 3U);
	capsule.body.image_version = 1U;
	capsule.body.hardware_instance = 7U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) == EFI_SUCCESS &&
		sets == 5U);
	capsule.body.image_version = 3U;
	fmp_handle_count = 1U;
	capsule.body.hardware_instance = 7U;
	capsule.body.capsule_support = 2U;
	capsule.body.image_size = 67U;
	for (UINTN index = 0; index < 33U; index++)
		capsule.body.image[index] = 0x06U; /* TRUE */
	for (UINTN index = 33U; index < 65U; index++)
		capsule.body.image[index] = 0x03U; /* AND */
	capsule.body.image[65] = 0x0dU; /* END */
	capsule.body.image[66] = 0xa5U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) == EFI_SUCCESS &&
		sets == 6U);
	capsule.body.image_size = 8U;
	capsule.body.image[0] = 0x0eU; /* DECLARE_LENGTH */
	capsule.body.image[1] = 7U;
	capsule.body.image[2] = capsule.body.image[3] = capsule.body.image[4] = 0U;
	capsule.body.image[5] = 0x06U; /* TRUE */
	capsule.body.image[6] = 0x0dU; /* END */
	capsule.body.image[7] = 0xa5U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) == EFI_SUCCESS &&
		sets == 7U);
	capsule.body.image_size = 1U;
	capsule.body.image[0] = 0x0eU;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) ==
		EFI_INVALID_PARAMETER);
	capsule.body.capsule_support = 3U;
	capsule.body.image_size = 40U;
	memset(capsule.body.image, 0, 40U);
	capsule.body.image[8] = 24U; /* WIN_CERTIFICATE_UEFI_GUID length. */
	capsule.body.image[32] = 0x0eU;
	capsule.body.image[33] = 7U;
	capsule.body.image[37] = 0x06U;
	capsule.body.image[38] = 0x0dU;
	capsule.body.image[39] = 0xa5U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) == EFI_SUCCESS &&
		sets == 8U);
	capsule.body.capsule_support = 0U;
	capsule.body.image_size = 4U;
	updatable_result = CDK2_FMP_IMAGE_UPDATABLE_VALID;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	fmp_handle_count = 2U;
	first_handle_status = EFI_DEVICE_ERROR;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	first_handle_status = EFI_SUCCESS;
	fmp_handle_count = 1U;
	updatable_result = CDK2_FMP_IMAGE_UPDATABLE_INVALID_OLD;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	updatable_result = 0U;
	{
		UINT64 maximum = 0;
		UINT32 reset_type = 9U;

		assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &maximum,
			&reset_type) == EFI_SUCCESS);
	}
	updatable_result = CDK2_FMP_IMAGE_UPDATABLE_INVALID;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	updatable_result = CDK2_FMP_IMAGE_UPDATABLE_INVALID_TYPE;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	updatable_result = CDK2_FMP_IMAGE_UPDATABLE_VALID_WITH_VENDOR_CODE;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	capsule.body.vendor_size = 1U;
	capsule.body.image[4] = 0x5aU;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	{
		UINTN prior_sets = sets;

		assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) ==
			EFI_SUCCESS);
		assert(sets == prior_sets + 1U &&
			last_vendor == &capsule.body.image[4] &&
			*(const UINT8 *)last_vendor == 0x5aU);
	}
	capsule.body.vendor_size = 0U;
	updatable_result = 6U;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	fmp.set_image = NULL;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	fmp.set_image = set_image;
	locate_status = EFI_NOT_FOUND;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U, &(UINT64) { 0 },
		&(UINT32) { 0 }) == EFI_SUCCESS);
	locate_status = EFI_SUCCESS;
	updatable_result = CDK2_FMP_IMAGE_UPDATABLE_VALID;
	set_image_status = 1U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) == 1U);
	set_image_status = EFI_SUCCESS;
	sets = 0U;
	fmp_handle_count = 2U;
	capsule.body.hardware_instance = 0U;
	set_image_status = 1U;
	set_image_status_second = EFI_DEVICE_ERROR;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) ==
		EFI_DEVICE_ERROR);
	set_image_status = set_image_status_second = EFI_SUCCESS;
	fmp_handle_count = 1U;
	capsule.body.hardware_instance = 7U;
	capsule.outer.header_size = 0U;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U,
		&(UINT64) { 0 }, &(UINT32) { 0 }) == EFI_INVALID_PARAMETER);
	capsule.outer.header_size = sizeof(capsule.outer);
	capsule.outer.flags = CDK2_CAPSULE_PERSIST;
	blocks[0].length = 0U;
	blocks[0].address = 0U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U,
		(UINT64)(UINTN)blocks) == EFI_INVALID_PARAMETER);
	blocks[0].length = sizeof(capsule) - 1U;
	blocks[0].address = (UINT64)(UINTN)&capsule;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U,
		(UINT64)(UINTN)blocks) == EFI_INVALID_PARAMETER);
	blocks[0].length = 0x567800U;
	blocks[0].address = (UINT64)(UINTN)&capsule;
	blocks[1].length = 0x567800U;
	blocks[1].address = (UINT64)(UINTN)capsule.body.image;
	blocks[2].length = 0U;
	blocks[2].address = 0U;
	flush_status = EFI_DEVICE_ERROR;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U,
		(UINT64)(UINTN)blocks) == EFI_DEVICE_ERROR);
	blocks[0].length = sizeof(capsule);
	blocks[0].address = (UINT64)(UINTN)&capsule;
	blocks[1].length = 0U;
	blocks[1].address = 0U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U,
		(UINT64)(UINTN)blocks) == EFI_DEVICE_ERROR && variables == 0U);
	flush_status = EFI_SUCCESS;
	flushes = 0U;
	for (UINTN sequence = 0; sequence < 12U; sequence++)
		assert(((update_fn *)runtime.update_capsule)(capsules, 1U,
			(UINT64)(UINTN)blocks) == EFI_SUCCESS);
	assert(variables == 12U && flushes == 36U && last_name[17] == L'1' &&
		last_name[18] == L'1' && last_name[19] == 0);
	assert(notification[0] != NULL && notification[1] != NULL);
	checks_before_runtime = checks;
	sets_before_runtime = sets;
	notification[1]((void *)3, NULL);
	assert(converts == 0U);
	capsule.outer.flags = 0U;
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U, 0U) ==
		EFI_OUT_OF_RESOURCES);
	assert(sets == sets_before_runtime && checks == checks_before_runtime);
	diagnostic_runtime_guard_prepare();
	notification[0]((void *)2, NULL);
	assert(converts == 6U && runtime_pointer_converted);
	capsule.outer.flags = CDK2_CAPSULE_PERSIST;
	capsule.outer.header_size = 0U;
	assert(((query_fn *)runtime.query_capsule)(capsules, 1U,
		&(UINT64) { 0 }, &(UINT32) { 0 }) == EFI_INVALID_PARAMETER);
	capsule.outer.header_size = sizeof(capsule.outer);
	assert(((update_fn *)runtime.update_capsule)(capsules, 1U,
		(UINT64)(UINTN)blocks) == EFI_SUCCESS);
	/* Runtime scatter storage is a physical ACPI NVS address, not a pointer
	 * covered by ConvertPointer. */
	assert(converts == 6U && variables == 13U);
	diagnostic_runtime_guard_finish();
	return 0;
}
