/* SPDX-License-Identifier: GPL-2.0-only */
#include <assert.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include <cdk2/system_fmp_provider.h>
#include <guid/cbmem_table_hob.h>
#include <pi/hob.h>

#include "../src/boot/coreboot.h"

#if defined(__x86_64__)
#define MS_VA_LIST __builtin_ms_va_list
#define MS_VA_START(list, last) __builtin_ms_va_start(list, last)
#define MS_VA_END(list) __builtin_ms_va_end(list)
#define MS_VA_ARG(list, type) __builtin_va_arg(list, type)
#else
#define MS_VA_LIST va_list
#define MS_VA_START(list, last) va_start(list, last)
#define MS_VA_END(list) va_end(list)
#define MS_VA_ARG(list, type) va_arg(list, type)
#endif

EFI_STATUS cdk2_system_fmp_test_cache_bounds(void *base, size_t size,
	uintptr_t *first, uintptr_t *last);
EFI_STATUS cdk2_system_fmp_test_coreboot_handoff(
	const struct cdk2_system_table_view *system, struct cdk2_coreboot_handoff *handoff);

typedef EFI_STATUS CDK2_MS_ABI unload_fn(void *);
struct loaded_image_protocol {
	UINT32 revision;
	void *parent_handle, *system_table, *device_handle, *file_path, *reserved;
	UINT32 load_options_size;
	void *load_options, *image_base;
	UINT64 image_size;
	UINT32 image_code_type, image_data_type;
	unload_fn *unload;
};
struct configuration_table_view {
	EFI_GUID guid;
	void *table;
};
struct hob_fixture {
	EFI_HOB_HANDOFF_INFO_TABLE handoff;
	EFI_HOB_GUID_TYPE coreboot_guid;
	COREBOOT_TABLE_HOB coreboot_table;
	EFI_HOB_GENERIC_HEADER end;
};
struct duplicate_hob_fixture {
	EFI_HOB_HANDOFF_INFO_TABLE handoff;
	EFI_HOB_GUID_TYPE first_guid;
	COREBOOT_TABLE_HOB first_table;
	EFI_HOB_GUID_TYPE second_guid;
	COREBOOT_TABLE_HOB second_table;
	EFI_HOB_GENERIC_HEADER end;
};

static const EFI_GUID hob_list_guid = {
	0x7739f24c, 0x93d7, 0x11d4,
	{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d }
};
static const EFI_GUID coreboot_table_guid = {
	0x9e0d4b6f, 0xa8e8, 0x4d7e,
	{ 0x9a, 0x2d, 0x31, 0x0d, 0x4c, 0x9a, 0x8f, 0x2b }
};
const EFI_GUID cdk2_system_fmp_protocol_guid = {
	0x86c77a67, 0x0b97, 0x4633,
	{ 0xa1, 0x87, 0x49, 0x10, 0x4d, 0x06, 0x85, 0xc7 }
};
static struct cb_header raw_coreboot;
static struct loaded_image_protocol loaded;
static UINTN parses, initializes, closes, installs, uninstalls;
static EFI_STATUS parse_status, initialize_status, close_status;
static EFI_STATUS install_status, uninstall_status;
static EFI_STATUS handle_status;
static struct cdk2_system_fmp_provider *initialized_provider;

static EFI_STATUS CDK2_MS_ABI prior_unload(void *image)
{
	(void)image;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_coreboot_parse_table(const void *table, UINTN size,
	struct cdk2_coreboot_handoff *handoff)
{
	parses++;
	assert(table == &raw_coreboot && size == sizeof(raw_coreboot));
	if (EFI_ERROR(parse_status))
		return parse_status;
	memset(handoff, 0, sizeof(*handoff));
	handoff->header = table;
	handoff->table_size = size;
	return EFI_SUCCESS;
}

void cdk2_system_fmp_sha256(const void *data, size_t size, uint8_t output[32])
{
	(void)data;
	(void)size;
	memset(output, 0, 32U);
}

EFI_STATUS cdk2_system_fmp_provider_initialize(
	struct cdk2_system_fmp_provider *provider,
	const struct cdk2_system_fmp_session_config *config)
{
	initializes++;
	assert(config->coreboot->header == &raw_coreboot);
	assert(config->certificate_xdr != NULL &&
		config->certificate_xdr_size == 1442U);
	assert(config->dependency_versions == NULL &&
		config->dependency_version_count == 0U);
	assert(config->transport_port.sha256 != NULL &&
		config->transport_port.publish != NULL &&
		config->transport_port.acquire != NULL &&
		config->transport_port.barrier != NULL &&
		config->transport_port.trigger_apm_io8 != NULL);
	if (EFI_ERROR(initialize_status))
		return initialize_status;
	initialized_provider = provider;
	provider->session.initialized = true;
	provider->session.ready = true;
	return EFI_SUCCESS;
}

EFI_STATUS cdk2_system_fmp_provider_close(
	struct cdk2_system_fmp_provider *provider)
{
	closes++;
	if (EFI_ERROR(close_status))
		return close_status;
	memset(provider, 0, sizeof(*provider));
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI handle_protocol(void *image, EFI_GUID *guid,
	void **interface)
{
	(void)image;
	(void)guid;
	if (EFI_ERROR(handle_status))
		return handle_status;
	*interface = &loaded;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI install_multiple(void **handle, ...)
{
	static const EFI_GUID check_guid = CDK2_CAPSULE_CHECK_OUTCOME_GUID;
	MS_VA_LIST arguments;
	const EFI_GUID *guid;

	MS_VA_START(arguments, handle);
	guid = MS_VA_ARG(arguments, const EFI_GUID *);
	assert(memcmp(guid, &cdk2_system_fmp_protocol_guid, sizeof(*guid)) == 0);
	assert(MS_VA_ARG(arguments, void *) == &initialized_provider->protocol);
	guid = MS_VA_ARG(arguments, const EFI_GUID *);
	assert(memcmp(guid, &check_guid, sizeof(*guid)) == 0);
	assert(MS_VA_ARG(arguments, void *) == &initialized_provider->check_outcome);
	assert(MS_VA_ARG(arguments, void *) == NULL);
	MS_VA_END(arguments);
	installs++;
	if (EFI_ERROR(install_status))
		return install_status;
	*handle = (void *)0x1234;
	return EFI_SUCCESS;
}

static EFI_STATUS CDK2_MS_ABI uninstall_multiple(void *handle, ...)
{
	static const EFI_GUID check_guid = CDK2_CAPSULE_CHECK_OUTCOME_GUID;
	MS_VA_LIST arguments;
	const EFI_GUID *guid;

	MS_VA_START(arguments, handle);
	guid = MS_VA_ARG(arguments, const EFI_GUID *);
	assert(memcmp(guid, &cdk2_system_fmp_protocol_guid, sizeof(*guid)) == 0);
	assert(MS_VA_ARG(arguments, void *) == &initialized_provider->protocol);
	guid = MS_VA_ARG(arguments, const EFI_GUID *);
	assert(memcmp(guid, &check_guid, sizeof(*guid)) == 0);
	assert(MS_VA_ARG(arguments, void *) == &initialized_provider->check_outcome);
	assert(MS_VA_ARG(arguments, void *) == NULL);
	MS_VA_END(arguments);
	assert(handle == (void *)0x1234);
	uninstalls++;
	return uninstall_status;
}

static void fixture_initialize(struct hob_fixture *fixture,
	struct configuration_table_view *table,
	struct cdk2_system_table_view *system,
	struct cdk2_boot_services_view *boot)
{
	memset(fixture, 0, sizeof(*fixture));
	fixture->handoff.header.hob_type = EFI_HOB_TYPE_HANDOFF;
	fixture->handoff.header.hob_length = sizeof(fixture->handoff);
	fixture->handoff.efi_end_of_hob_list = (UINTN)&fixture->end;
	fixture->coreboot_guid.header.hob_type = EFI_HOB_TYPE_GUID_EXTENSION;
	fixture->coreboot_guid.header.hob_length =
		sizeof(fixture->coreboot_guid) + sizeof(fixture->coreboot_table);
	fixture->coreboot_guid.name = coreboot_table_guid;
	fixture->coreboot_table.address = (UINTN)&raw_coreboot;
	fixture->coreboot_table.size = sizeof(raw_coreboot);
	fixture->end.hob_type = EFI_HOB_TYPE_END_OF_HOB_LIST;
	fixture->end.hob_length = sizeof(fixture->end);
	*table = (struct configuration_table_view) {
		.guid = hob_list_guid,
		.table = fixture,
	};
	memset(boot, 0, sizeof(*boot));
	boot->handle_protocol = (void *)handle_protocol;
	boot->install_multiple = (void *)install_multiple;
	boot->uninstall_multiple = (void *)uninstall_multiple;
	memset(system, 0, sizeof(*system));
	system->boot = boot;
	system->table_entries = 1U;
	system->configuration_table = table;
}

int main(void)
{
	struct hob_fixture fixture;
	struct configuration_table_view tables[2];
	struct cdk2_system_table_view system;
	struct cdk2_boot_services_view boot;
	struct cdk2_coreboot_handoff handoff;
	struct duplicate_hob_fixture duplicate;
	UINTN close_before;
	uintptr_t first, last;

	fixture_initialize(&fixture, &tables[0], &system, &boot);
	assert(cdk2_system_fmp_test_cache_bounds(NULL, 1U, &first, &last) ==
		EFI_INVALID_PARAMETER);
	assert(cdk2_system_fmp_test_cache_bounds((void *)UINTPTR_MAX, 1U,
		&first, &last) == EFI_INVALID_PARAMETER);
	assert(cdk2_system_fmp_test_cache_bounds((void *)(UINTPTR_MAX - 63U), 63U,
		&first, &last) == EFI_SUCCESS);
	assert(first == UINTPTR_MAX - 63U && last == first);
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_SUCCESS && parses == 1U);
	assert(cdk2_system_fmp_test_coreboot_handoff(&system,
		(struct cdk2_coreboot_handoff *)MAX_UINTN) == EFI_INVALID_PARAMETER);
	system.table_entries = 257U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_INVALID_PARAMETER);
	system.table_entries = 1U;
	system.configuration_table = (void *)(MAX_UINTN - 1U);
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_INVALID_PARAMETER);
	system.configuration_table = tables;
	system.configuration_table = (UINT8 *)tables + 1U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_INVALID_PARAMETER);
	system.configuration_table = tables;
	tables[0].table = (void *)(MAX_UINTN - sizeof(fixture.handoff) + 1U);
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	tables[0].table = &fixture;

	tables[0].guid.data1 ^= 1U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_NOT_FOUND);
	tables[0].guid.data1 ^= 1U;
	tables[1] = tables[0];
	system.table_entries = 2U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	system.table_entries = 1U;
	fixture.handoff.efi_end_of_hob_list = (UINTN)&fixture - 1U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	fixture.handoff.efi_end_of_hob_list = (UINTN)&fixture.end;
	fixture.coreboot_table.reserved = 1U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	fixture.coreboot_table.reserved = 0U;
	fixture.coreboot_guid.header.hob_length--;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	fixture.coreboot_guid.header.hob_length++;
	fixture.coreboot_guid.header.hob_length += 8U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	fixture.coreboot_guid.header.hob_length -= 8U;
	fixture.coreboot_table.address = 0U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	fixture.coreboot_table.address = (UINTN)&raw_coreboot;
	fixture.coreboot_table.size = sizeof(raw_coreboot) - 1U;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	fixture.coreboot_table.size = sizeof(raw_coreboot);
	parse_status = EFI_COMPROMISED_DATA;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	parse_status = EFI_SUCCESS;

	memset(&duplicate, 0, sizeof(duplicate));
	duplicate.handoff.header.hob_type = EFI_HOB_TYPE_HANDOFF;
	duplicate.handoff.header.hob_length = sizeof(duplicate.handoff);
	duplicate.handoff.efi_end_of_hob_list = (UINTN)&duplicate.end;
	duplicate.first_guid.header.hob_type = EFI_HOB_TYPE_GUID_EXTENSION;
	duplicate.first_guid.header.hob_length =
		sizeof(duplicate.first_guid) + sizeof(duplicate.first_table);
	duplicate.first_guid.name = coreboot_table_guid;
	duplicate.first_table.address = (UINTN)&raw_coreboot;
	duplicate.first_table.size = sizeof(raw_coreboot);
	duplicate.second_guid = duplicate.first_guid;
	duplicate.second_table = duplicate.first_table;
	duplicate.end.hob_type = EFI_HOB_TYPE_END_OF_HOB_LIST;
	duplicate.end.hob_length = sizeof(duplicate.end);
	tables[0].table = &duplicate;
	assert(cdk2_system_fmp_test_coreboot_handoff(&system, &handoff) ==
		EFI_COMPROMISED_DATA);
	tables[0].table = &fixture;

	loaded.unload = prior_unload;
	assert(cdk2_system_fmp_entry(NULL, &system) == EFI_INVALID_PARAMETER);
	assert(cdk2_system_fmp_entry((void *)5,
		(struct cdk2_system_table_view *)MAX_UINTN) == EFI_INVALID_PARAMETER);
	system.boot = (struct cdk2_boot_services_view *)MAX_UINTN;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_INVALID_PARAMETER);
	system.boot = &boot;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_SUCCESS);
	assert(initializes == 1U && installs == 1U &&
		loaded.unload == cdk2_system_fmp_unload);
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_ALREADY_STARTED);
	assert(cdk2_system_fmp_unload((void *)6) == EFI_INVALID_PARAMETER);
	initialized_provider->busy = TRUE;
	assert(cdk2_system_fmp_unload((void *)5) == EFI_ACCESS_DENIED);
	assert(uninstalls == 0U && closes == 0U &&
		loaded.unload == cdk2_system_fmp_unload);
	initialized_provider->busy = FALSE;
	uninstall_status = EFI_DEVICE_ERROR;
	assert(cdk2_system_fmp_unload((void *)5) == EFI_DEVICE_ERROR);
	assert(uninstalls == 1U && closes == 0U &&
		loaded.unload == cdk2_system_fmp_unload);
	uninstall_status = EFI_SUCCESS;
	close_status = EFI_DEVICE_ERROR;
	assert(cdk2_system_fmp_unload((void *)5) == EFI_DEVICE_ERROR);
	assert(uninstalls == 2U && closes == 1U);
	close_status = EFI_SUCCESS;
	assert(cdk2_system_fmp_unload((void *)5) == EFI_SUCCESS);
	assert(uninstalls == 2U && closes == 2U && loaded.unload == prior_unload);
	assert(cdk2_system_fmp_unload((void *)5) == EFI_NOT_STARTED);

	install_status = EFI_DEVICE_ERROR;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_DEVICE_ERROR);
	assert(closes == 3U && loaded.unload == prior_unload);
	install_status = EFI_SUCCESS;
	handle_status = EFI_NOT_FOUND;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_NOT_FOUND);
	assert(closes == 4U && installs == 2U);
	handle_status = EFI_SUCCESS;
	initialize_status = EFI_COMPROMISED_DATA;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_COMPROMISED_DATA);
	assert(installs == 2U);

	initialize_status = EFI_SUCCESS;
	install_status = EFI_DEVICE_ERROR;
	close_status = EFI_ACCESS_DENIED;
	close_before = closes;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_ACCESS_DENIED);
	assert(closes == close_before + 1U);
	close_status = EFI_SUCCESS;
	install_status = EFI_SUCCESS;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_SUCCESS);
	assert(closes == close_before + 2U);
	assert(cdk2_system_fmp_unload((void *)5) == EFI_SUCCESS);

	handle_status = EFI_NOT_FOUND;
	close_status = EFI_ACCESS_DENIED;
	close_before = closes;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_ACCESS_DENIED);
	assert(closes == close_before + 1U);
	close_status = EFI_SUCCESS;
	handle_status = EFI_SUCCESS;
	assert(cdk2_system_fmp_entry((void *)5, &system) == EFI_SUCCESS);
	assert(closes == close_before + 2U);
	assert(cdk2_system_fmp_unload((void *)5) == EFI_SUCCESS);
	return 0;
}
