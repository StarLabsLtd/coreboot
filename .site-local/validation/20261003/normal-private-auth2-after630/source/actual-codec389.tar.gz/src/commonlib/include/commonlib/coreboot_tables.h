/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef COMMONLIB_COREBOOT_TABLES_H
#define COMMONLIB_COREBOOT_TABLES_H

#include <stddef.h>
#include <stdint.h>

/* The coreboot table information is for conveying information
 * from the firmware to the loaded OS image.  Primarily this
 * is expected to be information that cannot be discovered by
 * other means, such as querying the hardware directly.
 *
 * All of the information should be Position Independent Data.
 * That is it should be safe to relocated any of the information
 * without it's meaning/correctness changing.   For table that
 * can reasonably be used on multiple architectures the data
 * size should be fixed.  This should ease the transition between
 * 32 bit and 64 bit architectures etc.
 *
 * The completeness test for the information in this table is:
 * - Can all of the hardware be detected?
 * - Are the per motherboard constants available?
 * - Is there enough to allow a kernel to run that was written before
 *   a particular motherboard is constructed? (Assuming the kernel
 *   has drivers for all of the hardware but it does not have
 *   assumptions on how the hardware is connected together).
 *
 * With this test it should be straight forward to determine if a
 * table entry is required or not.  This should remove much of the
 * long term compatibility burden as table entries which are
 * irrelevant or have been replaced by better alternatives may be
 * dropped.  Of course it is polite and expedite to include extra
 * table entries and be backwards compatible, but it is not required.
 */

enum {
	LB_TAG_UNUSED			= 0x0000,
	LB_TAG_MEMORY			= 0x0001,
	LB_TAG_HWRPB			= 0x0002,
	LB_TAG_MAINBOARD		= 0x0003,
	LB_TAG_VERSION			= 0x0004,
	LB_TAG_EXTRA_VERSION		= 0x0005,
	LB_TAG_BUILD			= 0x0006,
	LB_TAG_COMPILE_TIME		= 0x0007,
	LB_TAG_COMPILE_BY		= 0x0008,
	LB_TAG_COMPILE_HOST		= 0x0009,
	LB_TAG_COMPILE_DOMAIN		= 0x000a,
	LB_TAG_COMPILER			= 0x000b,
	LB_TAG_LINKER			= 0x000c,
	LB_TAG_ASSEMBLER		= 0x000d,
	LB_TAG_SERIAL			= 0x000f,
	LB_TAG_CONSOLE			= 0x0010,
	LB_TAG_FORWARD			= 0x0011,
	LB_TAG_FRAMEBUFFER		= 0x0012,
	LB_TAG_GPIO			= 0x0013,
	LB_TAG_TIMESTAMPS		= 0x0016,
	LB_TAG_CBMEM_CONSOLE		= 0x0017,
	LB_TAG_MRC_CACHE		= 0x0018,
	LB_TAG_VBNV			= 0x0019,
	LB_TAG_VBOOT_HANDOFF		= 0x0020,  /* deprecated */
	LB_TAG_X86_ROM_MTRR		= 0x0021,
	LB_TAG_DMA			= 0x0022,
	LB_TAG_RAM_OOPS			= 0x0023,
	LB_TAG_ACPI_GNVS		= 0x0024,
	LB_TAG_BOARD_ID			= 0x0025,  /* deprecated */
	LB_TAG_VERSION_TIMESTAMP	= 0x0026,
	LB_TAG_WIFI_CALIBRATION		= 0x0027,
	LB_TAG_RAM_CODE			= 0x0028,  /* deprecated */
	LB_TAG_SPI_FLASH		= 0x0029,
	LB_TAG_SERIALNO			= 0x002a,
	LB_TAG_MTC			= 0x002b,
	LB_TAG_VPD			= 0x002c,
	LB_TAG_SKU_ID			= 0x002d,  /* deprecated */
	LB_TAG_BOOT_MEDIA_PARAMS	= 0x0030,
	LB_TAG_CBMEM_ENTRY		= 0x0031,
	LB_TAG_TSC_INFO			= 0x0032,
	LB_TAG_MAC_ADDRS		= 0x0033,
	LB_TAG_VBOOT_WORKBUF		= 0x0034,
	LB_TAG_MMC_INFO			= 0x0035,
	LB_TAG_TPM_CB_LOG		= 0x0036,
	LB_TAG_FMAP			= 0x0037,
	LB_TAG_PLATFORM_BLOB_VERSION	= 0x0038,
	LB_TAG_SMMSTOREV2		= 0x0039,
	LB_TAG_TPM_PPI_HANDOFF		= 0x003a,
	LB_TAG_BOARD_CONFIG		= 0x0040,
	LB_TAG_ACPI_CNVS		= 0x0041,
	LB_TAG_TYPE_C_INFO		= 0x0042,
	LB_TAG_ACPI_RSDP		= 0x0043,
	LB_TAG_PCIE			= 0x0044,
	LB_TAG_EFI_FW_INFO		= 0x0045,
	LB_TAG_CAPSULE			= 0x0046,
	LB_TAG_CFR_ROOT			= 0x0047,
	LB_TAG_ROOT_BRIDGE_INFO		= 0x0048,
	LB_TAG_PANEL_POWEROFF		= 0x0049,
	LB_TAG_SDHCI_NONPCI		= 0x004a,
	LB_TAG_PAYLOAD_RESOURCE_HANDOFF	= 0x004b,
	LB_TAG_LOCAL_APIC_TIMER_INFO	= 0x004e,
	LB_TAG_PAYLOAD_SPI_CONSOLE	= 0x0050,
	LB_TAG_BOOT_SPLASH		= 0x0051,
	LB_TAG_CAPSULE_HANDOFF		= 0x0052,
	LB_TAG_DMA_HANDOFF		= 0x0053,
	LB_TAG_CAPSULE_BROKER_ENDPOINT	= 0x0054,
	LB_TAG_AUTHVAR_SERVICE_ENDPOINT	= 0x0055,
	LB_TAG_AUTHVAR_PRESENCE_ENDPOINT = 0x0056,
	LB_TAG_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_ENDPOINT = 0x0057,
	LB_TAG_PAYLOAD_BOOT_PRIVATE_BUFFER = 0x0058,
	LB_TAG_CAPSULE_DELIVERY_POLICY	= 0x0059,
	/* The following options are CMOS-related */
	LB_TAG_CMOS_OPTION_TABLE	= 0x00c8,
	LB_TAG_OPTION			= 0x00c9,
	LB_TAG_OPTION_ENUM		= 0x00ca,
	LB_TAG_OPTION_DEFAULTS		= 0x00cb,
	LB_TAG_OPTION_CHECKSUM		= 0x00cc,
	LB_TAG_BOOT_MODE		= 0x00cd,
};

/* All table entry base addresses and sizes must be 4-byte aligned. */
#define LB_ENTRY_ALIGN 4

/* Since coreboot is usually compiled 32bit, gcc will align 64bit
 * types to 32bit boundaries. If the coreboot table is dumped on a
 * 64bit system, a uint64_t would be aligned to 64bit boundaries,
 * breaking the table format.
 *
 * lb_uint64_t will keep 64bit coreboot table values aligned to 32bit
 * to ensure compatibility.
 */

typedef __aligned(LB_ENTRY_ALIGN) uint64_t lb_uint64_t;

struct lb_header {
	uint8_t  signature[4]; /* LBIO */
	uint32_t header_bytes;
	uint32_t header_checksum;
	uint32_t table_bytes;
	uint32_t table_checksum;
	uint32_t table_entries;
};

/* Every entry in the boot environment list will correspond to a boot
 * info record.  Encoding both type and size.  The type is obviously
 * so you can tell what it is.  The size allows you to skip that
 * boot environment record if you don't know what it is.  This allows
 * forward compatibility with records not yet defined.
 */
struct lb_record {
	uint32_t tag;		/* tag ID */
	uint32_t size;		/* size of record (in bytes) */
};

struct lb_local_apic_timer_info {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t reserved;
	lb_uint64_t frequency_hz;
};

_Static_assert(sizeof(struct lb_local_apic_timer_info) == 20,
	"local APIC timer record ABI changed");
_Static_assert(offsetof(struct lb_local_apic_timer_info, frequency_hz) == 12,
	"local APIC timer frequency offset changed");

struct lb_memory_range {
	lb_uint64_t start;
	lb_uint64_t size;
	uint32_t type;
#define LB_MEM_RAM		 1	/* Memory anyone can use */
#define LB_MEM_RESERVED		 2	/* Don't use this memory region */
#define LB_MEM_ACPI		 3	/* ACPI Tables */
#define LB_MEM_NVS		 4	/* ACPI NVS Memory */
#define LB_MEM_UNUSABLE		 5	/* Unusable address space */
#define LB_MEM_VENDOR_RSVD	 6	/* Vendor Reserved */
/*
 * The memory type [1 ... 16) needs to match
 * https://uefi.org/htmlspecs/ACPI_Spec_6_4_html/15_System_Address_Map_Interfaces/Sys_Address_Map_Interfaces.html
 */
#define LB_MEM_TABLE		16	/* Ram configuration tables are kept in */
#define LB_MEM_TAG		17	/* Armv9 tag storage for MTE */
#define LB_MEM_SOFT_RESERVED	0xefffffff /* Specific purpose memory */
};

struct lb_memory {
	uint32_t tag;
	uint32_t size;
	struct lb_memory_range map[];
};

struct lb_pcie {
	uint32_t tag;
	uint32_t size;
	lb_uint64_t ctrl_base;		/* Base address of PCIe controller */
};

#define LB_PAYLOAD_RESOURCE_HANDOFF_REVISION 3
#define LB_PAYLOAD_RESOURCE_HANDOFF_REVISION_4 4

#define LB_PRH_SECTION_PCI_ROOT_BRIDGES 3
#define LB_PRH_SECTION_PCI_ASSIGNMENTS  4
#define LB_PRH_SECTION_BOOT_INTENT      5
#define LB_PRH_SECTION_MEMORY_POLICY    1
#define LB_PRH_SECTION_FRAMEBUFFER      7
#define LB_PRH_SECTION_PCI_TOPOLOGY     8

#define LB_PRH_PCI_ROOT_TOPOLOGY_ONLY 0x00000001

/* Resource type describes the assigned address aperture.  The assignment
 * flag below independently describes the BAR register encoding. */
#define LB_PRH_PCI_RESOURCE_IO              1
#define LB_PRH_PCI_RESOURCE_MMIO32          2
#define LB_PRH_PCI_RESOURCE_MMIO64          3
#define LB_PRH_PCI_RESOURCE_PREFETCH_MMIO32 4
#define LB_PRH_PCI_RESOURCE_PREFETCH_MMIO64 5
#define LB_PRH_PCI_ASSIGNMENT_64BIT 0x01
#define LB_PRH_PCI_MAX_ROOTS       16
#define LB_PRH_PCI_MAX_ASSIGNMENTS 256
#define LB_PRH_PCI_TOPOLOGY_MAX_ENTRIES 512
#define LB_PRH_PCI_TOPOLOGY_PATH_ONLY   0x01
#define LB_PRH_PCI_TOPOLOGY_PARENT_ROOT 0xffff
#define LB_PRH_GCD_MEMORY_TYPE_MMIO 3
#define LB_PRH_MEMORY_GCD_AUTHORITATIVE 0x00000004
#define LB_PRH_FRAMEBUFFER_GEOMETRY_AUTHORITATIVE 0x00000001
#define LB_PRH_FRAMEBUFFER_PCI_OWNER_AUTHORITATIVE 0x00000002
#define LB_PRH_FRAMEBUFFER_MEMORY_DELEGATED       0x80000000
#define LB_PRH_SECTION_FLAG_MANDATORY     0x0001
#define LB_PRH_SECTION_FLAG_AUTHORITATIVE 0x0002

#define LB_PRH_LIFETIME_COLD_BOOT          0x0000000000000001ULL
#define LB_PRH_LIFETIME_EXIT_BOOT_SERVICES 0x0000000000000008ULL

struct lb_payload_resource_section {
	uint16_t type;
	uint16_t flags;
	uint16_t header_length;
	uint16_t entry_size;
	uint32_t entry_count;
	uint32_t offset;
	uint32_t length;
};

struct lb_payload_resource_handoff {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_length;
	uint16_t section_header_length;
	uint16_t flags;
	uint32_t crc32;
	uint32_t section_count;
	uint32_t producer_stage;
	lb_uint64_t producer_generation;
	lb_uint64_t lifetime_flags;
	struct lb_payload_resource_section sections[];
};

struct lb_prh_pci_root_bridge {
	uint16_t segment;
	uint8_t bus_start;
	uint8_t bus_end;
	uint32_t flags;
	lb_uint64_t io_base;
	lb_uint64_t io_length;
	lb_uint64_t mem32_base;
	lb_uint64_t mem32_length;
	lb_uint64_t mem64_base;
	lb_uint64_t mem64_length;
	lb_uint64_t pref_mem32_base;
	lb_uint64_t pref_mem32_length;
	lb_uint64_t pref_mem64_base;
	lb_uint64_t pref_mem64_length;
};

struct lb_prh_pci_assignment {
	uint16_t segment;
	uint8_t bus;
	uint8_t device;
	uint8_t function;
	uint8_t bar;
	uint8_t resource_type;
	uint8_t flags;
	lb_uint64_t base;
	lb_uint64_t length;
	lb_uint64_t attributes;
};

struct lb_prh_pci_topology {
	uint16_t segment;
	uint8_t bus;
	uint8_t device;
	uint8_t function;
	uint8_t header_type;
	uint16_t parent_index;
	uint16_t vendor_id;
	uint16_t device_id;
	uint16_t command;
	uint8_t class_code;
	uint8_t subclass;
	uint8_t programming_interface;
	uint8_t secondary_bus;
	uint8_t subordinate_bus;
	uint8_t flags;
	uint32_t reserved;
} __packed;

struct lb_prh_boot_intent {
	uint16_t topology_index;
	uint16_t flags;
	uint32_t reserved;
} __packed;

struct lb_prh_memory_policy {
	lb_uint64_t base;
	lb_uint64_t length;
	lb_uint64_t capabilities;
	lb_uint64_t attributes;
	uint32_t gcd_type;
	uint32_t efi_memory_type;
	uint32_t owner_flags;
	uint32_t reserved;
};

struct lb_prh_framebuffer {
	lb_uint64_t physical_address;
	lb_uint64_t size;
	uint32_t x_resolution;
	uint32_t y_resolution;
	uint32_t bytes_per_line;
	uint8_t bits_per_pixel;
	uint8_t red_mask_pos;
	uint8_t red_mask_size;
	uint8_t green_mask_pos;
	uint8_t green_mask_size;
	uint8_t blue_mask_pos;
	uint8_t blue_mask_size;
	uint8_t reserved_mask_pos;
	uint8_t reserved_mask_size;
	union {
		uint8_t reserved[3];
		struct {
			uint16_t topology_index;
			uint8_t bar;
		} __packed;
	} __packed;
	uint32_t owner_flags;
};

_Static_assert(sizeof(struct lb_payload_resource_handoff) == 44,
	       "unexpected payload resource handoff header size");
_Static_assert(sizeof(struct lb_payload_resource_section) == 20,
	       "unexpected payload resource section size");
_Static_assert(sizeof(struct lb_prh_pci_root_bridge) == 88,
	       "unexpected payload resource root bridge size");
_Static_assert(sizeof(struct lb_prh_pci_assignment) == 32,
	       "unexpected payload resource PCI assignment size");
_Static_assert(sizeof(struct lb_prh_pci_topology) == 24,
	       "unexpected payload resource PCI topology size");
_Static_assert(sizeof(struct lb_prh_boot_intent) == 8,
	       "unexpected payload resource boot intent size");
_Static_assert(sizeof(struct lb_prh_memory_policy) == 48,
	       "unexpected payload resource memory policy size");
_Static_assert(sizeof(struct lb_prh_framebuffer) == 44,
	       "unexpected payload resource framebuffer size");
_Static_assert(offsetof(struct lb_prh_framebuffer, topology_index) == 37,
	       "unexpected payload resource framebuffer owner offset");
_Static_assert(offsetof(struct lb_prh_framebuffer, bar) == 39,
	       "unexpected payload resource framebuffer BAR offset");
_Static_assert(_Alignof(struct lb_pcie) == 4,
	       "lb_uint64_t alignment doesn't work as expected for struct lb_pcie!");

struct lb_hwrpb {
	uint32_t tag;
	uint32_t size;
	lb_uint64_t hwrpb;
};

struct lb_mainboard {
	uint32_t tag;
	uint32_t size;
	uint8_t  vendor_idx;
	uint8_t  part_number_idx;
	uint8_t  strings[];
};

struct lb_string {
	uint32_t tag;
	uint32_t size;
	uint8_t  string[];
};

struct lb_timestamp {
	uint32_t tag;
	uint32_t size;
	uint32_t timestamp;
};

/* 0xe is taken by v3 */

struct lb_serial {
	uint32_t tag;
	uint32_t size;
#define LB_SERIAL_TYPE_IO_MAPPED     1
#define LB_SERIAL_TYPE_MEMORY_MAPPED 2
	uint32_t type;
	uint32_t baseaddr;
	uint32_t baud;
	uint32_t regwidth;

	/* Crystal or input frequency to the chip containing the UART.
	 * Provide the board specific details to allow the payload to
	 * initialize the chip containing the UART and make independent
	 * decisions as to which dividers to select and their values
	 * to eventually arrive at the desired console baud-rate. */
	uint32_t input_hertz;
};

struct lb_console {
	uint32_t tag;
	uint32_t size;
	uint16_t type;
	uint8_t pad[2];
};

#define LB_TAG_CONSOLE_SERIAL8250	0
#define LB_TAG_CONSOLE_VGA		1 // OBSOLETE
#define LB_TAG_CONSOLE_BTEXT		2 // OBSOLETE
#define LB_TAG_CONSOLE_LOGBUF		3 // OBSOLETE
#define LB_TAG_CONSOLE_SROM		4 // OBSOLETE
#define LB_TAG_CONSOLE_EHCI		5
#define LB_TAG_CONSOLE_SERIAL8250MEM	6

struct lb_forward {
	uint32_t tag;
	uint32_t size;
	lb_uint64_t forward;
};

/**
 * coreboot framebuffer
 *
 * The coreboot framebuffer uses a very common format usually referred
 * to as "linear framebuffer":
 *
 * The first pixel of the framebuffer is the upper left corner, its
 * address is given by `physical_address`.
 *
 * Each pixel is represented by exactly `bits_per_pixel` bits. If a
 * pixel (or a color component therein) doesn't fill a whole byte or
 * doesn't start on a byte boundary, it starts at the least signifi-
 * cant bit not occupied by the previous pixel (or color component).
 * Pixels (or color components) that span multiple bytes always start
 * in the byte with the lowest address.
 *
 * The framebuffer provides a visible rectangle of `x_resolution` *
 * `y_resolution` pixels. However, the lines always start at a byte
 * boundary given by `bytes_per_line`, which may leave a gap after
 * each line of pixels. Thus, the data for a pixel with the coordi-
 * nates (x, y) from the upper left corner always starts at
 *
 *   physical_address + y * bytes_per_line + x * bits_per_pixel / 8
 *
 * `bytes_per_line` is always big enough to hold `x_resolution`
 * pixels. It can, however, be arbitrarily higher (e.g. to fulfill
 * hardware constraints or for optimization purposes). The size of
 * the framebuffer is always `y_resolution * bytes_per_line`.
 *
 * The coreboot framebuffer only supports RGB color formats. The
 * position and size of each color component are specified indivi-
 * dually by <color>_mask_pos and <color>_mask_size. To allow byte
 * or word aligned pixels, a fourth (padding) component may be
 * specified by `reserved_mask_pos` and `reserved_mask_size`.
 *
 * Software utilizing the coreboot framebuffer shall consider all
 * fields described above. It may, however, only implement a subset
 * of the possible color formats.
 */

/*
 * Framebuffer orientation, matches drm_connector.h drm_panel_orientation in the
 * Linux kernel.
 */
enum lb_fb_orientation {
	LB_FB_ORIENTATION_NORMAL = 0,
	LB_FB_ORIENTATION_BOTTOM_UP = 1,
	LB_FB_ORIENTATION_LEFT_UP = 2,
	LB_FB_ORIENTATION_RIGHT_UP = 3,
};

struct lb_framebuffer_flags {
	uint8_t has_external_display : 1;
	uint8_t has_dual_pipe : 1;
	uint8_t reserved : 6;
};

struct lb_framebuffer {
	uint32_t tag;
	uint32_t size;

	lb_uint64_t physical_address;
	uint32_t x_resolution;
	uint32_t y_resolution;
	uint32_t bytes_per_line;
	uint8_t bits_per_pixel;
	uint8_t red_mask_pos;
	uint8_t red_mask_size;
	uint8_t green_mask_pos;
	uint8_t green_mask_size;
	uint8_t blue_mask_pos;
	uint8_t blue_mask_size;
	uint8_t reserved_mask_pos;
	uint8_t reserved_mask_size;
	uint8_t orientation;
	struct lb_framebuffer_flags flags;
	uint8_t pad;
};

#define LB_BOOT_SPLASH_REVISION		2
#define LB_BOOT_SPLASH_FLAG_DISPLAYED	(1U << 0)
#define LB_BOOT_SPLASH_FLAG_BMP		(1U << 1)

struct lb_boot_splash {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t flags;
	lb_uint64_t framebuffer_address;
	uint32_t image_offset_x;
	uint32_t image_offset_y;
	uint32_t image_width;
	uint32_t image_height;
	lb_uint64_t bmp_address;
	uint32_t bmp_size;
};

_Static_assert(sizeof(struct lb_boot_splash) == 48, "boot splash record ABI changed");
_Static_assert(offsetof(struct lb_boot_splash, framebuffer_address) == 12,
	"boot splash framebuffer address offset changed");
_Static_assert(offsetof(struct lb_boot_splash, image_offset_x) == 20,
	"boot splash image offset changed");
_Static_assert(offsetof(struct lb_boot_splash, bmp_address) == 36,
	"boot splash BMP address offset changed");

struct lb_gpio {
	uint32_t port;
	uint32_t polarity;
#define ACTIVE_LOW	0
#define ACTIVE_HIGH	1
	uint32_t value;
#define GPIO_MAX_NAME_LENGTH 16
	uint8_t __nonstring name[GPIO_MAX_NAME_LENGTH];
};

struct lb_gpios {
	uint32_t tag;
	uint32_t size;

	uint32_t count;
	struct lb_gpio gpios[];
};

struct lb_range {
	uint32_t tag;
	uint32_t size;

	lb_uint64_t range_start;
	uint32_t range_size;
};

void lb_ramoops(struct lb_header *header);

struct lb_cbmem_ref {
	uint32_t tag;
	uint32_t size;

	lb_uint64_t cbmem_addr;
};

struct lb_x86_rom_mtrr {
	uint32_t tag;
	uint32_t size;
	/* The variable range MTRR index covering the ROM. */
	uint32_t index;
};

/* Memory map windows to translate addresses between SPI flash space and host address space. */
struct flash_mmap_window {
	uint32_t flash_base;
	uint32_t host_base;
	uint32_t size;
};

struct lb_spi_flash {
	uint32_t tag;
	uint32_t size;
	uint32_t flash_size;
	uint32_t sector_size;
	/*
	 * Note: `erase_cmd` was previously a uint32_t. It's now uint8_t because only
	 * the lowest byte was used, ensuring backward compatibility with older coreboot
	 * tables and allowing reuse of the remaining bytes.
	 */
	uint8_t erase_cmd;
#define LB_SPI_FLASH_FLAG_IN_4BYTE_ADDR_MODE    (1 << 0)
	uint8_t flags;
	uint16_t reserved;
	/*
	 * Number of mmap windows used by the platform to decode addresses between SPI flash
	 * space and host address space. This determines the number of entries in mmap_table.
	 */

	uint32_t mmap_count;
	struct flash_mmap_window mmap_table[];
};

struct lb_boot_media_params {
	uint32_t tag;
	uint32_t size;
	/* offsets are relative to start of boot media */
	lb_uint64_t fmap_offset;
	lb_uint64_t cbfs_offset;
	lb_uint64_t cbfs_size;
	lb_uint64_t boot_media_size;
};

/*
 * There can be more than one of these records as there is one per cbmem entry.
 */
struct lb_cbmem_entry {
	uint32_t tag;
	uint32_t size;

	lb_uint64_t address;
	uint32_t entry_size;
	uint32_t id;
};

struct lb_tsc_info {
	uint32_t tag;
	uint32_t size;

	uint32_t freq_khz;
};

struct mac_address {
	uint8_t mac_addr[6];
	uint8_t pad[2];		/* Pad it to 8 bytes to keep it simple. */
};

struct lb_mmc_info {
	uint32_t tag;
	uint32_t size;
	/*
	 * Passes the early mmc status to payload to indicate if firmware
	 * successfully sent CMD0, CMD1 to the card or not. In case of
	 * success, the payload can skip the first step of the initialization
	 * sequence which is to send CMD0, and instead start by sending CMD1
	 * as described in Jedec Standard JESD83-B1 section 6.4.3.
	 * passes 1 on success
	 */
	int32_t early_cmd1_status;
};

/*
 * USB Type-C Port Information
 * This record contains board-specific type-c port information.
 * There will be one record per type-C port.
 * Orientation fields should be of type enum type_c_orientation.
 */
enum type_c_orientation {
	/* The orientation of the signal follows the orientation of the CC lines. */
	TYPEC_ORIENTATION_NONE,
	/* The orientation of the signal is fixed to follow CC1 */
	TYPEC_ORIENTATION_NORMAL,
	/* The orientation of the signal is fixed to follow CC2 */
	TYPEC_ORIENTATION_REVERSE,
};

struct type_c_port_info {
	uint8_t usb2_port_number;
	uint8_t usb3_port_number;
	uint8_t sbu_orientation;
	uint8_t data_orientation;
};

struct type_c_info {
	uint32_t port_count;
	struct type_c_port_info port_info[];
};

struct lb_macs {
	uint32_t tag;
	uint32_t size;
	uint32_t count;
	struct mac_address mac_addrs[];
};

struct lb_board_config {
	uint32_t tag;
	uint32_t size;

	lb_uint64_t fw_config;
	uint32_t board_id;
	uint32_t ram_code;
	uint32_t sku_id;
	uint32_t soc_id;
};

#define MAX_SERIALNO_LENGTH	32

/* The following structures are for the CMOS definitions table */
/* CMOS header record */
struct cmos_option_table {
	uint32_t tag;               /* CMOS definitions table type */
	uint32_t size;               /* size of the entire table */
	uint32_t header_length;      /* length of header */
};

/* CMOS entry record
 * This record is variable length.  The name field may be
 * shorter than CMOS_MAX_NAME_LENGTH. The entry may start
 * anywhere in the byte, but can not span bytes unless it
 * starts at the beginning of the byte and the length is
 * fills complete bytes.
 */
struct cmos_entries {
	uint32_t tag;                /* entry type */
	uint32_t size;               /* length of this record */
	uint32_t bit;                /* starting bit from start of image */
	uint32_t length;             /* length of field in bits */
	uint32_t config;             /* e=enumeration, h=hex, r=reserved */
	uint32_t config_id;      /* a number linking to an enumeration record */
#define CMOS_MAX_NAME_LENGTH 32
	uint8_t name[CMOS_MAX_NAME_LENGTH]; /* name of entry in ascii,
					       variable length int aligned */
};

/* CMOS enumerations record
 * This record is variable length.  The text field may be
 * shorter than CMOS_MAX_TEXT_LENGTH.
 */
struct cmos_enums {
	uint32_t tag;		     /* enumeration type */
	uint32_t size;		     /* length of this record */
	uint32_t config_id;          /* a number identifying the config id */
	uint32_t value;              /* the value associated with the text */
#define CMOS_MAX_TEXT_LENGTH 32
	uint8_t text[CMOS_MAX_TEXT_LENGTH]; /* enum description in ascii,
						variable length int aligned */
};

/* CMOS defaults record
 * This record contains default settings for the CMOS ram.
 */
struct cmos_defaults {
	uint32_t tag;                /* default type */
	uint32_t size;               /* length of this record */
	uint32_t name_length;        /* length of the following name field */
	uint8_t name[CMOS_MAX_NAME_LENGTH]; /* name identifying the default */
#define CMOS_IMAGE_BUFFER_SIZE 256
	uint8_t default_set[CMOS_IMAGE_BUFFER_SIZE]; /* default settings */
};

struct	cmos_checksum {
	uint32_t tag;
	uint32_t size;
	/* In practice everything is byte aligned, but things are measured
	 * in bits to be consistent.
	 */
	uint32_t range_start; /* First bit that is checksummed (byte aligned) */
	uint32_t range_end;   /* Last bit that is checksummed (byte aligned) */
	uint32_t location;	/* First bit of the checksum (byte aligned) */
	uint32_t type;		/* Checksum algorithm that is used */
#define CHECKSUM_NONE	0
#define CHECKSUM_PCBIOS	1
};

/* SMMSTOREv2 record
 * This record contains information to use SMMSTOREv2.
 */

struct lb_smmstorev2 {
	uint32_t tag;
	uint32_t size;
	uint32_t num_blocks;		/* Number of writable blocks in SMM */
	uint32_t block_size;		/* Size of a block in byte. Default: 64 KiB */
	uint32_t mmap_addr_deprecated;	/* 32-bit MMIO address of the store for read only access.
					   Prefer 'mmap_addr' for new software.
					   Zero when the address won't fit into 32-bits. */
	uint32_t com_buffer;		/* Physical address of the communication buffer */
	uint32_t com_buffer_size;	/* Size of the communication buffer in bytes */
	uint8_t apm_cmd;		/* The command byte to write to the APM I/O port */
	uint8_t unused[3];		/* Set to zero */
	lb_uint64_t mmap_addr;		/* 64-bit MMIO address of the store for read only access.
					   Introduced after the initial implementation. Users of
					   this table must check the 'size' field to detect if its
					   written out by coreboot. */
};

struct lb_payload_spi_console {
	uint32_t tag;
	uint32_t size;
	uint16_t version;
	uint16_t request_header_size;
	lb_uint64_t com_buffer;
	uint32_t com_buffer_size;
	uint32_t max_chunk;
	uint32_t boot_limit;
	uint8_t apm_cmd;
	uint8_t reserved[3];
};

_Static_assert(sizeof(struct lb_payload_spi_console) == 36,
	"payload SPI console record ABI changed");
_Static_assert(offsetof(struct lb_payload_spi_console, com_buffer) == 12,
	"payload SPI console buffer offset changed");
_Static_assert(offsetof(struct lb_payload_spi_console, apm_cmd) == 32,
	"payload SPI console command offset changed");

enum lb_tpm_ppi_tpm_version {
	LB_TPM_VERSION_UNSPEC = 0,
	LB_TPM_VERSION_TPM_VERSION_1_2,
	LB_TPM_VERSION_TPM_VERSION_2,
};

/*
 * Handoff buffer for TPM Physical Presence Interface.
 * * ppi_address   Pointer to PPI buffer shared with ACPI
 *                 The layout of the buffer matches the QEMU virtual memory device
 *                 that is generated by QEMU.
 *                 See files 'hw/i386/acpi-build.c' and 'include/hw/acpi/tpm.h'
 *                 for details.
 * * tpm_version   TPM version: 1 for TPM1.2, 2 for TPM2.0
 * * ppi_version   BCD encoded version of TPM PPI interface
 */
struct lb_tpm_physical_presence {
	uint32_t tag;
	uint32_t size;
	uint32_t ppi_address;	/* Address of ACPI PPI communication buffer */
	uint8_t tpm_version;	/* 1: TPM1.2, 2: TPM2.0 */
	uint8_t ppi_version;	/* BCD encoded */
	uint8_t pad[2];
};


/*
 * Handoff the ACPI RSDP
 */
struct lb_acpi_rsdp {
	uint32_t tag;
	uint32_t size;
	lb_uint64_t rsdp_pointer; /* Address of the ACPI RSDP */
};

/*
 * Machine-friendly version of a system firmware component.  A component is
 * identified by a GUID.  coreboot is an obvious main component but there could
 * be others (like EC) which should get their own instances of the tag.
 *
 * The main consumer of this information is UEFI firmware but something else
 * could reuse it too.
 *
 * Larger number in a version field corresponds to a more recent version.
 */
struct lb_efi_fw_info {
	uint32_t tag;
	uint32_t size;
	uint8_t guid[16];			/* Called "firmware class" in UEFI */
	uint32_t version;			/* Current version */
	uint32_t lowest_supported_version;	/* Lowest allowed version for downgrades */
	uint32_t fw_size;			/* Size of firmware in bytes */
} __packed;

#define LB_CAPSULE_HANDOFF_REVISION 2

#define LB_CAPSULE_DELIVERY_POLICY_REVISION 1
#define LB_CAPSULE_DELIVERY_RAM (1U << 0)
#define LB_CAPSULE_DELIVERY_DISK (1U << 1)

/* Delivery policy describes capabilities, not discovery or flash authority. */
struct lb_capsule_delivery_policy {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t allowed_transports;
	lb_uint64_t max_nonpopulate;
	lb_uint64_t max_populate;
	uint32_t reserved[2];
} __packed;

_Static_assert(sizeof(struct lb_capsule_delivery_policy) == 40,
	"capsule delivery policy ABI");
_Static_assert(offsetof(struct lb_capsule_delivery_policy, allowed_transports) == 12 &&
	offsetof(struct lb_capsule_delivery_policy, max_nonpopulate) == 16 &&
	offsetof(struct lb_capsule_delivery_policy, max_populate) == 24 &&
	offsetof(struct lb_capsule_delivery_policy, reserved) == 32,
	"capsule delivery policy layout");

#define LB_CAPSULE_HANDOFF_AUTHENTICATED (1U << 0)
#define LB_CAPSULE_HANDOFF_RESET_REQUIRED (1U << 1)
#define LB_CAPSULE_HANDOFF_REQUIRED_FLAGS \
	(LB_CAPSULE_HANDOFF_AUTHENTICATED | LB_CAPSULE_HANDOFF_RESET_REQUIRED)

#define LB_CAPSULE_BROKER_COREBOOT_UPDATE 1
#define LB_CAPSULE_BROKER_APPLY_REGIONS     (1U << 0)
#define LB_CAPSULE_BROKER_PRESERVE_UNLISTED (1U << 1)
#define LB_CAPSULE_BROKER_VERIFY_READBACK   (1U << 2)
#define LB_CAPSULE_BROKER_REQUIRED_CAPABILITIES \
	(LB_CAPSULE_BROKER_APPLY_REGIONS | \
	 LB_CAPSULE_BROKER_PRESERVE_UNLISTED | \
	 LB_CAPSULE_BROKER_VERIFY_READBACK)

#define LB_CAPSULE_FORMAT_FMP_V3 3
#define LB_CAPSULE_AUTH_EFI_PKCS7 1
#define LB_CAPSULE_BOARD_BINDING_CBFS_BUILD_INFO_V1 1
#define LB_CAPSULE_PAYLOAD_MSS1_V1 1
#define LB_CAPSULE_FLAGS_PERSIST_RESET 0x00050000U

#define LB_CAPSULE_REGION_BIOS (1U << 0)
#define LB_CAPSULE_REGION_VALID_FLAGS LB_CAPSULE_REGION_BIOS

struct lb_capsule_update_region {
	lb_uint64_t image_offset;
	lb_uint64_t flash_offset;
	lb_uint64_t size;
	uint32_t flags;
	uint32_t reserved;
} __packed;

struct lb_capsule_handoff {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t flags;
	uint16_t broker_type;
	uint16_t capsule_format;
	uint16_t authentication_format;
	uint16_t board_binding_format;
	uint16_t payload_format;
	uint16_t reserved16;
	uint32_t broker_capabilities;
	uint8_t image_type_guid[16];
	uint32_t version;
	uint32_t lowest_supported_version;
	uint32_t capsule_flags;
	uint32_t block_size;
	uint32_t erase_size;
	uint32_t region_count;
	lb_uint64_t image_size;
	lb_uint64_t boot_media_size;
	lb_uint64_t smmstore_offset;
	lb_uint64_t smmstore_size;
	uint32_t reserved32[2];
	struct lb_capsule_update_region regions[];
} __packed;

_Static_assert(sizeof(struct lb_capsule_update_region) == 32,
	"capsule update region ABI");
_Static_assert(sizeof(struct lb_capsule_handoff) == 112,
	"capsule handoff header ABI");
_Static_assert(offsetof(struct lb_capsule_handoff, broker_type) == 16 &&
	offsetof(struct lb_capsule_handoff, broker_capabilities) == 28,
	"capsule broker ABI");
_Static_assert(offsetof(struct lb_capsule_handoff, image_type_guid) == 32 &&
	offsetof(struct lb_capsule_handoff, version) == 48,
	"capsule identity ABI");
_Static_assert(offsetof(struct lb_capsule_handoff, image_size) == 72 &&
	offsetof(struct lb_capsule_handoff, regions) == 112,
	"capsule bounds ABI");

#define LB_CAPSULE_BROKER_ENDPOINT_REVISION 1
/* Same layout; a private cold RAM window must be irreversibly closed before PCI. */
#define LB_CAPSULE_BROKER_ENDPOINT_RAM_REVISION 2

#define LB_CAPSULE_ENDPOINT_COREBOOT_SMM_OWNER    (1U << 0)
#define LB_CAPSULE_ENDPOINT_SMM_ONLY_SPI          (1U << 1)
#define LB_CAPSULE_ENDPOINT_FIXED_COMMUNICATION   (1U << 2)
#define LB_CAPSULE_ENDPOINT_DMA_PROTECTED         (1U << 3)
#define LB_CAPSULE_ENDPOINT_CPU_RENDEZVOUS        (1U << 4)
#define LB_CAPSULE_ENDPOINT_ONE_SHOT              (1U << 5)
#define LB_CAPSULE_ENDPOINT_NO_RAW_FLASH          (1U << 6)
#define LB_CAPSULE_ENDPOINT_REQUIRED_FLAGS \
	(LB_CAPSULE_ENDPOINT_COREBOOT_SMM_OWNER | \
	 LB_CAPSULE_ENDPOINT_SMM_ONLY_SPI | \
	 LB_CAPSULE_ENDPOINT_FIXED_COMMUNICATION | \
	 LB_CAPSULE_ENDPOINT_DMA_PROTECTED | \
	 LB_CAPSULE_ENDPOINT_CPU_RENDEZVOUS | \
	 LB_CAPSULE_ENDPOINT_ONE_SHOT | \
	 LB_CAPSULE_ENDPOINT_NO_RAW_FLASH)

#define LB_CAPSULE_ENDPOINT_TRANSPORT_APM_IO8 1

/*
 * Public description of a separately sealed, one-shot SMM endpoint. This
 * record is not authority and contains no writable route or raw media command.
 */
struct lb_capsule_broker_endpoint {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t flags;
	lb_uint64_t generation;
	lb_uint64_t communication_base;
	uint32_t communication_size;
	uint32_t message_size;
	lb_uint64_t staging_base;
	lb_uint64_t staging_size;
	uint16_t transport;
	uint16_t trigger_width;
	uint32_t trigger_address;
	uint32_t trigger_value;
	uint32_t reserved[3];
} __packed;

_Static_assert(sizeof(struct lb_capsule_broker_endpoint) == 80,
	"capsule broker endpoint ABI");
_Static_assert(offsetof(struct lb_capsule_broker_endpoint, generation) == 16 &&
	offsetof(struct lb_capsule_broker_endpoint, communication_base) == 24 &&
	offsetof(struct lb_capsule_broker_endpoint, staging_base) == 40 &&
	offsetof(struct lb_capsule_broker_endpoint, transport) == 56 &&
	offsetof(struct lb_capsule_broker_endpoint, reserved) == 68,
	"capsule broker endpoint layout");

#define LB_AUTHVAR_SERVICE_ENDPOINT_REVISION 5U

#define LB_AUTHVAR_ENDPOINT_COREBOOT_SMM_OWNER  (1U << 0)
#define LB_AUTHVAR_ENDPOINT_FIXED_COMMUNICATION (1U << 1)
/* Runtime hardware protection of private authority, not mutable shared RAM. */
#define LB_AUTHVAR_ENDPOINT_PROTECTED_AUTHORITY (1U << 2)
#define LB_AUTHVAR_ENDPOINT_CPU_RENDEZVOUS      (1U << 3)
#define LB_AUTHVAR_ENDPOINT_POLICY_IN_SMM       (1U << 4)
#define LB_AUTHVAR_ENDPOINT_NO_RAW_SMMSTORE     (1U << 5)
#define LB_AUTHVAR_ENDPOINT_SMM_BWP_REQUIRED    (1U << 6)
#define LB_AUTHVAR_ENDPOINT_LIFECYCLE_SEALED    (1U << 7)
/* Repeatable boot-services op9, not private BOOT delivery or origin proof. */
#define LB_AUTHVAR_ENDPOINT_IMAGE_POLICY_GENERAL (1U << 8)
/* The installed protected owner retains state-predicate classes after deletion. */
#define LB_AUTHVAR_ENDPOINT_STATE_PREDICATE_PINNED (1U << 9)
#define LB_AUTHVAR_ENDPOINT_REQUIRED_FLAGS \
	(LB_AUTHVAR_ENDPOINT_COREBOOT_SMM_OWNER | \
	 LB_AUTHVAR_ENDPOINT_FIXED_COMMUNICATION | \
	 LB_AUTHVAR_ENDPOINT_PROTECTED_AUTHORITY | \
	 LB_AUTHVAR_ENDPOINT_CPU_RENDEZVOUS | \
	 LB_AUTHVAR_ENDPOINT_POLICY_IN_SMM | \
	 LB_AUTHVAR_ENDPOINT_NO_RAW_SMMSTORE | \
	 LB_AUTHVAR_ENDPOINT_SMM_BWP_REQUIRED | \
	 LB_AUTHVAR_ENDPOINT_LIFECYCLE_SEALED)

#define LB_AUTHVAR_ENDPOINT_TRANSPORT_APM_IO8 1U

/*
 * Public description of a fixed authenticated-variable mailbox. Authority,
 * SMRAM and media geometry are deliberately absent from this record.
 */
struct lb_authvar_service_endpoint {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t flags;
	lb_uint64_t generation;
	lb_uint64_t communication_base;
	uint32_t communication_size;
	uint32_t message_size;
	uint16_t transport;
	uint16_t trigger_width;
	uint32_t trigger_address;
	uint32_t trigger_value;
	uint32_t maximum_name_size;
	/* Logical data limit; unused bytes through message_size are zero padding. */
	uint32_t maximum_data_size;
	uint32_t reserved;
} __packed;

_Static_assert(sizeof(struct lb_authvar_service_endpoint) == 64,
	"authenticated-variable endpoint ABI");
_Static_assert(offsetof(struct lb_authvar_service_endpoint, generation) == 16 &&
	offsetof(struct lb_authvar_service_endpoint, communication_base) == 24 &&
	offsetof(struct lb_authvar_service_endpoint, transport) == 40 &&
	offsetof(struct lb_authvar_service_endpoint, maximum_name_size) == 52 &&
	offsetof(struct lb_authvar_service_endpoint, reserved) == 60,
	"authenticated-variable endpoint layout");

#define LB_AUTHVAR_PRESENCE_ENDPOINT_REVISION 1U

#define LB_AUTHVAR_PRESENCE_COREBOOT_SMM_OWNER  (1U << 0)
#define LB_AUTHVAR_PRESENCE_FIXED_COMMUNICATION (1U << 1)
#define LB_AUTHVAR_PRESENCE_DMA_PROTECTED       (1U << 2)
#define LB_AUTHVAR_PRESENCE_CPU_RENDEZVOUS      (1U << 3)
#define LB_AUTHVAR_PRESENCE_ONE_SHOT_CAPABILITY (1U << 4)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_SEALED    (1U << 5)
#define LB_AUTHVAR_PRESENCE_REQUIRED_FLAGS \
	(LB_AUTHVAR_PRESENCE_COREBOOT_SMM_OWNER | \
	 LB_AUTHVAR_PRESENCE_FIXED_COMMUNICATION | \
	 LB_AUTHVAR_PRESENCE_DMA_PROTECTED | \
	 LB_AUTHVAR_PRESENCE_CPU_RENDEZVOUS | \
	 LB_AUTHVAR_PRESENCE_ONE_SHOT_CAPABILITY | \
	 LB_AUTHVAR_PRESENCE_LIFECYCLE_SEALED)

#define LB_AUTHVAR_PRESENCE_TRANSPORT_APM_IO8 1U
#define LB_AUTHVAR_PRESENCE_ENTER_SETUP_MODE 1U
#define LB_AUTHVAR_PRESENCE_CAPABILITY_SIZE 32U

/*
 * Public description of the fixed physical-presence mailbox. The capability
 * size describes the message field; capability bytes are never in this table.
 */
struct lb_authvar_presence_endpoint {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t flags;
	lb_uint64_t generation;
	lb_uint64_t communication_base;
	uint32_t communication_size;
	uint32_t message_size;
	uint16_t transport;
	uint16_t trigger_width;
	uint32_t trigger_address;
	uint32_t trigger_value;
	uint32_t action_scope;
	uint32_t capability_size;
	uint32_t reserved;
} __packed;

_Static_assert(sizeof(struct lb_authvar_presence_endpoint) == 64,
	"authenticated-variable presence endpoint ABI");
_Static_assert(offsetof(struct lb_authvar_presence_endpoint, generation) == 16 &&
	offsetof(struct lb_authvar_presence_endpoint, communication_base) == 24 &&
	offsetof(struct lb_authvar_presence_endpoint, communication_size) == 32 &&
	offsetof(struct lb_authvar_presence_endpoint, message_size) == 36 &&
	offsetof(struct lb_authvar_presence_endpoint, transport) == 40 &&
	offsetof(struct lb_authvar_presence_endpoint, trigger_width) == 42 &&
	offsetof(struct lb_authvar_presence_endpoint, trigger_address) == 44 &&
	offsetof(struct lb_authvar_presence_endpoint, trigger_value) == 48 &&
	offsetof(struct lb_authvar_presence_endpoint, action_scope) == 52 &&
	offsetof(struct lb_authvar_presence_endpoint, capability_size) == 56 &&
	offsetof(struct lb_authvar_presence_endpoint, reserved) == 60,
	"authenticated-variable presence endpoint layout");

#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_ENDPOINT_REVISION 1U
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SMM_OWNER (1U << 0)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_FIXED_COMMUNICATION (1U << 1)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_AUTHORITY_DMA_PROTECTED (1U << 2)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CPU_RENDEZVOUS (1U << 3)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_EXACT_GENERATION (1U << 4)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_BOOT_EPOCH_SCOPED (1U << 5)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SOURCE_SCOPED (1U << 6)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SYNCHRONOUS_CLOSED_PROOF (1U << 7)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_ONE_SHOT_SOURCES (1U << 8)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_TERMINAL_BEFORE_EBS (1U << 9)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_REQUIRED_FLAGS ((1U << 10) - 1U)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_TRANSPORT_APM_IO8 1U
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_PRE_EXTERNAL_IMAGE (1U << 0)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_PAYLOAD_FAILURE_OR_RETURN (1U << 1)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_CLOSED_REPROOF (1U << 2)
#define LB_AUTHVAR_PRESENCE_LIFECYCLE_CLOSE_SOURCE_MASK ((1U << 3) - 1U)

struct lb_authvar_presence_lifecycle_close_endpoint {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t flags;
	lb_uint64_t generation;
	lb_uint64_t communication_base;
	uint32_t communication_size;
	uint32_t message_size;
	uint16_t transport;
	uint16_t trigger_width;
	uint32_t trigger_address;
	uint32_t trigger_value;
	uint32_t source_mask;
	uint32_t reserved[2];
} __packed;

_Static_assert(sizeof(struct lb_authvar_presence_lifecycle_close_endpoint) == 64,
	"authenticated-variable presence lifecycle-close endpoint ABI");
_Static_assert(offsetof(struct lb_authvar_presence_lifecycle_close_endpoint,
	generation) == 16 &&
	offsetof(struct lb_authvar_presence_lifecycle_close_endpoint,
	communication_base) == 24 &&
	offsetof(struct lb_authvar_presence_lifecycle_close_endpoint, transport) == 40 &&
	offsetof(struct lb_authvar_presence_lifecycle_close_endpoint, source_mask) == 52 &&
	offsetof(struct lb_authvar_presence_lifecycle_close_endpoint, reserved) == 56,
	"authenticated-variable presence lifecycle-close endpoint layout");
struct lb_cfr {
	uint32_t tag;
	uint32_t size;
	uint32_t version;
	uint32_t checksum;	/* Checksum of the variable payload. */
	/* struct lb_cfr_option_form		forms[] */
};

struct lb_panel_poweroff {
	uint32_t tag;
	uint32_t size;

	/* MIPI DSI poweroff commands from panel_serializable_data. */
	uint8_t cmd[];
};

struct lb_dma_handoff {
	uint32_t tag;
	uint32_t size;
	lb_uint64_t address;
	uint32_t bytes;
	uint16_t revision;
	uint16_t reserved;
} __packed;

#define LB_PAYLOAD_BOOT_PRIVATE_BUFFER_REVISION 1U
#define LB_PAYLOAD_BOOT_PRIVATE_BUFFER_SLOT_SIZE 65536U
#define LB_PAYLOAD_BOOT_PRIVATE_BUFFER_SLOT_COUNT 3U
#define LB_PAYLOAD_BOOT_PRIVATE_BUFFER_BYTES \
	(LB_PAYLOAD_BOOT_PRIVATE_BUFFER_SLOT_SIZE * LB_PAYLOAD_BOOT_PRIVATE_BUFFER_SLOT_COUNT)

/* Allocation metadata only; this record proves neither origin nor DMA exclusion. */
struct lb_payload_boot_private_buffer {
	uint32_t tag;
	uint32_t size;
	uint16_t revision;
	uint16_t header_size;
	uint32_t slot_size;
	lb_uint64_t physical_base;
	uint32_t bytes;
	uint32_t slot_count;
	uint32_t reserved[2];
} __packed;

_Static_assert(sizeof(struct lb_payload_boot_private_buffer) == 40,
	"unexpected boot-private buffer record size");
_Static_assert(offsetof(struct lb_payload_boot_private_buffer, revision) == 8 &&
	offsetof(struct lb_payload_boot_private_buffer, header_size) == 10 &&
	offsetof(struct lb_payload_boot_private_buffer, slot_size) == 12 &&
	offsetof(struct lb_payload_boot_private_buffer, physical_base) == 16 &&
	offsetof(struct lb_payload_boot_private_buffer, bytes) == 24 &&
	offsetof(struct lb_payload_boot_private_buffer, slot_count) == 28 &&
	offsetof(struct lb_payload_boot_private_buffer, reserved) == 32,
	"unexpected boot-private buffer record offsets");

_Static_assert(sizeof(struct lb_dma_handoff) == 24,
	"unexpected DMA handoff reference size");

enum boot_mode_t {
	/* Regular boot scenarios */
	LB_BOOT_MODE_NORMAL,
	/* Device is booting in low-batter w/o charger attached */
	LB_BOOT_MODE_LOW_BATTERY,
	/* Device is booting in low-batter w/ charger attached */
	LB_BOOT_MODE_LOW_BATTERY_CHARGING,
	/* Device is booting in due to charger insertion */
	LB_BOOT_MODE_OFFMODE_CHARGING,
	/* Device is booting in due to RTC alarm */
	LB_BOOT_MODE_RTC_WAKE,
	/* Device is booting in "no-battery" */
	LB_BOOT_MODE_NO_BATTERY,
	/* Device is booting with flash protections disabled.
	 *
	 * The payload is part of the trusted code base and can be used to update the flash.
	 * The payload is also responsible to lock down the platform or reboot in order
	 * to re-enable flash protection mechanisms.
	 * The payload must not allow any untrusted code (Option ROMs, Bootloaders, ...)
	 * to run in this boot mode.
	 */
	LB_BOOT_MODE_FLASH_UPDATE,
};

/*
 * Boot Mode: Pass the platform boot mode information to payload.
 */
struct lb_boot_mode {
	uint32_t tag;
	uint32_t size;

	enum boot_mode_t boot_mode;
};

#endif
