#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

case $# in
	3) ;;
	4) test "$4" = --expect-live-older-append ;;
	*) echo 'usage: private_media_check.sh MEDIA EXPECTED_CERTDB OUTPUT [--expect-live-older-append]' >&2; exit 2 ;;
esac
: "${COREBOOT_TREE:?actual producer codec source required}"
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
mkdir -p "$3"
output=$(mktemp -d "$3/private-media.XXXXXX")
printf 'Actual-codec private media artifacts: %s\n' "$output"
sources=
for implementation in fv store record ftw certdb; do
	sources="$sources $COREBOOT_TREE/src/lib/payload_mm_authvar_$implementation.c"
done
compiler=${HOSTCC:-cc}
oracle="$root/tests/protected_variable_private_media_check.c"
# Bind the real codec header closure as well as its implementation bodies.
# No compilation cache or generated media is input authority.
codec_flags="-std=gnu11 -Wall -Wextra -Werror -g -fno-builtin -fno-pie -no-pie
	-fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer
	-DENV_TEST=1 -Du8=uint8_t -Du16=uint16_t -Du32=uint32_t -Du64=uint64_t
	-Ds32=int32_t -Ds64=int64_t"
tools="$(command -v "$compiler") $(command -v perl) $(command -v sha256sum)"
for program in cc1 as ld; do
	tools="$tools $(command -v "$("$compiler" -print-prog-name="$program")")"
done
# shellcheck disable=SC2086
sha256sum "$1" "$2" "$oracle" "$0" $tools $sources \
	> "$output/inputs-before.sha256"
export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
for optimization in 0 2; do
	# shellcheck disable=SC2086
	"$compiler" $codec_flags -O"$optimization" -M -MT closure \
		-include "$COREBOOT_TREE/src/commonlib/bsd/include/commonlib/bsd/compiler.h" \
		-I"$COREBOOT_TREE/src/commonlib/include" -I"$COREBOOT_TREE/src/commonlib/bsd/include" \
		-idirafter "$COREBOOT_TREE/src/include" "$oracle" $sources \
		> "$output/closure-o$optimization.mk"
done
perl - "$output/closure-o0.mk" "$output/closure-o2.mk" <<-'PERL' > "$output/closure.list"
	use strict;
	use warnings;
	my %paths;
	my $targets = 0;
	for my $file (@ARGV) {
		open my $input, '<', $file or die $!;
		local $/;
		my $body = <$input>;
		$body =~ s/\\\n/ /g;
		$targets += ($body =~ s/^closure:\s*//mg);
		for my $path (split /\s+/, $body) {
			next unless length $path;
			die "unsupported escaped dependency" if $path =~ /\\/;
			$paths{$path} = 1;
		}
	}
	die "expected twelve actual codec translation-unit targets" unless $targets == 12;
	print "$_\n" for sort keys %paths;
PERL
while IFS= read -r path; do
	sha256sum "$path"
done < "$output/closure.list" > "$output/closure-before.sha256"
for optimization in 0 2; do
	# Coreboot HOST type aliases close its real codec; none grants authority.
	# shellcheck disable=SC2086
	"$compiler" -std=gnu11 -Wall -Wextra -Werror -g -O"$optimization" -fno-builtin \
		-fno-pie -no-pie -fsanitize=address,undefined -fno-sanitize-recover=all \
		-fno-omit-frame-pointer -DENV_TEST=1 \
		-Du8=uint8_t -Du16=uint16_t -Du32=uint32_t -Du64=uint64_t \
		-Ds32=int32_t -Ds64=int64_t \
		-include "$COREBOOT_TREE/src/commonlib/bsd/include/commonlib/bsd/compiler.h" \
		-I"$COREBOOT_TREE/src/commonlib/include" -I"$COREBOOT_TREE/src/commonlib/bsd/include" \
		-idirafter "$COREBOOT_TREE/src/include" "$oracle" $sources \
		-o "$output/check-o$optimization" > "$output/build-o$optimization.log" 2>&1
	if test "$#" -eq 4; then
		"$output/check-o$optimization" "$1" "$2" "$4" > "$output/check-o$optimization.log" 2>&1
	else
		"$output/check-o$optimization" "$1" "$2" > "$output/check-o$optimization.log" 2>&1
	fi
done
sha256sum -c "$output/closure-before.sha256" > "$output/closure-after-check.log"
sha256sum -c "$output/inputs-before.sha256"
