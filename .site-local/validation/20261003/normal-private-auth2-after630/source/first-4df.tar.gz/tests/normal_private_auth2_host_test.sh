#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-2.0-only
# HOST input/syntax/legacy-parity gate, not SMM policy or native AUTH2 evidence.
set -euo pipefail
[[ $# == 2 ]] || { echo 'usage: normal_private_auth2_host_test.sh NORMAL_HEADER OUTPUT' >&2; exit 2; }
: "${COREBOOT_TREE:?actual immutable producer codec source required}"
repo=$(cd -- "$(dirname -- "$0")/.." && pwd -P)
header=$(realpath "$1")
mkdir -p "$2"
output=$(mktemp -d "$2/normal-private-auth2-HOST.XXXXXX")
ulimit -c 0
for symbol in PROTECTED_VARIABLE_RUNTIME NATIVE_SYSTEM_FMP NATIVE_SECURITY_STUB; do
	grep -qx "#define CONFIG_CDK2_$symbol 1" "$header"
done
for symbol in NATIVE_QEMU_TEST_FMP QEMU_ACCEPTANCE_PROFILE BUILD_DEBUG BOOT_TIMEOUT; do
	grep -qx "#define CONFIG_CDK2_$symbol 0" "$header"
done
compiler=${HOSTCC:-cc}
tools=("$(command -v "$compiler")" "$BASH")
for tool in sh git python3 perl openssl sha256sum sed grep cmp dirname realpath mkdir mktemp; do
	tools+=("$(command -v "$tool")")
done
for program in cc1 as ld; do
	tools+=("$(command -v "$("$compiler" -print-prog-name="$program")")")
done
sources=("$repo/tests/protected_variable_fullgraph_runtime_app.c"
	"$repo/tests/protected_variable_fullgraph_enrolled_inputs.sh"
	"$repo/tests/protected_variable_native_service_auth_inputs.sh"
	"$repo/tests/protected_variable_private_media_check.c"
	"$repo/tests/protected_variable_private_media_check.sh"
	"$repo/tests/normal_private_auth2_host_test.sh" "$header")
codec_sources=()
for implementation in fv store record ftw certdb; do
	codec_sources+=("$COREBOOT_TREE/src/lib/payload_mm_authvar_$implementation.c")
done
sha256sum "${sources[@]}" "${codec_sources[@]}" "${tools[@]}" > "$output/inputs-before.sha256"
git -C "$repo" rev-parse HEAD > "$output/head-before.txt"
git -C "$repo" status --porcelain > "$output/status-before.txt"
git -C "$repo" show d8e49af2ab0c90c6f6542b29026bd80309a9e1da:tests/protected_variable_fullgraph_runtime_app.c \
	> "$output/ready628-runtime-app.c"
sha256sum "$output/ready628-runtime-app.c" > "$output/baseline.sha256"
app_flags=(-std=gnu11 -Wall -Wextra -Werror -fno-builtin -maccumulate-outgoing-args
	-include "$header" -I"$repo/include")
dependencies=()
for optimization in 0 2; do
	for mode in ordinary enrolled cold normal; do
		variant=()
		case $mode in
			enrolled) variant=(-DCDK2_FULLGRAPH_ENROLLED=1) ;;
			cold) variant=(-DCDK2_FULLGRAPH_COLD_ENROLLED=1) ;;
			normal) variant=(-DCDK2_NORMAL_PRIVATE_OLDER_APPEND=1) ;;
		esac
		dependencies+=("$output/$mode-o$optimization.mk")
		"$compiler" "${app_flags[@]}" -O"$optimization" "${variant[@]}" -M -MT closure \
			"${sources[0]}" > "${dependencies[-1]}"
	done
done
codec_flags=(-std=gnu11 -Wall -Wextra -Werror -g -fno-builtin -fno-pie -no-pie
	-fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer
	-DENV_TEST=1 -Du8=uint8_t -Du16=uint16_t -Du32=uint32_t -Du64=uint64_t
	-Ds32=int32_t -Ds64=int64_t
	-include "$COREBOOT_TREE/src/commonlib/bsd/include/commonlib/bsd/compiler.h"
	-I"$COREBOOT_TREE/src/commonlib/include" -I"$COREBOOT_TREE/src/commonlib/bsd/include"
	-idirafter "$COREBOOT_TREE/src/include")
for optimization in 0 2; do
	dependencies+=("$output/codec-o$optimization.mk")
	"$compiler" "${codec_flags[@]}" -O"$optimization" -M -MT closure \
		"${sources[3]}" "${codec_sources[@]}" > "${dependencies[-1]}"
done
perl - 20 "${dependencies[@]}" <<-'PERL' > "$output/dependencies.list"
	use strict;
	use warnings;
	my $expected = shift @ARGV;
	my $targets = 0;
	my %paths;
	for my $file (@ARGV) {
		open my $input, '<', $file or die $!;
		local $/;
		my $body = <$input>;
		$body =~ s/\\\n/ /g;
		$targets += ($body =~ s/^closure:\s*//mg);
		for my $path (split /\s+/, $body) {
			next unless length $path;
			die "unsupported escaped dependency" if $path =~ /\\/;
			$paths{$path} = 1;
		}
	}
	die "unexpected actual translation-unit target count" unless $targets == $expected;
	print "$_\n" for sort keys %paths;
PERL
while IFS= read -r path; do
	sha256sum "$path"
done < "$output/dependencies.list" > "$output/closure-before.sha256"
for optimization in 0 2; do
	for mode in ordinary enrolled cold normal; do
		variant=()
		case $mode in
			enrolled) variant=(-DCDK2_FULLGRAPH_ENROLLED=1) ;;
			cold) variant=(-DCDK2_FULLGRAPH_COLD_ENROLLED=1) ;;
			normal) variant=(-DCDK2_NORMAL_PRIVATE_OLDER_APPEND=1) ;;
		esac
		"$compiler" "${app_flags[@]}" -O"$optimization" "${variant[@]}" -fsyntax-only \
			"${sources[0]}" > "$output/$mode-o$optimization-syntax.log" 2>&1
		if [[ $mode != normal ]]; then
			"$compiler" "${app_flags[@]}" -O"$optimization" "${variant[@]}" -E -P \
				"${sources[0]}" > "$output/$mode-o$optimization-current.i"
			"$compiler" "${app_flags[@]}" -O"$optimization" "${variant[@]}" -E -P \
				"$output/ready628-runtime-app.c" > "$output/$mode-o$optimization-628.i"
			cmp "$output/$mode-o$optimization-628.i" "$output/$mode-o$optimization-current.i"
		fi
	done
done
for optimization in 0 2; do
	"$compiler" "${codec_flags[@]}" -O"$optimization" "${sources[3]}" "${codec_sources[@]}" \
		-o "$output/codec-o$optimization" > "$output/codec-o$optimization-build.log" 2>&1
done
sh "${sources[1]}" "$output/normal-inputs" --no-child normal-older-append \
	> "$output/genuine-CMS-inputs.log" 2>&1
python3 - "$output/normal-inputs" <<-'PY'
	from pathlib import Path
	import struct
	import sys

	root = Path(sys.argv[1])
	name = 'Cdk2PrivateAuth2Diagnostic'.encode('utf-16le')
	guid = bytes.fromhex('269f79375917494db8da1d6fc47b85c0')
	for key, second, attrs, value in (
	    ('private_create', 7, 0x27, b'auth2-created'),
	    ('private_wrong', 8, 0x27, b'wrong-private-value'),
	    ('private_append', 6, 0x67, b'-appended'),
	):
	    time = struct.pack('<H6BIhBB', 2024, 1, 1, 0, 0, second, 0, 0, 0, 0, 0)
	    expected = name + guid + struct.pack('<I', attrs) + time + value
	    if (root / (key + '.signed.bin')).read_bytes() != expected:
	        raise ValueError('signed operand content is not exact name/GUID/attrs/time/value')
	    signature = (root / (key + '.pk7')).read_bytes()
	    frame = time + struct.pack('<IHH', 24 + len(signature), 0x200, 0xef1)
	    frame += bytes.fromhex('9dd2af4adf68ee498aa9347d375665a7') + signature + value
	    if (root / (key + '_auth.bin')).read_bytes() != frame:
	        raise ValueError('AUTH2 frame differs from genuine verified signature/content')
	if (root / 'private_appended_value.bin').read_bytes() != b'auth2-created-appended':
	    raise ValueError('unexpected independent appended value')
	print('Genuine CMS fixture operands: t7 create, signed t6 APPEND attrs0x67; HOST input check only')
PY
sha256sum -c "$output/inputs-before.sha256" > "$output/inputs-after-check.log"
sha256sum -c "$output/closure-before.sha256" > "$output/closure-after-check.log"
git -C "$repo" rev-parse HEAD > "$output/head-after.txt"
git -C "$repo" status --porcelain > "$output/status-after.txt"
cmp "$output/head-before.txt" "$output/head-after.txt"
cmp "$output/status-before.txt" "$output/status-after.txt"
printf 'HOST syntax/legacy source parity/genuine inputs only (no codec media execution): %s\n' "$output"
