/* SPDX-License-Identifier: GPL-2.0-only */

/* Read-only HOST oracle over actual native media, never request authority. */
#include <boot/payload_mm_authvar_certdb.h>
#include <boot/payload_mm_authvar_ftw.h>
#include <boot/payload_mm_authvar_record.h>
#include <boot/payload_mm_authvar_store.h>
#include <commonlib/helpers.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

#define REGION_SIZE (64U * 1024U)
#define ENTRY_CAPACITY 128U

static const uint8_t private_guid[16] = {
	0x26, 0x9f, 0x79, 0x37, 0x59, 0x17, 0x49, 0x4d,
	0xb8, 0xda, 0x1d, 0x6f, 0xc4, 0x7b, 0x85, 0xc0,
};
static const uint8_t certdb_guid[16] = {
	0x6e, 0xe5, 0xbe, 0xd9, 0xdc, 0x75, 0xd9, 0x49,
	0xb4, 0xd7, 0xb5, 0x34, 0x21, 0x0f, 0x63, 0x7a,
};
static const uint16_t private_name[] = u"Cdk2PrivateAuth2Diagnostic";
static const uint16_t certdb_name[] = u"certdb";
static uint8_t media[REGION_SIZE], changed[REGION_SIZE];

static bool scan(const uint8_t *region, struct payload_mm_authvar_store_index *index)
{
	struct payload_mm_authvar_fv_geometry geometry;
	const struct payload_mm_authvar_store_limits limits = {
		.maximum_store_size = REGION_SIZE, .maximum_name_size = 4096U,
		.maximum_data_size = REGION_SIZE, .maximum_records = ENTRY_CAPACITY,
	};

	return payload_mm_authvar_fv_geometry(&geometry, REGION_SIZE, 4096U) &&
		payload_mm_authvar_store_scan(index, region + PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE,
			geometry.variable_size - PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE, &limits) == CB_SUCCESS &&
		index->dirty_tail_offset == 0U;
}

static bool matches(const uint8_t *region)
{
	struct payload_mm_authvar_ftw_plan plan;
	struct payload_mm_authvar_store_entry entries[ENTRY_CAPACITY];
	struct payload_mm_authvar_store_index index = {
		.entries = entries, .entry_capacity = ARRAY_SIZE(entries),
	};
	struct payload_mm_authvar_certdb_binding binding;
	const uint8_t empty[] = { 4, 0, 0, 0 }, zero_time[16] = { 0 };
	const struct payload_mm_authvar_store_entry *entry;
	const void *data;

	if (payload_mm_authvar_ftw_plan(region, REGION_SIZE, 4096U, &plan) != CB_SUCCESS ||
	    plan.action != PAYLOAD_MM_AUTHVAR_FTW_CLEAN ||
	    plan.workspace != PAYLOAD_MM_AUTHVAR_FTW_WORKSPACE_WORKING ||
	    plan.queue_entry_size)
		return false;
	/* The real decoder also classifies validated completed history as clean. */
	if (plan.queue_disposition == PAYLOAD_MM_AUTHVAR_FTW_QUEUE_EMPTY ?
	    plan.queue_offset != PAYLOAD_MM_AUTHVAR_FTW_WORK_HEADER_SIZE :
	    plan.queue_disposition != PAYLOAD_MM_AUTHVAR_FTW_QUEUE_NONE ||
	    plan.queue_offset <= PAYLOAD_MM_AUTHVAR_FTW_WORK_HEADER_SIZE ||
	    plan.queue_offset >= plan.geometry.working_size)
		return false;
	if (!scan(region, &index))
		return false;
	if (payload_mm_authvar_store_find(&index, private_guid, private_name,
	    sizeof(private_name)) != NULL)
		return false;
	entry = payload_mm_authvar_store_find(&index, certdb_guid, certdb_name,
		sizeof(certdb_name));
	if (!entry || entry->attributes != 0x27 || entry->data_size != sizeof(empty) ||
	    memcmp(index.store + entry->record_offset + 16U, zero_time, sizeof(zero_time)))
		return false;
	data = payload_mm_authvar_store_data(&index, entry);
	if (!data || memcmp(data, empty, sizeof(empty)))
		return false;
	return payload_mm_authvar_certdb_find(data, entry->data_size, private_guid,
		private_name, sizeof(private_name) - sizeof(private_name[0]), &binding) ==
		PAYLOAD_MM_AUTHVAR_CERTDB_NOT_FOUND;
}

/* Build hostile HOST-only copies with the real record codec. These
 * copies are never passed to QEMU or used as expected authorization state. */
static void append(uint8_t *region, const uint8_t *guid, const uint16_t *name,
	size_t name_size, const void *data, size_t data_size)
{
	struct payload_mm_authvar_store_entry entries[ENTRY_CAPACITY];
	struct payload_mm_authvar_store_index index = {
		.entries = entries, .entry_capacity = ARRAY_SIZE(entries),
	};
	struct payload_mm_authvar_record_descriptor source = {
		.name = name, .name_size = name_size, .attributes = 0x27,
	};
	const struct payload_mm_authvar_record_span span = { .data = data, .size = data_size };
	uint8_t record[512];
	uint32_t record_size;
	enum payload_mm_authvar_record_timestamp timestamp =
		PAYLOAD_MM_AUTHVAR_RECORD_TIMESTAMP_TRUSTED_ZERO;

	assert(scan(region, &index));
	const struct payload_mm_authvar_store_entry *previous =
		payload_mm_authvar_store_find(&index, guid, name, name_size);

	if (!memcmp(guid, private_guid, sizeof(private_guid))) {
		source.timestamp[0] = 0xe8;
		source.timestamp[1] = 0x07;
		source.timestamp[2] = source.timestamp[3] = 1;
		timestamp = PAYLOAD_MM_AUTHVAR_RECORD_TIMESTAMP_VALIDATED;
	}
	memcpy(source.vendor_guid, guid, sizeof(source.vendor_guid));
	assert(payload_mm_authvar_record_encode(&source, &span, 1, timestamp,
		record, sizeof(record), &record_size));
	assert(index.used_size <= index.store_size && record_size <= index.store_size - index.used_size);
	uint8_t *destination = region + PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE + index.used_size;

	for (size_t byte = 0; byte < record_size; byte++)
		assert(destination[byte] == 0xff);
	record[2] = PAYLOAD_MM_AUTHVAR_STATE_ADDED;
	memcpy(destination, record, record_size);
	if (previous)
		region[PAYLOAD_MM_AUTHVAR_FV_HEADER_SIZE + previous->record_offset + 2U] =
			PAYLOAD_MM_AUTHVAR_STATE_ADDED_DELETED;
}

int main(int argc, char **argv)
{
	struct payload_mm_authvar_fv_geometry geometry;
	struct payload_mm_authvar_ftw_plan plan;
	uint8_t bound_certdb[512];
	size_t bound_size;
	FILE *input;

	assert(argc == 3);
	input = fopen(argv[1], "rb");
	assert(input && fread(media, 1, sizeof(media), input) == sizeof(media));
	assert(fgetc(input) == EOF && !ferror(input) && fclose(input) == 0);
	assert(matches(media));
	input = fopen(argv[2], "rb");
	assert(input != NULL);
	bound_size = fread(bound_certdb, 1, sizeof(bound_certdb), input);
	assert(bound_size > 4 && bound_size < sizeof(bound_certdb) &&
		fgetc(input) == EOF && !ferror(input) && fclose(input) == 0);
	memcpy(changed, media, sizeof(changed));
	append(changed, private_guid, private_name, sizeof(private_name), "live", 4);
	bool private_refused = !matches(changed);

	assert(private_refused);
	memcpy(changed, media, sizeof(changed));
	append(changed, certdb_guid, certdb_name, sizeof(certdb_name), bound_certdb, bound_size);
	bool binding_refused = !matches(changed);

	assert(binding_refused);
	assert(payload_mm_authvar_fv_geometry(&geometry, REGION_SIZE, 4096U));
	for (size_t byte = 0; byte < PAYLOAD_MM_AUTHVAR_FTW_WORK_HEADER_SIZE; byte++) {
		memcpy(changed, media, sizeof(changed));
		changed[geometry.working_offset + byte] ^= 1;
		bool workspace_refused = !matches(changed);

		assert(workspace_refused);
	}
	assert(payload_mm_authvar_ftw_plan(media, sizeof(media), 4096U, &plan) == CB_SUCCESS);
	if (plan.queue_disposition == PAYLOAD_MM_AUTHVAR_FTW_QUEUE_NONE) {
		const size_t entry_size = PAYLOAD_MM_AUTHVAR_FTW_WRITE_HEADER_SIZE +
			PAYLOAD_MM_AUTHVAR_FTW_WRITE_RECORD_SIZE;

		assert(plan.queue_offset >= PAYLOAD_MM_AUTHVAR_FTW_WORK_HEADER_SIZE + entry_size);
		const size_t header = geometry.working_offset + plan.queue_offset - entry_size;

		memcpy(changed, media, sizeof(changed));
		changed[header] = PAYLOAD_MM_AUTHVAR_FTW_HEADER_WRITES_ALLOCATED;
		assert(payload_mm_authvar_ftw_plan(changed, sizeof(changed), 4096U, &plan) == CB_SUCCESS);
		assert(plan.action == PAYLOAD_MM_AUTHVAR_FTW_COMPLETE_NEW);
		assert(!matches(changed));
		for (size_t byte = 0; byte < entry_size; byte++) {
			memcpy(changed, media, sizeof(changed));
			changed[header + byte] ^= 1;
			bool history_refused = !matches(changed);

			assert(history_refused);
		}
	}
	puts("Actual native final private value/certdb both absent; clean FTW and hostile live/orphan/workspace copies refused: PASS");
	return 0;
}
