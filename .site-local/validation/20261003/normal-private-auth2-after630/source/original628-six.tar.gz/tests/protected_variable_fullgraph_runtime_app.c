/* SPDX-License-Identifier: GPL-2.0-only */

#include <cdk2/authvar_native_x86.h>
#include <cdk2/authvar_runtime_owner.h>
#include <cdk2/dxe_core_abi.h>
#include <cdk2/runtime_arch.h>
#include <string.h>

/* Terminal OS-loader diagnostic, reached only by real CoreLoad/StartImage.
 * It owns real loader-allocated page tables, not firmware authority. */
#define ALIAS_BASE UINT64_C(0x2000000000)
#define PHYSICAL_LIMIT UINT64_C(0x100000000)
#define TABLE_PAGES 266U
#define MAP_CAPACITY (256U * 1024U)

typedef EFI_STATUS CDK2_MS_ABI allocate_pages_fn(UINT32, UINT32, UINTN, UINT64 *);
typedef EFI_STATUS CDK2_MS_ABI get_map_fn(UINTN *, void *, UINTN *, UINTN *, UINT32 *);
typedef EFI_STATUS CDK2_MS_ABI exit_boot_fn(void *, UINTN);
typedef EFI_STATUS CDK2_MS_ABI get_fn(CHAR16 *, const EFI_GUID *, UINT32 *, UINTN *, void *);
typedef EFI_STATUS CDK2_MS_ABI set_fn(CHAR16 *, const EFI_GUID *, UINT32, UINTN, const void *);

static const EFI_GUID hob_guid = { 0x7739f24c, 0x93d7, 0x11d4,
	{ 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
static const EFI_GUID global_guid = { 0x8be4df61, 0x93ca, 0x11d2,
	{ 0xaa, 0x0d, 0x00, 0xe0, 0x98, 0x03, 0x2b, 0x8c } };
static const EFI_GUID test_guid = { 0x37799f26, 0x1759, 0x4d49,
	{ 0xb8, 0xda, 0x1d, 0x6f, 0xc4, 0x7b, 0x85, 0xc0 } };
static CHAR16 setup[] = u"SetupMode", secure[] = u"SecureBoot";
static CHAR16 variable[] = u"Cdk2PublicRuntimeDiagnostic";
static UINT8 memory_map[MAP_CAPACITY] __aligned(8);
static UINT8 request[CDK2_AUTHVAR_SERVICE_MAX_MESSAGE_SIZE] __aligned(8);
static UINT8 response[CDK2_AUTHVAR_SERVICE_MAX_MESSAGE_SIZE] __aligned(8);
static UINT8 scratch[CDK2_AUTHVAR_SERVICE_MAX_MESSAGE_SIZE] __aligned(8);
static struct cdk2_authvar_client client;

#ifdef CDK2_FULLGRAPH_ENROLLED
typedef EFI_STATUS CDK2_MS_ABI load_fn(BOOLEAN, void *, void *, void *, UINTN, void **);
typedef EFI_STATUS CDK2_MS_ABI start_fn(void *, UINTN *, CHAR16 **);
static const EFI_GUID image_guid = { 0xd719b2cb, 0x3d3a, 0x4596,
	{ 0xa3, 0xbc, 0xda, 0xd0, 0x0e, 0x67, 0x65, 0x6f } };
static const EFI_GUID certdb_guid = { 0xd9bee56e, 0x75dc, 0x49d9,
	{ 0xb4, 0xd7, 0xb5, 0x34, 0x21, 0x0f, 0x63, 0x7a } };
static CHAR16 pk[] = u"PK", kek[] = u"KEK", db[] = u"db";
static CHAR16 private_name[] = u"Cdk2PrivateAuth2Diagnostic", certdb[] = u"certdb";
#define AUTH_INPUT(name) extern const UINT8 _binary_##name##_start[], _binary_##name##_end[]
AUTH_INPUT(pk_auth_bin);
AUTH_INPUT(kek_auth_bin);
AUTH_INPUT(db_auth_bin);
AUTH_INPUT(db_newer_auth_bin);
AUTH_INPUT(db_wrong_auth_bin);
AUTH_INPUT(private_create_auth_bin);
AUTH_INPUT(private_wrong_auth_bin);
AUTH_INPUT(private_append_auth_bin);
AUTH_INPUT(private_delete_auth_bin);
AUTH_INPUT(private_appended_value_bin);
AUTH_INPUT(private_certdb_bin);
AUTH_INPUT(child_unsigned_efi);
AUTH_INPUT(child_db_efi);
AUTH_INPUT(child_rogue_efi);
#endif

static void marker(const char *text)
{
	while (*text) {
		UINT8 ready;

		do {
			__asm__ volatile("inb %1, %0" : "=a"(ready) : "Nd"((UINT16)0x3fd));
		} while (!(ready & 0x20));
		__asm__ volatile("outb %0, %1" : : "a"(*text++), "Nd"((UINT16)0x3f8));
	}
}

static bool interrupts_enabled(void)
{
	UINTN flags;

	__asm__ volatile("pushfq; popq %0" : "=r"(flags) : : "memory");
	return (flags & (1U << 9)) != 0;
}

static void finish(bool passed)
{
	UINT32 value = passed ? 1 : 2;

	marker(passed ? "CDK2_PUBLIC_FULLGRAPH_RUNTIME_PASS\r\n" :
		"CDK2_PUBLIC_FULLGRAPH_RUNTIME_FAIL\r\n");
	__asm__ volatile("outl %0, %1" : : "a"(value), "Nd"((UINT16)0xf4));
	for (;;)
		__asm__ volatile("cli; hlt" : : : "memory");
}

static bool mode(struct cdk2_dxe_runtime_services *runtime, CHAR16 *name, UINT8 expected)
{
	UINTN bytes = 1;
	UINT32 attributes = 0;
	UINT8 value = 0xff;

	return ((get_fn *)runtime->get_variable)(name, &global_guid, &attributes,
		&bytes, &value) == EFI_SUCCESS && bytes == 1 && attributes == 6 && value == expected;
}

static bool variables(struct cdk2_dxe_runtime_services *runtime, UINT32 expected)
{
	UINT32 value = 0, attributes = 0;
	UINTN bytes = sizeof(value);

#if defined(CDK2_FULLGRAPH_ENROLLED) || defined(CDK2_FULLGRAPH_COLD_ENROLLED)
	return mode(runtime, setup, 0) && mode(runtime, secure, 1) &&
#else
	return mode(runtime, setup, 1) && mode(runtime, secure, 0) &&
#endif
		((get_fn *)runtime->get_variable)(variable, &test_guid, &attributes,
			&bytes, &value) == EFI_SUCCESS && bytes == sizeof(value) &&
		attributes == 7 && value == expected;
}

static bool write_variable(struct cdk2_dxe_runtime_services *runtime, UINT32 value)
{
	EFI_STATUS status;
	bool restored;

	if (interrupts_enabled())
		return false;
	__asm__ volatile("sti" : : : "memory");
	status = ((set_fn *)runtime->set_variable)(variable, &test_guid, 7, sizeof(value), &value);
	restored = interrupts_enabled();
	__asm__ volatile("cli" : : : "memory");
	return status == EFI_SUCCESS && restored && variables(runtime, value) &&
		!interrupts_enabled();
}

#ifdef CDK2_FULLGRAPH_ENROLLED
static bool read_value(struct cdk2_dxe_runtime_services *runtime, CHAR16 *name,
	const EFI_GUID *guid, const UINT8 *value, UINTN bytes)
{
	static UINT8 readback[8192];
	UINTN read_bytes = sizeof(readback);
	UINT32 attributes = 0;

	return bytes <= sizeof(readback) &&
		((get_fn *)runtime->get_variable)(name, guid, &attributes,
			&read_bytes, readback) == EFI_SUCCESS && attributes == 0x27 &&
		read_bytes == bytes && !memcmp(readback, value, bytes);
}

static bool read_key(struct cdk2_dxe_runtime_services *runtime, CHAR16 *name,
	const EFI_GUID *guid, const UINT8 *begin, const UINT8 *end)
{
	UINTN bytes = end - begin;
	UINT32 certificate_bytes;

	if (bytes < 40)
		return false;
	memcpy(&certificate_bytes, begin + 16, sizeof(certificate_bytes));
	if (certificate_bytes < 24 || certificate_bytes > bytes - 16)
		return false;
	return read_value(runtime, name, guid, begin + 16 + certificate_bytes,
		bytes - 16 - certificate_bytes);
}

static bool write_auth(struct cdk2_dxe_runtime_services *runtime, CHAR16 *name,
	const EFI_GUID *guid, UINT32 attributes, const UINT8 *begin, const UINT8 *end,
	EFI_STATUS expected)
{
	EFI_STATUS status;
	bool restored;

	if (interrupts_enabled())
		return false;
	__asm__ volatile("sti" : : : "memory");
	status = ((set_fn *)runtime->set_variable)(name, guid, attributes, end - begin, begin);
	restored = interrupts_enabled();
	__asm__ volatile("cli" : : : "memory");
	return status == expected && restored && !interrupts_enabled();
}

static bool enroll(struct cdk2_dxe_runtime_services *runtime)
{
	/* Initial SetupMode PK is the real platform's documented trust bypass.
	 * KEK and db, in contrast, require actual PK/KEK CMS authorization. */
	if (!mode(runtime, setup, 1) || !mode(runtime, secure, 0) ||
	    !write_auth(runtime, pk, &global_guid, 0x27, _binary_pk_auth_bin_start,
		_binary_pk_auth_bin_end, EFI_SUCCESS) ||
	    !read_key(runtime, pk, &global_guid, _binary_pk_auth_bin_start, _binary_pk_auth_bin_end) ||
	    !mode(runtime, setup, 0) || !mode(runtime, secure, 1))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_AFTER_READY_SETUP_PK_ACCEPTED\r\n");
	if (!write_auth(runtime, kek, &global_guid, 0x27, _binary_kek_auth_bin_start,
		_binary_kek_auth_bin_end, EFI_SUCCESS) ||
	    !read_key(runtime, kek, &global_guid, _binary_kek_auth_bin_start, _binary_kek_auth_bin_end))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_AFTER_READY_PK_TRUSTED_KEK_ACCEPTED\r\n");
	if (!write_auth(runtime, db, &image_guid, 0x27, _binary_db_auth_bin_start,
		_binary_db_auth_bin_end, EFI_SUCCESS) ||
	    !read_key(runtime, db, &image_guid, _binary_db_auth_bin_start, _binary_db_auth_bin_end))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_AFTER_READY_KEK_TRUSTED_DB_ACCEPTED\r\n");
	marker("CDK2_PUBLIC_FULLGRAPH_AFTER_READY_ENROLLED_SECURE_BOOT_ON\r\n");
	return true;
}

static bool image_admission(struct cdk2_dxe_boot_services *boot, void *parent)
{
	void *child = NULL;
	EFI_STATUS status;

	status = ((load_fn *)boot->load_image)(FALSE, parent, NULL,
		(void *)_binary_child_unsigned_efi_start,
		_binary_child_unsigned_efi_end - _binary_child_unsigned_efi_start, &child);
	if (status != EFI_SECURITY_VIOLATION || child != NULL)
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_AFTER_READY_UNSIGNED_CHILD_DENIED\r\n");
	status = ((load_fn *)boot->load_image)(FALSE, parent, NULL,
		(void *)_binary_child_rogue_efi_start,
		_binary_child_rogue_efi_end - _binary_child_rogue_efi_start, &child);
	if (status != EFI_SECURITY_VIOLATION || child != NULL)
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_AFTER_READY_WRONG_SIGNER_CHILD_DENIED\r\n");
	status = ((load_fn *)boot->load_image)(FALSE, parent, NULL,
		(void *)_binary_child_db_efi_start,
		_binary_child_db_efi_end - _binary_child_db_efi_start, &child);
	if (EFI_ERROR(status) || !child ||
	    ((start_fn *)boot->start_image)(child, NULL, NULL) != EFI_SUCCESS)
		return false;
	/* The real Core automatically unloads the exited EFI application. */
	marker("CDK2_PUBLIC_FULLGRAPH_AFTER_READY_SIGNED_CHILD_RETURNED\r\n");
	return true;
}

static bool virtual_auth(struct cdk2_dxe_runtime_services *runtime)
{
	UINT8 absent[64];
	UINTN absent_bytes = sizeof(absent);
	UINT32 attributes = 0;
	const UINT8 empty_certdb[] = { 4, 0, 0, 0 };
	const UINTN certdb_bytes = _binary_private_certdb_bin_end -
		_binary_private_certdb_bin_start;

	if (!write_auth(runtime, db, &image_guid, 0x27, _binary_db_newer_auth_bin_start,
		_binary_db_newer_auth_bin_end, EFI_SUCCESS) ||
	    !read_key(runtime, db, &image_guid, _binary_db_newer_auth_bin_start,
		_binary_db_newer_auth_bin_end))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_NEWER_AUTH2_ACCEPTED\r\n");
	if (!write_auth(runtime, db, &image_guid, 0x27, _binary_db_newer_auth_bin_start,
		_binary_db_newer_auth_bin_end, EFI_SECURITY_VIOLATION) ||
	    !read_key(runtime, db, &image_guid, _binary_db_newer_auth_bin_start,
		_binary_db_newer_auth_bin_end))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_AUTH2_REPLAY_DENIED_UNCHANGED\r\n");
	if (!write_auth(runtime, db, &image_guid, 0x27, _binary_db_wrong_auth_bin_start,
		_binary_db_wrong_auth_bin_end, EFI_SECURITY_VIOLATION) ||
	    !read_key(runtime, db, &image_guid, _binary_db_newer_auth_bin_start,
		_binary_db_newer_auth_bin_end))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_WRONG_AUTH2_DENIED_UNCHANGED\r\n");
	if (((get_fn *)runtime->get_variable)(private_name, &test_guid, &attributes,
		&absent_bytes, absent) != EFI_NOT_FOUND ||
	    !read_value(runtime, certdb, &certdb_guid, empty_certdb, sizeof(empty_certdb)) ||
	    !write_auth(runtime, private_name, &test_guid, 0x27,
		_binary_private_create_auth_bin_start, _binary_private_create_auth_bin_end,
		EFI_SUCCESS) ||
	    !read_key(runtime, private_name, &test_guid, _binary_private_create_auth_bin_start,
		_binary_private_create_auth_bin_end) ||
	    !read_value(runtime, certdb, &certdb_guid, _binary_private_certdb_bin_start,
		certdb_bytes))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_PRIVATE_AUTH2_CREATED_BOUND\r\n");
	if (!write_auth(runtime, private_name, &test_guid, 0x27,
		_binary_private_wrong_auth_bin_start, _binary_private_wrong_auth_bin_end,
		EFI_SECURITY_VIOLATION) ||
	    !read_key(runtime, private_name, &test_guid, _binary_private_create_auth_bin_start,
		_binary_private_create_auth_bin_end) ||
	    !read_value(runtime, certdb, &certdb_guid, _binary_private_certdb_bin_start,
		certdb_bytes))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_PRIVATE_WRONG_AUTH2_DENIED_UNCHANGED\r\n");
	/* EDK2 exempts APPEND from timestamp replay checks. This negative is the
	 * original non-append create, not an assumed append replay rejection. */
	if (!write_auth(runtime, private_name, &test_guid, 0x27,
		_binary_private_create_auth_bin_start, _binary_private_create_auth_bin_end,
		EFI_SECURITY_VIOLATION) ||
	    !read_key(runtime, private_name, &test_guid, _binary_private_create_auth_bin_start,
		_binary_private_create_auth_bin_end) ||
	    !read_value(runtime, certdb, &certdb_guid, _binary_private_certdb_bin_start,
		certdb_bytes))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_PRIVATE_AUTH2_REPLAY_DENIED_UNCHANGED\r\n");
	if (!write_auth(runtime, private_name, &test_guid, 0x67,
		_binary_private_append_auth_bin_start, _binary_private_append_auth_bin_end,
		EFI_SUCCESS) ||
	    !read_value(runtime, private_name, &test_guid, _binary_private_appended_value_bin_start,
		_binary_private_appended_value_bin_end - _binary_private_appended_value_bin_start) ||
	    !read_value(runtime, certdb, &certdb_guid, _binary_private_certdb_bin_start,
		certdb_bytes))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_PRIVATE_AUTH2_APPENDED_BOUND\r\n");
	if (!write_auth(runtime, private_name, &test_guid, 0x27,
		_binary_private_delete_auth_bin_start, _binary_private_delete_auth_bin_end,
		EFI_SUCCESS))
		return false;
	absent_bytes = sizeof(absent);
	if (((get_fn *)runtime->get_variable)(private_name, &test_guid, &attributes,
		&absent_bytes, absent) != EFI_NOT_FOUND ||
	    !read_value(runtime, certdb, &certdb_guid, empty_certdb, sizeof(empty_certdb)))
		return false;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_PRIVATE_AUTH2_DELETED_UNBOUND\r\n");
	return mode(runtime, setup, 0) && mode(runtime, secure, 1);
}
#endif

static bool prepare_client(struct cdk2_dxe_system_table *system)
{
	const void *hobs = NULL;

	for (UINTN index = 0; index < system->number_of_table_entries; index++)
		if (!memcmp(&system->configuration_table[index].guid, &hob_guid, sizeof(hob_guid))) {
			if (hobs != NULL)
				return false;
			hobs = system->configuration_table[index].table;
		}
	if (EFI_ERROR(cdk2_authvar_endpoint_from_hob(hobs, &client.endpoint)))
		return false;
	client.mailbox_alias = (void *)(UINTN)client.endpoint.communication_base;
	client.scratch = scratch;
	client.scratch_size = sizeof(scratch);
	client.trigger = cdk2_authvar_native_x86_trigger;
	client.cache = cdk2_authvar_native_x86_cache;
	client.barrier = cdk2_authvar_native_x86_barrier;
	return true;
}

/* Well-formed OS-public policy RPC. ReadyToBoot must already have closed SMM
 * registration before dispatch; runtime closure must remain irreversible. */
static bool closed_policy(void)
{
	struct cdk2_authvar_service_frame *frame = (void *)request;
	UINT8 *policy;
	UINTN size = client.endpoint.descriptor.message_size;
	UINTN offset = (sizeof(*frame) + client.endpoint.descriptor.maximum_name_size + 7U) & ~7U;
	UINT32 version = 0x10000, maximum = MAX_UINT32;
	UINT16 policy_size = 44, name_offset = 44;

	if (size > sizeof(request) || offset > size || policy_size > size - offset)
		return false;
	memset(request, 0, size);
	frame->revision = CDK2_AUTHVAR_SERVICE_REVISION;
	frame->header_size = sizeof(*frame);
	frame->operation = CDK2_AUTHVAR_SERVICE_REGISTER_POLICY;
	frame->generation = client.endpoint.generation;
	frame->status = CDK2_AUTHVAR_SERVICE_STATUS_PENDING;
	frame->completion = CDK2_AUTHVAR_SERVICE_PENDING;
	frame->data_size = policy_size;
	policy = request + offset;
	memcpy(policy, &version, sizeof(version));
	memcpy(policy + 4, &policy_size, sizeof(policy_size));
	memcpy(policy + 6, &name_offset, sizeof(name_offset));
	memcpy(policy + 8, &test_guid, sizeof(test_guid));
	memcpy(policy + 28, &maximum, sizeof(maximum));
	return cdk2_authvar_client_call(&client, request, response, size) == EFI_SUCCESS &&
		((struct cdk2_authvar_service_frame *)response)->status == CDK2_AUTHVAR_STATUS_WRITE_PROTECTED;
}

static bool phase_snapshot(bool runtime)
{
	struct cdk2_authvar_service_frame *frame = (void *)request;
	UINTN size = client.endpoint.descriptor.message_size;

	if (size > sizeof(request))
		return false;
	memset(request, 0, size);
	frame->revision = CDK2_AUTHVAR_SERVICE_REVISION;
	frame->header_size = sizeof(*frame);
	frame->operation = CDK2_AUTHVAR_SERVICE_IMAGE_POLICY_SNAPSHOT;
	frame->generation = client.endpoint.generation;
	frame->status = CDK2_AUTHVAR_SERVICE_STATUS_PENDING;
	frame->completion = CDK2_AUTHVAR_SERVICE_PENDING;
	return cdk2_authvar_client_call(&client, request, response, size) == EFI_SUCCESS &&
		((struct cdk2_authvar_service_frame *)response)->status ==
		(runtime ? CDK2_AUTHVAR_STATUS_UNSUPPORTED : CDK2_AUTHVAR_STATUS_BUFFER_TOO_SMALL);
}

static bool runtime_range(UINTN bytes, UINTN stride, UINT64 base, UINT64 size)
{
	if (!size || base > UINT64_MAX - size)
		return false;
	for (UINTN offset = 0; offset < bytes; offset += stride) {
		struct cdk2_runtime_memory_descriptor *descriptor = (void *)(memory_map + offset);
		UINT64 length = descriptor->number_of_pages * EFI_PAGE_SIZE;

		if ((descriptor->attributes & EFI_MEMORY_RUNTIME) && descriptor->physical_start <= base &&
		    base - descriptor->physical_start < length && size <= length - (base - descriptor->physical_start))
			return true;
	}
	return false;
}

static bool prepare_paging(UINT64 *tables, UINTN bytes, UINTN stride)
{
	UINT64 *pdpt = tables + 512, *physical_pd = tables + 1024, *alias_pd = tables + 3072;
	UINTN runtime_count = 0;

	memset(tables, 0, TABLE_PAGES * EFI_PAGE_SIZE);
	tables[0] = (UINTN)pdpt | 3U;
	for (UINTN index = 0; index < 4; index++) {
		pdpt[index] = (UINTN)(physical_pd + index * 512) | 3U;
		pdpt[index + 128] = (UINTN)(alias_pd + index * 512) | 3U;
	}
	for (UINTN index = 0; index < 2048; index++)
		physical_pd[index] = alias_pd[index] = ((UINT64)index << 21) | 0x83U;
	for (UINTN offset = 0; offset < bytes; offset += stride) {
		struct cdk2_runtime_memory_descriptor *descriptor = (void *)(memory_map + offset);
		UINT64 length;

		if (!(descriptor->attributes & EFI_MEMORY_RUNTIME))
			continue;
		if (!descriptor->number_of_pages || descriptor->number_of_pages > PHYSICAL_LIMIT / EFI_PAGE_SIZE ||
		    (descriptor->physical_start & EFI_PAGE_MASK))
			return false;
		length = descriptor->number_of_pages * EFI_PAGE_SIZE;
		if (descriptor->physical_start >= PHYSICAL_LIMIT || length > PHYSICAL_LIMIT - descriptor->physical_start)
			return false;
		descriptor->virtual_start = descriptor->physical_start + ALIAS_BASE;
		runtime_count++;
	}
	return runtime_count != 0;
}

/* Remove precisely the actual map's runtime physical pages after conversion.
 * Ordinary loader code/stack and this OS-owned page-table allocation remain.
 * High aliases retain independent 2 MiB mappings; no arbitrary OS table walk. */
static bool remove_runtime_identity(UINT64 *tables, UINTN bytes, UINTN stride)
{
	UINT64 *physical_pd = tables + 1024, *next = tables + 5120;
	UINT64 *end = tables + TABLE_PAGES * 512;

	for (UINTN offset = 0; offset < bytes; offset += stride) {
		struct cdk2_runtime_memory_descriptor *descriptor = (void *)(memory_map + offset);

		if (!(descriptor->attributes & EFI_MEMORY_RUNTIME))
			continue;
		for (UINT64 page = 0; page < descriptor->number_of_pages; page++) {
			UINT64 address = descriptor->physical_start + page * EFI_PAGE_SIZE;
			UINTN index = (UINTN)(address >> 21), slot = (UINTN)((address >> 12) & 511U);
			UINT64 *table;

			if (physical_pd[index] & 0x80U) {
				if (next == end)
					return false;
				for (UINTN item = 0; item < 512; item++)
					next[item] = ((UINT64)index << 21) + item * EFI_PAGE_SIZE + 3U;
				physical_pd[index] = (UINTN)next | 3U;
				next += 512;
			}
			table = (void *)(UINTN)(physical_pd[index] & ~UINT64_C(0xfff));
			table[slot] = 0;
		}
	}
	__asm__ volatile("mov %0, %%cr3" : : "r"((UINTN)tables) : "memory");
	return true;
}

EFI_STATUS CDK2_MS_ABI cdk2_public_fullgraph_runtime_entry(void *image,
	struct cdk2_dxe_system_table *system)
{
	struct cdk2_dxe_runtime_services *runtime;
	struct cdk2_dxe_boot_services *boot;
	struct cdk2_dxe_system_table *virtual_system;
	UINT64 table_address = 0;
	UINTN bytes = sizeof(memory_map), key, stride;
	UINT32 version;
	UINTN cr4;
	EFI_STATUS status;

	marker("CDK2_PUBLIC_FULLGRAPH_APP_ENTERED\r\n");
	if (!image || !system || !system->boot_services || !system->runtime_services)
		goto bad;
	boot = system->boot_services;
	runtime = system->runtime_services;
	__asm__ volatile("cli" : : : "memory");
	if (!prepare_client(system) || !closed_policy() || !phase_snapshot(false))
		goto bad;
#ifdef CDK2_FULLGRAPH_COLD_ENROLLED
	/* The prior boot genuinely enrolled this media. Do not enroll again or
	 * infer mode from the PE signature; read actual mode and persisted NV. */
	if (!variables(runtime, 0x52543032U))
		goto bad;
	marker("CDK2_PUBLIC_FULLGRAPH_COLD_ENROLLED_MODE_NV_PERSISTED\r\n");
#else
	if (!mode(runtime, setup, 1) || !mode(runtime, secure, 0))
		goto bad;
#endif
#ifdef CDK2_FULLGRAPH_ENROLLED
	if (!enroll(runtime) || !image_admission(boot, image))
		goto bad;
#endif
	if (!write_variable(runtime, 0x52543031U))
		goto bad;
	marker("CDK2_PUBLIC_FULLGRAPH_READY_CLOSED_OP7_IF1_SET\r\n");
	status = ((allocate_pages_fn *)boot->allocate_pages)(0, 2, TABLE_PAGES, &table_address);
	if (EFI_ERROR(status) || !table_address || table_address >= PHYSICAL_LIMIT ||
	    TABLE_PAGES * EFI_PAGE_SIZE > PHYSICAL_LIMIT - table_address)
		goto bad;
	status = ((get_map_fn *)boot->get_memory_map)(&bytes, memory_map, &key, &stride, &version);
	if (EFI_ERROR(status) || !bytes || stride < sizeof(struct cdk2_runtime_memory_descriptor) ||
	    bytes > sizeof(memory_map) || bytes % stride || version != CDK2_RUNTIME_DESCRIPTOR_VERSION ||
	    !prepare_paging((void *)(UINTN)table_address, bytes, stride) ||
	    !runtime_range(bytes, stride, (UINTN)system, sizeof(*system)) ||
	    !runtime_range(bytes, stride, (UINTN)runtime, sizeof(*runtime)) ||
	    !runtime_range(bytes, stride, client.endpoint.communication_base,
		client.endpoint.descriptor.communication_size))
		goto bad;
	__asm__ volatile("mov %%cr4, %0" : "=r"(cr4));
	if (cr4 & ((1U << 12) | (1U << 17)))
		goto bad;
	status = ((exit_boot_fn *)boot->exit_boot_services)(image, key);
	if (EFI_ERROR(status) || system->boot_services != NULL || interrupts_enabled() ||
	    !variables(runtime, 0x52543031U) || !closed_policy() || !phase_snapshot(true))
		goto bad;
	marker("CDK2_PUBLIC_FULLGRAPH_REAL_EBS_CALLBACKS_LIVE\r\n");
	__asm__ volatile("mov %0, %%cr3" : : "r"((UINTN)table_address) : "memory");
	virtual_system = (void *)((UINTN)system + ALIAS_BASE);
	status = ((cdk2_runtime_set_map_fn *)runtime->set_virtual_address_map)(bytes, stride, version, memory_map);
	if (EFI_ERROR(status) || virtual_system->boot_services != NULL ||
	    (UINTN)virtual_system->runtime_services != (UINTN)runtime + ALIAS_BASE)
		goto bad;
	runtime = virtual_system->runtime_services;
	for (UINTN index = 0; index < 14; index++)
		if ((UINTN)((void **)((UINT8 *)runtime + sizeof(runtime->header)))[index] < ALIAS_BASE)
			goto bad;
	client.mailbox_alias = (void *)(UINTN)(client.endpoint.communication_base + ALIAS_BASE);
	marker("CDK2_PUBLIC_FULLGRAPH_REAL_SET_VIRTUAL_MAP\r\n");
	if (!remove_runtime_identity((void *)(UINTN)table_address, bytes, stride))
		goto bad;
	marker("CDK2_PUBLIC_FULLGRAPH_RUNTIME_PHYSICAL_ALIASES_REMOVED\r\n");
	if (!variables(runtime, 0x52543031U) || !closed_policy() || !phase_snapshot(true) ||
	    !write_variable(runtime, 0x52543032U))
		goto bad;
	marker("CDK2_PUBLIC_FULLGRAPH_VIRTUAL_GET_SET_CLOSED_OP7\r\n");
#ifdef CDK2_FULLGRAPH_COLD_ENROLLED
	marker("CDK2_PUBLIC_FULLGRAPH_COLD_ENROLLED_VIRTUAL_MODE_NV_LIVE\r\n");
#endif
#ifdef CDK2_FULLGRAPH_ENROLLED
	if (!virtual_auth(runtime))
		goto bad;
#endif
	finish(true);
bad:
	finish(false);
	return EFI_DEVICE_ERROR;
}
