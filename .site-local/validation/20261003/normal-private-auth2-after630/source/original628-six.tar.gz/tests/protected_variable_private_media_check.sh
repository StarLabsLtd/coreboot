#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

test "$#" -eq 3
: "${COREBOOT_TREE:?actual producer codec source required}"
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
mkdir -p "$3"
output=$(mktemp -d "$3/private-media.XXXXXX")
printf 'Actual-codec private media artifacts: %s\n' "$output"
sources=
for implementation in fv store record ftw certdb; do
	sources="$sources $COREBOOT_TREE/src/lib/payload_mm_authvar_$implementation.c"
done
compiler=${HOSTCC:-cc}
oracle="$root/tests/protected_variable_private_media_check.c"
# shellcheck disable=SC2086
sha256sum "$1" "$2" "$oracle" "$0" "$(command -v "$compiler")" $sources \
	> "$output/inputs-before.sha256"
export ASAN_OPTIONS=abort_on_error=1:detect_leaks=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
for optimization in 0 2; do
	# Coreboot HOST type aliases close its real codec; none grants authority.
	# shellcheck disable=SC2086
	"$compiler" -std=gnu11 -Wall -Wextra -Werror -g -O"$optimization" -fno-builtin \
		-fno-pie -no-pie -fsanitize=address,undefined -fno-sanitize-recover=all \
		-fno-omit-frame-pointer -DENV_TEST=1 \
		-Du8=uint8_t -Du16=uint16_t -Du32=uint32_t -Du64=uint64_t \
		-Ds32=int32_t -Ds64=int64_t \
		-include "$COREBOOT_TREE/src/commonlib/bsd/include/commonlib/bsd/compiler.h" \
		-I"$COREBOOT_TREE/src/commonlib/include" -I"$COREBOOT_TREE/src/commonlib/bsd/include" \
		-idirafter "$COREBOOT_TREE/src/include" "$oracle" $sources \
		-o "$output/check-o$optimization" > "$output/build-o$optimization.log" 2>&1
	"$output/check-o$optimization" "$1" "$2" > "$output/check-o$optimization.log" 2>&1
done
sha256sum -c "$output/inputs-before.sha256"
