#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu

output=${1:?isolated enrolled inputs directory required}
child=${2:?actual unsigned child PE required}
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
sh "$root/tests/protected_variable_native_service_auth_inputs.sh" "$output"
openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days 2 \
	-subj /CN=fullgraph-untrusted -keyout "$output/rogue.key.pem" \
	-out "$output/rogue.cert.pem" > "$output/rogue.certificate.log" 2>&1

# Distinct, well-formed db ESL values and strictly later timestamps. Changing
# the signature owner proves an actual value update, not just timestamp state.
# Private APPEND signs the exact 0x67 call attributes. EDK2 aab7b589's
# VerifyTimeBasedPayload copies Attributes unchanged into the signed content.
perl - "$output" <<-'PERL'
use strict;
use warnings;
my ($directory) = @ARGV;
open my $input, '<:raw', "$directory/db.value.bin" or die $!;
local $/;
my $original = <$input>;
my $private_name = join('', map { $_ . "\0" } split //, 'Cdk2PrivateAuth2Diagnostic');
my $private_guid = pack('H*', '269f79375917494db8da1d6fc47b85c0');
my @updates = (
	['db_newer', 5, 0x27, "d\0b\0", pack('H*', 'cbb219d73a3d9645a3bcdad00e67656f'), $original],
	['db_wrong', 6, 0x27, "d\0b\0", pack('H*', 'cbb219d73a3d9645a3bcdad00e67656f'), $original],
	['private_create', 7, 0x27, $private_name, $private_guid, 'auth2-created'],
	['private_wrong', 8, 0x27, $private_name, $private_guid, 'wrong-private-value'],
	['private_append', 9, 0x67, $private_name, $private_guid, '-appended'],
	['private_delete', 10, 0x27, $private_name, $private_guid, ''],
);
for my $update (@updates) {
	my ($file, $second, $attributes, $name, $guid, $value) = @$update;
	substr($value, 28, 16) = chr($second) x 16 if $file =~ /^db_/;
	my $time = pack('vC6VvCC', 2024, 1, 1, 0, 0, $second, 0, 0, 0, 0, 0);
	my $signed = $name . $guid . pack('V', $attributes) . $time . $value;
	for my $pair (["$file.signed.bin", $signed], ["$file.time.bin", $time],
		["$file.value.bin", $value]) {
		open my $out, '>:raw', "$directory/$pair->[0]" or die $!;
		print {$out} $pair->[1] or die $!;
	}
}
open my $appended, '>:raw', "$directory/private_appended_value.bin" or die $!;
print {$appended} 'auth2-created-appended' or die $!;
PERL
for update in db_newer db_wrong private_create private_wrong private_append private_delete; do
	case $update in
		db_newer) signer=kek ;;
		db_wrong|private_wrong) signer=rogue ;;
		private_*) signer=db ;;
	esac
	openssl cms -sign -binary -in "$output/$update.signed.bin" \
		-signer "$output/$signer.cert.pem" -inkey "$output/$signer.key.pem" \
		-md sha256 -outform DER -out "$output/$update.pk7"
	openssl cms -verify -binary -inform DER -in "$output/$update.pk7" \
		-content "$output/$update.signed.bin" -CAfile "$output/$signer.cert.pem" \
		-out /dev/null
done
perl - "$output" <<-'PERL'
use strict;
use warnings;
my ($directory) = @ARGV;
for my $update ('db_newer', 'db_wrong', 'private_create', 'private_wrong',
	'private_append', 'private_delete') {
	my @bytes;
	for my $file ("$update.time.bin", "$update.pk7", "$update.value.bin") {
		open my $input, '<:raw', "$directory/$file" or die $!;
		local $/;
		push @bytes, <$input>;
	}
	my ($time, $signature, $value) = @bytes;
	open my $out, '>:raw', "$directory/${update}_auth.bin" or die $!;
	print {$out} $time, pack('Vvv', 24 + length($signature), 0x200, 0xef1),
		pack('H*', '9dd2af4adf68ee498aa9347d375665a7'), $signature, $value;
}
# The private signer is self-signed with the known ASCII CN native-service-db.
# Extract the complete first child (TBSCertificate) from actual DER, rather
# than learning a binding from the guest's certdb. Hash CN || encoded TBS.
open my $certificate, '<:raw', "$directory/db.cert.der" or die $!;
local $/;
my $der = <$certificate>;
sub sequence_end {
	my ($bytes, $start) = @_;
	die "expected DER SEQUENCE\n" unless ord(substr($bytes, $start, 1)) == 0x30;
	my $length = ord(substr($bytes, $start + 1, 1));
	my $header = 2;
	if ($length & 0x80) {
		my $count = $length & 0x7f;
		die "invalid DER length\n" unless $count && $count <= 4 && $start + 2 + $count <= length($bytes);
		$length = 0;
		for my $byte (0 .. $count - 1) {
			$length = ($length << 8) | ord(substr($bytes, $start + 2 + $byte, 1));
		}
		$header += $count;
	}
	die "DER span exceeds certificate\n" if $start + $header + $length > length($bytes);
	return ($start + $header, $start + $header + $length);
}
my ($child, $end) = sequence_end($der, 0);
die "trailing certificate bytes\n" unless $end == length($der);
my (undef, $tbs_end) = sequence_end($der, $child);
open my $binding, '>:raw', "$directory/private.binding-content.bin" or die $!;
print {$binding} 'native-service-db', substr($der, $child, $tbs_end - $child) or die $!;
PERL
openssl dgst -sha256 -binary -out "$output/private.binding.bin" \
	"$output/private.binding-content.bin"
perl - "$output" <<-'PERL'
use strict;
use warnings;
my ($directory) = @ARGV;
open my $input, '<:raw', "$directory/private.binding.bin" or die $!;
local $/;
my $binding = <$input>;
die "expected SHA256 binding\n" unless length($binding) == 32;
my $name = join('', map { $_ . "\0" } split //, 'Cdk2PrivateAuth2Diagnostic');
my $node = pack('H*', '269f79375917494db8da1d6fc47b85c0') .
	pack('V3', 28 + length($name) + length($binding), length($name) / 2, length($binding)) .
	$name . $binding;
open my $out, '>:raw', "$directory/private_certdb.bin" or die $!;
print {$out} pack('V', 4 + length($node)), $node or die $!;
PERL
cp "$child" "$output/child_unsigned.efi"
for signer in db rogue; do
	sbsign --key "$output/$signer.key.pem" --cert "$output/$signer.cert.pem" \
		--output "$output/child_$signer.efi" "$child"
	sbverify --cert "$output/$signer.cert.pem" "$output/child_$signer.efi"
done
printf '%s\n' 'Enrolled inputs: genuine child/db CMS and private create/append/delete; exact append attributes and independent CN+TBS certdb binding'
